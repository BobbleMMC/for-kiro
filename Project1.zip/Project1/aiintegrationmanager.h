C++
#ifndef AIINTEGRATIONMANAGER_H
#define AIINTEGRATIONMANAGER_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QString>

class AiIntegrationManager : public QObject {
    Q_OBJECT

public:
    explicit AiIntegrationManager(QObject *parent = nullptr);
    Q_INVOKABLE void requestLogicGeneration(const QString& prompt);

signals:
    void responseReceived(const QString& jsonResponse);
    void errorOccurred(const QString& errorString);

private slots:
    void onNetworkReply(QNetworkReply* reply);

private:
    QNetworkAccessManager* networkManager;
};

#endif