CREATE TABLE IF NOT EXISTS project_metadata (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    mod_id VARCHAR(64) UNIQUE NOT NULL,
    mc_version VARCHAR(20) NOT NULL,
    loader_type VARCHAR(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS registry_objects (
    id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36),
    object_type VARCHAR(50) NOT NULL,
    registry_name VARCHAR(100) NOT NULL,
    FOREIGN KEY(project_id) REFERENCES project_metadata(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS object_properties (
    id VARCHAR(36) PRIMARY KEY,
    object_id VARCHAR(36),
    property_key VARCHAR(100) NOT NULL,
    property_value TEXT NOT NULL,
    FOREIGN KEY(object_id) REFERENCES registry_objects(id) ON DELETE CASCADE
);