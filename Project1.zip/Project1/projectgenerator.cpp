C++
#include "projectgenerator.h"
#include <QDir>
#include <QFile>
#include <QTextStream>

ProjectGenerator::ProjectGenerator(QObject *parent) : QObject(parent) {}

bool ProjectGenerator::generateFileSystem(const QString& basePath, const QString& modId) {
    QDir dir(basePath);
    if (!dir.exists()) {
        dir.mkpath(".");
    }

    QStringList paths = {
        "src/main/java/com/project1/" + modId + "/registry",
        "src/main/java/com/project1/" + modId + "/core",
        "src/main/resources/META-INF",
        "src/main/resources/assets/" + modId + "/models/block",
        "src/main/resources/assets/" + modId + "/models/item",
        "src/main/resources/assets/" + modId + "/blockstates",
        "src/main/resources/assets/" + modId + "/textures/block",
        "src/main/resources/assets/" + modId + "/textures/item",
        "src/main/resources/assets/" + modId + "/lang",
        "src/main/resources/data/" + modId + "/recipes",
        "src/main/resources/data/" + modId + "/loot_tables/blocks",
        "src/main/resources/data/" + modId + "/tags/blocks",
        "src/main/resources/data/" + modId + "/tags/items"
    };

    for (const QString& path : paths) {
        if (!dir.mkpath(path)) {
            return false;
        }
    }
    return true;
}

bool ProjectGenerator::generateBuildGradle(const QString& basePath, const QString& modVersion, const QString& mcVersion) {
    QString gradleContent = "plugins {\n"
                            "    id 'eclipse'\n"
                            "    id 'maven-publish'\n"
                            "    id 'net.minecraftforge.gradle' version '5.1.+'\n"
                            "}\n\n"
                            "version = '" + modVersion + "'\n"
                            "group = 'com.project1'\n"
                            "archivesBaseName = 'project1_mod'\n\n"
                            "java.toolchain.languageVersion = JavaLanguageVersion.of(17)\n\n"
                            "minecraft {\n"
                            "    mappings channel: 'official', version: '" + mcVersion + "'\n"
                            "    runs {\n"
                            "        client {\n"
                            "            workingDirectory project.file('run')\n"
                            "            property 'forge.logging.markers', 'REGISTRIES'\n"
                            "            property 'forge.logging.console.level', 'debug'\n"
                            "            mods {\n"
                            "                project1 {\n"
                            "                    source sourceSets.main\n"
                            "                }\n"
                            "            }\n"
                            "        }\n"
                            "    }\n"
                            "}\n\n"
                            "dependencies {\n"
                            "    minecraft 'net.minecraftforge:forge:" + mcVersion + "-47.1.0'\n"
                            "}\n";

    QFile file(basePath + "/build.gradle");
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return false;
    }
    QTextStream out(&file);
    out << gradleContent;
    file.close();
    
    return true;
}

8. JsonResourceGenerator