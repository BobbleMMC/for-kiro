C++
#ifndef PROJECTGENERATOR_H
#define PROJECTGENERATOR_H

#include <QObject>
#include <QString>

class ProjectGenerator : public QObject {
    Q_OBJECT

public:
    explicit ProjectGenerator(QObject *parent = nullptr);

    Q_INVOKABLE bool generateFileSystem(const QString& basePath, const QString& modId);
    Q_INVOKABLE bool generateBuildGradle(const QString& basePath, const QString& modVersion, const QString& mcVersion);
};

#endif