C++
#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QString>
#include <QVariantList>
#include <QVariantMap>

class DatabaseManager : public QObject {
    Q_OBJECT

public:
    explicit DatabaseManager(QObject *parent = nullptr);
    ~DatabaseManager();

    Q_INVOKABLE void initializeDatabase();
    Q_INVOKABLE bool insertProject(const QString& id, const QString& name, const QString& modId, const QString& mcVersion, const QString& loaderType);
    Q_INVOKABLE QVariantList getAllProjects();

private:
    QSqlDatabase db;
};

#endif