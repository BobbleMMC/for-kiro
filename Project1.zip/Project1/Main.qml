import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

ApplicationWindow {
    visible: true
    width: 1024
    height: 768
    title: "Project 1 - Minecraft Mod Generator"

    ListModel {
        id: projectModel
    }

    Component.onCompleted: {
        loadProjects()
    }

    function loadProjects() {
        projectModel.clear()
        var projects = dbManager.getAllProjects()
        for (var i = 0; i < projects.length; i++) {
            projectModel.append(projects[i])
        }
    }

    RowLayout {
        anchors.fill: parent
        spacing: 0

        Rectangle {
            Layout.preferredWidth: 300
            Layout.fillHeight: true
            color: "#2c3e50"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 15
                spacing: 15

                Label {
                    text: "Project 1"
                    color: "white"
                    font.pixelSize: 26
                    font.bold: true
                    Layout.alignment: Qt.AlignHCenter
                }

                Button {
                    text: "Yangi Loyiha Qo'shish"
                    Layout.fillWidth: true
                    onClicked: {
                        var newId = "proj-" + Math.floor(Math.random() * 10000)
                        dbManager.insertProject(newId, "Yangi Mod", "newmod", "1.20.1", "Forge")
                        loadProjects()
                    }
                }

                ListView {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    model: projectModel
                    clip: true
                    spacing: 10

                    delegate: Rectangle {
                        width: ListView.view.width
                        height: 65
                        color: "#34495e"
                        radius: 5

                        ColumnLayout {
                            anchors.fill: parent
                            anchors.margins: 10
                            spacing: 4

                            Label {
                                text: model.name + " (" + model.mcVersion + ")"
                                color: "white"
                                font.bold: true
                                font.pixelSize: 14
                            }

                            Label {
                                text: "ID: " + model.modId + " | Loader: " + model.loaderType
                                color: "#bdc3c7"
                                font.pixelSize: 12
                            }
                        }
                    }
                }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            color: "#ecf0f1"

            BlockEditor {
                anchors.centerIn: parent
            }
        }
    }
}