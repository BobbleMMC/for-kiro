C++
#ifndef JSONRESOURCEGENERATOR_H
#define JSONRESOURCEGENERATOR_H

#include <QObject>
#include <QString>

class JsonResourceGenerator : public QObject {
    Q_OBJECT

public:
    explicit JsonResourceGenerator(QObject *parent = nullptr);

    Q_INVOKABLE bool createBlockState(const QString& basePath, const QString& modId, const QString& blockName);
    Q_INVOKABLE bool createBlockModel(const QString& basePath, const QString& modId, const QString& blockName);
    Q_INVOKABLE bool createItemModel(const QString& basePath, const QString& modId, const QString& itemName);
};

#endif