C++
#include "databasemanager.h"

DatabaseManager::DatabaseManager(QObject *parent) : QObject(parent) {}

DatabaseManager::~DatabaseManager() {
    if (db.isOpen()) {
        db.close();
    }
}

void DatabaseManager::initializeDatabase() {
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("project1_data.db");

    if (!db.open()) {
        return;
    }

    QSqlQuery query;
    query.exec("CREATE TABLE IF NOT EXISTS project_metadata (id VARCHAR(36) PRIMARY KEY, name VARCHAR(255) NOT NULL, mod_id VARCHAR(64) UNIQUE NOT NULL, mc_version VARCHAR(20) NOT NULL, loader_type VARCHAR(20) NOT NULL)");
    query.exec("CREATE TABLE IF NOT EXISTS registry_objects (id VARCHAR(36) PRIMARY KEY, project_id VARCHAR(36), object_type VARCHAR(50) NOT NULL, registry_name VARCHAR(100) NOT NULL, FOREIGN KEY(project_id) REFERENCES project_metadata(id) ON DELETE CASCADE)");
    query.exec("CREATE TABLE IF NOT EXISTS object_properties (id VARCHAR(36) PRIMARY KEY, object_id VARCHAR(36), property_key VARCHAR(100) NOT NULL, property_value TEXT NOT NULL, FOREIGN KEY(object_id) REFERENCES registry_objects(id) ON DELETE CASCADE)");
}

bool DatabaseManager::insertProject(const QString& id, const QString& name, const QString& modId, const QString& mcVersion, const QString& loaderType) {
    QSqlQuery query;
    query.prepare("INSERT INTO project_metadata (id, name, mod_id, mc_version, loader_type) VALUES (:id, :name, :mod_id, :mc_version, :loader_type)");
    query.bindValue(":id", id);
    query.bindValue(":name", name);
    query.bindValue(":mod_id", modId);
    query.bindValue(":mc_version", mcVersion);
    query.bindValue(":loader_type", loaderType);
    return query.exec();
}

QVariantList DatabaseManager::getAllProjects() {
    QVariantList list;
    QSqlQuery query("SELECT id, name, mod_id, mc_version, loader_type FROM project_metadata");
    while (query.next()) {
        QVariantMap project;
        project["id"] = query.value(0).toString();
        project["name"] = query.value(1).toString();
        project["modId"] = query.value(2).toString();
        project["mcVersion"] = query.value(3).toString();
        project["loaderType"] = query.value(4).toString();
        list.append(project);
    }
    return list;
}

5. AST Generator