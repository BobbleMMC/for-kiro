C++
#ifndef MODBUILDER_H
#define MODBUILDER_H

#include <QObject>
#include <QProcess>
#include <QString>

class ModBuilder : public QObject {
    Q_OBJECT
public:
    explicit ModBuilder(QObject *parent = nullptr);
    Q_INVOKABLE void buildMod(const QString& projectPath);
    Q_INVOKABLE void runSandbox(const QString& projectPath);

signals:
    void outputReady(const QString& text);
    void errorReady(const QString& text);
    void processFinished(int exitCode);

private:
    QProcess* process;
};

#endif