C++
#include "codebuilder.h"
#include "ast_generator.h"
#include <QFile>
#include <QTextStream>
#include <memory>

class StatementNode : public ASTNode {
    std::string stmt;
public:
    StatementNode(const std::string& s) : stmt(s) {}
    std::string generateCode(int indentLevel = 0) const override {
        return getIndent(indentLevel) + stmt + ";\n";
    }
};

CodeBuilder::CodeBuilder(QObject *parent) : QObject(parent) {}

QString CodeBuilder::buildRegistryClass(const QString& modId) {
    auto modClass = std::make_shared<ClassNode>("public", "ModItems");

    auto itemRegistry = std::make_shared<FieldNode>(
        "public static final",
        "DeferredRegister<Item>",
        "ITEMS",
        "DeferredRegister.create(ForgeRegistries.ITEMS, \"" + modId.toStdString() + "\")"
    );
    modClass->addMember(itemRegistry);

    auto registerMethod = std::make_shared<MethodNode>("public static", "void", "register");
    registerMethod->addParameter("IEventBus eventBus");
    
    auto statement = std::make_shared<StatementNode>("ITEMS.register(eventBus)");
    registerMethod->addStatement(statement);
    
    modClass->addMember(registerMethod);

    std::string finalCode = "package com.project1." + modId.toStdString() + ".registry;\n\n";
    finalCode += "import net.minecraft.world.item.Item;\n";
    finalCode += "import net.minecraftforge.eventbus.api.IEventBus;\n";
    finalCode += "import net.minecraftforge.registries.DeferredRegister;\n";
    finalCode += "import net.minecraftforge.registries.ForgeRegistries;\n\n";
    finalCode += modClass->generateCode(0);

    return QString::fromStdString(finalCode);
}

bool CodeBuilder::saveToFile(const QString& path, const QString& content) {
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return false;
    }
    QTextStream out(&file);
    out << content;
    file.close();
    return true;
}

7. ProjectGenerator