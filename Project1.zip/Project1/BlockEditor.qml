import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Item {
    width: 600
    height: 400

    ColumnLayout {
        anchors.centerIn: parent
        spacing: 15

        Label {
            text: "Yangi Blok Yaratish"
            font.pixelSize: 24
            font.bold: true
        }

        TextField {
            id: blockNameInput
            placeholderText: "Blok nomi (masalan: custom_ore)"
            Layout.fillWidth: true
        }

        TextField {
            id: hardnessInput
            placeholderText: "Qattiqligi (masalan: 3.0)"
            Layout.fillWidth: true
        }

        Button {
            text: "Saqlash va Generatsiya Qilish"
            Layout.fillWidth: true
            onClicked: {
                var bName = blockNameInput.text
                var bHardness = hardnessInput.text
                
                var newId = "block-" + Math.floor(Math.random() * 10000)
                
                dbManager.insertProject(newId, bName, "block", bHardness, "Forge")
                
                var javaCode = codeBuilder.buildRegistryClass("project1")
                
                jsonGen.createBlockState("project_path", "project1", bName)
                jsonGen.createBlockModel("project_path", "project1", bName)
                
                console.log("Blok muvaffaqiyatli yaratildi va ma'lumotlar saqlandi.")
            }
        }
    }
}