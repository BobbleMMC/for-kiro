C++
#include "aiintegrationmanager.h"
#include <QNetworkRequest>
#include <QUrl>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

AiIntegrationManager::AiIntegrationManager(QObject *parent) : QObject(parent) {
    networkManager = new QNetworkAccessManager(this);
    connect(networkManager, &QNetworkAccessManager::finished, this, &AiIntegrationManager::onNetworkReply);
}

void AiIntegrationManager::requestLogicGeneration(const QString& prompt) {
    QUrl url("http://127.0.0.1:8080/v1/chat/completions");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QJsonObject messageObject;
    messageObject["role"] = "user";
    messageObject["content"] = prompt;

    QJsonArray messagesArray;
    messagesArray.append(messageObject);

    QJsonObject requestObject;
    requestObject["model"] = "project1-cuda-model";
    requestObject["messages"] = messagesArray;

    QJsonDocument doc(requestObject);
    networkManager->post(request, doc.toJson());
}

void AiIntegrationManager::onNetworkReply(QNetworkReply* reply) {
    if (reply->error() == QNetworkReply::NoError) {
        QString response = QString(reply->readAll());
        emit responseReceived(response);
    } else {
        emit errorOccurred(reply->errorString());
    }
    reply->deleteLater();
}