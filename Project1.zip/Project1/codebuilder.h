C++
#ifndef CODEBUILDER_H
#define CODEBUILDER_H

#include <QObject>
#include <QString>

class CodeBuilder : public QObject {
    Q_OBJECT

public:
    explicit CodeBuilder(QObject *parent = nullptr);

    Q_INVOKABLE QString buildRegistryClass(const QString& modId);
    Q_INVOKABLE bool saveToFile(const QString& path, const QString& content);
};

#endif