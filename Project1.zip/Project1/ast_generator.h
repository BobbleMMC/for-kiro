C++
#ifndef AST_GENERATOR_H
#define AST_GENERATOR_H

#include <string>
#include <vector>
#include <memory>

class ASTNode {
public:
    virtual ~ASTNode() = default;
    virtual std::string generateCode(int indentLevel = 0) const = 0;
protected:
    std::string getIndent(int level) const {
        return std::string(level * 4, ' ');
    }
};

class FieldNode : public ASTNode {
    std::string modifiers;
    std::string type;
    std::string name;
    std::string initialization;
public:
    FieldNode(const std::string& mods, const std::string& t, const std::string& n, const std::string& init = "");
    std::string generateCode(int indentLevel = 0) const override;
};

class MethodNode : public ASTNode {
    std::string modifiers;
    std::string returnType;
    std::string name;
    std::vector<std::string> parameters;
    std::vector<std::shared_ptr<ASTNode>> body;
public:
    MethodNode(const std::string& mods, const std::string& ret, const std::string& n);
    void addParameter(const std::string& param);
    void addStatement(std::shared_ptr<ASTNode> statement);
    std::string generateCode(int indentLevel = 0) const override;
};

class ClassNode : public ASTNode {
    std::string modifiers;
    std::string name;
    std::string extendsClass;
    std::vector<std::shared_ptr<ASTNode>> members;
public:
    ClassNode(const std::string& mods, const std::string& n, const std::string& ext = "");
    void addMember(std::shared_ptr<ASTNode> member);
    std::string generateCode(int indentLevel = 0) const override;
};

#endif