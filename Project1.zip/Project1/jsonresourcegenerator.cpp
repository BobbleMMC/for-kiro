C++
#include "jsonresourcegenerator.h"
#include <QFile>
#include <QJsonObject>
#include <QJsonDocument>

JsonResourceGenerator::JsonResourceGenerator(QObject *parent) : QObject(parent) {}

bool JsonResourceGenerator::createBlockState(const QString& basePath, const QString& modId, const QString& blockName) {
    QJsonObject variants;
    QJsonObject normalVariant;
    normalVariant["model"] = modId + ":block/" + blockName;
    variants[""] = normalVariant;

    QJsonObject rootObject;
    rootObject["variants"] = variants;

    QJsonDocument doc(rootObject);
    QFile file(basePath + "/src/main/resources/assets/" + modId + "/blockstates/" + blockName + ".json");
    
    if (!file.open(QIODevice::WriteOnly)) {
        return false;
    }
    file.write(doc.toJson());
    file.close();
    return true;
}

bool JsonResourceGenerator::createBlockModel(const QString& basePath, const QString& modId, const QString& blockName) {
    QJsonObject textures;
    textures["all"] = modId + ":block/" + blockName;

    QJsonObject rootObject;
    rootObject["parent"] = "block/cube_all";
    rootObject["textures"] = textures;

    QJsonDocument doc(rootObject);
    QFile file(basePath + "/src/main/resources/assets/" + modId + "/models/block/" + blockName + ".json");
    
    if (!file.open(QIODevice::WriteOnly)) {
        return false;
    }
    file.write(doc.toJson());
    file.close();
    return true;
}

bool JsonResourceGenerator::createItemModel(const QString& basePath, const QString& modId, const QString& itemName) {
    QJsonObject textures;
    textures["layer0"] = modId + ":item/" + itemName;

    QJsonObject rootObject;
    rootObject["parent"] = "item/generated";
    rootObject["textures"] = textures;

    QJsonDocument doc(rootObject);
    QFile file(basePath + "/src/main/resources/assets/" + modId + "/models/item/" + itemName + ".json");
    
    if (!file.open(QIODevice::WriteOnly)) {
        return false;
    }
    file.write(doc.toJson());
    file.close();
    return true;
}

9. ModBuilder