C++
#include "ast_generator.h"

FieldNode::FieldNode(const std::string& mods, const std::string& t, const std::string& n, const std::string& init)
    : modifiers(mods), type(t), name(n), initialization(init) {}

std::string FieldNode::generateCode(int indentLevel) const {
    std::string code = getIndent(indentLevel) + modifiers + " " + type + " " + name;
    if (!initialization.empty()) {
        code += " = " + initialization;
    }
    return code + ";\n";
}

MethodNode::MethodNode(const std::string& mods, const std::string& ret, const std::string& n)
    : modifiers(mods), returnType(ret), name(n) {}

void MethodNode::addParameter(const std::string& param) {
    parameters.push_back(param);
}

void MethodNode::addStatement(std::shared_ptr<ASTNode> statement) {
    body.push_back(statement);
}

std::string MethodNode::generateCode(int indentLevel) const {
    std::string code = getIndent(indentLevel) + modifiers + " " + returnType + " " + name + "(";
    for (size_t i = 0; i < parameters.size(); ++i) {
        code += parameters[i];
        if (i < parameters.size() - 1) code += ", ";
    }
    code += ") {\n";
    for (const auto& stmt : body) {
        code += stmt->generateCode(indentLevel + 1);
    }
    code += getIndent(indentLevel) + "}\n";
    return code;
}

ClassNode::ClassNode(const std::string& mods, const std::string& n, const std::string& ext)
    : modifiers(mods), name(n), extendsClass(ext) {}

void ClassNode::addMember(std::shared_ptr<ASTNode> member) {
    members.push_back(member);
}

std::string ClassNode::generateCode(int indentLevel) const {
    std::string code = getIndent(indentLevel) + modifiers + " class " + name;
    if (!extendsClass.empty()) {
        code += " extends " + extendsClass;
    }
    code += " {\n";
    for (const auto& member : members) {
        code += member->generateCode(indentLevel + 1);
    }
    code += getIndent(indentLevel) + "}\n";
    return code;
}

6. CodeBuilder