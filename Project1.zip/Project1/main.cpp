#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "databasemanager.h"
#include "codebuilder.h"
#include "projectgenerator.h"
#include "jsonresourcegenerator.h"
#include "modbuilder.h"
#include "aiintegrationmanager.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    DatabaseManager dbManager;
    dbManager.initializeDatabase();

    CodeBuilder codeBuilder;
    ProjectGenerator projectGen;
    JsonResourceGenerator jsonGen;
    ModBuilder modBuilder;
    AiIntegrationManager aiManager;

    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("dbManager", &dbManager);
    engine.rootContext()->setContextProperty("codeBuilder", &codeBuilder);
    engine.rootContext()->setContextProperty("projectGen", &projectGen);
    engine.rootContext()->setContextProperty("jsonGen", &jsonGen);
    engine.rootContext()->setContextProperty("modBuilder", &modBuilder);
    engine.rootContext()->setContextProperty("aiManager", &aiManager);

    const QUrl url(u"qrc:/Project1/Main.qml"_qs);
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    
    engine.load(url);

    return app.exec();
}

4. DatabaseManager