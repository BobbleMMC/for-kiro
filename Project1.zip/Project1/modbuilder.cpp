C++
#include "modbuilder.h"

ModBuilder::ModBuilder(QObject *parent) : QObject(parent) {
    process = new QProcess(this);

    connect(process, &QProcess::readyReadStandardOutput, this, [this]() {
        emit outputReady(QString(process->readAllStandardOutput()));
    });

    connect(process, &QProcess::readyReadStandardError, this, [this]() {
        emit errorReady(QString(process->readAllStandardError()));
    });

    connect(process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, [this](int exitCode, QProcess::ExitStatus) {
        emit processFinished(exitCode);
    });
}

void ModBuilder::buildMod(const QString& projectPath) {
    if (process->state() != QProcess::NotRunning) {
        return;
    }
    process->setWorkingDirectory(projectPath);
    QString program = "cmd.exe";
    QStringList arguments;
    arguments << "/c" << "gradlew.bat build";
    process->start(program, arguments);
}

void ModBuilder::runSandbox(const QString& projectPath) {
    if (process->state() != QProcess::NotRunning) {
        return;
    }
    process->setWorkingDirectory(projectPath);
    QString program = "cmd.exe";
    QStringList arguments;
    arguments << "/c" << "gradlew.bat runClient";
    process->start(program, arguments);
}

10. AiIntegrationManager