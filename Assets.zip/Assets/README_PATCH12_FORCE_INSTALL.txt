PATCH 12 FORCE INSTALL HOTFIX

Bu hotfix CS0246 xatolarini tuzatadi:
- BlockDataModel not found
- ItemDataModel not found
- MinecraftCreativeTab not found
- ModValidator not found

Nega bu chiqdi?
Oldingi hotfix fayllari projectga tushmagan yoki noto'g'ri joyga extract bo'lgan. Bu paket script orqali fayllarni aniq Assets/Core/... joyiga nusxalaydi va eski duplicate papkalarni tozalaydi.

Ishlatish:
1) Unity'ni to'liq yoping.
2) Zipni Unity project root ichiga extract qiling. Project root = Assets papkasi turgan joy.
3) RUN_PATCH12_FORCE_INSTALL.bat ni ishga tushiring.
4) Unity'ni qayta oching.

Agar xato qolsa:
- Unity yopiq holda Library/ScriptAssemblies papkasini o'chiring.
- Unity'ni qayta oching.
- Console logni qayta tashlang.
