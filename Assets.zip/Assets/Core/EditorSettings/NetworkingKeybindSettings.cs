using System;
using System.Text;
using System.Collections.Generic;

public enum StudioPacketDirection
{
    ClientToServer,
    ServerToClient,
    Bidirectional
}

public enum StudioPacketFieldType
{
    Boolean,
    Byte,
    Short,
    Integer,
    Long,
    Float,
    Double,
    String,
    BlockPos,
    Vec3d,
    Identifier,
    ItemStack,
    NbtCompound,
    Uuid,
    Custom
}

public enum StudioPacketThreadMode
{
    MainThread,
    NetworkThread,
    AutoSchedule
}

public enum StudioKeybindActionType
{
    SendPacket,
    OpenScreen,
    ToggleMode,
    UseAbility,
    ExecuteCommand,
    CustomHandler
}

public enum StudioKeybindConflictContext
{
    Universal,
    InGame,
    Gui,
    Custom
}

[System.Serializable]
public class StudioPacketPayloadField
{
    public string fieldName = "blockPos";
    public StudioPacketFieldType fieldType = StudioPacketFieldType.BlockPos;
    public bool required = true;
    public string defaultValue = "";
    public string notes = "";

    public string ToDescriptorJson(int indent = 4)
    {
        string pad = new string(' ', indent);
        return pad + "{ " +
            $"\"name\": \"{Escape(fieldName)}\", " +
            $"\"type\": \"{fieldType}\", " +
            $"\"required\": {Bool(required)}, " +
            $"\"defaultValue\": \"{Escape(defaultValue)}\"" +
            " }";
    }

    public string ToJavaFieldLine()
    {
        return "    // payload field: " + fieldName + " : " + fieldType + (required ? " (required)" : " (optional)");
    }

    private static string Bool(bool v) => v ? "true" : "false";
    private static string Escape(string value) => (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"");
}

[System.Serializable]
public class NetworkPacketDataModel
{
    public bool enabled = false;
    public string packetId = "open_machine_screen";
    public string displayName = "Open Machine Screen Packet";
    public StudioPacketDirection direction = StudioPacketDirection.ClientToServer;
    public string channelNamespace = "";
    public string channelPath = "open_machine_screen";
    public string payloadFieldsCsv = "blockPos:BlockPos:true, syncId:Integer:false";
    public List<StudioPacketPayloadField> payloadFields = new List<StudioPacketPayloadField>();

    public StudioPacketThreadMode threadMode = StudioPacketThreadMode.AutoSchedule;
    public bool requiresValidation = true;
    public bool checkPlayerDistance = true;
    public bool checkChunkLoaded = true;
    public bool syncBlockEntity = false;
    public string linkedBlockId = "";
    public string linkedEntityId = "";
    public string linkedScreenId = "";
    public bool generateJavaStub = true;
    public string customPacketClass = "";
    public string customHandlerClass = "";
    public string notes = "";

    public void SyncFieldsFromCsv()
    {
        if (payloadFields == null) payloadFields = new List<StudioPacketPayloadField>();
        payloadFields.Clear();
        if (string.IsNullOrWhiteSpace(payloadFieldsCsv)) return;

        string[] entries = payloadFieldsCsv.Split(new[] { ',', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
        foreach (string raw in entries)
        {
            string[] parts = raw.Trim().Split(':');
            var field = new StudioPacketPayloadField();
            field.fieldName = parts.Length > 0 && !string.IsNullOrWhiteSpace(parts[0]) ? Sanitize(parts[0].Trim()) : "field_" + payloadFields.Count;
            if (parts.Length > 1 && Enum.TryParse(parts[1].Trim(), true, out StudioPacketFieldType t)) field.fieldType = t;
            if (parts.Length > 2 && bool.TryParse(parts[2].Trim(), out bool required)) field.required = required;
            if (parts.Length > 3) field.defaultValue = parts[3].Trim();
            payloadFields.Add(field);
        }
    }

    public string GetDescriptorPath(string modId)
    {
        return ".modstudio/networking/" + Sanitize(packetId) + ".json";
    }

    public string GenerateDescriptorJson(string modId)
    {
        SyncFieldsFromCsv();
        string ns = string.IsNullOrWhiteSpace(channelNamespace) ? modId : channelNamespace;
        string path = string.IsNullOrWhiteSpace(channelPath) ? Sanitize(packetId) : channelPath;
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine($"  \"id\": \"{Escape(modId)}:{Escape(Sanitize(packetId))}\",");
        sb.AppendLine($"  \"displayName\": \"{Escape(displayName)}\",");
        sb.AppendLine($"  \"direction\": \"{direction}\",");
        sb.AppendLine($"  \"channel\": \"{Escape(ns)}:{Escape(path)}\",");
        sb.AppendLine($"  \"threadMode\": \"{threadMode}\",");
        sb.AppendLine($"  \"requiresValidation\": {Bool(requiresValidation)},");
        sb.AppendLine($"  \"checkPlayerDistance\": {Bool(checkPlayerDistance)},");
        sb.AppendLine($"  \"checkChunkLoaded\": {Bool(checkChunkLoaded)},");
        sb.AppendLine($"  \"syncBlockEntity\": {Bool(syncBlockEntity)},");
        sb.AppendLine($"  \"linkedBlockId\": \"{Escape(linkedBlockId)}\",");
        sb.AppendLine($"  \"linkedEntityId\": \"{Escape(linkedEntityId)}\",");
        sb.AppendLine($"  \"linkedScreenId\": \"{Escape(linkedScreenId)}\",");
        sb.AppendLine("  \"payloadFields\": [");
        for (int i = 0; i < payloadFields.Count; i++)
        {
            sb.Append(payloadFields[i].ToDescriptorJson(4));
            sb.AppendLine(i < payloadFields.Count - 1 ? "," : "");
        }
        sb.AppendLine("  ],");
        sb.AppendLine($"  \"generateJavaStub\": {Bool(generateJavaStub)},");
        sb.AppendLine($"  \"customPacketClass\": \"{Escape(customPacketClass)}\",");
        sb.AppendLine($"  \"customHandlerClass\": \"{Escape(customHandlerClass)}\",");
        sb.AppendLine($"  \"notes\": \"{Escape(notes)}\"");
        sb.AppendLine("}");
        return sb.ToString();
    }

    public string GenerateJavaStub(string modId)
    {
        SyncFieldsFromCsv();
        string className = string.IsNullOrWhiteSpace(customPacketClass) ? ToPascalCase(packetId) + "Packet" : customPacketClass.Trim();
        string handlerName = string.IsNullOrWhiteSpace(customHandlerClass) ? className + "Handler" : customHandlerClass.Trim();
        string ns = string.IsNullOrWhiteSpace(channelNamespace) ? modId : channelNamespace;
        string path = string.IsNullOrWhiteSpace(channelPath) ? Sanitize(packetId) : channelPath;

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("// GENERATED STUB ONLY — verify against the selected loader/version API before moving into src/main/java.");
        sb.AppendLine($"// Packet: {packetId} | Direction: {direction} | Channel: {ns}:{path}");
        sb.AppendLine($"package net.{modId}.network;");
        sb.AppendLine();
        sb.AppendLine($"public final class {className} {{");
        sb.AppendLine($"    public static final String CHANNEL = \"{ns}:{path}\";");
        foreach (var field in payloadFields) sb.AppendLine(field.ToJavaFieldLine());
        sb.AppendLine();
        sb.AppendLine("    // TODO: implement codec/read/write using Fabric PayloadTypeRegistry or the selected loader API.");
        sb.AppendLine("}");
        sb.AppendLine();
        sb.AppendLine($"final class {handlerName} {{");
        sb.AppendLine("    // TODO: validate sender, schedule work on server/client thread, then handle payload.");
        sb.AppendLine($"    // Validation: distance={Bool(checkPlayerDistance)}, chunkLoaded={Bool(checkChunkLoaded)}, threadMode={threadMode}");
        sb.AppendLine("}");
        return sb.ToString();
    }

    public string GeneratePreview(string modId)
    {
        SyncFieldsFromCsv();
        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"Networking Packet: {packetId} ({direction})");
        sb.AppendLine(GenerateDescriptorJson(modId));
        sb.AppendLine("\n// Java Stub Preview");
        sb.AppendLine(GenerateJavaStub(modId));
        return sb.ToString();
    }

    public static string Sanitize(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "unnamed";
        value = value.Trim().ToLowerInvariant();
        StringBuilder sb = new StringBuilder();
        foreach (char c in value)
        {
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '/' || c == ':' || c == '.') sb.Append(c);
            else if (c == '-' || char.IsWhiteSpace(c)) sb.Append('_');
        }
        return sb.Length == 0 ? "unnamed" : sb.ToString();
    }

    public static string ToPascalCase(string value)
    {
        string safe = Sanitize(value).Replace('/', '_').Replace(':', '_').Replace('.', '_');
        string[] parts = safe.Split(new[] { '_' }, StringSplitOptions.RemoveEmptyEntries);
        StringBuilder sb = new StringBuilder();
        foreach (string p in parts)
        {
            if (p.Length == 0) continue;
            sb.Append(char.ToUpperInvariant(p[0]));
            if (p.Length > 1) sb.Append(p.Substring(1));
        }
        return sb.Length == 0 ? "Generated" : sb.ToString();
    }

    private static string Bool(bool v) => v ? "true" : "false";
    private static string Escape(string value) => (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
}

[System.Serializable]
public class KeybindDataModel
{
    public bool enabled = false;
    public string keybindId = "open_machine";
    public string displayName = "Open Machine";
    public string defaultKey = "key.keyboard.g";
    public string category = "key.categories.mymod";
    public StudioKeybindConflictContext conflictContext = StudioKeybindConflictContext.InGame;
    public StudioKeybindActionType actionType = StudioKeybindActionType.SendPacket;
    public string sendPacketId = "open_machine_screen";
    public string openScreenId = "";
    public string command = "";
    public int cooldownTicks = 20;
    public bool clientOnly = true;
    public bool requiresSneak = false;
    public bool requiresCreativeMode = false;
    public bool repeatWhileHeld = false;
    public bool generateJavaStub = true;
    public string customHandlerClass = "";
    public string notes = "";

    public string GetDescriptorPath(string modId)
    {
        return ".modstudio/keybinds/" + NetworkPacketDataModel.Sanitize(keybindId) + ".json";
    }

    public string GenerateDescriptorJson(string modId)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine($"  \"id\": \"{Escape(modId)}:{Escape(NetworkPacketDataModel.Sanitize(keybindId))}\",");
        sb.AppendLine($"  \"displayName\": \"{Escape(displayName)}\",");
        sb.AppendLine($"  \"defaultKey\": \"{Escape(defaultKey)}\",");
        sb.AppendLine($"  \"category\": \"{Escape(category)}\",");
        sb.AppendLine($"  \"conflictContext\": \"{conflictContext}\",");
        sb.AppendLine($"  \"actionType\": \"{actionType}\",");
        sb.AppendLine($"  \"sendPacketId\": \"{Escape(sendPacketId)}\",");
        sb.AppendLine($"  \"openScreenId\": \"{Escape(openScreenId)}\",");
        sb.AppendLine($"  \"command\": \"{Escape(command)}\",");
        sb.AppendLine($"  \"cooldownTicks\": {cooldownTicks},");
        sb.AppendLine($"  \"clientOnly\": {Bool(clientOnly)},");
        sb.AppendLine($"  \"requiresSneak\": {Bool(requiresSneak)},");
        sb.AppendLine($"  \"requiresCreativeMode\": {Bool(requiresCreativeMode)},");
        sb.AppendLine($"  \"repeatWhileHeld\": {Bool(repeatWhileHeld)},");
        sb.AppendLine($"  \"generateJavaStub\": {Bool(generateJavaStub)},");
        sb.AppendLine($"  \"customHandlerClass\": \"{Escape(customHandlerClass)}\",");
        sb.AppendLine($"  \"notes\": \"{Escape(notes)}\"");
        sb.AppendLine("}");
        return sb.ToString();
    }

    public string GenerateJavaStub(string modId)
    {
        string handler = string.IsNullOrWhiteSpace(customHandlerClass) ? NetworkPacketDataModel.ToPascalCase(keybindId) + "KeybindHandler" : customHandlerClass.Trim();
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("// GENERATED STUB ONLY — register this from the client initializer after adapting to your loader API.");
        sb.AppendLine($"package net.{modId}.client;");
        sb.AppendLine();
        sb.AppendLine($"public final class {handler} {{");
        sb.AppendLine($"    public static final String KEY_ID = \"key.{modId}.{NetworkPacketDataModel.Sanitize(keybindId)}\";");
        sb.AppendLine($"    public static final String DEFAULT_KEY = \"{Escape(defaultKey)}\";");
        sb.AppendLine($"    public static final String CATEGORY = \"{Escape(category)}\";");
        sb.AppendLine();
        sb.AppendLine("    // TODO: ClientTickEvents.END_CLIENT_TICK / KeyBindingHelper.registerKeyBinding integration.");
        sb.AppendLine($"    // Action: {actionType}, packet: {sendPacketId}, screen: {openScreenId}, command: {command}");
        sb.AppendLine($"    // Guards: sneak={Bool(requiresSneak)}, creative={Bool(requiresCreativeMode)}, cooldownTicks={cooldownTicks}, repeat={Bool(repeatWhileHeld)}");
        sb.AppendLine("}");
        return sb.ToString();
    }

    public string GeneratePreview(string modId)
    {
        return GenerateDescriptorJson(modId) + "\n// Java Stub Preview\n" + GenerateJavaStub(modId);
    }

    private static string Bool(bool v) => v ? "true" : "false";
    private static string Escape(string value) => (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
}
