using System;
using System.Collections.Generic;

public enum StudioTextureTargetType
{
    Block,
    Item,
    Entity,
    Armor,
    Gui,
    Particle,
    Effect,
    Enchantment,
    Dimension,
    Other
}

public enum StudioTextureToolType
{
    Pencil,
    Eraser,
    FillBucket,
    Line,
    Rectangle,
    FilledRectangle,
    Ellipse,
    FilledEllipse,
    Gradient,
    Noise,
    Dither,
    Shade,
    Dodge,
    CloneStamp,
    Selection,
    Move,
    ReplaceColor,
    Outline,
    Mirror,
    Rotate,
    Flip,
    PalettePicker,
    Eyedropper,
    Lighten,
    Darken,
    Saturate,
    Desaturate,
    AlphaBrush
}

public enum StudioTextureBrushShape
{
    Square,
    Circle,
    Diamond,
    HorizontalLine,
    VerticalLine
}

public enum StudioTextureBackgroundMode
{
    Checker,
    Dark,
    Light,
    Transparent,
    Custom
}

[Serializable]
public class TextureEditorToolSettings
{
    public StudioTextureTargetType targetType = StudioTextureTargetType.Item;
    public StudioTextureToolType activeTool = StudioTextureToolType.Pencil;
    public StudioTextureBrushShape brushShape = StudioTextureBrushShape.Square;
    public StudioTextureBackgroundMode backgroundMode = StudioTextureBackgroundMode.Checker;

    public string textureId = "custom_texture";
    public int canvasWidth = 16;
    public int canvasHeight = 16;
    public int zoom = 16;
    public int brushSize = 1;
    public float opacity = 1f;
    public float toolStrength = 0.15f;
    public bool alphaLock = false;
    public bool symmetryX = false;
    public bool symmetryY = false;
    public bool showGrid = true;
    public bool showCheckerboard = true;
    public bool tilePreview = true;
    public bool pixelPerfectExport = true;
    public bool layersEnabled = true;
    public bool animationEnabled = false;
    public int frameCount = 1;
    public int frameTimeTicks = 2;
    public bool generateMcmeta = false;
    public string exportPath = "textures/item/custom_texture.png";
    public string selectedPrimaryColor = "#8BC34AFF";
    public string selectedSecondaryColor = "#00000000";

    // Patch 22: workspace/export integration settings.
    public bool exportToUnityAssets = true;
    public bool exportToMinecraftResources = true;
    public bool writeTextureManifest = true;
    public bool openFolderAfterExport = false;
    public string minecraftProjectPath = string.Empty;
    public string overrideModId = string.Empty;
    public string langKey = string.Empty;
    public string displayName = "Custom Texture";

    public List<string> layers = new List<string> { "base", "shadow", "highlight" };
    public List<string> paletteColors = new List<string>
    {
        "#000000FF", "#FFFFFFFF", "#7F7F7FFF", "#FF0000FF", "#00FF00FF", "#0000FFFF", "#FFC107FF", "#8BC34AFF"
    };

    public void ClampValues()
    {
        canvasWidth = ClampPowerCanvas(canvasWidth);
        canvasHeight = ClampPowerCanvas(canvasHeight);
        zoom = Math.Max(2, Math.Min(64, zoom));
        brushSize = Math.Max(1, Math.Min(64, brushSize));
        opacity = Math.Max(0f, Math.Min(1f, opacity));
        toolStrength = Math.Max(0f, Math.Min(1f, toolStrength));
        frameCount = Math.Max(1, Math.Min(512, frameCount));
        frameTimeTicks = Math.Max(1, Math.Min(1200, frameTimeTicks));
        if (layers == null || layers.Count == 0) layers = new List<string> { "base" };
        if (paletteColors == null || paletteColors.Count == 0) paletteColors = new List<string> { "#000000FF", "#FFFFFFFF" };
        if (string.IsNullOrWhiteSpace(textureId)) textureId = "custom_texture";
        textureId = SanitizeId(textureId);
        if (string.IsNullOrWhiteSpace(exportPath)) exportPath = GetMinecraftTextureFolder() + "/" + textureId + ".png";
        exportPath = exportPath.Replace('\\', '/');
        if (string.IsNullOrWhiteSpace(displayName)) displayName = Humanize(textureId);
        if (string.IsNullOrWhiteSpace(langKey)) langKey = textureId;
    }

    public string GetMinecraftTextureFolder()
    {
        switch (targetType)
        {
            case StudioTextureTargetType.Block: return "textures/block";
            case StudioTextureTargetType.Entity: return "textures/entity";
            case StudioTextureTargetType.Armor: return "textures/models/armor";
            case StudioTextureTargetType.Gui: return "textures/gui";
            case StudioTextureTargetType.Particle: return "textures/particle";
            case StudioTextureTargetType.Effect: return "textures/mob_effect";
            case StudioTextureTargetType.Enchantment: return "textures/enchantment";
            case StudioTextureTargetType.Dimension: return "textures/environment";
            case StudioTextureTargetType.Item:
            default: return "textures/item";
        }
    }

    public void AutoUpdateExportPath()
    {
        exportPath = GetMinecraftTextureFolder() + "/" + SanitizeId(textureId) + ".png";
    }

    private static int ClampPowerCanvas(int value)
    {
        if (value <= 16) return 16;
        if (value <= 32) return 32;
        if (value <= 64) return 64;
        if (value <= 128) return 128;
        return 256;
    }

    private static string SanitizeId(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "custom_texture";
        string safe = value.Trim().ToLowerInvariant();
        string result = string.Empty;
        foreach (char c in safe)
        {
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '/') result += c;
            else if (c == ' ' || c == '.') result += "_";
        }
        result = result.Trim('_', '/', '-');
        return string.IsNullOrEmpty(result) ? "custom_texture" : result;
    }

    private static string Humanize(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) return "Custom Texture";
        string[] parts = id.Replace('-', '_').Split('_');
        for (int i = 0; i < parts.Length; i++)
        {
            if (parts[i].Length > 0) parts[i] = char.ToUpper(parts[i][0]) + (parts[i].Length > 1 ? parts[i].Substring(1) : string.Empty);
        }
        return string.Join(" ", parts);
    }
}
