using System;
using System.Text;
using System.Collections.Generic;
using System.Globalization;

public enum StudioBiomeCategory
{
    None,
    Plains,
    Forest,
    Desert,
    Taiga,
    Jungle,
    Swamp,
    Mountain,
    Ocean,
    River,
    Nether,
    End,
    Underground,
    Custom
}

public enum StudioBiomeTemperatureModifier
{
    None,
    Frozen
}

public enum StudioWorldgenFeatureKind
{
    Ore,
    Tree,
    Flower,
    Vegetation,
    Lake,
    Spring,
    Disk,
    Structure,
    CustomPlacedFeature
}

public enum StudioDimensionGeneratorType
{
    Noise,
    Flat,
    Debug,
    Custom
}

public enum StudioStructurePlacementType
{
    RandomSpread,
    ConcentricRings,
    Custom
}

[System.Serializable]
public class AdvancedBiomeClimateSettings
{
    public StudioBiomeCategory category = StudioBiomeCategory.Plains;
    public StudioBiomeTemperatureModifier temperatureModifier = StudioBiomeTemperatureModifier.None;
    public float downfall = 0.4f;
    public bool forceRain = false;
    public bool forceSnow = false;
    public string biomeTagCsv = "minecraft:is_overworld";
}

[System.Serializable]
public class AdvancedBiomeEffectsSettings
{
    public bool overrideGrassColor = true;
    public bool overrideFoliageColor = true;
    public bool overrideWaterColor = true;
    public bool overrideFogColor = true;
    public string dryFoliageColor = "#8A7038";
    public string particleId = "";
    public float particleProbability = 0.01f;
    public string musicId = "";
    public int musicMinDelay = 12000;
    public int musicMaxDelay = 24000;
    public bool replaceCurrentMusic = false;
    public string ambientLoopSound = "";
    public string moodSound = "minecraft:ambient.cave";
    public int moodTickDelay = 6000;
    public int moodBlockSearchExtent = 8;
    public float moodOffset = 2f;
    public string additionsSound = "";
    public float additionsTickChance = 0.0111f;
}

[System.Serializable]
public class AdvancedBiomeCarverSettings
{
    public bool caves = true;
    public bool canyons = false;
    public bool underwaterCaves = false;
    public string customCarversCsv = "";
}

[System.Serializable]
public class StudioOreFeatureSettings
{
    public bool enabled = false;
    public string oreBlockId = "minecraft:iron_ore";
    public string targetBlockTag = "minecraft:stone_ore_replaceables";
    public int veinSize = 8;
    public int veinsPerChunk = 20;
    public int minY = -64;
    public int maxY = 64;
    public bool triangleDistribution = true;
    public string placedFeatureId = "custom_ore";
}

[System.Serializable]
public class StudioVegetationFeatureSettings
{
    public bool customTrees = false;
    public string treeFeatureId = "minecraft:trees_plains";
    public int treeChance = 1;
    public bool customFlowers = false;
    public string flowerFeatureId = "minecraft:flower_plain";
    public bool customGrass = false;
    public string grassFeatureId = "minecraft:patch_grass_plain";
}

[System.Serializable]
public class AdvancedBiomeSpawnSettings
{
    public bool overrideDefaultSpawns = false;
    public bool spawnMonsters = true;
    public bool spawnCreatures = true;
    public bool spawnAmbient = true;
    public bool spawnWaterCreatures = false;
    public string customSpawnJson = "";
}

[System.Serializable]
public class AdvancedBiomeSettings
{
    public bool enabled = true;
    public AdvancedBiomeClimateSettings climate = new AdvancedBiomeClimateSettings();
    public AdvancedBiomeEffectsSettings effects = new AdvancedBiomeEffectsSettings();
    public AdvancedBiomeCarverSettings carvers = new AdvancedBiomeCarverSettings();
    public StudioOreFeatureSettings ore = new StudioOreFeatureSettings();
    public StudioVegetationFeatureSettings vegetation = new StudioVegetationFeatureSettings();
    public AdvancedBiomeSpawnSettings spawns = new AdvancedBiomeSpawnSettings();

    public bool generateBiomeJson = true;
    public bool generatePlacedFeatureJson = false;
    public bool generateConfiguredFeatureJson = false;
    public bool generateBiomeTag = true;
    public string notes = "";
}

[System.Serializable]
public class DimensionDataModel
{
    public bool enabled = false;
    public string dimensionId = "deep_realm";
    public string displayName = "Deep Realm";
    public StudioDimensionGeneratorType generatorType = StudioDimensionGeneratorType.Noise;
    public string biomeSourceType = "minecraft:multi_noise";
    public string fixedBiomeId = "minecraft:plains";
    public bool hasSkylight = true;
    public bool hasCeiling = false;
    public bool ultraWarm = false;
    public bool natural = true;
    public bool piglinSafe = false;
    public bool bedWorks = true;
    public bool respawnAnchorWorks = false;
    public bool hasRaids = true;
    public int minY = -64;
    public int height = 384;
    public int logicalHeight = 384;
    public float coordinateScale = 1f;
    public float ambientLight = 0f;
    public string effects = "minecraft:overworld";
    public int monsterMinLight = 0;
    public int monsterMaxLight = 7;
    public string customDimensionJson = "";
    public string customDimensionTypeJson = "";

    public string GetDimensionPath(string modId)
    {
        return $"{modId}/dimension/{dimensionId}.json";
    }

    public string GetDimensionTypePath(string modId)
    {
        return $"{modId}/dimension_type/{dimensionId}.json";
    }

    public string GenerateDimensionJson(string modId)
    {
        if (!string.IsNullOrWhiteSpace(customDimensionJson)) return customDimensionJson;
        if (generatorType == StudioDimensionGeneratorType.Flat)
        {
            return "{\n" +
                   "  \"type\": \"" + modId + ":" + dimensionId + "\",\n" +
                   "  \"generator\": {\n" +
                   "    \"type\": \"minecraft:flat\",\n" +
                   "    \"settings\": {}\n" +
                   "  }\n" +
                   "}";
        }

        return "{\n" +
               "  \"type\": \"" + modId + ":" + dimensionId + "\",\n" +
               "  \"generator\": {\n" +
               "    \"type\": \"minecraft:noise\",\n" +
               "    \"settings\": \"minecraft:overworld\",\n" +
               "    \"biome_source\": {\n" +
               "      \"type\": \"minecraft:fixed\",\n" +
               "      \"biome\": \"" + fixedBiomeId + "\"\n" +
               "    }\n" +
               "  }\n" +
               "}";
    }

    public string GenerateDimensionTypeJson()
    {
        if (!string.IsNullOrWhiteSpace(customDimensionTypeJson)) return customDimensionTypeJson;
        return "{\n" +
               "  \"ultrawarm\": " + Bool(ultraWarm) + ",\n" +
               "  \"natural\": " + Bool(natural) + ",\n" +
               "  \"piglin_safe\": " + Bool(piglinSafe) + ",\n" +
               "  \"respawn_anchor_works\": " + Bool(respawnAnchorWorks) + ",\n" +
               "  \"bed_works\": " + Bool(bedWorks) + ",\n" +
               "  \"has_raids\": " + Bool(hasRaids) + ",\n" +
               "  \"has_skylight\": " + Bool(hasSkylight) + ",\n" +
               "  \"has_ceiling\": " + Bool(hasCeiling) + ",\n" +
               "  \"coordinate_scale\": " + F(coordinateScale) + ",\n" +
               "  \"ambient_light\": " + F(ambientLight) + ",\n" +
               "  \"min_y\": " + minY + ",\n" +
               "  \"height\": " + height + ",\n" +
               "  \"logical_height\": " + logicalHeight + ",\n" +
               "  \"infiniburn\": \"#minecraft:infiniburn_overworld\",\n" +
               "  \"effects\": \"" + effects + "\",\n" +
               "  \"monster_spawn_light_level\": {\n" +
               "    \"type\": \"minecraft:uniform\",\n" +
               "    \"value\": { \"min_inclusive\": " + monsterMinLight + ", \"max_inclusive\": " + monsterMaxLight + " }\n" +
               "  },\n" +
               "  \"monster_spawn_block_light_limit\": " + monsterMaxLight + "\n" +
               "}";
    }

    private static string Bool(bool value) { return value ? "true" : "false"; }
    private static string F(float value) { return value.ToString("0.###", CultureInfo.InvariantCulture); }
}

[System.Serializable]
public class StructureDataModel
{
    public bool enabled = false;
    public string structureId = "deep_ruins";
    public string displayName = "Deep Ruins";
    public string structureType = "minecraft:jigsaw";
    public string startPool = "mymod:deep_ruins/start_pool";
    public int size = 5;
    public int maxDistanceFromCenter = 80;
    public string biomes = "#minecraft:is_overworld";
    public string terrainAdaptation = "beard_thin";
    public StudioStructurePlacementType placementType = StudioStructurePlacementType.RandomSpread;
    public int spacing = 32;
    public int separation = 8;
    public int salt = 14357617;
    public string heightmap = "WORLD_SURFACE_WG";
    public string customStructureJson = "";
    public string customStructureSetJson = "";

    public string GetStructurePath(string modId)
    {
        return $"{modId}/worldgen/structure/{structureId}.json";
    }

    public string GetStructureSetPath(string modId)
    {
        return $"{modId}/worldgen/structure_set/{structureId}.json";
    }

    public string GenerateStructureJson(string modId)
    {
        if (!string.IsNullOrWhiteSpace(customStructureJson)) return customStructureJson;
        return "{\n" +
               "  \"type\": \"" + structureType + "\",\n" +
               "  \"biomes\": \"" + biomes + "\",\n" +
               "  \"spawn_overrides\": {},\n" +
               "  \"step\": \"surface_structures\",\n" +
               "  \"terrain_adaptation\": \"" + terrainAdaptation + "\",\n" +
               "  \"start_pool\": \"" + startPool.Replace("mymod:", modId + ":") + "\",\n" +
               "  \"size\": " + size + ",\n" +
               "  \"max_distance_from_center\": " + maxDistanceFromCenter + ",\n" +
               "  \"start_height\": { \"absolute\": 0 },\n" +
               "  \"project_start_to_heightmap\": \"" + heightmap + "\",\n" +
               "  \"use_expansion_hack\": false\n" +
               "}";
    }

    public string GenerateStructureSetJson(string modId)
    {
        if (!string.IsNullOrWhiteSpace(customStructureSetJson)) return customStructureSetJson;
        return "{\n" +
               "  \"structures\": [ { \"structure\": \"" + modId + ":" + structureId + "\", \"weight\": 1 } ],\n" +
               "  \"placement\": {\n" +
               "    \"type\": \"minecraft:random_spread\",\n" +
               "    \"spacing\": " + spacing + ",\n" +
               "    \"separation\": " + separation + ",\n" +
               "    \"salt\": " + salt + "\n" +
               "  }\n" +
               "}";
    }
}
