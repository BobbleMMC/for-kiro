using System;
using System.Collections.Generic;
using System.Text;

[System.Serializable]
public class AdvancementCriterionSettings
{
    public string criterionId = "has_item";
    public string trigger = "minecraft:inventory_changed";
    public string item = "minecraft:diamond";
}

[System.Serializable]
public class AdvancementDataModel
{
    public bool enabled = true;
    public string advancementId = "first_step";
    public string displayName = "First Step";
    public string description = "Complete your first custom advancement.";
    public string iconItem = "minecraft:diamond";
    public string frameType = "task";
    public string parent = "";
    public bool showToast = true;
    public bool announceToChat = true;
    public bool hidden = false;
    public string criteriaCsv = "has_item:minecraft:inventory_changed:minecraft:diamond";
    public int rewardExperience = 0;
    public string rewardLootTablesCsv = "";
    public string rewardRecipesCsv = "";
    public string customJsonOverride = "";
    public string notes = "";

    public List<AdvancementCriterionSettings> criteria = new List<AdvancementCriterionSettings>();

    public void SyncCriteriaFromCsv()
    {
        if (criteria == null) criteria = new List<AdvancementCriterionSettings>();
        criteria.Clear();
        if (string.IsNullOrWhiteSpace(criteriaCsv)) return;

        string[] rows = criteriaCsv.Split(new[] { ',', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < rows.Length; i++)
        {
            string[] parts = rows[i].Trim().Split(':');
            var c = new AdvancementCriterionSettings();
            c.criterionId = parts.Length > 0 && !string.IsNullOrWhiteSpace(parts[0]) ? parts[0].Trim() : "criterion_" + i;
            c.trigger = parts.Length > 1 && !string.IsNullOrWhiteSpace(parts[1]) ? parts[1].Trim() : "minecraft:inventory_changed";
            if (parts.Length > 2) c.item = parts[2].Trim();
            if (!string.IsNullOrWhiteSpace(c.criterionId)) criteria.Add(c);
        }
    }

    public string GenerateJson(string modId)
    {
        if (!string.IsNullOrWhiteSpace(customJsonOverride)) return customJsonOverride;
        SyncCriteriaFromCsv();
        string id = Sanitize(advancementId, "first_step");
        var sb = new StringBuilder();
        sb.AppendLine("{");
        if (!string.IsNullOrWhiteSpace(parent)) sb.AppendLine("  \"parent\": \"" + Escape(parent.Trim()) + "\",");
        sb.AppendLine("  \"display\": {");
        sb.AppendLine("    \"icon\": { \"item\": \"" + Escape(iconItem) + "\" },");
        sb.AppendLine("    \"title\": { \"translate\": \"advancement." + Escape(modId) + "." + Escape(id) + ".title\" },");
        sb.AppendLine("    \"description\": { \"translate\": \"advancement." + Escape(modId) + "." + Escape(id) + ".description\" },");
        sb.AppendLine("    \"frame\": \"" + Escape(string.IsNullOrWhiteSpace(frameType) ? "task" : frameType.ToLowerInvariant()) + "\",");
        sb.AppendLine("    \"show_toast\": " + Bool(showToast) + ",");
        sb.AppendLine("    \"announce_to_chat\": " + Bool(announceToChat) + ",");
        sb.AppendLine("    \"hidden\": " + Bool(hidden));
        sb.AppendLine("  },");
        sb.AppendLine("  \"criteria\": {");
        if (criteria.Count == 0) criteria.Add(new AdvancementCriterionSettings());
        for (int i = 0; i < criteria.Count; i++)
        {
            AdvancementCriterionSettings c = criteria[i];
            sb.AppendLine("    \"" + Escape(Sanitize(c.criterionId, "criterion_" + i)) + "\": {");
            sb.AppendLine("      \"trigger\": \"" + Escape(string.IsNullOrWhiteSpace(c.trigger) ? "minecraft:inventory_changed" : c.trigger) + "\"");
            sb.Append("    }");
            sb.AppendLine(i < criteria.Count - 1 ? "," : "");
        }
        sb.AppendLine("  },");
        sb.AppendLine("  \"rewards\": {");
        sb.AppendLine("    \"experience\": " + rewardExperience + ",");
        sb.AppendLine("    \"loot\": " + StringArray(rewardLootTablesCsv) + ",");
        sb.AppendLine("    \"recipes\": " + StringArray(rewardRecipesCsv));
        sb.AppendLine("  }");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string StringArray(string csv)
    {
        if (string.IsNullOrWhiteSpace(csv)) return "[]";
        string[] parts = csv.Split(new[] { ',', '\n', '\r', ';' }, StringSplitOptions.RemoveEmptyEntries);
        var sb = new StringBuilder();
        sb.Append("[");
        for (int i = 0; i < parts.Length; i++)
        {
            if (i > 0) sb.Append(", ");
            sb.Append("\"").Append(Escape(parts[i].Trim())).Append("\"");
        }
        sb.Append("]");
        return sb.ToString();
    }

    private static string Sanitize(string value, string fallback)
    {
        if (string.IsNullOrWhiteSpace(value)) return fallback;
        return value.Trim().ToLowerInvariant().Replace(" ", "_").Replace("-", "_");
    }

    private static string Escape(string value)
    {
        return (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
    }

    private static string Bool(bool value) { return value ? "true" : "false"; }
}

[System.Serializable]
public class FunctionDataModel
{
    public bool enabled = true;
    public string functionId = "init";
    public string namespaceId = "";
    public string functionType = "normal";
    public string commandsText = "say Hello from Mod Studio";
    public bool addToLoadTag = false;
    public bool addToTickTag = false;
    public int permissionLevel = 2;
    public string notes = "";

    public string GenerateMcFunction()
    {
        if (string.IsNullOrWhiteSpace(commandsText)) return "# Generated by Mod Studio\n";
        return commandsText.Replace("\r\n", "\n").Replace("\r", "\n").TrimEnd() + "\n";
    }

    public string GenerateDescriptorJson(string modId)
    {
        string ns = string.IsNullOrWhiteSpace(namespaceId) ? modId : namespaceId;
        string id = string.IsNullOrWhiteSpace(functionId) ? "init" : functionId;
        return "{\n" +
            "  \"id\": \"" + Escape(ns) + ":" + Escape(id) + "\",\n" +
            "  \"type\": \"" + Escape(functionType) + "\",\n" +
            "  \"addToLoadTag\": " + Bool(addToLoadTag) + ",\n" +
            "  \"addToTickTag\": " + Bool(addToTickTag) + ",\n" +
            "  \"permissionLevel\": " + permissionLevel + "\n" +
            "}\n";
    }

    private static string Escape(string value)
    {
        return (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
    }

    private static string Bool(bool value) { return value ? "true" : "false"; }
}
