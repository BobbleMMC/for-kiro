using System;
using System.Collections.Generic;
using System.Text;

public enum StudioEntityRendererType
{
    Vanilla,
    CustomModel,
    GeckoLib,
    BlockbenchJson,
    CustomRenderer
}

public enum StudioEntityDimensionPreset
{
    Overworld,
    Nether,
    End,
    All,
    Custom
}

public enum StudioEntitySpawnPlacement
{
    OnGround,
    InWater,
    NoRestrictions,
    InLava,
    OnCeiling
}

[Serializable]
public class EntityAdvancedAttributeSettings
{
    public float armorToughness = 0f;
    public float attackKnockback = 0f;
    public float flyingSpeed = 0.4f;
    public float stepHeight = 0.6f;
    public float gravity = 0.08f;
    public float scale = 1.0f;
    public bool hasGravity = true;
}

[Serializable]
public class EntityAiGoalSettings
{
    public bool enabled = true;
    public string goalsCsv = "SwimGoal, MeleeAttack, WanderAround, LookAtPlayer, TargetNearestPlayer, HurtByTarget";
    public string targetGoalsCsv = "TargetNearestPlayer, HurtByTarget";
    public bool canOpenDoors = false;
    public bool canBreakDoors = false;
    public bool avoidsWater = false;
    public bool attacksPlayers = true;
    public bool attacksVillagers = false;
    public bool panicWhenHurt = false;
    public string temptItemId = "minecraft:wheat";
    public string avoidEntityId = "minecraft:wolf";
    public string customGoalsCode = "";

    public void SyncToEntity(EntityDataModel entity)
    {
        if (entity == null) return;
        if (!enabled) return;

        List<AIGoalType> parsed = ParseGoals(goalsCsv);
        if (parsed.Count > 0)
            entity.aiGoals = parsed;
    }

    public static List<AIGoalType> ParseGoals(string csv)
    {
        var goals = new List<AIGoalType>();
        if (string.IsNullOrWhiteSpace(csv)) return goals;

        string[] parts = csv.Split(new[] { ',', '\n', ';' }, StringSplitOptions.RemoveEmptyEntries);
        foreach (string raw in parts)
        {
            string value = raw.Trim();
            if (string.IsNullOrEmpty(value)) continue;

            if (Enum.TryParse(value, true, out AIGoalType goal))
            {
                if (!goals.Contains(goal)) goals.Add(goal);
            }
        }
        return goals;
    }
}

[Serializable]
public class EntitySpawnAdvancedSettings
{
    public bool naturalSpawn = true;
    public bool spawnEgg = true;
    public StudioEntityDimensionPreset dimension = StudioEntityDimensionPreset.Overworld;
    public string customDimensionId = "minecraft:overworld";
    public string biomeSelector = "overworld";
    public string biomeTagsCsv = "minecraft:is_overworld";
    public StudioEntitySpawnPlacement placement = StudioEntitySpawnPlacement.OnGround;
    public int spawnWeight = 80;
    public int minGroup = 1;
    public int maxGroup = 3;
    public int minY = 0;
    public int maxY = 256;
    public int minLight = 0;
    public int maxLight = 15;
    public bool requiresDarkness = false;
    public bool onlyOnGrass = false;
    public bool despawnsNaturally = true;

    public void SyncToEntity(EntityDataModel entity)
    {
        if (entity == null) return;
        if (entity.spawnRule == null) entity.spawnRule = new EntitySpawnRule();

        entity.spawnRule.naturalSpawn = naturalSpawn;
        entity.spawnRule.spawnEgg = spawnEgg;
        entity.spawnRule.spawnWeight = spawnWeight;
        entity.spawnRule.minGroup = minGroup;
        entity.spawnRule.maxGroup = maxGroup;
        entity.spawnRule.minY = minY;
        entity.spawnRule.maxY = maxY;
        entity.spawnRule.requiresDarkness = requiresDarkness;
        entity.spawnRule.onlyOnGrass = onlyOnGrass;
    }
}

[Serializable]
public class EntityVisualAdvancedSettings
{
    public StudioEntityRendererType rendererType = StudioEntityRendererType.Vanilla;
    public string texturePath = "";
    public string modelPath = "";
    public string animationJsonPath = "";
    public string customRendererClass = "";
    public float shadowRadius = 0.5f;
    public bool hasBabyVariant = false;
    public bool variantTextures = false;
    public string variantTextureCsv = "";
    public string spawnEggPrimaryHex = "7A0000";
    public string spawnEggSecondaryHex = "FF0000";
    public bool emissiveLayer = false;
    public string notes = "";
}

[Serializable]
public class EntityBehaviorAdvancedSettings
{
    public bool fireImmune = false;
    public bool saveable = true;
    public bool summonable = true;
    public bool persistent = false;
    public bool canPickUpLoot = false;
    public bool noGravity = false;
    public bool bossBar = false;
    public bool tameable = false;
    public string tameItemId = "minecraft:bone";
    public string ambientSound = "";
    public string hurtSound = "";
    public string deathSound = "";
    public string stepSound = "";
    public string customTickCode = "";
}

[Serializable]
public class AdvancedEntitySettings
{
    public EntityAdvancedAttributeSettings attributes = new EntityAdvancedAttributeSettings();
    public EntityAiGoalSettings ai = new EntityAiGoalSettings();
    public EntitySpawnAdvancedSettings spawn = new EntitySpawnAdvancedSettings();
    public EntityVisualAdvancedSettings visual = new EntityVisualAdvancedSettings();
    public EntityBehaviorAdvancedSettings behavior = new EntityBehaviorAdvancedSettings();

    public void EnsureDefaults(EntityDataModel entity)
    {
        if (attributes == null) attributes = new EntityAdvancedAttributeSettings();
        if (ai == null) ai = new EntityAiGoalSettings();
        if (spawn == null) spawn = new EntitySpawnAdvancedSettings();
        if (visual == null) visual = new EntityVisualAdvancedSettings();
        if (behavior == null) behavior = new EntityBehaviorAdvancedSettings();

        if (entity != null)
        {
            if (string.IsNullOrWhiteSpace(ai.goalsCsv) && entity.aiGoals != null && entity.aiGoals.Count > 0)
                ai.goalsCsv = string.Join(", ", entity.aiGoals);

            if (entity.spawnRule != null)
            {
                spawn.naturalSpawn = entity.spawnRule.naturalSpawn;
                spawn.spawnEgg = entity.spawnRule.spawnEgg;
                spawn.spawnWeight = entity.spawnRule.spawnWeight;
                spawn.minGroup = entity.spawnRule.minGroup;
                spawn.maxGroup = entity.spawnRule.maxGroup;
                spawn.minY = entity.spawnRule.minY;
                spawn.maxY = entity.spawnRule.maxY;
                spawn.requiresDarkness = entity.spawnRule.requiresDarkness;
                spawn.onlyOnGrass = entity.spawnRule.onlyOnGrass;
            }
        }
    }

    public void ApplyToEntity(EntityDataModel entity)
    {
        if (entity == null) return;
        EnsureDefaults(entity);
        ai.SyncToEntity(entity);
        spawn.SyncToEntity(entity);
    }

    public string GenerateSummary()
    {
        EnsureDefaults(null);
        var sb = new StringBuilder();
        sb.AppendLine($"Renderer: {visual.rendererType}");
        sb.AppendLine($"AI: {(ai.enabled ? ai.goalsCsv : "disabled")}");
        sb.AppendLine($"Spawn: {(spawn.naturalSpawn ? "natural" : "manual only")}, weight={spawn.spawnWeight}, group={spawn.minGroup}-{spawn.maxGroup}");
        sb.AppendLine($"Behavior: fireImmune={behavior.fireImmune}, persistent={behavior.persistent}, bossBar={behavior.bossBar}");
        return sb.ToString();
    }
}
