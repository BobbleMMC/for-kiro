using System;

public enum StudioBlockSoundGroup
{
    Stone,
    Wood,
    Metal,
    Glass,
    Grass,
    Gravel,
    Sand,
    Wool,
    Amethyst,
    Copper,
    Custom
}

public enum StudioBlockRenderLayer
{
    Solid,
    Cutout,
    CutoutMipped,
    Translucent
}

public enum StudioBlockShapeMode
{
    FullCube,
    NoCollision,
    Slab,
    Stairs,
    Fence,
    Pane,
    CustomVoxel
}

public enum StudioBlockStatePreset
{
    None,
    Facing,
    Axis,
    Lit,
    Powered,
    Open,
    Waterlogged,
    Age,
    Level,
    Half,
    Custom
}

[System.Serializable]
public class BlockVisualSettings
{
    public StudioBlockRenderLayer renderLayer = StudioBlockRenderLayer.Solid;
    public bool opaque = true;
    public bool transparent = false;
    public bool ambientOcclusion = true;
    public bool emissiveTexture = false;
    public string tintHex = "#FFFFFF";
    public string topTexture = "";
    public string bottomTexture = "";
    public string sideTexture = "";
    public string customModelJsonPath = "";
}

[System.Serializable]
public class BlockBehaviorSettings
{
    public bool requiresTool = false;
    public string requiredToolTag = "mineable/pickaxe";
    public int miningLevel = 0;
    public bool flammable = false;
    public int burnChance = 0;
    public int spreadChance = 0;
    public bool randomTicks = false;
    public bool gravity = false;
    public bool redstoneOutput = false;
    public int redstonePower = 0;
    public bool waterloggable = false;
}

[System.Serializable]
public class BlockCollisionSettings
{
    public StudioBlockShapeMode shapeMode = StudioBlockShapeMode.FullCube;
    public bool fullCube = true;
    public bool noCollision = false;
    public bool customOutlineShape = false;
    public string voxelShape = "0,0,0,16,16,16";
    public bool pathfindThrough = false;
}

[System.Serializable]
public class BlockStateSettings
{
    public bool enabled = false;
    public StudioBlockStatePreset preset = StudioBlockStatePreset.None;
    public bool facing = false;
    public bool axis = false;
    public bool lit = false;
    public bool powered = false;
    public bool open = false;
    public bool waterlogged = false;
    public string customStates = ""; // format: name:type:values, e.g. charge:int:0-4
}

[System.Serializable]
public class BlockEntitySettings
{
    public bool enabled = false;
    public bool hasInventory = false;
    public int inventorySlots = 9;
    public bool hasTicker = false;
    public bool hasScreen = false;
    public bool syncToClient = false;
    public string customDataFields = "";
}

[System.Serializable]
public class AdvancedBlockSettings
{
    public StudioBlockSoundGroup soundGroup = StudioBlockSoundGroup.Stone;
    public int mapColor = 0;

    public BlockVisualSettings visual = new BlockVisualSettings();
    public BlockBehaviorSettings behavior = new BlockBehaviorSettings();
    public BlockCollisionSettings collision = new BlockCollisionSettings();
    public BlockStateSettings states = new BlockStateSettings();
    public BlockEntitySettings blockEntity = new BlockEntitySettings();

    public void NormalizeLegacy(BlockDataModel block)
    {
        if (block == null) return;
        if (visual == null) visual = new BlockVisualSettings();
        if (behavior == null) behavior = new BlockBehaviorSettings();
        if (collision == null) collision = new BlockCollisionSettings();
        if (states == null) states = new BlockStateSettings();
        if (blockEntity == null) blockEntity = new BlockEntitySettings();

        if (string.IsNullOrEmpty(visual.sideTexture)) visual.sideTexture = block.texturePath;
    }
}
