using System;

public enum StudioItemRarity
{
    Common,
    Uncommon,
    Rare,
    Epic
}

public enum StudioItemUseAction
{
    None,
    Eat,
    Drink,
    Bow,
    Spear,
    Block,
    Brush,
    Custom
}

public enum StudioItemModelType
{
    Generated,
    Handheld,
    Custom
}

[System.Serializable]
public class FoodItemSettings
{
    public bool enabled = false;
    public int nutrition = 4;
    public float saturation = 0.3f;
    public bool alwaysEdible = false;
    public bool fastEating = false;
    public bool canEatWhenFull = false;
    public string afterEatReturnItem = "";
    public string statusEffects = ""; // format: effect_id:duration:amplifier:chance, comma separated
}

[System.Serializable]
public class ItemBehaviorSettings
{
    public StudioItemUseAction useAction = StudioItemUseAction.None;
    public int useDuration = 32;
    public int cooldownTicks = 0;
    public bool hasRightClickAction = false;
    public bool hasInventoryTick = false;
    public bool hasCraftRemainder = false;
    public string craftRemainderItem = "";
    public string tooltipLines = ""; // one tooltip per line
}

[System.Serializable]
public class ItemVisualSettings
{
    public StudioItemModelType modelType = StudioItemModelType.Generated;
    public string texturePath = "";
    public string customModelJsonPath = "";
    public bool animatedTexture = false;
    public bool hasGlint = false;
    public string tintHex = "#FFFFFF";
}

[System.Serializable]
public class ItemDataComponentSettings
{
    public bool enableDataComponents = true;
    public bool customName = false;
    public bool lore = false;
    public bool enchantable = true;
    public bool repairable = false;
    public bool attributeModifiers = false;
    public string customDataJson = "";
}

[System.Serializable]
public class AdvancedItemSettings
{
    public StudioItemRarity rarity = StudioItemRarity.Common;
    public bool fireproof = false;
    public bool enchantable = true;
    public int enchantability = 10;
    public int maxDamage = 0;
    public string repairItemId = "";

    public FoodItemSettings food = new FoodItemSettings();
    public ItemBehaviorSettings behavior = new ItemBehaviorSettings();
    public ItemVisualSettings visual = new ItemVisualSettings();
    public ItemDataComponentSettings components = new ItemDataComponentSettings();

    public void NormalizeLegacy(ItemDataModel item)
    {
        if (item == null) return;
        if (food == null) food = new FoodItemSettings();
        if (behavior == null) behavior = new ItemBehaviorSettings();
        if (visual == null) visual = new ItemVisualSettings();
        if (components == null) components = new ItemDataComponentSettings();

        food.enabled = item.isFood || food.enabled;
        if (string.IsNullOrEmpty(visual.texturePath)) visual.texturePath = item.itemId;
    }
}
