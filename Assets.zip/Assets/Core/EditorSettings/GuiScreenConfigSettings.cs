using System;
using System.Text;
using System.Collections.Generic;

public enum StudioScreenType
{
    SimpleInfo,
    BlockEntityContainer,
    EntityScreen,
    ItemScreen,
    ConfigScreen,
    Custom
}

public enum StudioSlotKind
{
    Input,
    Output,
    Fuel,
    Upgrade,
    Filter,
    Custom
}

public enum StudioConfigFormat
{
    Json,
    Toml,
    Properties
}

public enum StudioConfigScope
{
    Common,
    Client,
    Server
}

public enum StudioConfigEntryType
{
    Boolean,
    Integer,
    Float,
    String,
    Enum,
    ResourceLocation
}

[System.Serializable]
public class StudioGuiSlotSettings
{
    public string slotId = "input_0";
    public StudioSlotKind kind = StudioSlotKind.Input;
    public int x = 56;
    public int y = 35;
    public int index = 0;
    public string allowedItemTag = "";
    public int maxStackSize = 64;

    public string GeneratePreview()
    {
        return $"slot {index}: {slotId} ({kind}) x={x}, y={y}, max={maxStackSize}";
    }
}

[System.Serializable]
public class StudioConfigEntrySettings
{
    public string key = "enabled";
    public string displayName = "Enabled";
    public StudioConfigEntryType type = StudioConfigEntryType.Boolean;
    public string defaultValue = "true";
    public string minValue = "";
    public string maxValue = "";
    public string enumValuesCsv = "";
    public string comment = "";
    public bool restartRequired = false;

    public string ToJsonLine()
    {
        string value = defaultValue;
        if (type == StudioConfigEntryType.Boolean)
            value = value.ToLowerInvariant() == "true" ? "true" : "false";
        else if (type == StudioConfigEntryType.Integer || type == StudioConfigEntryType.Float)
            value = string.IsNullOrWhiteSpace(value) ? "0" : value;
        else
            value = "\"" + Escape(value) + "\"";
        return "  \"" + Escape(key) + "\": " + value;
    }

    public string ToTomlLine()
    {
        string value = defaultValue;
        if (type == StudioConfigEntryType.Boolean)
            value = value.ToLowerInvariant() == "true" ? "true" : "false";
        else if (type == StudioConfigEntryType.Integer || type == StudioConfigEntryType.Float)
            value = string.IsNullOrWhiteSpace(value) ? "0" : value;
        else
            value = "\"" + Escape(value) + "\"";
        return key + " = " + value;
    }

    public string ToPropertiesLine()
    {
        return key + "=" + defaultValue;
    }

    private static string Escape(string value)
    {
        return (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"");
    }
}

[System.Serializable]
public class ScreenDataModel
{
    public bool enabled = false;
    public string screenId = "custom_machine_screen";
    public string displayName = "Custom Machine Screen";
    public StudioScreenType screenType = StudioScreenType.BlockEntityContainer;
    public string linkedBlockId = "";
    public string linkedEntityId = "";
    public string linkedItemId = "";

    public int width = 176;
    public int height = 166;
    public string titleTranslationKey = "";
    public string backgroundTexture = "textures/gui/custom_machine.png";

    public bool showPlayerInventory = true;
    public int playerInventoryX = 8;
    public int playerInventoryY = 84;
    public int hotbarX = 8;
    public int hotbarY = 142;

    public int containerSlots = 3;
    public string slotsCsv = "input_0:Input:56:35, fuel_0:Fuel:56:53, output_0:Output:116:35";
    public List<StudioGuiSlotSettings> slots = new List<StudioGuiSlotSettings>();

    public bool hasProgressBar = false;
    public int progressX = 80;
    public int progressY = 35;
    public int progressWidth = 24;
    public int progressHeight = 17;

    public bool hasEnergyBar = false;
    public int energyX = 152;
    public int energyY = 14;
    public int energyWidth = 16;
    public int energyHeight = 54;

    public bool hasFluidBar = false;
    public int fluidX = 10;
    public int fluidY = 15;
    public int fluidWidth = 16;
    public int fluidHeight = 52;

    public string labelsCsv = "";
    public string buttonsCsv = "";
    public bool syncProperties = true;
    public bool openOnRightClick = true;
    public bool generateJavaStubs = true;
    public string customScreenClass = "";
    public string customMenuClass = "";
    public string customPacketNotes = "";
    public string notes = "";

    public void SyncSlotsFromCsv()
    {
        if (slots == null) slots = new List<StudioGuiSlotSettings>();
        slots.Clear();
        if (string.IsNullOrWhiteSpace(slotsCsv)) return;

        string[] parts = slotsCsv.Split(new[] { ',', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
        int index = 0;
        foreach (string raw in parts)
        {
            string[] bits = raw.Trim().Split(':');
            var slot = new StudioGuiSlotSettings();
            slot.slotId = bits.Length > 0 && !string.IsNullOrWhiteSpace(bits[0]) ? bits[0].Trim() : "slot_" + index;
            if (bits.Length > 1 && Enum.TryParse(bits[1].Trim(), true, out StudioSlotKind kind)) slot.kind = kind;
            if (bits.Length > 2 && int.TryParse(bits[2].Trim(), out int x)) slot.x = x;
            if (bits.Length > 3 && int.TryParse(bits[3].Trim(), out int y)) slot.y = y;
            slot.index = index;
            slots.Add(slot);
            index++;
        }
        containerSlots = Math.Max(containerSlots, slots.Count);
    }

    public string GetDescriptorPath(string modId)
    {
        return ".modstudio/gui/" + Sanitize(screenId) + ".json";
    }

    public string GenerateDescriptorJson(string modId)
    {
        SyncSlotsFromCsv();
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine($"  \"id\": \"{Escape(modId)}:{Escape(Sanitize(screenId))}\",");
        sb.AppendLine($"  \"displayName\": \"{Escape(displayName)}\",");
        sb.AppendLine($"  \"screenType\": \"{screenType}\",");
        sb.AppendLine($"  \"linkedBlockId\": \"{Escape(linkedBlockId)}\",");
        sb.AppendLine($"  \"linkedEntityId\": \"{Escape(linkedEntityId)}\",");
        sb.AppendLine($"  \"linkedItemId\": \"{Escape(linkedItemId)}\",");
        sb.AppendLine($"  \"width\": {width},");
        sb.AppendLine($"  \"height\": {height},");
        sb.AppendLine($"  \"backgroundTexture\": \"{Escape(backgroundTexture)}\",");
        sb.AppendLine($"  \"showPlayerInventory\": {Bool(showPlayerInventory)},");
        sb.AppendLine($"  \"syncProperties\": {Bool(syncProperties)},");
        sb.AppendLine("  \"slots\": [");
        for (int i = 0; i < slots.Count; i++)
        {
            var s = slots[i];
            sb.Append("    { ");
            sb.Append($"\"id\": \"{Escape(s.slotId)}\", \"kind\": \"{s.kind}\", \"x\": {s.x}, \"y\": {s.y}, \"index\": {s.index}, \"maxStackSize\": {s.maxStackSize}");
            sb.Append(" }");
            sb.AppendLine(i < slots.Count - 1 ? "," : "");
        }
        sb.AppendLine("  ],");
        sb.AppendLine($"  \"progressBar\": {{ \"enabled\": {Bool(hasProgressBar)}, \"x\": {progressX}, \"y\": {progressY}, \"width\": {progressWidth}, \"height\": {progressHeight} }},");
        sb.AppendLine($"  \"energyBar\": {{ \"enabled\": {Bool(hasEnergyBar)}, \"x\": {energyX}, \"y\": {energyY}, \"width\": {energyWidth}, \"height\": {energyHeight} }},");
        sb.AppendLine($"  \"fluidBar\": {{ \"enabled\": {Bool(hasFluidBar)}, \"x\": {fluidX}, \"y\": {fluidY}, \"width\": {fluidWidth}, \"height\": {fluidHeight} }},");
        sb.AppendLine($"  \"labelsCsv\": \"{Escape(labelsCsv)}\",");
        sb.AppendLine($"  \"buttonsCsv\": \"{Escape(buttonsCsv)}\",");
        sb.AppendLine($"  \"generateJavaStubs\": {Bool(generateJavaStubs)},");
        sb.AppendLine($"  \"customScreenClass\": \"{Escape(customScreenClass)}\",");
        sb.AppendLine($"  \"customMenuClass\": \"{Escape(customMenuClass)}\"");
        sb.AppendLine("}");
        return sb.ToString();
    }

    public string GeneratePreview()
    {
        SyncSlotsFromCsv();
        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"GUI: {screenId} ({screenType}) {width}x{height}");
        sb.AppendLine($"Linked block/entity/item: {linkedBlockId} / {linkedEntityId} / {linkedItemId}");
        foreach (var slot in slots) sb.AppendLine("- " + slot.GeneratePreview());
        return sb.ToString();
    }

    private static string Sanitize(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "custom_screen";
        return value.Trim().ToLowerInvariant().Replace(" ", "_");
    }

    private static string Escape(string value)
    {
        return (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
    }

    private static string Bool(bool value) { return value ? "true" : "false"; }
}

[System.Serializable]
public class ConfigDataModel
{
    public bool enabled = true;
    public string configId = "main_config";
    public string displayName = "Main Config";
    public StudioConfigFormat format = StudioConfigFormat.Json;
    public StudioConfigScope scope = StudioConfigScope.Common;
    public string fileName = "mymod-common.json";
    public bool createDefaultFile = true;
    public bool syncToClient = false;
    public bool restartRequired = false;
    public string entriesCsv = "enabled:Boolean:true, spawn_weight:Integer:80, damage_multiplier:Float:1.0";
    public List<StudioConfigEntrySettings> entries = new List<StudioConfigEntrySettings>();
    public string customConfigText = "";
    public string notes = "";

    public void SyncEntriesFromCsv()
    {
        if (entries == null) entries = new List<StudioConfigEntrySettings>();
        entries.Clear();
        if (string.IsNullOrWhiteSpace(entriesCsv)) return;

        string[] rows = entriesCsv.Split(new[] { ',', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
        foreach (string raw in rows)
        {
            string[] bits = raw.Trim().Split(':');
            if (bits.Length == 0) continue;
            var entry = new StudioConfigEntrySettings();
            entry.key = bits[0].Trim();
            entry.displayName = ToDisplayName(entry.key);
            if (bits.Length > 1 && Enum.TryParse(bits[1].Trim(), true, out StudioConfigEntryType type)) entry.type = type;
            if (bits.Length > 2) entry.defaultValue = bits[2].Trim();
            if (!string.IsNullOrWhiteSpace(entry.key)) entries.Add(entry);
        }
    }

    public string GetRelativeConfigPath(string modId)
    {
        string cleanFile = string.IsNullOrWhiteSpace(fileName) ? modId + "-common.json" : fileName.Trim();
        return ".modstudio/config/" + cleanFile;
    }

    public string GenerateConfigText(string modId)
    {
        if (!string.IsNullOrWhiteSpace(customConfigText)) return customConfigText;
        SyncEntriesFromCsv();
        if (format == StudioConfigFormat.Toml) return GenerateToml();
        if (format == StudioConfigFormat.Properties) return GenerateProperties();
        return GenerateJson();
    }

    public string GenerateSchemaJson(string modId)
    {
        SyncEntriesFromCsv();
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine($"  \"id\": \"{Escape(configId)}\",");
        sb.AppendLine($"  \"scope\": \"{scope}\",");
        sb.AppendLine($"  \"format\": \"{format}\",");
        sb.AppendLine($"  \"syncToClient\": {Bool(syncToClient)},");
        sb.AppendLine($"  \"restartRequired\": {Bool(restartRequired)},");
        sb.AppendLine("  \"entries\": [");
        for (int i = 0; i < entries.Count; i++)
        {
            var e = entries[i];
            sb.Append("    { ");
            sb.Append($"\"key\": \"{Escape(e.key)}\", \"type\": \"{e.type}\", \"default\": \"{Escape(e.defaultValue)}\", \"restartRequired\": {Bool(e.restartRequired)}");
            sb.Append(" }");
            sb.AppendLine(i < entries.Count - 1 ? "," : "");
        }
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private string GenerateJson()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        for (int i = 0; i < entries.Count; i++)
        {
            sb.Append(entries[i].ToJsonLine());
            sb.AppendLine(i < entries.Count - 1 ? "," : "");
        }
        sb.AppendLine("}");
        return sb.ToString();
    }

    private string GenerateToml()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("# Generated by Mod Studio");
        foreach (var entry in entries)
        {
            if (!string.IsNullOrWhiteSpace(entry.comment)) sb.AppendLine("# " + entry.comment);
            sb.AppendLine(entry.ToTomlLine());
        }
        return sb.ToString();
    }

    private string GenerateProperties()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("# Generated by Mod Studio");
        foreach (var entry in entries) sb.AppendLine(entry.ToPropertiesLine());
        return sb.ToString();
    }

    private static string ToDisplayName(string key)
    {
        if (string.IsNullOrEmpty(key)) return "Config Entry";
        return key.Replace("_", " ");
    }

    private static string Escape(string value)
    {
        return (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"");
    }

    private static string Bool(bool value) { return value ? "true" : "false"; }
}
