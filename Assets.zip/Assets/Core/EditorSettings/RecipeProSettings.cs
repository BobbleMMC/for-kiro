using System;
using System.Collections.Generic;

public enum StudioRecipeBookCategory
{
    Building,
    Equipment,
    Redstone,
    Misc,
    Food
}

public enum StudioRecipeIngredientMode
{
    Item,
    Tag
}

[Serializable]
public class RecipeUnlockCriterion
{
    public string criterionId = "has_item";
    public StudioRecipeIngredientMode mode = StudioRecipeIngredientMode.Item;
    public string targetId = "minecraft:stick";
}

[Serializable]
public class RecipeConditionSettings
{
    public bool enabled = false;
    public string conditionJson = "";
    public string note = "Optional loader/datapack condition. JSON is kept as raw metadata for future generator support.";
}

[Serializable]
public class RecipeProSettings
{
    public bool enabled = true;
    public string recipeId = "";
    public string group = "";
    public StudioRecipeBookCategory category = StudioRecipeBookCategory.Misc;
    public bool showNotification = true;
    public bool useDatagenProvider = false;
    public bool autoNormalizeIds = true;
    public bool useTagsAsIngredients = false;
    public string shapelessIngredientsCsv = "";
    public string customJsonOverride = "";
    public string notes = "";
    public RecipeUnlockCriterion unlock = new RecipeUnlockCriterion();
    public RecipeConditionSettings conditions = new RecipeConditionSettings();

    public string GetSafeRecipeId(string fallbackResultItem)
    {
        string source = string.IsNullOrWhiteSpace(recipeId) ? fallbackResultItem : recipeId;
        if (string.IsNullOrWhiteSpace(source)) return "recipe";
        source = source.Trim();
        if (source.Contains(":")) source = source.Substring(source.IndexOf(':') + 1);
        foreach (char c in System.IO.Path.GetInvalidFileNameChars()) source = source.Replace(c, '_');
        return source.ToLowerInvariant().Replace(' ', '_');
    }
}
