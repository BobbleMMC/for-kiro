using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

public static class RecipeLootTagBindingGenerator
{
    public static RecipeLootTagBindingReport Generate(object workspace, string projectRoot, string modId)
    {
        var report = new RecipeLootTagBindingReport();
        if (string.IsNullOrEmpty(projectRoot))
        {
            report.AddError("Project root is empty. Select exported Minecraft project root first.");
            return report;
        }

        projectRoot = Path.GetFullPath(projectRoot);
        modId = RecipeLootTagBindingUtility.CleanId(modId, "mymod");

        if (workspace == null)
        {
            report.AddWarning("Workspace object is null. Only field binding manifest will be exported.");
        }

        GenerateRecipes(workspace, projectRoot, modId, report);
        GenerateLootTables(workspace, projectRoot, modId, report);
        GenerateTags(workspace, projectRoot, modId, report);
        GenerateBindingManifest(projectRoot, modId, report);
        GenerateReport(projectRoot, report);

        return report;
    }

    private static void GenerateRecipes(object workspace, string projectRoot, string modId, RecipeLootTagBindingReport report)
    {
        object listObj = RecipeLootTagBindingUtility.GetMemberValue(workspace, "recipes");
        int index = 0;
        foreach (object recipe in RecipeLootTagBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string recipeId = GetFirstString(recipe, new string[] { "recipeId", "id", "name" }, "recipe_" + index);
            recipeId = RecipeLootTagBindingUtility.CleanId(recipeId, "recipe_" + index);

            string customJson = GetFirstString(recipe, new string[] { "customJsonOverride", "customJson", "jsonOverride" }, string.Empty);
            string json = string.IsNullOrWhiteSpace(customJson) ? GenerateRecipeJson(recipe, modId, recipeId) : RecipeLootTagBindingUtility.EnsureObjectJson(customJson, GenerateRecipeJson(recipe, modId, recipeId));

            string file = Path.Combine(projectRoot, "src/main/resources/data", modId, "recipes", recipeId + ".json");
            RecipeLootTagBindingUtility.WriteText(file, json, report);
            WriteBinding(projectRoot, "recipe", recipeId, "data/" + modId + "/recipes/" + recipeId + ".json", report);
            report.recipesGenerated++;
        }
    }

    private static string GenerateRecipeJson(object recipe, string modId, string recipeId)
    {
        string type = GetFirstString(recipe, new string[] { "recipeType", "type" }, "crafting_shaped").ToLowerInvariant();
        string resultItem = GetFirstString(recipe, new string[] { "resultItem", "outputItem", "result", "output" }, modId + ":" + recipeId);
        int resultCount = GetFirstInt(recipe, new string[] { "resultCount", "outputCount", "count" }, 1);
        string group = GetFirstString(recipe, new string[] { "group" }, string.Empty);
        string category = GetFirstString(recipe, new string[] { "category", "recipeBookCategory" }, string.Empty);
        string ingredientsRaw = GetFirstString(recipe, new string[] { "ingredientsCsv", "ingredients", "inputItems" }, "minecraft:stone");
        List<string> ingredients = RecipeLootTagBindingUtility.SplitCsvOrLines(ingredientsRaw);
        if (ingredients.Count == 0) ingredients.Add("minecraft:stone");

        var sb = new StringBuilder();
        sb.AppendLine("{");

        if (type.Contains("smelt") || type.Contains("blast") || type.Contains("smok") || type.Contains("campfire"))
        {
            string mcType = type.Contains("blast") ? "minecraft:blasting" : type.Contains("smok") ? "minecraft:smoking" : type.Contains("campfire") ? "minecraft:campfire_cooking" : "minecraft:smelting";
            float experience = GetFirstFloat(recipe, new string[] { "experience", "xp" }, 0.1f);
            int cookingTime = GetFirstInt(recipe, new string[] { "cookingTime", "time" }, type.Contains("blast") ? 100 : 200);
            sb.AppendLine("  \"type\": \"" + mcType + "\",");
            if (!string.IsNullOrEmpty(group)) sb.AppendLine("  \"group\": \"" + RecipeLootTagBindingUtility.EscapeJson(group) + "\",");
            if (!string.IsNullOrEmpty(category)) sb.AppendLine("  \"category\": \"" + RecipeLootTagBindingUtility.EscapeJson(category) + "\",");
            sb.AppendLine("  \"ingredient\": { \"item\": \"" + RecipeLootTagBindingUtility.EscapeJson(ingredients[0]) + "\" },");
            sb.AppendLine("  \"result\": \"" + RecipeLootTagBindingUtility.EscapeJson(resultItem) + "\",");
            sb.AppendLine("  \"experience\": " + experience.ToString(System.Globalization.CultureInfo.InvariantCulture) + ",");
            sb.AppendLine("  \"cookingtime\": " + cookingTime);
        }
        else if (type.Contains("stonecut"))
        {
            sb.AppendLine("  \"type\": \"minecraft:stonecutting\",");
            sb.AppendLine("  \"ingredient\": { \"item\": \"" + RecipeLootTagBindingUtility.EscapeJson(ingredients[0]) + "\" },");
            sb.AppendLine("  \"result\": { \"id\": \"" + RecipeLootTagBindingUtility.EscapeJson(resultItem) + "\", \"count\": " + Math.Max(1, resultCount) + " }");
        }
        else if (type.Contains("shapeless"))
        {
            sb.AppendLine("  \"type\": \"minecraft:crafting_shapeless\",");
            if (!string.IsNullOrEmpty(group)) sb.AppendLine("  \"group\": \"" + RecipeLootTagBindingUtility.EscapeJson(group) + "\",");
            if (!string.IsNullOrEmpty(category)) sb.AppendLine("  \"category\": \"" + RecipeLootTagBindingUtility.EscapeJson(category) + "\",");
            sb.AppendLine("  \"ingredients\": [");
            for (int i = 0; i < ingredients.Count; i++)
            {
                sb.Append("    { \"item\": \"").Append(RecipeLootTagBindingUtility.EscapeJson(ingredients[i])).Append("\" }");
                sb.AppendLine(i < ingredients.Count - 1 ? "," : string.Empty);
            }
            sb.AppendLine("  ],");
            sb.AppendLine("  \"result\": { \"id\": \"" + RecipeLootTagBindingUtility.EscapeJson(resultItem) + "\", \"count\": " + Math.Max(1, resultCount) + " }");
        }
        else
        {
            sb.AppendLine("  \"type\": \"minecraft:crafting_shaped\",");
            if (!string.IsNullOrEmpty(group)) sb.AppendLine("  \"group\": \"" + RecipeLootTagBindingUtility.EscapeJson(group) + "\",");
            if (!string.IsNullOrEmpty(category)) sb.AppendLine("  \"category\": \"" + RecipeLootTagBindingUtility.EscapeJson(category) + "\",");
            sb.AppendLine("  \"pattern\": [\"AAA\", \"AAA\", \"AAA\"],");
            sb.AppendLine("  \"key\": { \"A\": { \"item\": \"" + RecipeLootTagBindingUtility.EscapeJson(ingredients[0]) + "\" } },");
            sb.AppendLine("  \"result\": { \"id\": \"" + RecipeLootTagBindingUtility.EscapeJson(resultItem) + "\", \"count\": " + Math.Max(1, resultCount) + " }");
        }

        sb.AppendLine("}");
        return sb.ToString();
    }

    private static void GenerateLootTables(object workspace, string projectRoot, string modId, RecipeLootTagBindingReport report)
    {
        object listObj = RecipeLootTagBindingUtility.GetMemberValue(workspace, "lootTables");
        int index = 0;
        foreach (object loot in RecipeLootTagBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string lootId = GetFirstString(loot, new string[] { "lootId", "id", "name" }, "loot_table_" + index);
            lootId = RecipeLootTagBindingUtility.CleanId(lootId, "loot_table_" + index);
            string lootType = GetFirstString(loot, new string[] { "lootType", "type", "category" }, "blocks").ToLowerInvariant();
            string customJson = GetFirstString(loot, new string[] { "customJsonOverride", "customJson", "jsonOverride" }, string.Empty);
            string json = string.IsNullOrWhiteSpace(customJson) ? GenerateLootTableJson(loot, modId, lootId) : RecipeLootTagBindingUtility.EnsureObjectJson(customJson, GenerateLootTableJson(loot, modId, lootId));

            string folder = "loot_tables";
            if (lootType.Contains("entity")) folder = "loot_tables/entities";
            else if (lootType.Contains("chest")) folder = "loot_tables/chests";
            else if (lootType.Contains("game")) folder = "loot_tables/gameplay";
            else if (lootType.Contains("block")) folder = "loot_tables/blocks";
            else folder = "loot_tables/custom";

            string file = Path.Combine(projectRoot, "src/main/resources/data", modId, folder, lootId + ".json");
            RecipeLootTagBindingUtility.WriteText(file, json, report);
            WriteBinding(projectRoot, "loot_table", lootId, "data/" + modId + "/" + folder + "/" + lootId + ".json", report);
            report.lootTablesGenerated++;
        }
    }

    private static string GenerateLootTableJson(object loot, string modId, string lootId)
    {
        string entry = GetFirstString(loot, new string[] { "entryItem", "item", "dropItem", "outputItem" }, modId + ":" + lootId);
        int min = GetFirstInt(loot, new string[] { "minCount", "min" }, 1);
        int max = GetFirstInt(loot, new string[] { "maxCount", "max" }, Math.Max(1, min));
        bool explosionDecay = GetFirstBool(loot, new string[] { "explosionDecay", "applyExplosionDecay" }, true);

        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"type\": \"minecraft:block\",");
        sb.AppendLine("  \"pools\": [");
        sb.AppendLine("    {");
        sb.AppendLine("      \"rolls\": 1,");
        sb.AppendLine("      \"entries\": [ { \"type\": \"minecraft:item\", \"name\": \"" + RecipeLootTagBindingUtility.EscapeJson(entry) + "\" } ],");
        sb.AppendLine("      \"functions\": [");
        sb.AppendLine("        { \"function\": \"minecraft:set_count\", \"count\": { \"min\": " + Math.Max(1, min) + ", \"max\": " + Math.Max(min, max) + " } }" + (explosionDecay ? "," : string.Empty));
        if (explosionDecay)
            sb.AppendLine("        { \"function\": \"minecraft:explosion_decay\" }");
        sb.AppendLine("      ]");
        sb.AppendLine("    }");
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static void GenerateTags(object workspace, string projectRoot, string modId, RecipeLootTagBindingReport report)
    {
        object listObj = RecipeLootTagBindingUtility.GetMemberValue(workspace, "tags");
        int index = 0;
        foreach (object tag in RecipeLootTagBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string tagId = GetFirstString(tag, new string[] { "tagId", "id", "name" }, "tag_" + index);
            tagId = RecipeLootTagBindingUtility.CleanId(tagId, "tag_" + index);
            string tagType = GetFirstString(tag, new string[] { "tagType", "type", "category" }, "items").ToLowerInvariant();
            string ns = GetFirstString(tag, new string[] { "tagNamespace", "namespace" }, modId);
            ns = RecipeLootTagBindingUtility.CleanId(ns, modId);
            bool replace = GetFirstBool(tag, new string[] { "replace" }, false);
            string valuesRaw = GetFirstString(tag, new string[] { "valuesCsv", "valuesText", "values" }, string.Empty);
            List<string> values = RecipeLootTagBindingUtility.SplitCsvOrLines(valuesRaw);
            object valuesObj = RecipeLootTagBindingUtility.GetMemberValue(tag, "values");
            foreach (object v in RecipeLootTagBindingUtility.AsEnumerable(valuesObj))
            {
                string s = Convert.ToString(v);
                if (!string.IsNullOrEmpty(s) && !values.Contains(s)) values.Add(s);
            }

            string customJson = GetFirstString(tag, new string[] { "customJsonOverride", "customJson", "jsonOverride" }, string.Empty);
            string json = string.IsNullOrWhiteSpace(customJson) ? GenerateTagJson(values, replace) : RecipeLootTagBindingUtility.EnsureObjectJson(customJson, GenerateTagJson(values, replace));
            string folder = NormalizeTagFolder(tagType);
            string file = Path.Combine(projectRoot, "src/main/resources/data", ns, "tags", folder, tagId + ".json");
            RecipeLootTagBindingUtility.WriteText(file, json, report);
            WriteBinding(projectRoot, "tag", ns + ":" + folder + "/" + tagId, "data/" + ns + "/tags/" + folder + "/" + tagId + ".json", report);
            report.tagsGenerated++;
        }
    }

    private static string GenerateTagJson(List<string> values, bool replace)
    {
        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"replace\": " + (replace ? "true" : "false") + ",");
        sb.AppendLine("  \"values\": " + RecipeLootTagBindingUtility.ListToJsonArray(values));
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string NormalizeTagFolder(string tagType)
    {
        if (string.IsNullOrEmpty(tagType)) return "items";
        tagType = tagType.ToLowerInvariant().Trim();
        if (tagType == "item") return "items";
        if (tagType == "block") return "blocks";
        if (tagType == "entity" || tagType == "entity_type") return "entity_types";
        if (tagType == "biome") return "worldgen/biome";
        if (tagType == "fluid") return "fluids";
        if (tagType == "damage" || tagType == "damage_type") return "damage_type";
        if (tagType == "function") return "functions";
        return tagType.Replace(" ", "_");
    }

    private static void GenerateBindingManifest(string projectRoot, string modId, RecipeLootTagBindingReport report)
    {
        string manifest = "{\n" +
            "  \"patch\": \"29\",\n" +
            "  \"name\": \"Recipe/Loot/Tag Real Binding\",\n" +
            "  \"modId\": \"" + RecipeLootTagBindingUtility.EscapeJson(modId) + "\",\n" +
            "  \"bindings\": [\n" +
            "    { \"id\": \"recipe.type\", \"dataModel\": \"recipes[].pro.recipeType\", \"ui\": \"Recipe Editor Pro\", \"generator\": \"data/<modid>/recipes/*.json\", \"validator\": \"recipe_json_object_valid\" },\n" +
            "    { \"id\": \"recipe.ingredients\", \"dataModel\": \"recipes[].ingredients\", \"ui\": \"Recipe Editor Pro\", \"generator\": \"recipe.ingredients/key\", \"validator\": \"recipe_has_ingredient\" },\n" +
            "    { \"id\": \"recipe.result\", \"dataModel\": \"recipes[].resultItem/resultCount\", \"ui\": \"Recipe Editor Pro\", \"generator\": \"recipe.result\", \"validator\": \"recipe_has_result\" },\n" +
            "    { \"id\": \"loot.pools\", \"dataModel\": \"lootTables[].pools\", \"ui\": \"Loot Table Editor\", \"generator\": \"data/<modid>/loot_tables/**/*.json\", \"validator\": \"loot_has_pool\" },\n" +
            "    { \"id\": \"tag.values\", \"dataModel\": \"tags[].values\", \"ui\": \"Tag Editor\", \"generator\": \"data/<namespace>/tags/**/*.json\", \"validator\": \"tag_has_values\" }\n" +
            "  ]\n" +
            "}\n";
        string path = Path.Combine(projectRoot, ".modstudio/field-bindings/recipe-loot-tag-bindings.json");
        RecipeLootTagBindingUtility.WriteText(path, manifest, report);
        report.bindingManifestsGenerated++;
    }

    private static void WriteBinding(string projectRoot, string kind, string id, string target, RecipeLootTagBindingReport report)
    {
        string safeId = RecipeLootTagBindingUtility.CleanFileId(id, kind);
        string json = "{\n" +
            "  \"kind\": \"" + RecipeLootTagBindingUtility.EscapeJson(kind) + "\",\n" +
            "  \"id\": \"" + RecipeLootTagBindingUtility.EscapeJson(id) + "\",\n" +
            "  \"target\": \"" + RecipeLootTagBindingUtility.EscapeJson(target) + "\",\n" +
            "  \"dataModel\": \"WorkspaceData." + kind + "\",\n" +
            "  \"ui\": \"" + (kind == "recipe" ? "Recipe Editor Pro" : kind == "tag" ? "Tag Editor" : "Loot Table Editor") + "\",\n" +
            "  \"validator\": \"" + kind + "_binding_valid\"\n" +
            "}\n";
        string path = Path.Combine(projectRoot, ".modstudio/recipe-loot-tag-binding", kind + "-" + safeId + ".binding.json");
        RecipeLootTagBindingUtility.WriteText(path, json, report);
        report.bindingManifestsGenerated++;
    }

    private static void GenerateReport(string projectRoot, RecipeLootTagBindingReport report)
    {
        string path = Path.Combine(projectRoot, ".modstudio/reports/recipe-loot-tag-binding-report.txt");
        RecipeLootTagBindingUtility.WriteText(path, report.Format(), report);
    }

    private static string GetFirstString(object target, string[] names, string fallback)
    {
        for (int i = 0; i < names.Length; i++)
        {
            string v = RecipeLootTagBindingUtility.GetString(target, names[i], null);
            if (!string.IsNullOrEmpty(v)) return v;
        }
        return fallback;
    }

    private static int GetFirstInt(object target, string[] names, int fallback)
    {
        for (int i = 0; i < names.Length; i++)
        {
            object value = RecipeLootTagBindingUtility.GetMemberValue(target, names[i]);
            if (value != null)
            {
                try { return Convert.ToInt32(value); } catch { }
            }
        }
        return fallback;
    }

    private static float GetFirstFloat(object target, string[] names, float fallback)
    {
        for (int i = 0; i < names.Length; i++)
        {
            object value = RecipeLootTagBindingUtility.GetMemberValue(target, names[i]);
            if (value != null)
            {
                try { return Convert.ToSingle(value); } catch { }
            }
        }
        return fallback;
    }

    private static bool GetFirstBool(object target, string[] names, bool fallback)
    {
        for (int i = 0; i < names.Length; i++)
        {
            object value = RecipeLootTagBindingUtility.GetMemberValue(target, names[i]);
            if (value != null)
            {
                try { return Convert.ToBoolean(value); } catch { }
            }
        }
        return fallback;
    }
}
