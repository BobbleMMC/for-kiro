using System.Collections.Generic;
using System.Text;

public class EquipmentGameplayBindingReport
{
    public int toolsGenerated;
    public int armorsGenerated;
    public int foodsGenerated;
    public int dataComponentsGenerated;
    public int effectsGenerated;
    public int enchantmentsGenerated;
    public int soundsGenerated;
    public int particlesGenerated;
    public int javaStubsGenerated;

    public readonly List<string> generatedFiles = new List<string>();
    public readonly List<string> warnings = new List<string>();
    public readonly List<string> errors = new List<string>();

    public bool HasErrors
    {
        get { return errors.Count > 0; }
    }

    public void AddGenerated(string path)
    {
        if (!string.IsNullOrEmpty(path)) generatedFiles.Add(path);
    }

    public void AddWarning(string message)
    {
        if (!string.IsNullOrEmpty(message)) warnings.Add(message);
    }

    public void AddError(string message)
    {
        if (!string.IsNullOrEmpty(message)) errors.Add(message);
    }

    public string Format()
    {
        var sb = new StringBuilder();
        sb.AppendLine("Equipment / Gameplay Binding Report");
        sb.AppendLine("===================================");
        sb.AppendLine("Tools generated: " + toolsGenerated);
        sb.AppendLine("Armors generated: " + armorsGenerated);
        sb.AppendLine("Foods generated: " + foodsGenerated);
        sb.AppendLine("Data components generated: " + dataComponentsGenerated);
        sb.AppendLine("Effects generated: " + effectsGenerated);
        sb.AppendLine("Enchantments generated: " + enchantmentsGenerated);
        sb.AppendLine("Sounds generated: " + soundsGenerated);
        sb.AppendLine("Particles generated: " + particlesGenerated);
        sb.AppendLine("Java stubs generated: " + javaStubsGenerated);
        sb.AppendLine();

        if (warnings.Count > 0)
        {
            sb.AppendLine("Warnings:");
            for (int i = 0; i < warnings.Count; i++) sb.AppendLine("- " + warnings[i]);
            sb.AppendLine();
        }

        if (errors.Count > 0)
        {
            sb.AppendLine("Errors:");
            for (int i = 0; i < errors.Count; i++) sb.AppendLine("- " + errors[i]);
            sb.AppendLine();
        }

        if (generatedFiles.Count > 0)
        {
            sb.AppendLine("Generated files:");
            for (int i = 0; i < generatedFiles.Count; i++) sb.AppendLine("- " + generatedFiles[i]);
        }

        return sb.ToString();
    }
}
