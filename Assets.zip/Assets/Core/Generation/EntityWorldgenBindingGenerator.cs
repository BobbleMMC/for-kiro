using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

public static class EntityWorldgenBindingGenerator
{
    public static EntityWorldgenBindingReport Generate(object workspace, string projectRoot, string modId)
    {
        var report = new EntityWorldgenBindingReport();
        if (string.IsNullOrEmpty(projectRoot))
        {
            report.AddError("Project root is empty. Select exported Minecraft project root first.");
            return report;
        }

        projectRoot = Path.GetFullPath(projectRoot);
        modId = EntityWorldgenBindingUtility.CleanId(modId, "mymod");

        if (workspace == null)
        {
            report.AddWarning("Workspace object is null. Only field binding manifest will be exported.");
        }

        GenerateEntities(workspace, projectRoot, modId, report);
        GenerateBiomes(workspace, projectRoot, modId, report);
        GenerateDimensions(workspace, projectRoot, modId, report);
        GenerateStructures(workspace, projectRoot, modId, report);
        GenerateBindingManifest(projectRoot, modId, report);
        GenerateReport(projectRoot, report);
        return report;
    }

    private static void GenerateEntities(object workspace, string projectRoot, string modId, EntityWorldgenBindingReport report)
    {
        object listObj = EntityWorldgenBindingUtility.GetMemberValue(workspace, "entities");
        int index = 0;
        foreach (object entity in EntityWorldgenBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EntityWorldgenBindingUtility.GetFirstString(entity, new string[] { "entityId", "id", "name" }, "entity_" + index);
            id = EntityWorldgenBindingUtility.CleanId(id, "entity_" + index);
            string display = EntityWorldgenBindingUtility.GetFirstString(entity, new string[] { "displayName", "name", "title" }, EntityWorldgenBindingUtility.ToPascalCase(id));
            string category = EntityWorldgenBindingUtility.GetFirstString(entity, new string[] { "mobCategory", "category", "spawnGroup" }, "monster").ToLowerInvariant();
            float health = EntityWorldgenBindingUtility.GetFirstFloat(entity, new string[] { "health", "maxHealth" }, 20f);
            float width = EntityWorldgenBindingUtility.GetFirstFloat(entity, new string[] { "width" }, 0.6f);
            float height = EntityWorldgenBindingUtility.GetFirstFloat(entity, new string[] { "height" }, 1.8f);
            string texture = EntityWorldgenBindingUtility.GetFirstString(entity, new string[] { "texturePath", "texture", "entityTexture" }, "textures/entity/" + id + ".png");

            WriteEntityJavaStubs(projectRoot, modId, id, display, category, health, width, height, texture, report);
            WriteEntityDescriptor(projectRoot, modId, id, display, category, health, width, height, texture, report);
            WriteEntityBinding(projectRoot, modId, id, report);
            report.entitiesGenerated++;
        }
    }

    private static void WriteEntityJavaStubs(string projectRoot, string modId, string id, string display, string category, float health, float width, float height, string texture, EntityWorldgenBindingReport report)
    {
        string packageBase = EntityWorldgenBindingUtility.GetPackageBase(modId);
        string className = EntityWorldgenBindingUtility.ToPascalCase(id);
        string packagePath = packageBase.Replace('.', '/');
        string root = Path.Combine(projectRoot, ".modstudio/generated-java/entity-worldgen", packagePath);

        string entityClass = "package " + packageBase + ".entity;\n\n" +
            "// Generated stub by Mod Studio Patch 30. Review before applying to src/main/java.\n" +
            "// Entity: " + display + " (" + id + ")\n" +
            "public class " + className + "Entity {\n" +
            "    public static final String ID = \"" + EntityWorldgenBindingUtility.EscapeJson(id) + "\";\n" +
            "    public static final String CATEGORY = \"" + EntityWorldgenBindingUtility.EscapeJson(category) + "\";\n" +
            "    public static final float WIDTH = " + EntityWorldgenBindingUtility.F(width) + "f;\n" +
            "    public static final float HEIGHT = " + EntityWorldgenBindingUtility.F(height) + "f;\n" +
            "    public static final double MAX_HEALTH = " + EntityWorldgenBindingUtility.F(health) + "D;\n" +
            "}\n";
        EntityWorldgenBindingUtility.WriteText(Path.Combine(root, "entity", className + "Entity.java.stub"), entityClass, report);
        report.javaStubsGenerated++;

        string rendererClass = "package " + packageBase + ".client.renderer;\n\n" +
            "// Generated renderer texture hook stub by Mod Studio Patch 30.\n" +
            "public class " + className + "Renderer {\n" +
            "    public static final String TEXTURE = \"" + EntityWorldgenBindingUtility.EscapeJson(modId + ":" + texture.Replace("textures/", string.Empty).Replace(".png", string.Empty)) + "\";\n" +
            "}\n";
        EntityWorldgenBindingUtility.WriteText(Path.Combine(root, "client/renderer", className + "Renderer.java.stub"), rendererClass, report);
        report.javaStubsGenerated++;

        string registry = "package " + packageBase + ".entity;\n\n" +
            "// Add these lines to your real entity registry for Fabric/NeoForge after review.\n" +
            "public final class ModEntities_" + className + "_BindingStub {\n" +
            "    public static final String ENTITY_ID = \"" + EntityWorldgenBindingUtility.EscapeJson(modId + ":" + id) + "\";\n" +
            "    public static final String SPAWN_GROUP = \"" + EntityWorldgenBindingUtility.EscapeJson(category) + "\";\n" +
            "}\n";
        EntityWorldgenBindingUtility.WriteText(Path.Combine(root, "entity", "ModEntities_" + className + ".java.stub"), registry, report);
        report.javaStubsGenerated++;
    }

    private static void WriteEntityDescriptor(string projectRoot, string modId, string id, string display, string category, float health, float width, float height, string texture, EntityWorldgenBindingReport report)
    {
        string json = "{\n" +
            "  \"kind\": \"entity\",\n" +
            "  \"id\": \"" + EntityWorldgenBindingUtility.EscapeJson(modId + ":" + id) + "\",\n" +
            "  \"displayName\": \"" + EntityWorldgenBindingUtility.EscapeJson(display) + "\",\n" +
            "  \"category\": \"" + EntityWorldgenBindingUtility.EscapeJson(category) + "\",\n" +
            "  \"health\": " + EntityWorldgenBindingUtility.F(health) + ",\n" +
            "  \"width\": " + EntityWorldgenBindingUtility.F(width) + ",\n" +
            "  \"height\": " + EntityWorldgenBindingUtility.F(height) + ",\n" +
            "  \"texture\": \"" + EntityWorldgenBindingUtility.EscapeJson(texture) + "\"\n" +
            "}\n";
        EntityWorldgenBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/entity-worldgen/entities", id + ".entity.json"), json, report);
    }

    private static void GenerateBiomes(object workspace, string projectRoot, string modId, EntityWorldgenBindingReport report)
    {
        object listObj = EntityWorldgenBindingUtility.GetMemberValue(workspace, "biomes");
        int index = 0;
        foreach (object biome in EntityWorldgenBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EntityWorldgenBindingUtility.GetFirstString(biome, new string[] { "biomeId", "id", "name" }, "biome_" + index);
            id = EntityWorldgenBindingUtility.CleanId(id, "biome_" + index);
            string custom = EntityWorldgenBindingUtility.GetFirstString(biome, new string[] { "customBiomeJson", "customJson", "jsonOverride" }, string.Empty);
            string json = string.IsNullOrWhiteSpace(custom) ? TryGenerateBiomeJson(biome, id) : EntityWorldgenBindingUtility.EnsureObjectJson(custom, TryGenerateBiomeJson(biome, id));
            string file = Path.Combine(projectRoot, "src/main/resources/data", modId, "worldgen/biome", id + ".json");
            EntityWorldgenBindingUtility.WriteText(file, json, report);
            WriteBinding(projectRoot, "biome", id, "data/" + modId + "/worldgen/biome/" + id + ".json", report);
            report.biomesGenerated++;
        }
    }

    private static string TryGenerateBiomeJson(object biome, string id)
    {
        try
        {
            MethodInfo method = biome.GetType().GetMethod("GenerateFullBiomeJson", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (method != null)
            {
                object value = method.Invoke(biome, null);
                if (value != null && value.ToString().Trim().StartsWith("{")) return value.ToString();
            }
        }
        catch { }

        float temperature = EntityWorldgenBindingUtility.GetFirstFloat(biome, new string[] { "temperature" }, 0.8f);
        float downfall = EntityWorldgenBindingUtility.GetFirstFloat(biome, new string[] { "downfall" }, 0.4f);
        bool precipitation = EntityWorldgenBindingUtility.GetFirstBool(biome, new string[] { "precipitation", "hasPrecipitation" }, true);
        return "{\n" +
            "  \"has_precipitation\": " + (precipitation ? "true" : "false") + ",\n" +
            "  \"temperature\": " + EntityWorldgenBindingUtility.F(temperature) + ",\n" +
            "  \"downfall\": " + EntityWorldgenBindingUtility.F(downfall) + ",\n" +
            "  \"effects\": { \"sky_color\": 7907327, \"water_fog_color\": 329011, \"fog_color\": 12638463, \"water_color\": 4159204 },\n" +
            "  \"spawners\": {},\n" +
            "  \"spawn_costs\": {},\n" +
            "  \"carvers\": {},\n" +
            "  \"features\": [[], [], [], [], [], [], [], [], [], [], []]\n" +
            "}\n";
    }

    private static void GenerateDimensions(object workspace, string projectRoot, string modId, EntityWorldgenBindingReport report)
    {
        object listObj = EntityWorldgenBindingUtility.GetFirstMemberValue(workspace, new string[] { "dimensions", "worldDimensions", "dimensionSettings" });
        int index = 0;
        foreach (object dimension in EntityWorldgenBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EntityWorldgenBindingUtility.GetFirstString(dimension, new string[] { "dimensionId", "id", "name" }, "dimension_" + index);
            id = EntityWorldgenBindingUtility.CleanId(id, "dimension_" + index);
            string dimensionJson = EntityWorldgenBindingUtility.GetFirstString(dimension, new string[] { "customDimensionJson", "dimensionJson", "customJson" }, string.Empty);
            string typeJson = EntityWorldgenBindingUtility.GetFirstString(dimension, new string[] { "customDimensionTypeJson", "dimensionTypeJson" }, string.Empty);

            string dimFile = Path.Combine(projectRoot, "src/main/resources/data", modId, "dimension", id + ".json");
            EntityWorldgenBindingUtility.WriteText(dimFile, EntityWorldgenBindingUtility.EnsureObjectJson(dimensionJson, GenerateDimensionJson(dimension, modId, id)), report);
            string typeFile = Path.Combine(projectRoot, "src/main/resources/data", modId, "dimension_type", id + ".json");
            EntityWorldgenBindingUtility.WriteText(typeFile, EntityWorldgenBindingUtility.EnsureObjectJson(typeJson, GenerateDimensionTypeJson(dimension)), report);
            WriteBinding(projectRoot, "dimension", id, "data/" + modId + "/dimension/" + id + ".json", report);
            report.dimensionsGenerated++;
        }
    }

    private static string GenerateDimensionJson(object dimension, string modId, string id)
    {
        string generator = EntityWorldgenBindingUtility.GetFirstString(dimension, new string[] { "generatorType", "generator" }, "minecraft:noise");
        string biome = EntityWorldgenBindingUtility.GetFirstString(dimension, new string[] { "fixedBiomeId", "biomeId", "biome" }, "minecraft:plains");
        return "{\n" +
            "  \"type\": \"" + EntityWorldgenBindingUtility.EscapeJson(modId + ":" + id) + "\",\n" +
            "  \"generator\": {\n" +
            "    \"type\": \"" + EntityWorldgenBindingUtility.EscapeJson(generator) + "\",\n" +
            "    \"biome_source\": { \"type\": \"minecraft:fixed\", \"biome\": \"" + EntityWorldgenBindingUtility.EscapeJson(biome) + "\" },\n" +
            "    \"settings\": \"minecraft:overworld\"\n" +
            "  }\n" +
            "}\n";
    }

    private static string GenerateDimensionTypeJson(object dimension)
    {
        bool skylight = EntityWorldgenBindingUtility.GetFirstBool(dimension, new string[] { "hasSkylight", "skylight" }, true);
        bool ceiling = EntityWorldgenBindingUtility.GetFirstBool(dimension, new string[] { "hasCeiling", "ceiling" }, false);
        bool natural = EntityWorldgenBindingUtility.GetFirstBool(dimension, new string[] { "natural" }, true);
        int minY = EntityWorldgenBindingUtility.GetFirstInt(dimension, new string[] { "minY" }, -64);
        int height = EntityWorldgenBindingUtility.GetFirstInt(dimension, new string[] { "height" }, 384);
        return "{\n" +
            "  \"ultrawarm\": false,\n" +
            "  \"natural\": " + (natural ? "true" : "false") + ",\n" +
            "  \"coordinate_scale\": 1.0,\n" +
            "  \"piglin_safe\": false,\n" +
            "  \"respawn_anchor_works\": false,\n" +
            "  \"bed_works\": true,\n" +
            "  \"has_raids\": true,\n" +
            "  \"has_skylight\": " + (skylight ? "true" : "false") + ",\n" +
            "  \"has_ceiling\": " + (ceiling ? "true" : "false") + ",\n" +
            "  \"ambient_light\": 0.0,\n" +
            "  \"logical_height\": " + height + ",\n" +
            "  \"min_y\": " + minY + ",\n" +
            "  \"height\": " + height + ",\n" +
            "  \"infiniburn\": \"#minecraft:infiniburn_overworld\",\n" +
            "  \"effects\": \"minecraft:overworld\",\n" +
            "  \"monster_spawn_light_level\": { \"type\": \"minecraft:uniform\", \"value\": { \"min_inclusive\": 0, \"max_inclusive\": 7 } },\n" +
            "  \"monster_spawn_block_light_limit\": 0\n" +
            "}\n";
    }

    private static void GenerateStructures(object workspace, string projectRoot, string modId, EntityWorldgenBindingReport report)
    {
        object listObj = EntityWorldgenBindingUtility.GetFirstMemberValue(workspace, new string[] { "structures", "worldStructures", "structureSettings" });
        int index = 0;
        foreach (object structure in EntityWorldgenBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EntityWorldgenBindingUtility.GetFirstString(structure, new string[] { "structureId", "id", "name" }, "structure_" + index);
            id = EntityWorldgenBindingUtility.CleanId(id, "structure_" + index);
            string structureJson = EntityWorldgenBindingUtility.GetFirstString(structure, new string[] { "customStructureJson", "structureJson", "customJson" }, string.Empty);
            string setJson = EntityWorldgenBindingUtility.GetFirstString(structure, new string[] { "customStructureSetJson", "structureSetJson" }, string.Empty);
            EntityWorldgenBindingUtility.WriteText(Path.Combine(projectRoot, "src/main/resources/data", modId, "worldgen/structure", id + ".json"), EntityWorldgenBindingUtility.EnsureObjectJson(structureJson, GenerateStructureJson(structure, modId, id)), report);
            EntityWorldgenBindingUtility.WriteText(Path.Combine(projectRoot, "src/main/resources/data", modId, "worldgen/structure_set", id + ".json"), EntityWorldgenBindingUtility.EnsureObjectJson(setJson, GenerateStructureSetJson(structure, modId, id)), report);
            WriteBinding(projectRoot, "structure", id, "data/" + modId + "/worldgen/structure/" + id + ".json", report);
            report.structuresGenerated++;
        }
    }

    private static string GenerateStructureJson(object structure, string modId, string id)
    {
        string biomeFilter = EntityWorldgenBindingUtility.GetFirstString(structure, new string[] { "biomeFilter", "biomes", "biomeTag" }, "#minecraft:is_overworld");
        string startPool = EntityWorldgenBindingUtility.GetFirstString(structure, new string[] { "startPool", "pool" }, modId + ":" + id + "/start_pool");
        int size = EntityWorldgenBindingUtility.GetFirstInt(structure, new string[] { "jigsawSize", "size" }, 7);
        return "{\n" +
            "  \"type\": \"minecraft:jigsaw\",\n" +
            "  \"biomes\": \"" + EntityWorldgenBindingUtility.EscapeJson(biomeFilter) + "\",\n" +
            "  \"step\": \"surface_structures\",\n" +
            "  \"spawn_overrides\": {},\n" +
            "  \"start_pool\": \"" + EntityWorldgenBindingUtility.EscapeJson(startPool) + "\",\n" +
            "  \"size\": " + Math.Max(1, size) + ",\n" +
            "  \"start_height\": { \"absolute\": 0 },\n" +
            "  \"project_start_to_heightmap\": \"WORLD_SURFACE_WG\",\n" +
            "  \"max_distance_from_center\": 80,\n" +
            "  \"use_expansion_hack\": false\n" +
            "}\n";
    }

    private static string GenerateStructureSetJson(object structure, string modId, string id)
    {
        int spacing = EntityWorldgenBindingUtility.GetFirstInt(structure, new string[] { "spacing" }, 32);
        int separation = EntityWorldgenBindingUtility.GetFirstInt(structure, new string[] { "separation" }, 8);
        int salt = EntityWorldgenBindingUtility.GetFirstInt(structure, new string[] { "salt" }, 1234567);
        return "{\n" +
            "  \"structures\": [ { \"structure\": \"" + EntityWorldgenBindingUtility.EscapeJson(modId + ":" + id) + "\", \"weight\": 1 } ],\n" +
            "  \"placement\": {\n" +
            "    \"type\": \"minecraft:random_spread\",\n" +
            "    \"spacing\": " + Math.Max(1, spacing) + ",\n" +
            "    \"separation\": " + Math.Max(0, separation) + ",\n" +
            "    \"salt\": " + salt + "\n" +
            "  }\n" +
            "}\n";
    }

    private static void WriteBinding(string projectRoot, string kind, string id, string target, EntityWorldgenBindingReport report)
    {
        string json = "{\n" +
            "  \"patch\": \"30\",\n" +
            "  \"kind\": \"" + EntityWorldgenBindingUtility.EscapeJson(kind) + "\",\n" +
            "  \"id\": \"" + EntityWorldgenBindingUtility.EscapeJson(id) + "\",\n" +
            "  \"dataModel\": \"WorkspaceData." + EntityWorldgenBindingUtility.EscapeJson(kind) + "s[]\",\n" +
            "  \"ui\": \"" + EntityWorldgenBindingUtility.EscapeJson(GetUiName(kind)) + "\",\n" +
            "  \"generator\": \"" + EntityWorldgenBindingUtility.EscapeJson(target) + "\",\n" +
            "  \"validator\": \"" + EntityWorldgenBindingUtility.EscapeJson(kind + "_binding_valid") + "\"\n" +
            "}\n";
        EntityWorldgenBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/entity-worldgen-binding", kind + "-" + id + ".binding.json"), json, report);
        report.bindingManifestsGenerated++;
    }

    private static string GetUiName(string kind)
    {
        if (kind == "entity") return "Entity AI / Entity Spawn Editor";
        if (kind == "biome") return "Biome Pro Editor";
        if (kind == "dimension") return "Dimension Editor";
        if (kind == "structure") return "Structure Editor";
        return "Mod Studio Editor";
    }

    private static void GenerateBindingManifest(string projectRoot, string modId, EntityWorldgenBindingReport report)
    {
        string manifest = "{\n" +
            "  \"patch\": \"30\",\n" +
            "  \"name\": \"Entity/Biome/Dimension/Structure Real Binding\",\n" +
            "  \"modId\": \"" + EntityWorldgenBindingUtility.EscapeJson(modId) + "\",\n" +
            "  \"bindings\": [\n" +
            "    { \"id\": \"entity.attributes\", \"dataModel\": \"entities[].health/movementSpeed/attackDamage\", \"ui\": \"Entity AI Editor\", \"generator\": \"generated-java/entity/*.java.stub\", \"validator\": \"entity_attributes_valid\" },\n" +
            "    { \"id\": \"entity.spawn\", \"dataModel\": \"entities[].spawnRule\", \"ui\": \"Entity Spawn Editor\", \"generator\": \"generated-java/spawn rules stub\", \"validator\": \"entity_spawn_valid\" },\n" +
            "    { \"id\": \"biome.json\", \"dataModel\": \"biomes[]\", \"ui\": \"Biome Pro Editor\", \"generator\": \"data/<modid>/worldgen/biome/*.json\", \"validator\": \"biome_json_valid\" },\n" +
            "    { \"id\": \"dimension.json\", \"dataModel\": \"dimensions[]\", \"ui\": \"Dimension Editor\", \"generator\": \"data/<modid>/dimension/*.json\", \"validator\": \"dimension_json_valid\" },\n" +
            "    { \"id\": \"structure.json\", \"dataModel\": \"structures[]\", \"ui\": \"Structure Editor\", \"generator\": \"data/<modid>/worldgen/structure*.json\", \"validator\": \"structure_json_valid\" }\n" +
            "  ]\n" +
            "}\n";
        EntityWorldgenBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/field-bindings/entity-worldgen-bindings.json"), manifest, report);
        report.bindingManifestsGenerated++;
    }

    private static void GenerateReport(string projectRoot, EntityWorldgenBindingReport report)
    {
        string path = Path.Combine(projectRoot, ".modstudio/reports/entity-worldgen-binding-report.txt");
        EntityWorldgenBindingUtility.WriteText(path, report.Format(), report);
    }
}
