using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

public static class EquipmentGameplayBindingUtility
{
    public static object GetMemberValue(object obj, string name)
    {
        if (obj == null || string.IsNullOrEmpty(name)) return null;
        Type t = obj.GetType();
        const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
        FieldInfo f = t.GetField(name, flags);
        if (f != null) return f.GetValue(obj);
        PropertyInfo p = t.GetProperty(name, flags);
        if (p != null && p.GetIndexParameters().Length == 0) return p.GetValue(obj, null);
        return null;
    }

    public static object GetFirstMemberValue(object obj, string[] names)
    {
        if (obj == null || names == null) return null;
        for (int i = 0; i < names.Length; i++)
        {
            object value = GetMemberValue(obj, names[i]);
            if (value != null) return value;
        }
        return null;
    }

    public static IEnumerable<object> AsEnumerable(object listObj)
    {
        if (listObj == null) yield break;
        IEnumerable enumerable = listObj as IEnumerable;
        if (enumerable == null) yield break;
        foreach (object item in enumerable)
        {
            if (item != null) yield return item;
        }
    }

    public static string GetFirstString(object obj, string[] names, string fallback)
    {
        object value = GetFirstMemberValue(obj, names);
        if (value == null) return fallback;
        string text = value.ToString();
        return string.IsNullOrEmpty(text) ? fallback : text;
    }

    public static int GetFirstInt(object obj, string[] names, int fallback)
    {
        object value = GetFirstMemberValue(obj, names);
        if (value == null) return fallback;
        try
        {
            if (value is int) return (int)value;
            if (value is long) return (int)(long)value;
            if (value is float) return (int)(float)value;
            if (value is double) return (int)(double)value;
            int parsed;
            if (int.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out parsed)) return parsed;
        }
        catch { }
        return fallback;
    }

    public static float GetFirstFloat(object obj, string[] names, float fallback)
    {
        object value = GetFirstMemberValue(obj, names);
        if (value == null) return fallback;
        try
        {
            if (value is float) return (float)value;
            if (value is double) return (float)(double)value;
            if (value is int) return (int)value;
            float parsed;
            if (float.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out parsed)) return parsed;
        }
        catch { }
        return fallback;
    }

    public static bool GetFirstBool(object obj, string[] names, bool fallback)
    {
        object value = GetFirstMemberValue(obj, names);
        if (value == null) return fallback;
        try
        {
            if (value is bool) return (bool)value;
            string s = value.ToString().Trim().ToLowerInvariant();
            if (s == "true" || s == "yes" || s == "1") return true;
            if (s == "false" || s == "no" || s == "0") return false;
        }
        catch { }
        return fallback;
    }

    public static object GetAdvanced(object obj)
    {
        return GetFirstMemberValue(obj, new string[] { "advanced", "settings", "pro", "config" });
    }

    public static string CleanId(string raw, string fallback)
    {
        if (string.IsNullOrEmpty(raw)) raw = fallback;
        raw = raw.Trim().ToLowerInvariant().Replace(' ', '_').Replace('-', '_');
        raw = Regex.Replace(raw, "[^a-z0-9_./:-]", "_");
        raw = raw.Replace(":", "_").Replace("/", "_").Replace(".", "_");
        raw = Regex.Replace(raw, "_+", "_").Trim('_');
        return string.IsNullOrEmpty(raw) ? fallback : raw;
    }

    public static string CleanResourceId(string raw, string fallback)
    {
        if (string.IsNullOrEmpty(raw)) raw = fallback;
        raw = raw.Trim().ToLowerInvariant().Replace(' ', '_');
        raw = Regex.Replace(raw, "[^a-z0-9_./:-]", "_");
        raw = Regex.Replace(raw, "_+", "_").Trim('_');
        return string.IsNullOrEmpty(raw) ? fallback : raw;
    }

    public static string ToPascalCase(string id)
    {
        id = CleanId(id, "generated");
        string[] parts = id.Split(new char[] { '_', '-', '.', '/', ':' }, StringSplitOptions.RemoveEmptyEntries);
        var sb = new StringBuilder();
        for (int i = 0; i < parts.Length; i++)
        {
            string p = parts[i];
            if (p.Length == 0) continue;
            sb.Append(char.ToUpperInvariant(p[0]));
            if (p.Length > 1) sb.Append(p.Substring(1));
        }
        return sb.Length == 0 ? "Generated" : sb.ToString();
    }

    public static string EscapeJson(string value)
    {
        if (value == null) return string.Empty;
        return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "\\n");
    }

    public static string F(float value)
    {
        return value.ToString("0.###", CultureInfo.InvariantCulture);
    }

    public static string GetPackageBase(string modId)
    {
        return "net." + CleanId(modId, "mymod").Replace("_", "");
    }

    public static string MakeLangName(string id)
    {
        id = CleanId(id, "generated");
        string[] parts = id.Split('_');
        var sb = new StringBuilder();
        for (int i = 0; i < parts.Length; i++)
        {
            if (parts[i].Length == 0) continue;
            if (sb.Length > 0) sb.Append(' ');
            sb.Append(char.ToUpperInvariant(parts[i][0]));
            if (parts[i].Length > 1) sb.Append(parts[i].Substring(1));
        }
        return sb.Length == 0 ? "Generated" : sb.ToString();
    }

    public static string EnsureObjectJson(string customJson, string fallbackJson)
    {
        if (string.IsNullOrWhiteSpace(customJson)) return fallbackJson;
        string trimmed = customJson.Trim();
        if (trimmed.StartsWith("{") && trimmed.EndsWith("}")) return trimmed;
        return fallbackJson;
    }

    public static void WriteText(string path, string text, EquipmentGameplayBindingReport report)
    {
        try
        {
            string dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
            File.WriteAllText(path, text == null ? string.Empty : text, Encoding.UTF8);
            if (report != null) report.AddGenerated(path);
        }
        catch (Exception ex)
        {
            if (report != null) report.AddError("Failed to write " + path + ": " + ex.Message);
        }
    }

    public static List<string> SplitCsv(string csv)
    {
        var result = new List<string>();
        if (string.IsNullOrEmpty(csv)) return result;
        string[] parts = csv.Replace("\r", "\n").Split(new char[] { ',', '\n', ';' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < parts.Length; i++)
        {
            string p = parts[i].Trim();
            if (p.Length > 0) result.Add(p);
        }
        return result;
    }

    public static string JsonStringArray(List<string> values)
    {
        if (values == null || values.Count == 0) return "[]";
        var sb = new StringBuilder();
        sb.Append("[");
        for (int i = 0; i < values.Count; i++)
        {
            if (i > 0) sb.Append(", ");
            sb.Append("\"").Append(EscapeJson(values[i])).Append("\"");
        }
        sb.Append("]");
        return sb.ToString();
    }
}
