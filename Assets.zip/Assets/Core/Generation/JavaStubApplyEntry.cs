using System;

[Serializable]
public class JavaStubApplyEntry
{
    public string loader;
    public string sourcePath;
    public string destinationPath;
    public string relativeJavaPath;
    public bool destinationExists;
    public bool willOverwrite;
    public bool skipped;
    public string skipReason;
}
