using System.Collections.Generic;
using System.Text;

public class AdvancementFunctionConfigBindingReport
{
    public int advancementsGenerated;
    public int functionsGenerated;
    public int functionTagsGenerated;
    public int configsGenerated;
    public int schemasGenerated;
    public int javaStubsGenerated;
    public int bindingsGenerated;

    public readonly List<string> generatedFiles = new List<string>();
    public readonly List<string> warnings = new List<string>();
    public readonly List<string> errors = new List<string>();

    public bool HasErrors
    {
        get { return errors.Count > 0; }
    }

    public void AddGenerated(string path)
    {
        if (!string.IsNullOrEmpty(path)) generatedFiles.Add(path);
    }

    public void AddWarning(string message)
    {
        if (!string.IsNullOrEmpty(message)) warnings.Add(message);
    }

    public void AddError(string message)
    {
        if (!string.IsNullOrEmpty(message)) errors.Add(message);
    }

    public string Format()
    {
        var sb = new StringBuilder();
        sb.AppendLine("Advancement / Function / Config Binding Report");
        sb.AppendLine("==============================================");
        sb.AppendLine("Advancements generated: " + advancementsGenerated);
        sb.AppendLine("Functions generated: " + functionsGenerated);
        sb.AppendLine("Function tags generated: " + functionTagsGenerated);
        sb.AppendLine("Configs generated: " + configsGenerated);
        sb.AppendLine("Config schemas generated: " + schemasGenerated);
        sb.AppendLine("Java stubs generated: " + javaStubsGenerated);
        sb.AppendLine("Bindings generated: " + bindingsGenerated);
        sb.AppendLine();

        if (warnings.Count > 0)
        {
            sb.AppendLine("Warnings:");
            for (int i = 0; i < warnings.Count; i++) sb.AppendLine("- " + warnings[i]);
            sb.AppendLine();
        }

        if (errors.Count > 0)
        {
            sb.AppendLine("Errors:");
            for (int i = 0; i < errors.Count; i++) sb.AppendLine("- " + errors[i]);
            sb.AppendLine();
        }

        if (generatedFiles.Count > 0)
        {
            sb.AppendLine("Generated files:");
            for (int i = 0; i < generatedFiles.Count; i++) sb.AppendLine("- " + generatedFiles[i]);
        }

        return sb.ToString();
    }
}
