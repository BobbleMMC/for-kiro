using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class JavaStubApplyResult
{
    public bool success;
    public string projectRoot;
    public string generatedRoot;
    public string backupRoot;
    public string reportPath;
    public readonly List<JavaStubApplyEntry> entries = new List<JavaStubApplyEntry>();
    public readonly List<string> errors = new List<string>();
    public readonly List<string> warnings = new List<string>();

    public int DiscoveredCount
    {
        get { return entries.Count; }
    }

    public int WillWriteCount
    {
        get
        {
            int count = 0;
            foreach (var entry in entries)
                if (entry != null && !entry.skipped) count++;
            return count;
        }
    }

    public int SkippedCount
    {
        get
        {
            int count = 0;
            foreach (var entry in entries)
                if (entry != null && entry.skipped) count++;
            return count;
        }
    }

    public string FormatSummary()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("JAVA STUB APPLY REPORT");
        sb.AppendLine("======================");
        sb.AppendLine("Project: " + projectRoot);
        sb.AppendLine("Generated root: " + generatedRoot);
        sb.AppendLine("Backup root: " + (string.IsNullOrEmpty(backupRoot) ? "none" : backupRoot));
        sb.AppendLine("Success: " + success);
        sb.AppendLine("Discovered: " + DiscoveredCount);
        sb.AppendLine("Will write / written: " + WillWriteCount);
        sb.AppendLine("Skipped: " + SkippedCount);
        sb.AppendLine();

        if (errors.Count > 0)
        {
            sb.AppendLine("ERRORS:");
            foreach (string error in errors) sb.AppendLine("  - " + error);
            sb.AppendLine();
        }

        if (warnings.Count > 0)
        {
            sb.AppendLine("WARNINGS:");
            foreach (string warning in warnings) sb.AppendLine("  - " + warning);
            sb.AppendLine();
        }

        sb.AppendLine("FILES:");
        foreach (var entry in entries)
        {
            if (entry == null) continue;
            string status = entry.skipped ? "SKIP" : (entry.destinationExists ? "OVERWRITE" : "CREATE");
            sb.AppendLine("  [" + status + "] " + entry.relativeJavaPath);
            sb.AppendLine("      from: " + entry.sourcePath);
            sb.AppendLine("      to:   " + entry.destinationPath);
            if (entry.skipped && !string.IsNullOrEmpty(entry.skipReason))
                sb.AppendLine("      reason: " + entry.skipReason);
        }

        if (!string.IsNullOrEmpty(reportPath))
        {
            sb.AppendLine();
            sb.AppendLine("Report path: " + reportPath);
        }

        return sb.ToString();
    }
}
