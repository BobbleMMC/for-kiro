using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

public static class AdvancementFunctionConfigBindingGenerator
{
    public static AdvancementFunctionConfigBindingReport Generate(object workspace, string projectRoot, string modId)
    {
        var report = new AdvancementFunctionConfigBindingReport();
        if (string.IsNullOrEmpty(projectRoot))
        {
            report.AddError("Project root is empty. Select exported Minecraft project root first.");
            return report;
        }

        projectRoot = Path.GetFullPath(projectRoot);
        modId = AdvancementFunctionConfigBindingUtility.CleanId(modId, "mymod");

        if (workspace == null)
        {
            report.AddWarning("Workspace object is null. Only field binding catalog can be exported.");
        }

        GenerateAdvancements(workspace, projectRoot, modId, report);
        GenerateFunctions(workspace, projectRoot, modId, report);
        GenerateConfigs(workspace, projectRoot, modId, report);
        GenerateBindingManifest(projectRoot, modId, report);
        GenerateReport(projectRoot, report);
        return report;
    }

    private static void GenerateAdvancements(object workspace, string projectRoot, string modId, AdvancementFunctionConfigBindingReport report)
    {
        object listObj = AdvancementFunctionConfigBindingUtility.GetFirstMemberValue(workspace, new string[] { "advancements", "advancementData", "advancementList" });
        int index = 0;
        foreach (object adv in AdvancementFunctionConfigBindingUtility.AsEnumerable(listObj))
        {
            index++;
            if (!AdvancementFunctionConfigBindingUtility.IsEnabled(adv, true)) continue;

            string id = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "advancementId", "id", "name" }, "advancement_" + index);
            id = AdvancementFunctionConfigBindingUtility.CleanResourcePath(id, "advancement_" + index);
            string display = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "displayName", "title", "name" }, AdvancementFunctionConfigBindingUtility.MakeLangName(id));
            string description = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "description", "desc" }, "Generated advancement");
            string customJson = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "customJsonOverride", "customJson", "jsonOverride" }, string.Empty);

            string json = TryCallStringMethod(adv, "GenerateJson", new object[] { modId });
            if (string.IsNullOrWhiteSpace(json)) json = GenerateAdvancementJson(adv, modId, id, display, description, customJson);

            AdvancementFunctionConfigBindingUtility.WriteText(Path.Combine(projectRoot, "src/main/resources/data", modId, "advancements", id + ".json"), json, report);
            WriteLangPatch(projectRoot, modId, "advancement." + modId + "." + id + ".title", display, report);
            WriteLangPatch(projectRoot, modId, "advancement." + modId + "." + id + ".description", description, report);
            WriteDescriptor(projectRoot, "advancements", id + ".advancement.json", BuildAdvancementDescriptor(modId, id, display), report);
            WriteBinding(projectRoot, "advancement", id, "data/" + modId + "/advancements/" + id + ".json", report);
            report.advancementsGenerated++;
        }
    }

    private static string GenerateAdvancementJson(object adv, string modId, string id, string display, string description, string customJson)
    {
        if (!string.IsNullOrWhiteSpace(customJson)) return AdvancementFunctionConfigBindingUtility.EnsureObjectJson(customJson, "{}");
        string icon = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "iconItem", "icon", "item" }, "minecraft:diamond");
        string frame = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "frameType", "frame" }, "task").ToLowerInvariant();
        string parent = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "parent", "parentId" }, string.Empty);
        bool showToast = AdvancementFunctionConfigBindingUtility.GetFirstBool(adv, new string[] { "showToast" }, true);
        bool announce = AdvancementFunctionConfigBindingUtility.GetFirstBool(adv, new string[] { "announceToChat" }, true);
        bool hidden = AdvancementFunctionConfigBindingUtility.GetFirstBool(adv, new string[] { "hidden" }, false);
        int xp = AdvancementFunctionConfigBindingUtility.GetFirstInt(adv, new string[] { "rewardExperience", "experience", "xp" }, 0);
        string criterion = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "criteriaCsv", "criteria", "criterion" }, "has_item:minecraft:inventory_changed:minecraft:diamond");
        string[] parts = criterion.Split(':');
        string criterionId = parts.Length > 0 && !string.IsNullOrWhiteSpace(parts[0]) ? AdvancementFunctionConfigBindingUtility.CleanId(parts[0], "has_item") : "has_item";
        string trigger = parts.Length > 1 && !string.IsNullOrWhiteSpace(parts[1]) ? parts[1] : "minecraft:inventory_changed";

        var sb = new StringBuilder();
        sb.AppendLine("{");
        if (!string.IsNullOrWhiteSpace(parent)) sb.AppendLine("  \"parent\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(parent.Trim()) + "\",");
        sb.AppendLine("  \"display\": {");
        sb.AppendLine("    \"icon\": { \"item\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(icon) + "\" },");
        sb.AppendLine("    \"title\": { \"translate\": \"advancement." + modId + "." + id + ".title\" },");
        sb.AppendLine("    \"description\": { \"translate\": \"advancement." + modId + "." + id + ".description\" },");
        sb.AppendLine("    \"frame\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(frame) + "\",");
        sb.AppendLine("    \"show_toast\": " + (showToast ? "true" : "false") + ",");
        sb.AppendLine("    \"announce_to_chat\": " + (announce ? "true" : "false") + ",");
        sb.AppendLine("    \"hidden\": " + (hidden ? "true" : "false"));
        sb.AppendLine("  },");
        sb.AppendLine("  \"criteria\": {");
        sb.AppendLine("    \"" + criterionId + "\": { \"trigger\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(trigger) + "\" }");
        sb.AppendLine("  },");
        sb.AppendLine("  \"rewards\": { \"experience\": " + xp + " }");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string BuildAdvancementDescriptor(string modId, string id, string display)
    {
        return "{\n" +
            "  \"kind\": \"advancement\",\n" +
            "  \"id\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(modId + ":" + id) + "\",\n" +
            "  \"displayName\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(display) + "\"\n" +
            "}\n";
    }

    private static void GenerateFunctions(object workspace, string projectRoot, string modId, AdvancementFunctionConfigBindingReport report)
    {
        object listObj = AdvancementFunctionConfigBindingUtility.GetFirstMemberValue(workspace, new string[] { "functions", "functionFiles", "mcFunctions", "commandFunctions" });
        var loadFunctions = new List<string>();
        var tickFunctions = new List<string>();
        int index = 0;
        foreach (object fn in AdvancementFunctionConfigBindingUtility.AsEnumerable(listObj))
        {
            index++;
            if (!AdvancementFunctionConfigBindingUtility.IsEnabled(fn, true)) continue;

            string ns = AdvancementFunctionConfigBindingUtility.GetFirstString(fn, new string[] { "namespaceId", "namespace", "modId" }, modId);
            ns = AdvancementFunctionConfigBindingUtility.CleanResourcePath(string.IsNullOrWhiteSpace(ns) ? modId : ns, modId);
            string id = AdvancementFunctionConfigBindingUtility.GetFirstString(fn, new string[] { "functionId", "id", "name" }, "function_" + index);
            id = AdvancementFunctionConfigBindingUtility.CleanResourcePath(id, "function_" + index);
            string commands = TryCallStringMethod(fn, "GenerateMcFunction", new object[0]);
            if (string.IsNullOrEmpty(commands)) commands = AdvancementFunctionConfigBindingUtility.NormalizeFunctionText(AdvancementFunctionConfigBindingUtility.GetFirstString(fn, new string[] { "commandsText", "commands", "body" }, "# Generated by Mod Studio"));
            bool addLoad = AdvancementFunctionConfigBindingUtility.GetFirstBool(fn, new string[] { "addToLoadTag", "load", "runOnLoad" }, false);
            bool addTick = AdvancementFunctionConfigBindingUtility.GetFirstBool(fn, new string[] { "addToTickTag", "tick", "runEveryTick" }, false);

            string path = Path.Combine(projectRoot, "src/main/resources/data", ns, "functions", id + ".mcfunction");
            AdvancementFunctionConfigBindingUtility.WriteText(path, commands, report);
            WriteDescriptor(projectRoot, "functions", id + ".function.json", BuildFunctionDescriptor(ns, id, addLoad, addTick), report);
            WriteFunctionJavaStub(projectRoot, modId, ns, id, addLoad, addTick, report);
            WriteBinding(projectRoot, "function", id, "data/" + ns + "/functions/" + id + ".mcfunction", report);
            if (addLoad) loadFunctions.Add(ns + ":" + id);
            if (addTick) tickFunctions.Add(ns + ":" + id);
            report.functionsGenerated++;
        }

        if (loadFunctions.Count > 0)
        {
            WriteFunctionTag(projectRoot, "load", loadFunctions, report);
        }
        if (tickFunctions.Count > 0)
        {
            WriteFunctionTag(projectRoot, "tick", tickFunctions, report);
        }
    }

    private static string BuildFunctionDescriptor(string ns, string id, bool load, bool tick)
    {
        return "{\n" +
            "  \"kind\": \"function\",\n" +
            "  \"id\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(ns + ":" + id) + "\",\n" +
            "  \"addToLoadTag\": " + (load ? "true" : "false") + ",\n" +
            "  \"addToTickTag\": " + (tick ? "true" : "false") + "\n" +
            "}\n";
    }

    private static void WriteFunctionTag(string projectRoot, string tag, List<string> values, AdvancementFunctionConfigBindingReport report)
    {
        string json = "{\n  \"values\": " + AdvancementFunctionConfigBindingUtility.JsonStringArray(values) + "\n}\n";
        AdvancementFunctionConfigBindingUtility.WriteText(Path.Combine(projectRoot, "src/main/resources/data/minecraft/tags/functions", tag + ".json"), json, report);
        report.functionTagsGenerated++;
    }

    private static void WriteFunctionJavaStub(string projectRoot, string modId, string ns, string id, bool load, bool tick, AdvancementFunctionConfigBindingReport report)
    {
        string packageBase = AdvancementFunctionConfigBindingUtility.GetPackageBase(modId);
        string packagePath = packageBase.Replace('.', '/');
        string className = AdvancementFunctionConfigBindingUtility.ToPascalCase(id) + "FunctionBindingStub";
        string text = "package " + packageBase + ".function;\n\n" +
            "// Generated stub by Mod Studio Patch 32. Review before applying.\n" +
            "public final class " + className + " {\n" +
            "    public static final String ID = \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(ns + ":" + id) + "\";\n" +
            "    public static final boolean LOAD_TAG = " + (load ? "true" : "false") + ";\n" +
            "    public static final boolean TICK_TAG = " + (tick ? "true" : "false") + ";\n" +
            "}\n";
        AdvancementFunctionConfigBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/generated-java/advancement-function-config", packagePath, "function", className + ".java.stub"), text, report);
        report.javaStubsGenerated++;
    }

    private static void GenerateConfigs(object workspace, string projectRoot, string modId, AdvancementFunctionConfigBindingReport report)
    {
        object listObj = AdvancementFunctionConfigBindingUtility.GetFirstMemberValue(workspace, new string[] { "configs", "configFiles", "configuration" });
        int index = 0;
        foreach (object cfg in AdvancementFunctionConfigBindingUtility.AsEnumerable(listObj))
        {
            index++;
            if (!AdvancementFunctionConfigBindingUtility.IsEnabled(cfg, true)) continue;

            string id = AdvancementFunctionConfigBindingUtility.GetFirstString(cfg, new string[] { "configId", "id", "name" }, "config_" + index);
            id = AdvancementFunctionConfigBindingUtility.CleanId(id, "config_" + index);
            string format = AdvancementFunctionConfigBindingUtility.GetFirstString(cfg, new string[] { "format", "configFormat" }, "Json");
            string fileName = AdvancementFunctionConfigBindingUtility.GetFirstString(cfg, new string[] { "fileName", "path" }, modId + "-common." + ExtensionForFormat(format));
            if (string.IsNullOrWhiteSpace(Path.GetExtension(fileName))) fileName += "." + ExtensionForFormat(format);
            string configText = TryCallStringMethod(cfg, "GenerateConfigText", new object[] { modId });
            if (string.IsNullOrWhiteSpace(configText)) configText = GenerateConfigText(cfg, format);
            string schema = TryCallStringMethod(cfg, "GenerateSchemaJson", new object[] { modId });
            if (string.IsNullOrWhiteSpace(schema)) schema = GenerateConfigSchema(cfg, id, format);

            AdvancementFunctionConfigBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/config", fileName), configText, report);
            report.configsGenerated++;
            AdvancementFunctionConfigBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/config/schemas", id + ".schema.json"), schema, report);
            report.schemasGenerated++;
            WriteConfigJavaStub(projectRoot, modId, id, fileName, format, report);
            WriteBinding(projectRoot, "config", id, ".modstudio/config/" + fileName, report);
        }
    }

    private static string GenerateConfigText(object cfg, string format)
    {
        string custom = AdvancementFunctionConfigBindingUtility.GetFirstString(cfg, new string[] { "customConfigText", "customText", "overrideText" }, string.Empty);
        if (!string.IsNullOrWhiteSpace(custom)) return custom;
        string entries = AdvancementFunctionConfigBindingUtility.GetFirstString(cfg, new string[] { "entriesCsv", "entries", "configEntries" }, "enabled:Boolean:true");
        List<string> rows = AdvancementFunctionConfigBindingUtility.SplitCsv(entries);
        if (format.ToLowerInvariant().Contains("toml"))
        {
            var sbToml = new StringBuilder();
            sbToml.AppendLine("# Generated by Mod Studio");
            for (int i = 0; i < rows.Count; i++) sbToml.AppendLine(ParseConfigKeyValue(rows[i], " = "));
            return sbToml.ToString();
        }
        if (format.ToLowerInvariant().Contains("propert"))
        {
            var sbProps = new StringBuilder();
            sbProps.AppendLine("# Generated by Mod Studio");
            for (int i = 0; i < rows.Count; i++) sbProps.AppendLine(ParseConfigKeyValue(rows[i], "="));
            return sbProps.ToString();
        }
        var sb = new StringBuilder();
        sb.AppendLine("{");
        for (int i = 0; i < rows.Count; i++)
        {
            string[] bits = rows[i].Split(':');
            string key = bits.Length > 0 ? AdvancementFunctionConfigBindingUtility.CleanId(bits[0], "entry_" + i) : "entry_" + i;
            string type = bits.Length > 1 ? bits[1].Trim().ToLowerInvariant() : "string";
            string value = bits.Length > 2 ? bits[2].Trim() : "";
            sb.Append("  \"").Append(AdvancementFunctionConfigBindingUtility.EscapeJson(key)).Append("\": ");
            if (type.Contains("bool")) sb.Append(value.ToLowerInvariant() == "true" ? "true" : "false");
            else if (type.Contains("int") || type.Contains("float") || type.Contains("double")) sb.Append(string.IsNullOrWhiteSpace(value) ? "0" : value);
            else sb.Append("\"").Append(AdvancementFunctionConfigBindingUtility.EscapeJson(value)).Append("\"");
            sb.AppendLine(i < rows.Count - 1 ? "," : "");
        }
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string ParseConfigKeyValue(string row, string sep)
    {
        string[] bits = row.Split(':');
        string key = bits.Length > 0 ? AdvancementFunctionConfigBindingUtility.CleanId(bits[0], "entry") : "entry";
        string value = bits.Length > 2 ? bits[2].Trim() : (bits.Length > 1 ? bits[1].Trim() : "true");
        if (value.Length == 0) value = "true";
        return key + sep + value;
    }

    private static string GenerateConfigSchema(object cfg, string id, string format)
    {
        string entries = AdvancementFunctionConfigBindingUtility.GetFirstString(cfg, new string[] { "entriesCsv", "entries", "configEntries" }, "");
        return "{\n" +
            "  \"id\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(id) + "\",\n" +
            "  \"format\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(format) + "\",\n" +
            "  \"entriesCsv\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(entries) + "\"\n" +
            "}\n";
    }

    private static string ExtensionForFormat(string format)
    {
        string f = string.IsNullOrEmpty(format) ? "json" : format.ToLowerInvariant();
        if (f.Contains("toml")) return "toml";
        if (f.Contains("propert")) return "properties";
        return "json";
    }

    private static void WriteConfigJavaStub(string projectRoot, string modId, string id, string fileName, string format, AdvancementFunctionConfigBindingReport report)
    {
        string packageBase = AdvancementFunctionConfigBindingUtility.GetPackageBase(modId);
        string packagePath = packageBase.Replace('.', '/');
        string className = AdvancementFunctionConfigBindingUtility.ToPascalCase(id) + "ConfigBindingStub";
        string text = "package " + packageBase + ".config;\n\n" +
            "// Generated config binding stub by Mod Studio Patch 32.\n" +
            "public final class " + className + " {\n" +
            "    public static final String FILE_NAME = \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(fileName) + "\";\n" +
            "    public static final String FORMAT = \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(format) + "\";\n" +
            "}\n";
        AdvancementFunctionConfigBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/generated-java/advancement-function-config", packagePath, "config", className + ".java.stub"), text, report);
        report.javaStubsGenerated++;
    }

    private static void WriteLangPatch(string projectRoot, string modId, string key, string value, AdvancementFunctionConfigBindingReport report)
    {
        string path = Path.Combine(projectRoot, "src/main/resources/assets", modId, "lang", "en_us.json");
        var map = new SortedDictionary<string, string>();
        if (File.Exists(path))
        {
            string existing = File.ReadAllText(path);
            foreach (System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(existing, "\\\"([^\\\"]+)\\\"\\s*:\\s*\\\"([^\\\"]*)\\\""))
            {
                map[m.Groups[1].Value] = m.Groups[2].Value;
            }
        }
        map[key] = value;
        var sb = new StringBuilder();
        sb.AppendLine("{");
        int i = 0;
        foreach (var kv in map)
        {
            sb.Append("  \"").Append(AdvancementFunctionConfigBindingUtility.EscapeJson(kv.Key)).Append("\": \"").Append(AdvancementFunctionConfigBindingUtility.EscapeJson(kv.Value)).Append("\"");
            sb.AppendLine(i < map.Count - 1 ? "," : "");
            i++;
        }
        sb.AppendLine("}");
        AdvancementFunctionConfigBindingUtility.WriteText(path, sb.ToString(), report);
    }

    private static void WriteDescriptor(string projectRoot, string folder, string fileName, string json, AdvancementFunctionConfigBindingReport report)
    {
        AdvancementFunctionConfigBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio", folder, fileName), json, report);
    }

    private static void WriteBinding(string projectRoot, string kind, string id, string target, AdvancementFunctionConfigBindingReport report)
    {
        string json = "{\n" +
            "  \"kind\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(kind) + "\",\n" +
            "  \"id\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(id) + "\",\n" +
            "  \"target\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(target) + "\",\n" +
            "  \"bindingChain\": [\"DataModel\", \"UI Editor\", \"Generator/PatchEngine\", \"Validator\"]\n" +
            "}\n";
        AdvancementFunctionConfigBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/advancement-function-config-binding", kind + "_" + id + ".binding.json"), json, report);
        report.bindingsGenerated++;
    }

    private static void GenerateBindingManifest(string projectRoot, string modId, AdvancementFunctionConfigBindingReport report)
    {
        string json = "{\n" +
            "  \"modId\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(modId) + "\",\n" +
            "  \"patch\": 32,\n" +
            "  \"scope\": \"advancement-function-config\",\n" +
            "  \"chain\": [\"DataModel\", \"UI Editor\", \"Generator/PatchEngine\", \"Validator\"]\n" +
            "}\n";
        AdvancementFunctionConfigBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/field-bindings/advancement-function-config-bindings.json"), json, report);
    }

    private static void GenerateReport(string projectRoot, AdvancementFunctionConfigBindingReport report)
    {
        AdvancementFunctionConfigBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/reports/advancement-function-config-binding-report.txt"), report.Format(), report);
    }

    private static string TryCallStringMethod(object target, string methodName, object[] args)
    {
        if (target == null) return null;
        try
        {
            MethodInfo method = target.GetType().GetMethod(methodName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (method == null) return null;
            object result = method.Invoke(target, args);
            return result as string;
        }
        catch { return null; }
    }
}
