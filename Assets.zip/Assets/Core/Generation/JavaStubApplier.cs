using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

public static class JavaStubApplier
{
    public static JavaStubApplyResult Preview(JavaStubApplyRequest request)
    {
        if (request == null) request = new JavaStubApplyRequest();
        request.dryRun = true;
        return Execute(request);
    }

    public static JavaStubApplyResult Apply(JavaStubApplyRequest request)
    {
        if (request == null) request = new JavaStubApplyRequest();
        request.dryRun = false;
        return Execute(request);
    }

    private static JavaStubApplyResult Execute(JavaStubApplyRequest request)
    {
        JavaStubApplyResult result = new JavaStubApplyResult();
        string projectRoot = NormalizeFullPath(request.projectRoot);
        result.projectRoot = projectRoot;

        if (string.IsNullOrEmpty(projectRoot) || !Directory.Exists(projectRoot))
        {
            result.errors.Add("Project root does not exist: " + request.projectRoot);
            result.success = false;
            return result;
        }

        string generatedRoot = Path.Combine(projectRoot, ".modstudio", "generated-java");
        result.generatedRoot = generatedRoot;
        if (!Directory.Exists(generatedRoot))
        {
            result.errors.Add("Generated Java stubs folder not found. Run Save/Export first: " + generatedRoot);
            result.success = false;
            return result;
        }

        string srcMainJava = Path.Combine(projectRoot, "src", "main", "java");
        if (!request.dryRun && !Directory.Exists(srcMainJava)) Directory.CreateDirectory(srcMainJava);

        DiscoverEntries(result, generatedRoot, srcMainJava, request.overwriteExisting);

        if (result.entries.Count == 0)
        {
            result.warnings.Add("No .java.stub files found under: " + generatedRoot);
        }

        if (!request.dryRun && result.entries.Count > 0)
        {
            if (request.backupExisting)
            {
                result.backupRoot = CreateBackupRoot(projectRoot);
            }

            foreach (var entry in result.entries)
            {
                if (entry == null || entry.skipped) continue;
                TryApplyEntry(entry, result, projectRoot, result.backupRoot, request.backupExisting);
            }
        }

        result.success = result.errors.Count == 0;

        if (request.writeReport)
        {
            WriteReport(projectRoot, result, request.dryRun);
        }

        return result;
    }

    private static void DiscoverEntries(JavaStubApplyResult result, string generatedRoot, string srcMainJava, bool overwriteExisting)
    {
        string[] stubs = Directory.GetFiles(generatedRoot, "*.java.stub", SearchOption.AllDirectories);
        Array.Sort(stubs, StringComparer.OrdinalIgnoreCase);

        foreach (string stub in stubs)
        {
            JavaStubApplyEntry entry = BuildEntry(generatedRoot, srcMainJava, stub, overwriteExisting);
            if (entry == null) continue;
            result.entries.Add(entry);
        }
    }

    private static JavaStubApplyEntry BuildEntry(string generatedRoot, string srcMainJava, string stubPath, bool overwriteExisting)
    {
        string fullStub = NormalizeFullPath(stubPath);
        string fullGeneratedRoot = EnsureTrailingSeparator(NormalizeFullPath(generatedRoot));
        if (!fullStub.StartsWith(fullGeneratedRoot, StringComparison.OrdinalIgnoreCase)) return null;

        string rel = fullStub.Substring(fullGeneratedRoot.Length);
        string[] parts = rel.Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        if (parts.Length < 2) return null;

        string loader = parts[0];
        string javaRel = rel.Substring(loader.Length).TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        if (!javaRel.EndsWith(".java.stub", StringComparison.OrdinalIgnoreCase)) return null;
        javaRel = javaRel.Substring(0, javaRel.Length - ".stub".Length);

        string destination = NormalizeFullPath(Path.Combine(srcMainJava, javaRel));
        bool exists = File.Exists(destination);
        bool skipped = false;
        string reason = "";

        if (exists && !overwriteExisting)
        {
            skipped = true;
            reason = "Destination exists and overwrite is disabled.";
        }

        if (!IsInsideDirectory(destination, srcMainJava))
        {
            skipped = true;
            reason = "Blocked by path sandbox: destination is outside src/main/java.";
        }

        return new JavaStubApplyEntry
        {
            loader = loader,
            sourcePath = fullStub,
            destinationPath = destination,
            relativeJavaPath = ToForwardSlash(javaRel),
            destinationExists = exists,
            willOverwrite = exists && overwriteExisting,
            skipped = skipped,
            skipReason = reason
        };
    }

    private static void TryApplyEntry(JavaStubApplyEntry entry, JavaStubApplyResult result, string projectRoot, string backupRoot, bool backupExisting)
    {
        try
        {
            if (File.Exists(entry.destinationPath) && backupExisting && !string.IsNullOrEmpty(backupRoot))
            {
                BackupExistingFile(projectRoot, entry.destinationPath, backupRoot);
            }

            string content = File.ReadAllText(entry.sourcePath);
            content = content.Replace("// This is a .java.stub preview. Copy into src/main/java only after checking imports for your exact loader/version.",
                                      "// Applied from Mod Studio .java.stub. Review imports for your exact loader/version before production release.");

            string dir = Path.GetDirectoryName(entry.destinationPath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
            File.WriteAllText(entry.destinationPath, content, new UTF8Encoding(false));
        }
        catch (Exception ex)
        {
            entry.skipped = true;
            entry.skipReason = "Apply failed: " + ex.Message;
            result.errors.Add("Failed to apply " + entry.relativeJavaPath + ": " + ex.Message);
        }
    }

    private static string CreateBackupRoot(string projectRoot)
    {
        string stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string backupRoot = Path.Combine(projectRoot, ".modstudio", "backups", "java-stubs-" + stamp);
        Directory.CreateDirectory(backupRoot);
        return backupRoot;
    }

    private static void BackupExistingFile(string projectRoot, string destinationPath, string backupRoot)
    {
        string srcMainJava = Path.Combine(projectRoot, "src", "main", "java");
        string rel = MakeRelativePath(srcMainJava, destinationPath);
        string backupPath = Path.Combine(backupRoot, "src", "main", "java", rel);
        string dir = Path.GetDirectoryName(backupPath);
        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
        File.Copy(destinationPath, backupPath, true);
    }

    private static void WriteReport(string projectRoot, JavaStubApplyResult result, bool dryRun)
    {
        try
        {
            string reportDir = Path.Combine(projectRoot, ".modstudio", "reports");
            Directory.CreateDirectory(reportDir);
            string name = dryRun ? "java-stub-preview-report.txt" : "java-stub-apply-report.txt";
            string path = Path.Combine(reportDir, name);
            result.reportPath = path;
            File.WriteAllText(path, result.FormatSummary(), new UTF8Encoding(false));

            string manifestPath = Path.Combine(reportDir, dryRun ? "java-stub-preview-manifest.json" : "java-stub-apply-manifest.json");
            File.WriteAllText(manifestPath, GenerateManifest(result, dryRun), new UTF8Encoding(false));
        }
        catch (Exception ex)
        {
            result.warnings.Add("Could not write report: " + ex.Message);
        }
    }

    private static string GenerateManifest(JavaStubApplyResult result, bool dryRun)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"dryRun\": " + JsonBool(dryRun) + ",");
        sb.AppendLine("  \"success\": " + JsonBool(result.success) + ",");
        sb.AppendLine("  \"projectRoot\": \"" + JsonEscape(result.projectRoot) + "\",");
        sb.AppendLine("  \"generatedRoot\": \"" + JsonEscape(result.generatedRoot) + "\",");
        sb.AppendLine("  \"backupRoot\": \"" + JsonEscape(result.backupRoot) + "\",");
        sb.AppendLine("  \"entries\": [");
        for (int i = 0; i < result.entries.Count; i++)
        {
            var e = result.entries[i];
            sb.AppendLine("    {");
            sb.AppendLine("      \"loader\": \"" + JsonEscape(e.loader) + "\",");
            sb.AppendLine("      \"relativeJavaPath\": \"" + JsonEscape(e.relativeJavaPath) + "\",");
            sb.AppendLine("      \"sourcePath\": \"" + JsonEscape(e.sourcePath) + "\",");
            sb.AppendLine("      \"destinationPath\": \"" + JsonEscape(e.destinationPath) + "\",");
            sb.AppendLine("      \"destinationExists\": " + JsonBool(e.destinationExists) + ",");
            sb.AppendLine("      \"willOverwrite\": " + JsonBool(e.willOverwrite) + ",");
            sb.AppendLine("      \"skipped\": " + JsonBool(e.skipped) + ",");
            sb.AppendLine("      \"skipReason\": \"" + JsonEscape(e.skipReason) + "\"");
            sb.Append("    }");
            if (i < result.entries.Count - 1) sb.Append(",");
            sb.AppendLine();
        }
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static bool IsInsideDirectory(string path, string directory)
    {
        string p = NormalizeFullPath(path);
        string d = EnsureTrailingSeparator(NormalizeFullPath(directory));
        return p.StartsWith(d, StringComparison.OrdinalIgnoreCase);
    }

    private static string MakeRelativePath(string root, string path)
    {
        Uri rootUri = new Uri(EnsureTrailingSeparator(NormalizeFullPath(root)));
        Uri pathUri = new Uri(NormalizeFullPath(path));
        return Uri.UnescapeDataString(rootUri.MakeRelativeUri(pathUri).ToString()).Replace('/', Path.DirectorySeparatorChar);
    }

    private static string NormalizeFullPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) return "";
        return Path.GetFullPath(path.Replace('\\', Path.DirectorySeparatorChar).Replace('/', Path.DirectorySeparatorChar));
    }

    private static string EnsureTrailingSeparator(string path)
    {
        if (string.IsNullOrEmpty(path)) return path;
        if (!path.EndsWith(Path.DirectorySeparatorChar.ToString())) return path + Path.DirectorySeparatorChar;
        return path;
    }

    private static string ToForwardSlash(string value)
    {
        return (value ?? "").Replace('\\', '/');
    }

    private static string JsonEscape(string value)
    {
        return (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
    }

    private static string JsonBool(bool value)
    {
        return value ? "true" : "false";
    }
}
