using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

public static class RecipeLootTagBindingUtility
{
    public static string CleanId(string value, string fallback)
    {
        if (string.IsNullOrEmpty(value)) value = fallback;
        value = value.Trim().ToLowerInvariant();
        value = Regex.Replace(value, @"[^a-z0-9_./-]", "_");
        value = value.Replace("//", "/");
        if (string.IsNullOrEmpty(value)) value = fallback;
        return value;
    }

    public static string CleanFileId(string value, string fallback)
    {
        string id = CleanId(value, fallback);
        id = id.Replace("/", "_").Replace(".", "_").Replace("-", "_");
        return id;
    }

    public static string EscapeJson(string value)
    {
        if (value == null) return string.Empty;
        return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n");
    }

    public static string EnsureObjectJson(string json, string fallback)
    {
        if (string.IsNullOrWhiteSpace(json)) return fallback;
        string t = json.Trim();
        if (t.StartsWith("{") && t.EndsWith("}")) return t;
        return fallback;
    }

    public static void WriteText(string path, string content, RecipeLootTagBindingReport report)
    {
        try
        {
            string dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            File.WriteAllText(path, content, Encoding.UTF8);
            if (report != null) report.AddGenerated(path);
        }
        catch (Exception ex)
        {
            if (report != null) report.AddError("Failed to write " + path + ": " + ex.Message);
        }
    }

    public static object GetMemberValue(object target, string memberName)
    {
        if (target == null || string.IsNullOrEmpty(memberName)) return null;
        Type type = target.GetType();
        const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

        FieldInfo field = type.GetField(memberName, flags);
        if (field != null) return field.GetValue(target);

        PropertyInfo prop = type.GetProperty(memberName, flags);
        if (prop != null && prop.GetIndexParameters().Length == 0) return prop.GetValue(target, null);

        return null;
    }

    public static string GetString(object target, string memberName, string fallback)
    {
        object value = GetMemberValue(target, memberName);
        if (value == null) return fallback;
        string s = Convert.ToString(value);
        return string.IsNullOrEmpty(s) ? fallback : s;
    }

    public static bool GetBool(object target, string memberName, bool fallback)
    {
        object value = GetMemberValue(target, memberName);
        if (value == null) return fallback;
        if (value is bool) return (bool)value;
        bool parsed;
        return bool.TryParse(Convert.ToString(value), out parsed) ? parsed : fallback;
    }

    public static int GetInt(object target, string memberName, int fallback)
    {
        object value = GetMemberValue(target, memberName);
        if (value == null) return fallback;
        try { return Convert.ToInt32(value); } catch { return fallback; }
    }

    public static float GetFloat(object target, string memberName, float fallback)
    {
        object value = GetMemberValue(target, memberName);
        if (value == null) return fallback;
        try { return Convert.ToSingle(value); } catch { return fallback; }
    }

    public static IEnumerable AsEnumerable(object value)
    {
        if (value == null) yield break;
        IEnumerable enumerable = value as IEnumerable;
        if (enumerable == null || value is string) yield break;
        foreach (object item in enumerable) yield return item;
    }

    public static List<string> SplitCsvOrLines(string value)
    {
        var result = new List<string>();
        if (string.IsNullOrEmpty(value)) return result;
        string[] parts = value.Replace("\r", "\n").Split(new char[] { ',', '\n', ';' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < parts.Length; i++)
        {
            string p = parts[i].Trim();
            if (!string.IsNullOrEmpty(p)) result.Add(p);
        }
        return result;
    }

    public static string ListToJsonArray(List<string> values)
    {
        var sb = new StringBuilder();
        sb.Append("[");
        for (int i = 0; i < values.Count; i++)
        {
            if (i > 0) sb.Append(", ");
            sb.Append("\"").Append(EscapeJson(values[i])).Append("\"");
        }
        sb.Append("]");
        return sb.ToString();
    }

    public static string PrettyNameFromId(string id)
    {
        if (string.IsNullOrEmpty(id)) return "Unnamed";
        string[] parts = id.Replace('/', '_').Replace('-', '_').Split('_');
        var sb = new StringBuilder();
        for (int i = 0; i < parts.Length; i++)
        {
            if (string.IsNullOrEmpty(parts[i])) continue;
            if (sb.Length > 0) sb.Append(' ');
            string p = parts[i];
            sb.Append(char.ToUpperInvariant(p[0]));
            if (p.Length > 1) sb.Append(p.Substring(1));
        }
        return sb.Length == 0 ? id : sb.ToString();
    }
}
