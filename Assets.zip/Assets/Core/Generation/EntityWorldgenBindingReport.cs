using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class EntityWorldgenBindingReport
{
    public int entitiesGenerated;
    public int biomesGenerated;
    public int dimensionsGenerated;
    public int structuresGenerated;
    public int bindingManifestsGenerated;
    public int javaStubsGenerated;
    public int warnings;
    public int errors;

    public readonly List<string> generatedFiles = new List<string>();
    public readonly List<string> warningMessages = new List<string>();
    public readonly List<string> errorMessages = new List<string>();

    public bool Success
    {
        get { return errors == 0; }
    }

    public void AddGenerated(string path)
    {
        if (!string.IsNullOrEmpty(path)) generatedFiles.Add(path);
    }

    public void AddWarning(string message)
    {
        warnings++;
        warningMessages.Add(message);
    }

    public void AddError(string message)
    {
        errors++;
        errorMessages.Add(message);
    }

    public string Format()
    {
        var sb = new StringBuilder();
        sb.AppendLine("=== Entity / Worldgen Binding Report ===");
        sb.AppendLine("Entities generated: " + entitiesGenerated);
        sb.AppendLine("Biomes generated: " + biomesGenerated);
        sb.AppendLine("Dimensions generated: " + dimensionsGenerated);
        sb.AppendLine("Structures generated: " + structuresGenerated);
        sb.AppendLine("Java stubs generated: " + javaStubsGenerated);
        sb.AppendLine("Binding manifests: " + bindingManifestsGenerated);
        sb.AppendLine("Warnings: " + warnings);
        sb.AppendLine("Errors: " + errors);
        sb.AppendLine();

        if (generatedFiles.Count > 0)
        {
            sb.AppendLine("Generated files:");
            for (int i = 0; i < generatedFiles.Count; i++) sb.AppendLine("  + " + generatedFiles[i]);
            sb.AppendLine();
        }

        if (warningMessages.Count > 0)
        {
            sb.AppendLine("Warnings:");
            for (int i = 0; i < warningMessages.Count; i++) sb.AppendLine("  ! " + warningMessages[i]);
            sb.AppendLine();
        }

        if (errorMessages.Count > 0)
        {
            sb.AppendLine("Errors:");
            for (int i = 0; i < errorMessages.Count; i++) sb.AppendLine("  x " + errorMessages[i]);
            sb.AppendLine();
        }

        return sb.ToString();
    }
}
