using System;

[Serializable]
public class JavaStubApplyRequest
{
    public string projectRoot;
    public bool overwriteExisting;
    public bool backupExisting = true;
    public bool writeReport = true;
    public bool dryRun;

    public static JavaStubApplyRequest Create(string root, bool overwrite, bool backup, bool dryRun)
    {
        return new JavaStubApplyRequest
        {
            projectRoot = root,
            overwriteExisting = overwrite,
            backupExisting = backup,
            dryRun = dryRun,
            writeReport = true
        };
    }
}
