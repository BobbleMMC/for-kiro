using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class RecipeLootTagBindingReport
{
    public int recipesGenerated;
    public int lootTablesGenerated;
    public int tagsGenerated;
    public int bindingManifestsGenerated;
    public int warnings;
    public int errors;

    public readonly List<string> generatedFiles = new List<string>();
    public readonly List<string> warningMessages = new List<string>();
    public readonly List<string> errorMessages = new List<string>();

    public bool Success
    {
        get { return errors == 0; }
    }

    public void AddGenerated(string path)
    {
        if (!string.IsNullOrEmpty(path))
            generatedFiles.Add(path);
    }

    public void AddWarning(string message)
    {
        warnings++;
        warningMessages.Add(message);
    }

    public void AddError(string message)
    {
        errors++;
        errorMessages.Add(message);
    }

    public string Format()
    {
        var sb = new StringBuilder();
        sb.AppendLine("=== Recipe/Loot/Tag Binding Report ===");
        sb.AppendLine("Recipes generated: " + recipesGenerated);
        sb.AppendLine("Loot tables generated: " + lootTablesGenerated);
        sb.AppendLine("Tags generated: " + tagsGenerated);
        sb.AppendLine("Binding manifests: " + bindingManifestsGenerated);
        sb.AppendLine("Warnings: " + warnings);
        sb.AppendLine("Errors: " + errors);
        sb.AppendLine();

        if (generatedFiles.Count > 0)
        {
            sb.AppendLine("Generated files:");
            for (int i = 0; i < generatedFiles.Count; i++)
                sb.AppendLine("  + " + generatedFiles[i]);
            sb.AppendLine();
        }

        if (warningMessages.Count > 0)
        {
            sb.AppendLine("Warnings:");
            for (int i = 0; i < warningMessages.Count; i++)
                sb.AppendLine("  ! " + warningMessages[i]);
            sb.AppendLine();
        }

        if (errorMessages.Count > 0)
        {
            sb.AppendLine("Errors:");
            for (int i = 0; i < errorMessages.Count; i++)
                sb.AppendLine("  x " + errorMessages[i]);
            sb.AppendLine();
        }

        return sb.ToString();
    }
}
