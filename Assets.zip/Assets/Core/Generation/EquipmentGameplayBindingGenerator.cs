using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public static class EquipmentGameplayBindingGenerator
{
    public static EquipmentGameplayBindingReport Generate(object workspace, string projectRoot, string modId)
    {
        var report = new EquipmentGameplayBindingReport();
        if (string.IsNullOrEmpty(projectRoot))
        {
            report.AddError("Project root is empty. Select exported Minecraft project root first.");
            return report;
        }

        projectRoot = Path.GetFullPath(projectRoot);
        modId = EquipmentGameplayBindingUtility.CleanId(modId, "mymod");

        if (workspace == null)
        {
            report.AddWarning("Workspace object is null. Only field binding catalog can be exported.");
        }

        GenerateTools(workspace, projectRoot, modId, report);
        GenerateArmors(workspace, projectRoot, modId, report);
        GenerateFoodAndDataComponents(workspace, projectRoot, modId, report);
        GenerateEffects(workspace, projectRoot, modId, report);
        GenerateEnchantments(workspace, projectRoot, modId, report);
        GenerateSounds(workspace, projectRoot, modId, report);
        GenerateParticles(workspace, projectRoot, modId, report);
        GenerateBindingManifest(projectRoot, modId, report);
        GenerateReport(projectRoot, report);
        return report;
    }

    private static void GenerateTools(object workspace, string projectRoot, string modId, EquipmentGameplayBindingReport report)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "tools", "toolItems", "weapons" });
        int index = 0;
        foreach (object tool in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(tool, new string[] { "toolId", "itemId", "id", "name" }, "tool_" + index);
            id = EquipmentGameplayBindingUtility.CleanId(id, "tool_" + index);
            string display = EquipmentGameplayBindingUtility.GetFirstString(tool, new string[] { "displayName", "title", "name" }, EquipmentGameplayBindingUtility.MakeLangName(id));
            string type = EquipmentGameplayBindingUtility.GetFirstString(tool, new string[] { "toolType", "type", "category" }, "pickaxe").ToLowerInvariant();
            int durability = EquipmentGameplayBindingUtility.GetFirstInt(tool, new string[] { "durability", "maxDamage" }, 250);
            float miningSpeed = EquipmentGameplayBindingUtility.GetFirstFloat(tool, new string[] { "miningSpeed", "speed" }, 6f);
            float attackDamage = EquipmentGameplayBindingUtility.GetFirstFloat(tool, new string[] { "attackDamage", "damage" }, 2f);
            float attackSpeed = EquipmentGameplayBindingUtility.GetFirstFloat(tool, new string[] { "attackSpeed" }, -2.4f);
            int enchantability = EquipmentGameplayBindingUtility.GetFirstInt(tool, new string[] { "enchantability" }, 14);
            string repairItem = EquipmentGameplayBindingUtility.GetFirstString(tool, new string[] { "repairItem", "repairIngredient" }, "minecraft:iron_ingot");
            string effectiveBlocks = EquipmentGameplayBindingUtility.GetFirstString(tool, new string[] { "effectiveBlocksCsv", "effectiveBlocks", "miningTags" }, string.Empty);

            WriteItemModel(projectRoot, modId, id, "item/handheld", report);
            WriteLangPatch(projectRoot, modId, "item." + modId + "." + id, display, report);
            WriteToolDescriptor(projectRoot, modId, id, display, type, durability, miningSpeed, attackDamage, attackSpeed, enchantability, repairItem, effectiveBlocks, report);
            WriteToolJavaStub(projectRoot, modId, id, display, type, durability, miningSpeed, attackDamage, attackSpeed, enchantability, repairItem, report);
            WriteBinding(projectRoot, "tool", id, "item." + modId + "." + id, report);
            report.toolsGenerated++;
        }
    }

    private static void WriteToolDescriptor(string projectRoot, string modId, string id, string display, string type, int durability, float miningSpeed, float attackDamage, float attackSpeed, int enchantability, string repairItem, string effectiveBlocks, EquipmentGameplayBindingReport report)
    {
        string json = "{\n" +
            "  \"kind\": \"tool\",\n" +
            "  \"id\": \"" + EquipmentGameplayBindingUtility.EscapeJson(modId + ":" + id) + "\",\n" +
            "  \"displayName\": \"" + EquipmentGameplayBindingUtility.EscapeJson(display) + "\",\n" +
            "  \"toolType\": \"" + EquipmentGameplayBindingUtility.EscapeJson(type) + "\",\n" +
            "  \"durability\": " + durability + ",\n" +
            "  \"miningSpeed\": " + EquipmentGameplayBindingUtility.F(miningSpeed) + ",\n" +
            "  \"attackDamage\": " + EquipmentGameplayBindingUtility.F(attackDamage) + ",\n" +
            "  \"attackSpeed\": " + EquipmentGameplayBindingUtility.F(attackSpeed) + ",\n" +
            "  \"enchantability\": " + enchantability + ",\n" +
            "  \"repairItem\": \"" + EquipmentGameplayBindingUtility.EscapeJson(repairItem) + "\",\n" +
            "  \"effectiveBlocks\": " + EquipmentGameplayBindingUtility.JsonStringArray(EquipmentGameplayBindingUtility.SplitCsv(effectiveBlocks)) + "\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/equipment/tools", id + ".tool.json"), json, report);
    }

    private static void WriteToolJavaStub(string projectRoot, string modId, string id, string display, string type, int durability, float miningSpeed, float attackDamage, float attackSpeed, int enchantability, string repairItem, EquipmentGameplayBindingReport report)
    {
        string packageBase = EquipmentGameplayBindingUtility.GetPackageBase(modId);
        string packagePath = packageBase.Replace('.', '/');
        string className = EquipmentGameplayBindingUtility.ToPascalCase(id);
        string text = "package " + packageBase + ".item;\n\n" +
            "// Generated stub by Mod Studio Patch 31. Review before applying to src/main/java.\n" +
            "// Tool: " + display + " (" + id + ")\n" +
            "public final class " + className + "ToolBindingStub {\n" +
            "    public static final String ID = \"" + EquipmentGameplayBindingUtility.EscapeJson(modId + ":" + id) + "\";\n" +
            "    public static final String TOOL_TYPE = \"" + EquipmentGameplayBindingUtility.EscapeJson(type) + "\";\n" +
            "    public static final int DURABILITY = " + durability + ";\n" +
            "    public static final float MINING_SPEED = " + EquipmentGameplayBindingUtility.F(miningSpeed) + "f;\n" +
            "    public static final float ATTACK_DAMAGE = " + EquipmentGameplayBindingUtility.F(attackDamage) + "f;\n" +
            "    public static final float ATTACK_SPEED = " + EquipmentGameplayBindingUtility.F(attackSpeed) + "f;\n" +
            "    public static final int ENCHANTABILITY = " + enchantability + ";\n" +
            "    public static final String REPAIR_ITEM = \"" + EquipmentGameplayBindingUtility.EscapeJson(repairItem) + "\";\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/generated-java/equipment-gameplay", packagePath, "item", className + "ToolBindingStub.java.stub"), text, report);
        report.javaStubsGenerated++;
    }

    private static void GenerateArmors(object workspace, string projectRoot, string modId, EquipmentGameplayBindingReport report)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "armors", "armorItems", "armorSets" });
        int index = 0;
        foreach (object armor in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(armor, new string[] { "armorId", "itemId", "id", "name" }, "armor_" + index);
            id = EquipmentGameplayBindingUtility.CleanId(id, "armor_" + index);
            string display = EquipmentGameplayBindingUtility.GetFirstString(armor, new string[] { "displayName", "title", "name" }, EquipmentGameplayBindingUtility.MakeLangName(id));
            string slot = EquipmentGameplayBindingUtility.GetFirstString(armor, new string[] { "slot", "armorSlot", "equipmentSlot" }, "chestplate").ToLowerInvariant();
            int durability = EquipmentGameplayBindingUtility.GetFirstInt(armor, new string[] { "durability", "maxDamage" }, 240);
            int protection = EquipmentGameplayBindingUtility.GetFirstInt(armor, new string[] { "protection", "defense" }, 5);
            float toughness = EquipmentGameplayBindingUtility.GetFirstFloat(armor, new string[] { "toughness", "armorToughness" }, 0f);
            float knockback = EquipmentGameplayBindingUtility.GetFirstFloat(armor, new string[] { "knockbackResistance" }, 0f);
            int enchantability = EquipmentGameplayBindingUtility.GetFirstInt(armor, new string[] { "enchantability" }, 9);
            string repairItem = EquipmentGameplayBindingUtility.GetFirstString(armor, new string[] { "repairItem", "repairIngredient" }, "minecraft:iron_ingot");

            WriteItemModel(projectRoot, modId, id, "item/generated", report);
            WriteLangPatch(projectRoot, modId, "item." + modId + "." + id, display, report);
            WriteArmorDescriptor(projectRoot, modId, id, display, slot, durability, protection, toughness, knockback, enchantability, repairItem, report);
            WriteArmorJavaStub(projectRoot, modId, id, display, slot, durability, protection, toughness, knockback, enchantability, repairItem, report);
            WriteBinding(projectRoot, "armor", id, "item." + modId + "." + id, report);
            report.armorsGenerated++;
        }
    }

    private static void WriteArmorDescriptor(string projectRoot, string modId, string id, string display, string slot, int durability, int protection, float toughness, float knockback, int enchantability, string repairItem, EquipmentGameplayBindingReport report)
    {
        string json = "{\n" +
            "  \"kind\": \"armor\",\n" +
            "  \"id\": \"" + EquipmentGameplayBindingUtility.EscapeJson(modId + ":" + id) + "\",\n" +
            "  \"displayName\": \"" + EquipmentGameplayBindingUtility.EscapeJson(display) + "\",\n" +
            "  \"slot\": \"" + EquipmentGameplayBindingUtility.EscapeJson(slot) + "\",\n" +
            "  \"durability\": " + durability + ",\n" +
            "  \"protection\": " + protection + ",\n" +
            "  \"toughness\": " + EquipmentGameplayBindingUtility.F(toughness) + ",\n" +
            "  \"knockbackResistance\": " + EquipmentGameplayBindingUtility.F(knockback) + ",\n" +
            "  \"enchantability\": " + enchantability + ",\n" +
            "  \"repairItem\": \"" + EquipmentGameplayBindingUtility.EscapeJson(repairItem) + "\"\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/equipment/armors", id + ".armor.json"), json, report);
    }

    private static void WriteArmorJavaStub(string projectRoot, string modId, string id, string display, string slot, int durability, int protection, float toughness, float knockback, int enchantability, string repairItem, EquipmentGameplayBindingReport report)
    {
        string packageBase = EquipmentGameplayBindingUtility.GetPackageBase(modId);
        string packagePath = packageBase.Replace('.', '/');
        string className = EquipmentGameplayBindingUtility.ToPascalCase(id);
        string text = "package " + packageBase + ".item;\n\n" +
            "// Generated armor material/item binding stub by Mod Studio Patch 31.\n" +
            "public final class " + className + "ArmorBindingStub {\n" +
            "    public static final String ID = \"" + EquipmentGameplayBindingUtility.EscapeJson(modId + ":" + id) + "\";\n" +
            "    public static final String SLOT = \"" + EquipmentGameplayBindingUtility.EscapeJson(slot) + "\";\n" +
            "    public static final int DURABILITY = " + durability + ";\n" +
            "    public static final int PROTECTION = " + protection + ";\n" +
            "    public static final float TOUGHNESS = " + EquipmentGameplayBindingUtility.F(toughness) + "f;\n" +
            "    public static final float KNOCKBACK_RESISTANCE = " + EquipmentGameplayBindingUtility.F(knockback) + "f;\n" +
            "    public static final int ENCHANTABILITY = " + enchantability + ";\n" +
            "    public static final String REPAIR_ITEM = \"" + EquipmentGameplayBindingUtility.EscapeJson(repairItem) + "\";\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/generated-java/equipment-gameplay", packagePath, "item", className + "ArmorBindingStub.java.stub"), text, report);
        report.javaStubsGenerated++;
    }

    private static void GenerateFoodAndDataComponents(object workspace, string projectRoot, string modId, EquipmentGameplayBindingReport report)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "items", "itemData", "customItems" });
        int index = 0;
        foreach (object item in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(item, new string[] { "itemId", "id", "name" }, "item_" + index);
            id = EquipmentGameplayBindingUtility.CleanId(id, "item_" + index);
            object advanced = EquipmentGameplayBindingUtility.GetAdvanced(item);
            object foodObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(advanced, new string[] { "food", "foodSettings" });
            bool foodEnabled = EquipmentGameplayBindingUtility.GetFirstBool(advanced, new string[] { "isFood", "foodEnabled" }, false) || EquipmentGameplayBindingUtility.GetFirstBool(foodObj, new string[] { "enabled", "isFood" }, false);
            string customComponents = EquipmentGameplayBindingUtility.GetFirstString(advanced, new string[] { "dataComponentsJson", "customDataComponents", "dataComponents" }, string.Empty);

            if (foodEnabled)
            {
                int nutrition = EquipmentGameplayBindingUtility.GetFirstInt(foodObj, new string[] { "nutrition", "hunger" }, EquipmentGameplayBindingUtility.GetFirstInt(advanced, new string[] { "nutrition" }, 4));
                float saturation = EquipmentGameplayBindingUtility.GetFirstFloat(foodObj, new string[] { "saturation", "saturationModifier" }, EquipmentGameplayBindingUtility.GetFirstFloat(advanced, new string[] { "saturation" }, 0.3f));
                bool alwaysEdible = EquipmentGameplayBindingUtility.GetFirstBool(foodObj, new string[] { "alwaysEdible" }, EquipmentGameplayBindingUtility.GetFirstBool(advanced, new string[] { "alwaysEdible" }, false));
                WriteFoodDescriptor(projectRoot, modId, id, nutrition, saturation, alwaysEdible, report);
                WriteFoodJavaStub(projectRoot, modId, id, nutrition, saturation, alwaysEdible, report);
                report.foodsGenerated++;
            }

            if (!string.IsNullOrWhiteSpace(customComponents))
            {
                string json = EquipmentGameplayBindingUtility.EnsureObjectJson(customComponents, "{\n  \"components\": {}\n}");
                EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/data-components", id + ".components.json"), json, report);
                WriteBinding(projectRoot, "data_component", id, ".modstudio/data-components/" + id + ".components.json", report);
                report.dataComponentsGenerated++;
            }
        }
    }

    private static void WriteFoodDescriptor(string projectRoot, string modId, string id, int nutrition, float saturation, bool alwaysEdible, EquipmentGameplayBindingReport report)
    {
        string json = "{\n" +
            "  \"kind\": \"food\",\n" +
            "  \"item\": \"" + EquipmentGameplayBindingUtility.EscapeJson(modId + ":" + id) + "\",\n" +
            "  \"nutrition\": " + nutrition + ",\n" +
            "  \"saturation\": " + EquipmentGameplayBindingUtility.F(saturation) + ",\n" +
            "  \"alwaysEdible\": " + (alwaysEdible ? "true" : "false") + "\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/food", id + ".food.json"), json, report);
        WriteBinding(projectRoot, "food", id, ".modstudio/food/" + id + ".food.json", report);
    }

    private static void WriteFoodJavaStub(string projectRoot, string modId, string id, int nutrition, float saturation, bool alwaysEdible, EquipmentGameplayBindingReport report)
    {
        string packageBase = EquipmentGameplayBindingUtility.GetPackageBase(modId);
        string packagePath = packageBase.Replace('.', '/');
        string className = EquipmentGameplayBindingUtility.ToPascalCase(id);
        string text = "package " + packageBase + ".item;\n\n" +
            "// Food/DataComponent binding stub by Mod Studio Patch 31.\n" +
            "public final class " + className + "FoodBindingStub {\n" +
            "    public static final int NUTRITION = " + nutrition + ";\n" +
            "    public static final float SATURATION = " + EquipmentGameplayBindingUtility.F(saturation) + "f;\n" +
            "    public static final boolean ALWAYS_EDIBLE = " + (alwaysEdible ? "true" : "false") + ";\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/generated-java/equipment-gameplay", packagePath, "item", className + "FoodBindingStub.java.stub"), text, report);
        report.javaStubsGenerated++;
    }

    private static void GenerateEffects(object workspace, string projectRoot, string modId, EquipmentGameplayBindingReport report)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "effects", "potions", "statusEffects" });
        int index = 0;
        foreach (object effect in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(effect, new string[] { "effectId", "potionId", "id", "name" }, "effect_" + index);
            id = EquipmentGameplayBindingUtility.CleanId(id, "effect_" + index);
            string display = EquipmentGameplayBindingUtility.GetFirstString(effect, new string[] { "displayName", "title", "name" }, EquipmentGameplayBindingUtility.MakeLangName(id));
            string category = EquipmentGameplayBindingUtility.GetFirstString(effect, new string[] { "category", "effectCategory" }, "neutral").ToLowerInvariant();
            int color = EquipmentGameplayBindingUtility.GetFirstInt(effect, new string[] { "color", "rgb" }, 0x6f6f6f);
            bool instant = EquipmentGameplayBindingUtility.GetFirstBool(effect, new string[] { "instant", "instantEffect" }, false);
            WriteEffectDescriptor(projectRoot, modId, id, display, category, color, instant, report);
            WriteSimpleJavaStub(projectRoot, modId, "effect", id, "Effect", report);
            WriteLangPatch(projectRoot, modId, "effect." + modId + "." + id, display, report);
            report.effectsGenerated++;
        }
    }

    private static void WriteEffectDescriptor(string projectRoot, string modId, string id, string display, string category, int color, bool instant, EquipmentGameplayBindingReport report)
    {
        string json = "{\n" +
            "  \"kind\": \"effect\",\n" +
            "  \"id\": \"" + EquipmentGameplayBindingUtility.EscapeJson(modId + ":" + id) + "\",\n" +
            "  \"displayName\": \"" + EquipmentGameplayBindingUtility.EscapeJson(display) + "\",\n" +
            "  \"category\": \"" + EquipmentGameplayBindingUtility.EscapeJson(category) + "\",\n" +
            "  \"color\": " + color + ",\n" +
            "  \"instant\": " + (instant ? "true" : "false") + "\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/effects", id + ".effect.json"), json, report);
        WriteBinding(projectRoot, "effect", id, ".modstudio/effects/" + id + ".effect.json", report);
    }

    private static void GenerateEnchantments(object workspace, string projectRoot, string modId, EquipmentGameplayBindingReport report)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "enchantments", "enchantmentSettings" });
        int index = 0;
        foreach (object enchantment in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(enchantment, new string[] { "enchantmentId", "id", "name" }, "enchantment_" + index);
            id = EquipmentGameplayBindingUtility.CleanId(id, "enchantment_" + index);
            string display = EquipmentGameplayBindingUtility.GetFirstString(enchantment, new string[] { "displayName", "title", "name" }, EquipmentGameplayBindingUtility.MakeLangName(id));
            int maxLevel = EquipmentGameplayBindingUtility.GetFirstInt(enchantment, new string[] { "maxLevel", "levels" }, 1);
            int weight = EquipmentGameplayBindingUtility.GetFirstInt(enchantment, new string[] { "weight", "rarityWeight" }, 10);
            string applicable = EquipmentGameplayBindingUtility.GetFirstString(enchantment, new string[] { "applicableItems", "items", "itemTags" }, "#minecraft:enchantable/weapon");
            bool treasure = EquipmentGameplayBindingUtility.GetFirstBool(enchantment, new string[] { "treasure", "isTreasure" }, false);
            bool curse = EquipmentGameplayBindingUtility.GetFirstBool(enchantment, new string[] { "curse", "isCurse" }, false);
            WriteEnchantmentJson(projectRoot, modId, id, maxLevel, weight, applicable, treasure, curse, report);
            WriteLangPatch(projectRoot, modId, "enchantment." + modId + "." + id, display, report);
            WriteSimpleJavaStub(projectRoot, modId, "enchantment", id, "Enchantment", report);
            report.enchantmentsGenerated++;
        }
    }

    private static void WriteEnchantmentJson(string projectRoot, string modId, string id, int maxLevel, int weight, string applicable, bool treasure, bool curse, EquipmentGameplayBindingReport report)
    {
        string json = "{\n" +
            "  \"description\": { \"translate\": \"enchantment." + EquipmentGameplayBindingUtility.EscapeJson(modId) + "." + EquipmentGameplayBindingUtility.EscapeJson(id) + "\" },\n" +
            "  \"supported_items\": \"" + EquipmentGameplayBindingUtility.EscapeJson(applicable) + "\",\n" +
            "  \"weight\": " + weight + ",\n" +
            "  \"max_level\": " + maxLevel + ",\n" +
            "  \"min_cost\": { \"base\": 1, \"per_level_above_first\": 10 },\n" +
            "  \"max_cost\": { \"base\": 50, \"per_level_above_first\": 10 },\n" +
            "  \"anvil_cost\": 1,\n" +
            "  \"slots\": [\"mainhand\"],\n" +
            "  \"effects\": {},\n" +
            "  \"exclusive_set\": []\n" +
            "}\n";
        string file = Path.Combine(projectRoot, "src/main/resources/data", modId, "enchantment", id + ".json");
        EquipmentGameplayBindingUtility.WriteText(file, json, report);
        WriteBinding(projectRoot, "enchantment", id, "data/" + modId + "/enchantment/" + id + ".json", report);
    }

    private static void GenerateSounds(object workspace, string projectRoot, string modId, EquipmentGameplayBindingReport report)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "sounds", "soundEvents" });
        var soundEntries = new List<string>();
        int index = 0;
        foreach (object sound in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(sound, new string[] { "soundId", "id", "name" }, "sound_" + index);
            id = EquipmentGameplayBindingUtility.CleanResourceId(id, "sound_" + index);
            string subtitle = EquipmentGameplayBindingUtility.GetFirstString(sound, new string[] { "subtitle", "displayName" }, "sound." + modId + "." + id);
            string file = EquipmentGameplayBindingUtility.GetFirstString(sound, new string[] { "file", "soundFile", "path" }, id);
            soundEntries.Add("  \"" + EquipmentGameplayBindingUtility.EscapeJson(id) + "\": { \"subtitle\": \"" + EquipmentGameplayBindingUtility.EscapeJson(subtitle) + "\", \"sounds\": [\"" + EquipmentGameplayBindingUtility.EscapeJson(file.Replace(".ogg", string.Empty)) + "\"] }");
            WriteBinding(projectRoot, "sound", id, "assets/" + modId + "/sounds.json", report);
            WriteSimpleJavaStub(projectRoot, modId, "sound", id, "Sound", report);
            report.soundsGenerated++;
        }
        if (soundEntries.Count > 0)
        {
            string json = "{\n" + string.Join(",\n", soundEntries.ToArray()) + "\n}\n";
            EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, "src/main/resources/assets", modId, "sounds.json"), json, report);
        }
    }

    private static void GenerateParticles(object workspace, string projectRoot, string modId, EquipmentGameplayBindingReport report)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "particles", "particleSettings" });
        int index = 0;
        foreach (object particle in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(particle, new string[] { "particleId", "id", "name" }, "particle_" + index);
            id = EquipmentGameplayBindingUtility.CleanId(id, "particle_" + index);
            string texture = EquipmentGameplayBindingUtility.GetFirstString(particle, new string[] { "texture", "texturePath" }, modId + ":" + id);
            string json = "{\n  \"textures\": [\"" + EquipmentGameplayBindingUtility.EscapeJson(texture) + "\"]\n}\n";
            EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, "src/main/resources/assets", modId, "particles", id + ".json"), json, report);
            WriteSimpleJavaStub(projectRoot, modId, "particle", id, "Particle", report);
            WriteBinding(projectRoot, "particle", id, "assets/" + modId + "/particles/" + id + ".json", report);
            report.particlesGenerated++;
        }
    }

    private static void WriteItemModel(string projectRoot, string modId, string id, string parent, EquipmentGameplayBindingReport report)
    {
        string json = "{\n" +
            "  \"parent\": \"minecraft:" + EquipmentGameplayBindingUtility.EscapeJson(parent) + "\",\n" +
            "  \"textures\": { \"layer0\": \"" + EquipmentGameplayBindingUtility.EscapeJson(modId + ":item/" + id) + "\" }\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, "src/main/resources/assets", modId, "models/item", id + ".json"), json, report);
    }

    private static void WriteLangPatch(string projectRoot, string modId, string key, string value, EquipmentGameplayBindingReport report)
    {
        string file = Path.Combine(projectRoot, ".modstudio/lang-patches", modId + ".equipment-gameplay.lang.jsonl");
        string line = "{\"key\":\"" + EquipmentGameplayBindingUtility.EscapeJson(key) + "\",\"value\":\"" + EquipmentGameplayBindingUtility.EscapeJson(value) + "\"}\n";
        try
        {
            string dir = Path.GetDirectoryName(file);
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            File.AppendAllText(file, line, Encoding.UTF8);
            report.AddGenerated(file);
        }
        catch (Exception ex)
        {
            report.AddError("Failed to append lang patch: " + ex.Message);
        }
    }

    private static void WriteSimpleJavaStub(string projectRoot, string modId, string folder, string id, string kind, EquipmentGameplayBindingReport report)
    {
        string packageBase = EquipmentGameplayBindingUtility.GetPackageBase(modId);
        string packagePath = packageBase.Replace('.', '/');
        string className = EquipmentGameplayBindingUtility.ToPascalCase(id) + kind + "BindingStub";
        string text = "package " + packageBase + "." + folder + ";\n\n" +
            "// Generated binding stub by Mod Studio Patch 31.\n" +
            "public final class " + className + " {\n" +
            "    public static final String ID = \"" + EquipmentGameplayBindingUtility.EscapeJson(modId + ":" + id) + "\";\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/generated-java/equipment-gameplay", packagePath, folder, className + ".java.stub"), text, report);
        report.javaStubsGenerated++;
    }

    private static void WriteBinding(string projectRoot, string kind, string id, string target, EquipmentGameplayBindingReport report)
    {
        string json = "{\n" +
            "  \"kind\": \"" + EquipmentGameplayBindingUtility.EscapeJson(kind) + "\",\n" +
            "  \"id\": \"" + EquipmentGameplayBindingUtility.EscapeJson(id) + "\",\n" +
            "  \"target\": \"" + EquipmentGameplayBindingUtility.EscapeJson(target) + "\",\n" +
            "  \"dataModel\": \"workspace." + EquipmentGameplayBindingUtility.EscapeJson(kind) + "s[]\",\n" +
            "  \"ui\": \"" + EquipmentGameplayBindingUtility.EscapeJson(kind) + " editor\",\n" +
            "  \"generator\": \"EquipmentGameplayBindingGenerator\",\n" +
            "  \"validator\": \"EquipmentGameplayBindingValidator\"\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/equipment-gameplay-binding", kind + "_" + id + ".binding.json"), json, report);
    }

    private static void GenerateBindingManifest(string projectRoot, string modId, EquipmentGameplayBindingReport report)
    {
        string json = "{\n" +
            "  \"modId\": \"" + EquipmentGameplayBindingUtility.EscapeJson(modId) + "\",\n" +
            "  \"patch\": 31,\n" +
            "  \"system\": \"equipment-gameplay-binding\",\n" +
            "  \"targets\": [\"tool\", \"armor\", \"food\", \"data_component\", \"effect\", \"enchantment\", \"sound\", \"particle\"]\n" +
            "}\n";
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/field-bindings/equipment-gameplay-bindings.json"), json, report);
    }

    private static void GenerateReport(string projectRoot, EquipmentGameplayBindingReport report)
    {
        EquipmentGameplayBindingUtility.WriteText(Path.Combine(projectRoot, ".modstudio/reports/equipment-gameplay-binding-report.txt"), report.Format(), report);
    }
}
