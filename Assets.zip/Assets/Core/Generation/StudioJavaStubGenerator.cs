using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

public static class StudioJavaStubGenerator
{
    public static int ExportAll(WorkspaceData workspace, string projectRoot)
    {
        if (workspace == null || string.IsNullOrEmpty(projectRoot)) return 0;

        string modId = SafeModId(workspace.modId);
        string loader = string.IsNullOrWhiteSpace(workspace.modloader) ? "Fabric" : workspace.modloader.Trim();
        string mcVersion = string.IsNullOrWhiteSpace(workspace.mcVersion) ? "1.21" : workspace.mcVersion.Trim();

        string baseDir = Path.Combine(projectRoot, ".modstudio");
        string networkingDir = Path.Combine(baseDir, "networking");
        string keybindDir = Path.Combine(baseDir, "keybinds");
        string stubDir = Path.Combine(baseDir, "java-stubs");
        string generatedDir = Path.Combine(baseDir, "generated-java", NormalizeFolder(loader));

        EnsureDirectory(networkingDir);
        EnsureDirectory(keybindDir);
        EnsureDirectory(stubDir);
        EnsureDirectory(generatedDir);
        EnsureDirectory(Path.Combine(stubDir, "network"));
        EnsureDirectory(Path.Combine(stubDir, "client"));
        EnsureDirectory(Path.Combine(stubDir, "screen"));
        EnsureDirectory(Path.Combine(generatedDir, "net", modId));
        EnsureDirectory(Path.Combine(generatedDir, "net", modId, "client"));
        EnsureDirectory(Path.Combine(generatedDir, "net", modId, "network"));
        EnsureDirectory(Path.Combine(generatedDir, "net", modId, "screen"));

        int count = 0;

        count += ExportPacketDescriptorsAndLegacyStubs(workspace, projectRoot, stubDir, modId);
        count += ExportKeybindDescriptorsAndLegacyStubs(workspace, projectRoot, stubDir, modId);
        count += ExportScreenLegacyStubs(workspace, stubDir, modId);

        // 18-patch: loader/version-aware Java source previews.
        count += ExportLoaderAwareSources(workspace, generatedDir, modId, loader, mcVersion);

        File.WriteAllText(Path.Combine(stubDir, "README_STUBS.txt"), GenerateReadme(loader, mcVersion));
        File.WriteAllText(Path.Combine(generatedDir, "README_GENERATED_JAVA.txt"), GenerateGeneratedJavaReadme(loader, mcVersion, modId));
        return count + 2;
    }

    private static int ExportPacketDescriptorsAndLegacyStubs(WorkspaceData workspace, string projectRoot, string stubDir, string modId)
    {
        int count = 0;
        if (workspace.networkPackets == null) return count;

        foreach (var packet in workspace.networkPackets)
        {
            if (packet == null || !packet.enabled) continue;
            packet.SyncFieldsFromCsv();

            string descriptorPath = Path.Combine(projectRoot, packet.GetDescriptorPath(modId).Replace('/', Path.DirectorySeparatorChar));
            EnsureDirectory(Path.GetDirectoryName(descriptorPath));
            File.WriteAllText(descriptorPath, packet.GenerateDescriptorJson(modId));
            count++;

            if (packet.generateJavaStub)
            {
                string className = GetPacketClassName(packet);
                File.WriteAllText(Path.Combine(stubDir, "network", className + ".java.stub"), packet.GenerateJavaStub(modId));
                count++;
            }
        }

        return count;
    }

    private static int ExportKeybindDescriptorsAndLegacyStubs(WorkspaceData workspace, string projectRoot, string stubDir, string modId)
    {
        int count = 0;
        if (workspace.keybinds == null) return count;

        foreach (var keybind in workspace.keybinds)
        {
            if (keybind == null || !keybind.enabled) continue;

            string descriptorPath = Path.Combine(projectRoot, keybind.GetDescriptorPath(modId).Replace('/', Path.DirectorySeparatorChar));
            EnsureDirectory(Path.GetDirectoryName(descriptorPath));
            File.WriteAllText(descriptorPath, keybind.GenerateDescriptorJson(modId));
            count++;

            if (keybind.generateJavaStub)
            {
                string className = GetKeybindHandlerClassName(keybind);
                File.WriteAllText(Path.Combine(stubDir, "client", className + ".java.stub"), keybind.GenerateJavaStub(modId));
                count++;
            }
        }

        return count;
    }

    private static int ExportScreenLegacyStubs(WorkspaceData workspace, string stubDir, string modId)
    {
        int count = 0;
        if (workspace.screens == null) return count;

        foreach (var screen in workspace.screens)
        {
            if (screen == null || !screen.enabled || !screen.generateJavaStubs) continue;
            string className = GetScreenClassName(screen);
            string menuName = GetMenuClassName(screen);
            File.WriteAllText(Path.Combine(stubDir, "screen", className + ".java.stub"), GenerateScreenStub(modId, screen, className, menuName));
            File.WriteAllText(Path.Combine(stubDir, "screen", menuName + ".java.stub"), GenerateMenuStub(modId, screen, menuName));
            count += 2;
        }

        return count;
    }

    private static int ExportLoaderAwareSources(WorkspaceData workspace, string generatedDir, string modId, string loader, string mcVersion)
    {
        int count = 0;
        string root = Path.Combine(generatedDir, "net", modId);
        string clientDir = Path.Combine(root, "client");
        string networkDir = Path.Combine(root, "network");
        string screenDir = Path.Combine(root, "screen");
        EnsureDirectory(clientDir);
        EnsureDirectory(networkDir);
        EnsureDirectory(screenDir);

        File.WriteAllText(Path.Combine(clientDir, "MyModClient.java.stub"), GenerateClientInitializer(workspace, modId, loader, mcVersion));
        count++;

        File.WriteAllText(Path.Combine(networkDir, "ModNetworking.java.stub"), GenerateNetworkingRegistry(workspace, modId, loader, mcVersion));
        count++;

        File.WriteAllText(Path.Combine(clientDir, "ModKeybinds.java.stub"), GenerateKeybindRegistry(workspace, modId, loader, mcVersion));
        count++;

        File.WriteAllText(Path.Combine(screenDir, "ModScreens.java.stub"), GenerateScreenRegistry(workspace, modId, loader, mcVersion));
        count++;

        if (workspace.networkPackets != null)
        {
            foreach (var packet in workspace.networkPackets)
            {
                if (packet == null || !packet.enabled || !packet.generateJavaStub) continue;
                packet.SyncFieldsFromCsv();
                string className = GetPacketClassName(packet);
                File.WriteAllText(Path.Combine(networkDir, className + ".java.stub"), GeneratePacketSource(packet, modId, loader, mcVersion));
                File.WriteAllText(Path.Combine(networkDir, className + "Handler.java.stub"), GeneratePacketHandlerSource(packet, modId, loader, mcVersion));
                count += 2;
            }
        }

        if (workspace.keybinds != null)
        {
            foreach (var keybind in workspace.keybinds)
            {
                if (keybind == null || !keybind.enabled || !keybind.generateJavaStub) continue;
                string handler = GetKeybindHandlerClassName(keybind);
                File.WriteAllText(Path.Combine(clientDir, handler + ".java.stub"), GenerateKeybindHandlerSource(keybind, modId, loader, mcVersion));
                count++;
            }
        }

        if (workspace.screens != null)
        {
            foreach (var screen in workspace.screens)
            {
                if (screen == null || !screen.enabled || !screen.generateJavaStubs) continue;
                string screenClass = GetScreenClassName(screen);
                string menuClass = GetMenuClassName(screen);
                File.WriteAllText(Path.Combine(screenDir, screenClass + ".java.stub"), GenerateLoaderAwareScreenSource(screen, modId, loader, mcVersion, screenClass, menuClass));
                File.WriteAllText(Path.Combine(screenDir, menuClass + ".java.stub"), GenerateLoaderAwareMenuSource(screen, modId, loader, mcVersion, menuClass));
                count += 2;
            }
        }

        return count;
    }

    private static string GenerateClientInitializer(WorkspaceData workspace, string modId, string loader, string mcVersion)
    {
        StringBuilder sb = new StringBuilder();
        AppendHeader(sb, loader, mcVersion, "Client initializer");
        sb.AppendLine($"package net.{modId}.client;");
        sb.AppendLine();

        if (IsNeoForge(loader))
        {
            sb.AppendLine("// NeoForge client registration preview.");
            sb.AppendLine("// Recommended location: src/main/java/net/" + modId + "/client/ClientEvents.java");
            sb.AppendLine("// Hook this class from your @Mod class or client-only event subscriber.");
            sb.AppendLine("public final class MyModClient {");
            sb.AppendLine("    private MyModClient() {}");
            sb.AppendLine();
            sb.AppendLine("    public static void registerClient() {");
            sb.AppendLine("        net." + modId + ".network.ModNetworking.registerClientPayloads();");
            sb.AppendLine("        ModKeybinds.register();");
            sb.AppendLine("        net." + modId + ".screen.ModScreens.registerClientScreens();");
            sb.AppendLine("    }");
            sb.AppendLine("}");
            return sb.ToString();
        }

        if (IsQuilt(loader))
        {
            sb.AppendLine("import org.quiltmc.loader.api.ModContainer;");
            sb.AppendLine("import org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer;");
            sb.AppendLine();
            sb.AppendLine("public final class MyModClient implements ClientModInitializer {");
            sb.AppendLine("    @Override");
            sb.AppendLine("    public void onInitializeClient(ModContainer mod) {");
            sb.AppendLine("        net." + modId + ".network.ModNetworking.registerClientPayloads();");
            sb.AppendLine("        ModKeybinds.register();");
            sb.AppendLine("        net." + modId + ".screen.ModScreens.registerClientScreens();");
            sb.AppendLine("    }");
            sb.AppendLine("}");
            return sb.ToString();
        }

        sb.AppendLine("import net.fabricmc.api.ClientModInitializer;");
        sb.AppendLine();
        sb.AppendLine("public final class MyModClient implements ClientModInitializer {");
        sb.AppendLine("    @Override");
        sb.AppendLine("    public void onInitializeClient() {");
        sb.AppendLine("        net." + modId + ".network.ModNetworking.registerClientPayloads();");
        sb.AppendLine("        ModKeybinds.register();");
        sb.AppendLine("        net." + modId + ".screen.ModScreens.registerClientScreens();");
        sb.AppendLine("    }");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string GenerateNetworkingRegistry(WorkspaceData workspace, string modId, string loader, string mcVersion)
    {
        StringBuilder sb = new StringBuilder();
        AppendHeader(sb, loader, mcVersion, "Networking registry");
        sb.AppendLine($"package net.{modId}.network;");
        sb.AppendLine();
        sb.AppendLine("public final class ModNetworking {");
        sb.AppendLine("    private ModNetworking() {}");
        sb.AppendLine();
        sb.AppendLine("    public static void registerCommonPayloads() {");
        AppendPacketRegistrationComments(sb, workspace, StudioPacketDirection.ClientToServer, loader, "server/common");
        AppendPacketRegistrationComments(sb, workspace, StudioPacketDirection.Bidirectional, loader, "bidirectional/common");
        sb.AppendLine("    }");
        sb.AppendLine();
        sb.AppendLine("    public static void registerClientPayloads() {");
        AppendPacketRegistrationComments(sb, workspace, StudioPacketDirection.ServerToClient, loader, "client");
        AppendPacketRegistrationComments(sb, workspace, StudioPacketDirection.Bidirectional, loader, "bidirectional/client");
        sb.AppendLine("    }");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static void AppendPacketRegistrationComments(StringBuilder sb, WorkspaceData workspace, StudioPacketDirection direction, string loader, string side)
    {
        bool any = false;
        if (workspace.networkPackets != null)
        {
            foreach (var packet in workspace.networkPackets)
            {
                if (packet == null || !packet.enabled || packet.direction != direction) continue;
                any = true;
                string className = GetPacketClassName(packet);
                string channel = GetPacketChannel(packet, "MOD_ID");
                if (IsNeoForge(loader))
                {
                    sb.AppendLine("        // NeoForge " + side + ": register " + className + " on channel " + channel + " using RegisterPayloadHandlersEvent.");
                    sb.AppendLine("        // registrar.playToServer/playToClient(...); // adapt codec/handler for " + className);
                }
                else
                {
                    sb.AppendLine("        // Fabric/Quilt " + side + ": register " + className + " on channel " + channel + ".");
                    sb.AppendLine("        // PayloadTypeRegistry.playC2S/playS2C(...); ServerPlayNetworking/ClientPlayNetworking.registerGlobalReceiver(...);");
                }
            }
        }
        if (!any) sb.AppendLine("        // No " + side + " packets configured yet.");
    }

    private static string GeneratePacketSource(NetworkPacketDataModel packet, string modId, string loader, string mcVersion)
    {
        packet.SyncFieldsFromCsv();
        string className = GetPacketClassName(packet);
        string channel = GetPacketChannel(packet, modId);
        StringBuilder sb = new StringBuilder();
        AppendHeader(sb, loader, mcVersion, "Packet payload: " + packet.packetId);
        sb.AppendLine($"package net.{modId}.network;");
        sb.AppendLine();

        if (IsNeoForge(loader))
        {
            sb.AppendLine("// NeoForge preview: turn this into a record/class with StreamCodec and Type.");
            sb.AppendLine("public final class " + className + " {");
            sb.AppendLine("    public static final String CHANNEL = \"" + Escape(channel) + "\";");
            AppendPayloadFieldComments(sb, packet);
            sb.AppendLine("    // TODO: add StreamCodec<RegistryFriendlyByteBuf, " + className + ">.");
            sb.AppendLine("}");
            return sb.ToString();
        }

        sb.AppendLine("// Fabric/Quilt preview: for 1.20.5+/1.21 prefer CustomPayload + PacketCodec.");
        sb.AppendLine("public final class " + className + " {");
        sb.AppendLine("    public static final String CHANNEL = \"" + Escape(channel) + "\";");
        AppendPayloadFieldComments(sb, packet);
        sb.AppendLine("    // TODO: convert into record " + className + "(...) implements CustomPayload.");
        sb.AppendLine("    // TODO: add Id<" + className + "> ID and PacketCodec<RegistryByteBuf, " + className + "> CODEC.");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string GeneratePacketHandlerSource(NetworkPacketDataModel packet, string modId, string loader, string mcVersion)
    {
        packet.SyncFieldsFromCsv();
        string packetClass = GetPacketClassName(packet);
        string handlerName = GetPacketHandlerClassName(packet);
        StringBuilder sb = new StringBuilder();
        AppendHeader(sb, loader, mcVersion, "Packet handler: " + packet.packetId);
        sb.AppendLine($"package net.{modId}.network;");
        sb.AppendLine();
        sb.AppendLine("public final class " + handlerName + " {");
        sb.AppendLine("    private " + handlerName + "() {}");
        sb.AppendLine();
        if (packet.direction == StudioPacketDirection.ClientToServer)
        {
            sb.AppendLine("    public static void handleServerbound(" + packetClass + " payload, Object context) {");
            sb.AppendLine("        // TODO: cast context to selected loader API context.");
            if (packet.requiresValidation)
            {
                sb.AppendLine("        // Validate sender, permission, distance, loaded chunk and linked object before mutating the world.");
                sb.AppendLine("        // checkPlayerDistance=" + Bool(packet.checkPlayerDistance) + ", checkChunkLoaded=" + Bool(packet.checkChunkLoaded));
            }
            sb.AppendLine("    }");
        }
        else if (packet.direction == StudioPacketDirection.ServerToClient)
        {
            sb.AppendLine("    public static void handleClientbound(" + packetClass + " payload, Object context) {");
            sb.AppendLine("        // TODO: run client-side UI/particle/sound update on the client thread.");
            sb.AppendLine("    }");
        }
        else
        {
            sb.AppendLine("    public static void handle(" + packetClass + " payload, Object context) {");
            sb.AppendLine("        // TODO: branch by logical side or create separate handlers.");
            sb.AppendLine("    }");
        }
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static void AppendPayloadFieldComments(StringBuilder sb, NetworkPacketDataModel packet)
    {
        if (packet.payloadFields == null || packet.payloadFields.Count == 0)
        {
            sb.AppendLine("    // No payload fields configured.");
            return;
        }
        foreach (var field in packet.payloadFields)
        {
            string type = field == null ? "Custom" : field.fieldType.ToString();
            string name = field == null ? "field" : field.fieldName;
            bool required = field == null || field.required;
            sb.AppendLine("    // field: " + name + " -> " + type + " required=" + Bool(required));
        }
    }

    private static string GenerateKeybindRegistry(WorkspaceData workspace, string modId, string loader, string mcVersion)
    {
        StringBuilder sb = new StringBuilder();
        AppendHeader(sb, loader, mcVersion, "Client keybind registry");
        sb.AppendLine($"package net.{modId}.client;");
        sb.AppendLine();
        sb.AppendLine("public final class ModKeybinds {");
        sb.AppendLine("    private ModKeybinds() {}");
        sb.AppendLine();
        sb.AppendLine("    public static void register() {");
        bool any = false;
        if (workspace.keybinds != null)
        {
            foreach (var keybind in workspace.keybinds)
            {
                if (keybind == null || !keybind.enabled) continue;
                any = true;
                string handler = GetKeybindHandlerClassName(keybind);
                if (IsNeoForge(loader))
                {
                    sb.AppendLine("        // NeoForge: register key mapping via RegisterKeyMappingsEvent, then tick handler for " + handler + ".");
                }
                else
                {
                    sb.AppendLine("        // Fabric/Quilt: KeyBindingHelper.registerKeyBinding(...) + ClientTickEvents.END_CLIENT_TICK -> " + handler + ".tick(client)");
                }
            }
        }
        if (!any) sb.AppendLine("        // No keybinds configured yet.");
        sb.AppendLine("    }");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string GenerateKeybindHandlerSource(KeybindDataModel keybind, string modId, string loader, string mcVersion)
    {
        string handler = GetKeybindHandlerClassName(keybind);
        StringBuilder sb = new StringBuilder();
        AppendHeader(sb, loader, mcVersion, "Keybind handler: " + keybind.keybindId);
        sb.AppendLine($"package net.{modId}.client;");
        sb.AppendLine();
        sb.AppendLine("public final class " + handler + " {");
        sb.AppendLine("    public static final String KEY_ID = \"key." + modId + "." + NetworkPacketDataModel.Sanitize(keybind.keybindId) + "\";");
        sb.AppendLine("    public static final String DEFAULT_KEY = \"" + Escape(keybind.defaultKey) + "\";");
        sb.AppendLine("    public static final String CATEGORY = \"" + Escape(keybind.category) + "\";");
        sb.AppendLine("    private static int cooldown;");
        sb.AppendLine();
        sb.AppendLine("    private " + handler + "() {}");
        sb.AppendLine();
        sb.AppendLine("    public static void tick(Object client) {");
        sb.AppendLine("        // TODO: replace Object with MinecraftClient / selected loader client class.");
        sb.AppendLine("        if (cooldown > 0) cooldown--;");
        sb.AppendLine("        // Guards: requiresSneak=" + Bool(keybind.requiresSneak) + ", requiresCreative=" + Bool(keybind.requiresCreativeMode) + ", repeatWhileHeld=" + Bool(keybind.repeatWhileHeld));
        sb.AppendLine("        // Action: " + keybind.actionType + ", packet=" + Escape(keybind.sendPacketId) + ", screen=" + Escape(keybind.openScreenId) + ", command=" + Escape(keybind.command));
        sb.AppendLine("        // After successful action: cooldown = " + keybind.cooldownTicks + ";");
        sb.AppendLine("    }");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string GenerateScreenRegistry(WorkspaceData workspace, string modId, string loader, string mcVersion)
    {
        StringBuilder sb = new StringBuilder();
        AppendHeader(sb, loader, mcVersion, "Screen/menu registry");
        sb.AppendLine($"package net.{modId}.screen;");
        sb.AppendLine();
        sb.AppendLine("public final class ModScreens {");
        sb.AppendLine("    private ModScreens() {}");
        sb.AppendLine();
        sb.AppendLine("    public static void registerCommonMenus() {");
        bool anyMenu = false;
        if (workspace.screens != null)
        {
            foreach (var screen in workspace.screens)
            {
                if (screen == null || !screen.enabled) continue;
                anyMenu = true;
                sb.AppendLine("        // Register menu/screen handler type for " + GetMenuClassName(screen) + " (" + screen.screenId + ").");
            }
        }
        if (!anyMenu) sb.AppendLine("        // No screen/menu models configured yet.");
        sb.AppendLine("    }");
        sb.AppendLine();
        sb.AppendLine("    public static void registerClientScreens() {");
        bool anyScreen = false;
        if (workspace.screens != null)
        {
            foreach (var screen in workspace.screens)
            {
                if (screen == null || !screen.enabled) continue;
                anyScreen = true;
                if (IsNeoForge(loader))
                    sb.AppendLine("        // NeoForge: MenuScreens.register(..., " + GetScreenClassName(screen) + "::new);");
                else
                    sb.AppendLine("        // Fabric/Quilt: HandledScreens.register(..., " + GetScreenClassName(screen) + "::new);");
            }
        }
        if (!anyScreen) sb.AppendLine("        // No client screen bindings configured yet.");
        sb.AppendLine("    }");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string GenerateLoaderAwareScreenSource(ScreenDataModel screen, string modId, string loader, string mcVersion, string className, string menuName)
    {
        screen.SyncSlotsFromCsv();
        StringBuilder sb = new StringBuilder();
        AppendHeader(sb, loader, mcVersion, "Screen class: " + screen.screenId);
        sb.AppendLine($"package net.{modId}.screen;");
        sb.AppendLine();
        sb.AppendLine("public final class " + className + " {");
        sb.AppendLine("    public static final int WIDTH = " + screen.width + ";");
        sb.AppendLine("    public static final int HEIGHT = " + screen.height + ";");
        sb.AppendLine("    public static final String BACKGROUND = \"" + Escape(screen.backgroundTexture) + "\";");
        sb.AppendLine("    public static final String TITLE_KEY = \"" + Escape(string.IsNullOrWhiteSpace(screen.titleTranslationKey) ? "screen." + modId + "." + screen.screenId : screen.titleTranslationKey) + "\";");
        sb.AppendLine("    // Extend the selected loader's HandledScreen/MenuScreen class after wiring " + menuName + ".");
        if (screen.hasProgressBar) sb.AppendLine("    // progress bar: x=" + screen.progressX + ", y=" + screen.progressY + ", w=" + screen.progressWidth + ", h=" + screen.progressHeight);
        if (screen.hasEnergyBar) sb.AppendLine("    // energy bar: x=" + screen.energyX + ", y=" + screen.energyY + ", w=" + screen.energyWidth + ", h=" + screen.energyHeight);
        if (screen.hasFluidBar) sb.AppendLine("    // fluid bar: x=" + screen.fluidX + ", y=" + screen.fluidY + ", w=" + screen.fluidWidth + ", h=" + screen.fluidHeight);
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string GenerateLoaderAwareMenuSource(ScreenDataModel screen, string modId, string loader, string mcVersion, string menuName)
    {
        screen.SyncSlotsFromCsv();
        StringBuilder sb = new StringBuilder();
        AppendHeader(sb, loader, mcVersion, "Menu/screen-handler class: " + screen.screenId);
        sb.AppendLine($"package net.{modId}.screen;");
        sb.AppendLine();
        sb.AppendLine("public final class " + menuName + " {");
        sb.AppendLine("    public static final int CONTAINER_SLOTS = " + screen.containerSlots + ";");
        sb.AppendLine("    public static final boolean SYNC_PROPERTIES = " + Bool(screen.syncProperties) + ";");
        if (screen.slots != null)
        {
            foreach (var slot in screen.slots)
                sb.AppendLine("    // slot " + slot.index + ": " + Escape(slot.slotId) + " kind=" + slot.kind + " x=" + slot.x + " y=" + slot.y + " max=" + slot.maxStackSize);
        }
        sb.AppendLine("    // TODO: extend ScreenHandler/Menu and add player inventory slots at x=" + screen.playerInventoryX + ", y=" + screen.playerInventoryY + ".");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string GenerateScreenStub(string modId, ScreenDataModel screen, string className, string menuName)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("// GENERATED STUB ONLY — move/adapt to src/main/java after confirming loader/version APIs.");
        sb.AppendLine($"package net.{modId}.client.screen;");
        sb.AppendLine();
        sb.AppendLine($"public final class {className} {{");
        sb.AppendLine($"    public static final int WIDTH = {screen.width};");
        sb.AppendLine($"    public static final int HEIGHT = {screen.height};");
        sb.AppendLine($"    public static final String BACKGROUND = \"{Escape(screen.backgroundTexture)}\";");
        sb.AppendLine($"    // Expected menu/handler: {menuName}");
        sb.AppendLine($"    // Title key: {Escape(screen.titleTranslationKey)}");
        sb.AppendLine("    // TODO: extend HandledScreen/MenuScreen and draw background/widgets.");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string GenerateMenuStub(string modId, ScreenDataModel screen, string menuName)
    {
        screen.SyncSlotsFromCsv();
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("// GENERATED STUB ONLY — move/adapt to src/main/java after confirming loader/version APIs.");
        sb.AppendLine($"package net.{modId}.screen;");
        sb.AppendLine();
        sb.AppendLine($"public final class {menuName} {{");
        sb.AppendLine($"    public static final int CONTAINER_SLOTS = {screen.containerSlots};");
        if (screen.slots != null)
        {
            foreach (var slot in screen.slots)
                sb.AppendLine($"    // slot {slot.index}: {slot.slotId} kind={slot.kind} x={slot.x} y={slot.y}");
        }
        sb.AppendLine("    // TODO: implement ScreenHandler/Menu slot layout and property sync.");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static void AppendHeader(StringBuilder sb, string loader, string mcVersion, string title)
    {
        sb.AppendLine("// Generated by Mod Studio patch18");
        sb.AppendLine("// " + title);
        sb.AppendLine("// Loader: " + loader + " | Minecraft: " + mcVersion);
        sb.AppendLine("// This is a .java.stub preview. Copy into src/main/java only after checking imports for your exact loader/version.");
        sb.AppendLine();
    }

    private static string GenerateReadme(string loader, string mcVersion)
    {
        return "Legacy .java.stub descriptors generated by Mod Studio. Loader=" + loader + ", Minecraft=" + mcVersion + ". These files are outside src/main/java and cannot break Gradle builds.";
    }

    private static string GenerateGeneratedJavaReadme(string loader, string mcVersion, string modId)
    {
        return "Patch18 generated loader-aware Java preview stubs for " + modId + ".\n" +
               "Loader: " + loader + "\nMinecraft: " + mcVersion + "\n\n" +
               "Files are written under .modstudio/generated-java/<loader>/net/" + modId + "/... as .java.stub.\n" +
               "They intentionally do not compile automatically. Review imports/API differences, then copy/adapt to src/main/java.\n";
    }

    private static string GetPacketClassName(NetworkPacketDataModel packet)
    {
        return string.IsNullOrWhiteSpace(packet.customPacketClass)
            ? NetworkPacketDataModel.ToPascalCase(packet.packetId) + "Packet"
            : SanitizeJavaIdentifier(packet.customPacketClass.Trim(), "GeneratedPacket");
    }

    private static string GetPacketHandlerClassName(NetworkPacketDataModel packet)
    {
        if (!string.IsNullOrWhiteSpace(packet.customHandlerClass))
            return SanitizeJavaIdentifier(packet.customHandlerClass.Trim(), "GeneratedPacketHandler");
        return GetPacketClassName(packet) + "Handler";
    }

    private static string GetKeybindHandlerClassName(KeybindDataModel keybind)
    {
        return string.IsNullOrWhiteSpace(keybind.customHandlerClass)
            ? NetworkPacketDataModel.ToPascalCase(keybind.keybindId) + "KeybindHandler"
            : SanitizeJavaIdentifier(keybind.customHandlerClass.Trim(), "GeneratedKeybindHandler");
    }

    private static string GetScreenClassName(ScreenDataModel screen)
    {
        return string.IsNullOrWhiteSpace(screen.customScreenClass)
            ? NetworkPacketDataModel.ToPascalCase(screen.screenId) + "Screen"
            : SanitizeJavaIdentifier(screen.customScreenClass.Trim(), "GeneratedScreen");
    }

    private static string GetMenuClassName(ScreenDataModel screen)
    {
        return string.IsNullOrWhiteSpace(screen.customMenuClass)
            ? NetworkPacketDataModel.ToPascalCase(screen.screenId) + "Menu"
            : SanitizeJavaIdentifier(screen.customMenuClass.Trim(), "GeneratedMenu");
    }

    private static string GetPacketChannel(NetworkPacketDataModel packet, string modId)
    {
        string ns = string.IsNullOrWhiteSpace(packet.channelNamespace) ? modId : NetworkPacketDataModel.Sanitize(packet.channelNamespace).Replace('/', '_').Replace(':', '_').Replace('.', '_');
        string path = string.IsNullOrWhiteSpace(packet.channelPath) ? NetworkPacketDataModel.Sanitize(packet.packetId) : NetworkPacketDataModel.Sanitize(packet.channelPath).Replace(':', '_').Replace('.', '_');
        return ns + ":" + path;
    }

    private static string SafeModId(string value)
    {
        string safe = NetworkPacketDataModel.Sanitize(value).Replace(':', '_').Replace('/', '_').Replace('.', '_');
        return string.IsNullOrWhiteSpace(safe) ? "mymod" : safe;
    }

    private static string SanitizeJavaIdentifier(string value, string fallback)
    {
        if (string.IsNullOrWhiteSpace(value)) return fallback;
        StringBuilder sb = new StringBuilder();
        foreach (char c in value.Trim())
        {
            if (char.IsLetterOrDigit(c) || c == '_') sb.Append(c);
        }
        if (sb.Length == 0) return fallback;
        if (char.IsDigit(sb[0])) sb.Insert(0, '_');
        return sb.ToString();
    }

    private static string NormalizeFolder(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "fabric";
        return NetworkPacketDataModel.Sanitize(value).Replace(':', '_').Replace('/', '_').Replace('.', '_');
    }

    private static void EnsureDirectory(string path)
    {
        if (!string.IsNullOrEmpty(path) && !Directory.Exists(path)) Directory.CreateDirectory(path);
    }

    private static bool IsNeoForge(string loader) => !string.IsNullOrEmpty(loader) && loader.ToLowerInvariant().Contains("neo");
    private static bool IsQuilt(string loader) => !string.IsNullOrEmpty(loader) && loader.ToLowerInvariant().Contains("quilt");
    private static string Bool(bool v) => v ? "true" : "false";
    private static string Escape(string value) => (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
}
