using System.IO;
using System.Text;

public static class EntityWorldgenFieldBindingCatalog
{
    public static string BuildJson(string modId)
    {
        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"patch\": \"30\",");
        sb.AppendLine("  \"catalog\": \"entity-worldgen-field-bindings\",");
        sb.AppendLine("  \"modId\": \"" + EntityWorldgenBindingUtility.EscapeJson(EntityWorldgenBindingUtility.CleanId(modId, "mymod")) + "\",");
        sb.AppendLine("  \"fields\": [");
        Append(sb, "entity.id", "entities[].entityId", "Entity AI Editor", "generated-java entity registry", "entity_id_valid", true);
        Append(sb, "entity.attributes", "entities[].health/movementSpeed/attackDamage/followRange", "Entity AI Editor", "entity attribute stub", "entity_attributes_valid", true);
        Append(sb, "entity.aiGoals", "entities[].aiGoals", "Entity AI Editor", "entity initGoals stub", "entity_ai_goals_valid", true);
        Append(sb, "entity.spawn", "entities[].spawnRule", "Entity Spawn Editor", "spawn placement stub", "entity_spawn_valid", true);
        Append(sb, "entity.renderer", "entities[].texturePath/modelPath/rendererType", "Entity Spawn Editor", "renderer texture stub", "entity_renderer_valid", true);
        Append(sb, "biome.effects", "biomes[].temperature/downfall/colors/sounds", "Biome Pro Editor", "worldgen/biome json", "biome_effects_valid", true);
        Append(sb, "biome.spawns", "biomes[].monsterSpawns/creatureSpawns", "Biome Pro Editor", "biome spawners json", "biome_spawns_valid", true);
        Append(sb, "biome.features", "biomes[].features/carvers", "Biome Pro Editor", "biome features json", "biome_features_valid", true);
        Append(sb, "dimension.type", "dimensions[].dimensionType", "Dimension Editor", "dimension_type json", "dimension_type_valid", true);
        Append(sb, "dimension.generator", "dimensions[].generatorType/biomeSource", "Dimension Editor", "dimension json", "dimension_generator_valid", true);
        Append(sb, "structure.placement", "structures[].spacing/separation/salt", "Structure Editor", "structure_set json", "structure_placement_valid", true);
        Append(sb, "structure.jigsaw", "structures[].startPool/jigsawSize", "Structure Editor", "structure json", "structure_jigsaw_valid", false);
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    public static void Export(string projectRoot, string modId)
    {
        if (string.IsNullOrEmpty(projectRoot)) return;
        string path = Path.Combine(projectRoot, ".modstudio/field-bindings/entity-worldgen-field-catalog.json");
        string dir = Path.GetDirectoryName(path);
        if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
        File.WriteAllText(path, BuildJson(modId), Encoding.UTF8);
    }

    private static void Append(StringBuilder sb, string id, string dataModel, string ui, string generator, string validator, bool comma)
    {
        sb.AppendLine("    { \"id\": \"" + id + "\", \"dataModel\": \"" + dataModel + "\", \"ui\": \"" + ui + "\", \"generator\": \"" + generator + "\", \"validator\": \"" + validator + "\" }" + (comma ? "," : string.Empty));
    }
}
