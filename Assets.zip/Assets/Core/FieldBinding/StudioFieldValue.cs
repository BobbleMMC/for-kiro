using System;

[Serializable]
public class StudioFieldValue
{
    public string fieldId = string.Empty;
    public string value = string.Empty;
    public string source = "ui";
    public string updatedAt = string.Empty;

    public StudioFieldValue() { }

    public StudioFieldValue(string fieldId, string value, string source = "ui")
    {
        this.fieldId = fieldId;
        this.value = value;
        this.source = source;
        updatedAt = DateTime.UtcNow.ToString("o");
    }
}
