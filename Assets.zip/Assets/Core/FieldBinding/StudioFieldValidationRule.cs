using System;

[Serializable]
public class StudioFieldValidationRule
{
    public string id = string.Empty;
    public string severity = "warning";
    public string target = string.Empty;
    public string ruleType = "custom";
    public string description = string.Empty;
    public string expected = string.Empty;

    public StudioFieldValidationRule() { }

    public StudioFieldValidationRule(string id, string severity, string target, string ruleType, string description, string expected = "")
    {
        this.id = id;
        this.severity = severity;
        this.target = target;
        this.ruleType = ruleType;
        this.description = description;
        this.expected = expected;
    }
}
