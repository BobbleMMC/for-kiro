using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public static class StudioFieldBindingExporter
{
    public static string ExportManifest(string projectRoot)
    {
        if (string.IsNullOrEmpty(projectRoot)) projectRoot = Directory.GetCurrentDirectory();
        string outputDir = Path.Combine(projectRoot, ".modstudio", "field-bindings");
        Directory.CreateDirectory(outputDir);
        string outputPath = Path.Combine(outputDir, "field-bindings.json");
        File.WriteAllText(outputPath, BuildManifestJson(), Encoding.UTF8);
        return outputPath;
    }

    public static string BuildManifestJson()
    {
        StudioFieldRegistry.EnsureInitialized();
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"schema\": \"modstudio.field-bindings.v1\",");
        sb.AppendLine("  \"generatedAt\": \"" + Escape(DateTime.UtcNow.ToString("o")) + "\",");
        sb.AppendLine("  \"note\": \"Each UI setting must map to DataModel + Generator/PatchEngine + Validator.\",");
        sb.AppendLine("  \"fields\": [");
        IReadOnlyList<StudioFieldBinding> fields = StudioFieldRegistry.All;
        for (int i = 0; i < fields.Count; i++)
        {
            StudioFieldBinding field = fields[i];
            sb.AppendLine("    {");
            AddProp(sb, "id", field.id, 6, true);
            AddProp(sb, "label", field.label, 6, true);
            AddProp(sb, "featureType", field.featureType, 6, true);
            AddProp(sb, "editorPage", field.editorPage, 6, true);
            AddProp(sb, "dataPath", field.dataPath, 6, true);
            AddProp(sb, "uiType", field.uiType, 6, true);
            AddProp(sb, "defaultValue", field.defaultValue, 6, true);
            AddProp(sb, "description", field.description, 6, true);
            AddStringArray(sb, "generatorTargets", ExtractGeneratorTargets(field), 6, true);
            AddStringArray(sb, "patchTargets", ExtractPatchTargets(field), 6, true);
            AddStringArray(sb, "validatorRules", ExtractValidatorIds(field), 6, false);
            sb.Append("    }");
            if (i < fields.Count - 1) sb.Append(",");
            sb.AppendLine();
        }
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static List<string> ExtractGeneratorTargets(StudioFieldBinding field)
    {
        List<string> values = new List<string>();
        if (field.generatorRules == null) return values;
        foreach (StudioFieldGeneratorRule rule in field.generatorRules)
        {
            values.Add(rule.target + " :: " + rule.outputKind);
        }
        return values;
    }

    private static List<string> ExtractPatchTargets(StudioFieldBinding field)
    {
        List<string> values = new List<string>();
        if (field.patchRules == null) return values;
        foreach (StudioFieldPatchRule rule in field.patchRules)
        {
            values.Add(rule.targetFile + " :: " + rule.mergeStrategy);
        }
        return values;
    }

    private static List<string> ExtractValidatorIds(StudioFieldBinding field)
    {
        List<string> values = new List<string>();
        if (field.validationRules == null) return values;
        foreach (StudioFieldValidationRule rule in field.validationRules)
        {
            values.Add(rule.id + " :: " + rule.ruleType + " :: " + rule.severity);
        }
        return values;
    }

    private static void AddProp(StringBuilder sb, string key, string value, int indent, bool comma)
    {
        sb.Append(new string(' ', indent));
        sb.Append("\"").Append(Escape(key)).Append("\": \"").Append(Escape(value)).Append("\"");
        if (comma) sb.Append(",");
        sb.AppendLine();
    }

    private static void AddStringArray(StringBuilder sb, string key, List<string> values, int indent, bool comma)
    {
        sb.Append(new string(' ', indent));
        sb.Append("\"").Append(Escape(key)).Append("\": [");
        if (values != null)
        {
            for (int i = 0; i < values.Count; i++)
            {
                sb.Append("\"").Append(Escape(values[i])).Append("\"");
                if (i < values.Count - 1) sb.Append(", ");
            }
        }
        sb.Append("]");
        if (comma) sb.Append(",");
        sb.AppendLine();
    }

    private static string Escape(string value)
    {
        if (value == null) return string.Empty;
        return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n");
    }
}
