using System.IO;
using System.Text;

public static class EquipmentGameplayFieldBindingCatalog
{
    public static string BuildJson(string modId)
    {
        modId = EquipmentGameplayBindingUtility.CleanId(modId, "mymod");
        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"modId\": \"" + EquipmentGameplayBindingUtility.EscapeJson(modId) + "\",");
        sb.AppendLine("  \"patch\": 31,");
        sb.AppendLine("  \"catalog\": \"equipment-gameplay-field-binding\",");
        sb.AppendLine("  \"fields\": [");
        Add(sb, "tool.durability", "tools[].durability", "Tool Material Editor", "java.tool.material, item.model", "tool_durability_positive", true);
        Add(sb, "tool.miningSpeed", "tools[].miningSpeed", "Tool Material Editor", "java.tool.material", "tool_speed_non_negative", true);
        Add(sb, "tool.attackDamage", "tools[].attackDamage", "Tool Material Editor", "java.attribute.modifiers", "attack_damage_valid", true);
        Add(sb, "tool.repairItem", "tools[].repairItem", "Tool Material Editor", "tag.repair_materials", "repair_item_resource_id", true);
        Add(sb, "armor.slot", "armors[].slot", "Armor Material Editor", "java.armor.item", "armor_slot_valid", true);
        Add(sb, "armor.protection", "armors[].protection", "Armor Material Editor", "java.armor.material", "armor_protection_range", true);
        Add(sb, "armor.toughness", "armors[].toughness", "Armor Material Editor", "java.armor.material", "armor_toughness_non_negative", true);
        Add(sb, "food.nutrition", "items[].advanced.food.nutrition", "Food Editor", "java.food.component", "food_nutrition_range", true);
        Add(sb, "food.saturation", "items[].advanced.food.saturation", "Food Editor", "java.food.component", "food_saturation_range", true);
        Add(sb, "item.dataComponents", "items[].advanced.dataComponentsJson", "Data Component Editor", "data_component.descriptor", "json_object_valid", true);
        Add(sb, "effect.category", "effects[].category", "Effect/Potion Editor", "java.effect.registry", "effect_category_valid", true);
        Add(sb, "effect.color", "effects[].color", "Effect/Potion Editor", "java.effect.registry", "effect_color_valid", true);
        Add(sb, "enchantment.maxLevel", "enchantments[].maxLevel", "Enchantment Editor", "data.enchantment.json", "enchantment_level_valid", true);
        Add(sb, "sound.file", "sounds[].file", "Sound Editor", "assets.sounds_json", "sound_file_present", true);
        Add(sb, "particle.texture", "particles[].texture", "Particle Editor", "assets.particle_json", "particle_texture_present", false);
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static void Add(StringBuilder sb, string id, string dataPath, string ui, string generator, string validator, bool comma)
    {
        sb.Append("    { ");
        sb.Append("\"id\": \"").Append(EquipmentGameplayBindingUtility.EscapeJson(id)).Append("\", ");
        sb.Append("\"dataModel\": \"").Append(EquipmentGameplayBindingUtility.EscapeJson(dataPath)).Append("\", ");
        sb.Append("\"ui\": \"").Append(EquipmentGameplayBindingUtility.EscapeJson(ui)).Append("\", ");
        sb.Append("\"generator\": \"").Append(EquipmentGameplayBindingUtility.EscapeJson(generator)).Append("\", ");
        sb.Append("\"patchEngine\": \"safe_write_with_backup\", ");
        sb.Append("\"validator\": \"").Append(EquipmentGameplayBindingUtility.EscapeJson(validator)).Append("\" ");
        sb.Append("}");
        if (comma) sb.Append(",");
        sb.AppendLine();
    }

    public static void Export(string projectRoot, string modId)
    {
        if (string.IsNullOrEmpty(projectRoot)) return;
        string path = Path.Combine(projectRoot, ".modstudio/field-bindings/equipment-gameplay-field-catalog.json");
        string dir = Path.GetDirectoryName(path);
        if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
        File.WriteAllText(path, BuildJson(modId), Encoding.UTF8);
    }
}
