using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class StudioFieldBindingReport
{
    public int totalFields;
    public int connectedFields;
    public int incompleteFields;
    public List<string> issues = new List<string>();
    public List<string> summaries = new List<string>();

    public bool HasErrors()
    {
        return issues != null && issues.Count > 0;
    }

    public string Format()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("=== Mod Studio Field Binding Report ===");
        sb.AppendLine("Total fields: " + totalFields);
        sb.AppendLine("Connected fields: " + connectedFields);
        sb.AppendLine("Incomplete fields: " + incompleteFields);
        if (issues != null && issues.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Issues:");
            foreach (string issue in issues)
            {
                sb.AppendLine("- " + issue);
            }
        }
        if (summaries != null && summaries.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Bindings:");
            foreach (string line in summaries)
            {
                sb.AppendLine("- " + line);
            }
        }
        return sb.ToString();
    }
}
