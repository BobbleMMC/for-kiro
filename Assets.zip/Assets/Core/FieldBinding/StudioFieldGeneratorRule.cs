using System;

[Serializable]
public class StudioFieldGeneratorRule
{
    public string id = string.Empty;
    public string target = string.Empty;
    public string outputKind = string.Empty;
    public string description = string.Empty;
    public string templateHint = string.Empty;

    public StudioFieldGeneratorRule() { }

    public StudioFieldGeneratorRule(string id, string target, string outputKind, string description, string templateHint = "")
    {
        this.id = id;
        this.target = target;
        this.outputKind = outputKind;
        this.description = description;
        this.templateHint = templateHint;
    }
}
