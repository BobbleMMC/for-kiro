using System.IO;
using System.Text;

public static class AdvancementFunctionConfigFieldBindingCatalog
{
    public static void Export(string projectRoot, string modId)
    {
        if (string.IsNullOrEmpty(projectRoot)) return;
        modId = AdvancementFunctionConfigBindingUtility.CleanId(modId, "mymod");
        string path = Path.Combine(projectRoot, ".modstudio/field-bindings/advancement-function-config-field-catalog.json");
        string dir = Path.GetDirectoryName(path);
        if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
        File.WriteAllText(path, BuildJson(modId), Encoding.UTF8);
    }

    public static string BuildJson(string modId)
    {
        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"modId\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(modId) + "\",");
        sb.AppendLine("  \"patch\": 32,");
        sb.AppendLine("  \"bindings\": [");
        Add(sb, "advancement.id", "advancements[].advancementId", "Advancement Editor", "data.advancements.json", "advancement_id_valid", true);
        Add(sb, "advancement.display", "advancements[].displayName", "Advancement Editor", "assets.lang", "advancement_lang_exists", true);
        Add(sb, "advancement.criteria", "advancements[].criteriaCsv", "Advancement Editor", "data.advancements.criteria", "criteria_not_empty", true);
        Add(sb, "advancement.rewards", "advancements[].rewardExperience/rewardLootTablesCsv/rewardRecipesCsv", "Advancement Editor", "data.advancements.rewards", "rewards_valid", true);
        Add(sb, "function.id", "functions[].functionId", "Function Editor", "data.functions.mcfunction", "function_id_valid", true);
        Add(sb, "function.commands", "functions[].commandsText", "Function Editor", "data.functions.mcfunction", "commands_not_empty", true);
        Add(sb, "function.load_tick_tags", "functions[].addToLoadTag/addToTickTag", "Function Editor", "data.minecraft.tags.functions", "function_tag_values_valid", true);
        Add(sb, "config.id", "configs[].configId", "Config Editor", ".modstudio.config", "config_id_valid", true);
        Add(sb, "config.entries", "configs[].entriesCsv", "Config Editor", ".modstudio.config.schemas", "config_entries_valid", true);
        Add(sb, "config.custom_text", "configs[].customConfigText", "Config Editor", ".modstudio.config", "config_text_valid", false);
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static void Add(StringBuilder sb, string id, string dataPath, string ui, string generator, string validator, bool comma)
    {
        sb.AppendLine("    {");
        sb.AppendLine("      \"id\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(id) + "\",");
        sb.AppendLine("      \"dataModel\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(dataPath) + "\",");
        sb.AppendLine("      \"uiEditor\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(ui) + "\",");
        sb.AppendLine("      \"generator\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(generator) + "\",");
        sb.AppendLine("      \"validator\": \"" + AdvancementFunctionConfigBindingUtility.EscapeJson(validator) + "\"");
        sb.Append("    }");
        sb.AppendLine(comma ? "," : "");
    }
}
