using System;
using System.Collections.Generic;

[Serializable]
public class StudioFieldBinding
{
    public string id = string.Empty;
    public string label = string.Empty;
    public string featureType = string.Empty;
    public string dataPath = string.Empty;
    public string uiType = "text";
    public string defaultValue = string.Empty;
    public string description = string.Empty;
    public string editorPage = string.Empty;

    public List<StudioFieldGeneratorRule> generatorRules = new List<StudioFieldGeneratorRule>();
    public List<StudioFieldPatchRule> patchRules = new List<StudioFieldPatchRule>();
    public List<StudioFieldValidationRule> validationRules = new List<StudioFieldValidationRule>();

    public StudioFieldBinding() { }

    public StudioFieldBinding(string id, string label, string featureType, string dataPath, string uiType, string defaultValue, string editorPage, string description)
    {
        this.id = id;
        this.label = label;
        this.featureType = featureType;
        this.dataPath = dataPath;
        this.uiType = uiType;
        this.defaultValue = defaultValue;
        this.editorPage = editorPage;
        this.description = description;
    }

    public StudioFieldBinding AddGenerator(string id, string target, string outputKind, string description, string templateHint = "")
    {
        generatorRules.Add(new StudioFieldGeneratorRule(id, target, outputKind, description, templateHint));
        return this;
    }

    public StudioFieldBinding AddPatch(string id, string targetFile, string mergeStrategy, string description)
    {
        patchRules.Add(new StudioFieldPatchRule(id, targetFile, mergeStrategy, description));
        return this;
    }

    public StudioFieldBinding AddValidator(string id, string severity, string target, string ruleType, string description, string expected = "")
    {
        validationRules.Add(new StudioFieldValidationRule(id, severity, target, ruleType, description, expected));
        return this;
    }

    public bool IsFullyConnected()
    {
        return !string.IsNullOrEmpty(id)
            && !string.IsNullOrEmpty(dataPath)
            && !string.IsNullOrEmpty(uiType)
            && generatorRules != null && generatorRules.Count > 0
            && validationRules != null && validationRules.Count > 0;
    }

    public string FormatSummary()
    {
        string status = IsFullyConnected() ? "OK" : "INCOMPLETE";
        return string.Format("[{0}] {1} -> {2} | UI={3} | gen={4} | val={5}", status, id, dataPath, uiType,
            generatorRules == null ? 0 : generatorRules.Count,
            validationRules == null ? 0 : validationRules.Count);
    }
}
