using System;

[Serializable]
public class StudioFieldPatchRule
{
    public string id = string.Empty;
    public string targetFile = string.Empty;
    public string mergeStrategy = "append_if_missing";
    public string description = string.Empty;

    public StudioFieldPatchRule() { }

    public StudioFieldPatchRule(string id, string targetFile, string mergeStrategy, string description)
    {
        this.id = id;
        this.targetFile = targetFile;
        this.mergeStrategy = mergeStrategy;
        this.description = description;
    }
}
