using System;
using System.Collections.Generic;
using System.Linq;

public static class StudioFieldRegistry
{
    private static readonly List<StudioFieldBinding> _fields = new List<StudioFieldBinding>();
    private static bool _initialized;

    public static IReadOnlyList<StudioFieldBinding> All
    {
        get
        {
            EnsureInitialized();
            return _fields;
        }
    }

    public static void EnsureInitialized()
    {
        if (_initialized) return;
        _initialized = true;
        _fields.Clear();
        RegisterDefaults();
    }

    public static void Register(StudioFieldBinding binding)
    {
        if (binding == null || string.IsNullOrEmpty(binding.id)) return;
        int existing = _fields.FindIndex(x => string.Equals(x.id, binding.id, StringComparison.OrdinalIgnoreCase));
        if (existing >= 0) _fields[existing] = binding;
        else _fields.Add(binding);
    }

    public static StudioFieldBinding Find(string id)
    {
        EnsureInitialized();
        return _fields.FirstOrDefault(x => string.Equals(x.id, id, StringComparison.OrdinalIgnoreCase));
    }

    public static List<StudioFieldBinding> ByFeature(string featureType)
    {
        EnsureInitialized();
        return _fields.Where(x => string.Equals(x.featureType, featureType, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    public static List<StudioFieldBinding> ByEditorPage(string editorPage)
    {
        EnsureInitialized();
        return _fields.Where(x => string.Equals(x.editorPage, editorPage, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    public static StudioFieldBindingReport ValidateRegistry()
    {
        EnsureInitialized();
        StudioFieldBindingReport report = new StudioFieldBindingReport();
        HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (StudioFieldBinding field in _fields)
        {
            report.totalFields++;
            if (!seen.Add(field.id)) report.issues.Add("Duplicate field id: " + field.id);
            if (field.IsFullyConnected()) report.connectedFields++;
            else
            {
                report.incompleteFields++;
                if (string.IsNullOrEmpty(field.dataPath)) report.issues.Add(field.id + ": dataPath bo'sh");
                if (field.generatorRules == null || field.generatorRules.Count == 0) report.issues.Add(field.id + ": generator rule yo'q");
                if (field.validationRules == null || field.validationRules.Count == 0) report.issues.Add(field.id + ": validator rule yo'q");
            }
            report.summaries.Add(field.FormatSummary());
        }
        return report;
    }

    private static StudioFieldBinding Field(string id, string label, string feature, string dataPath, string ui, string def, string page, string description)
    {
        StudioFieldBinding f = new StudioFieldBinding(id, label, feature, dataPath, ui, def, page, description);
        Register(f);
        return f;
    }

    private static void RegisterDefaults()
    {
        RegisterProjectFields();
        RegisterBlockFields();
        RegisterItemFields();
        RegisterDataFields();
        RegisterEntityFields();
        RegisterWorldgenFields();
        RegisterClientAssetFields();
    }

    private static void RegisterProjectFields()
    {
        Field("project.modId", "Mod ID", "project", "project.modId", "text", "mymod", "project", "Mod namespace/id")
            .AddGenerator("project.fabric_mod_json", "fabric.mod.json", "json", "mod id metadata yoziladi")
            .AddPatch("project.modid.patch", "src/main/resources/fabric.mod.json", "json_merge", "id field merge qilinadi")
            .AddValidator("project.modid.valid", "error", "project.modId", "regex", "modId faqat lowercase, number va underscore", "^[a-z][a-z0-9_]*$");

        Field("project.loader", "Loader", "project", "project.loader", "dropdown", "fabric", "project", "Fabric/Forge/NeoForge/Quilt tanlovi")
            .AddGenerator("project.loader.scaffold", "scaffold", "template", "loaderga mos scaffold tanlanadi")
            .AddValidator("project.loader.supported", "error", "project.loader", "enum", "loader qo'llab-quvvatlanishi kerak", "fabric|forge|neoforge|quilt");

        Field("project.minecraftVersion", "Minecraft Version", "project", "project.minecraftVersion", "text", "1.21.1", "project", "Minecraft target version")
            .AddGenerator("project.version.gradle", "gradle.properties", "properties", "minecraft_version yoziladi")
            .AddPatch("project.version.patch", "gradle.properties", "properties_merge", "minecraft_version yangilanadi")
            .AddValidator("project.version.compat", "error", "compatibility", "matrix", "loader/dependency matrix bilan mos bo'lishi kerak");

        Field("project.javaVersion", "Java Version", "project", "project.javaVersion", "integer", "21", "project", "Java target")
            .AddGenerator("project.java.gradle", "build.gradle", "gradle", "Java toolchain yoziladi")
            .AddValidator("project.java.range", "error", "project.javaVersion", "range", "Java 17 yoki 21 bo'lishi kerak", "17..21");
    }

    private static void RegisterBlockFields()
    {
        Field("block.id", "Block ID", "block", "blocks[].blockId", "text", "custom_block", "block", "Block registry id")
            .AddGenerator("block.registry", "java.block.registry", "java", "block registry field va register call")
            .AddGenerator("block.models", "assets.models.block", "json", "block model json")
            .AddValidator("block.id.valid", "error", "blocks[].blockId", "resource_id", "valid resource id");

        Field("block.displayName", "Display Name", "block", "blocks[].displayName", "text", "Custom Block", "block", "Translation display name")
            .AddGenerator("block.lang", "assets.lang.en_us", "json", "block translation entry")
            .AddPatch("block.lang.patch", "src/main/resources/assets/<modid>/lang/en_us.json", "json_merge", "lang entry merge")
            .AddValidator("block.name.present", "warning", "blocks[].displayName", "required", "display name bo'sh bo'lmasin");

        Field("block.hardness", "Hardness", "block", "blocks[].hardness", "float", "3", "block", "Mining hardness")
            .AddGenerator("block.hardness.java", "java.block.settings", "java", "strength(hardness,resistance)")
            .AddValidator("block.hardness.range", "error", "blocks[].hardness", "range", "hardness 0..50 oralig'ida", "0..50");

        Field("block.blastResistance", "Blast Resistance", "block", "blocks[].resistance", "float", "6", "block", "Explosion resistance")
            .AddGenerator("block.resistance.java", "java.block.settings", "java", "strength(hardness,resistance)")
            .AddValidator("block.resistance.range", "error", "blocks[].resistance", "range", "blast resistance 0..120", "0..120");

        Field("block.lightLevel", "Light Level", "block", "blocks[].lightLevel", "integer", "0", "block", "Luminance 0..15")
            .AddGenerator("block.light.java", "java.block.settings", "java", "luminance lambda qo'shiladi")
            .AddPatch("block.light.patch", "src/main/java/<package>/block/<BlockClass>.java", "java_stub", "block Settings luminance patch/stub")
            .AddValidator("block.light.range", "error", "blocks[].lightLevel", "range", "light level 0..15", "0..15");

        Field("block.requiresTool", "Requires Tool", "block", "blocks[].advanced.behavior.requiresTool", "toggle", "true", "block", "Correct tool required")
            .AddGenerator("block.requires_tool.java", "java.block.settings", "java", "requiresTool flag")
            .AddGenerator("block.requires_tool.tags", "data.minecraft.tags.blocks", "json", "mineable/needs tag")
            .AddPatch("block.requires_tool.tag_patch", "src/main/resources/data/minecraft/tags/blocks/<tag>.json", "json_merge", "mineable tagga block qo'shiladi")
            .AddValidator("block.requires_tool.tag", "warning", "blocks[].advanced.behavior.requiredToolTag", "exists_when_true", "requiresTool true bo'lsa tool tag bo'lishi kerak");

        Field("block.miningToolTag", "Mining Tool Tag", "block", "blocks[].advanced.behavior.requiredToolTag", "text", "mineable/pickaxe", "block", "Mineable tag")
            .AddGenerator("block.mineable_tag", "data.minecraft.tags.blocks", "json", "mineable tag entry")
            .AddValidator("block.mineable_tag.valid", "warning", "blocks[].advanced.behavior.requiredToolTag", "resource_path", "tag path valid bo'lishi kerak");

        Field("block.miningLevel", "Mining Level", "block", "blocks[].advanced.behavior.miningLevel", "integer", "0", "block", "Tool tier / needs_*_tool tag")
            .AddGenerator("block.needs_tool_tag", "data.minecraft.tags.blocks", "json", "needs_stone/iron/diamond_tool tag")
            .AddValidator("block.mining_level.range", "warning", "blocks[].advanced.behavior.miningLevel", "range", "mining level 0..4", "0..4");

        Field("block.renderLayer", "Render Layer", "block", "blocks[].advanced.visual.renderLayer", "dropdown", "Solid", "block", "Solid/Cutout/Translucent layer")
            .AddGenerator("block.render_layer", "client.render_layers", "java_stub", "RenderLayer registration stub")
            .AddValidator("block.render_layer.transparent", "warning", "blocks[].advanced.visual", "cross_field", "transparent block renderLayer Solid bo'lmasin");

        Field("block.transparent", "Transparent", "block", "blocks[].advanced.visual.transparent", "toggle", "false", "block", "Transparent/cutout rendering")
            .AddGenerator("block.render_layer", "client.render_layers", "java_stub", "cutout/translucent render layer")
            .AddValidator("block.transparent.opaque_conflict", "warning", "blocks[].advanced.visual", "conflict", "transparent true bo'lsa opaque false bo'lishi kerak");

        Field("block.opaque", "Opaque", "block", "blocks[].advanced.visual.opaque", "toggle", "true", "block", "Opaque cube rendering")
            .AddGenerator("block.opaque.settings", "java.block.settings", "java_stub", "nonOpaque/notSolid settings stub")
            .AddValidator("block.opaque.transparent_conflict", "warning", "blocks[].advanced.visual", "conflict", "opaque va transparent birga true bo'lmasin");

        Field("block.waterlogged", "Waterlogged", "block", "blocks[].advanced.behavior.waterloggable", "toggle", "false", "block", "Block can contain water")
            .AddGenerator("block.waterlogged.java", "java.block.class", "java_stub", "Waterloggable interface/property/state methods")
            .AddGenerator("block.waterlogged.blockstate", "assets.blockstates", "json", "waterlogged state variant support")
            .AddPatch("block.waterlogged.patch", "src/main/java/<package>/block/<BlockClass>.java", "java_stub", "waterlogged property va methods stub")
            .AddValidator("block.waterlogged.state", "error", "blocks[].advanced.states.waterlogged", "has_property_when_true", "waterlogged true bo'lsa blockstate property bo'lishi kerak");

        Field("block.stateWaterlogged", "BlockState Waterlogged", "block", "blocks[].advanced.states.waterlogged", "toggle", "false", "blockstate", "Blockstate property flag")
            .AddGenerator("block.state.waterlogged", "assets.blockstates", "json", "blockstate waterlogged variants")
            .AddValidator("block.state.waterlogged.sync", "warning", "blocks[].advanced.behavior.waterloggable", "cross_field", "behavior waterloggable bilan mos bo'lishi kerak");

        Field("block.shapeMode", "Shape Mode", "block", "blocks[].advanced.collision.shapeMode", "dropdown", "FullCube", "block", "Collision/outline shape")
            .AddGenerator("block.shape.java", "java.block.shape", "java_stub", "getOutlineShape/getCollisionShape stub")
            .AddValidator("block.shape.custom_voxel", "error", "blocks[].advanced.collision.voxelShape", "exists_when_custom", "CustomVoxel bo'lsa voxel shape bo'lishi kerak");

        Field("block.noCollision", "No Collision", "block", "blocks[].advanced.collision.noCollision", "toggle", "false", "block", "Entity collision disabled")
            .AddGenerator("block.no_collision.java", "java.block.settings", "java_stub", "noCollision setting")
            .AddValidator("block.no_collision.conflict", "warning", "blocks[].advanced.collision", "conflict", "noCollision va fullCube conflict qilmasin");

        Field("block.blockEntity", "Block Entity", "block", "blocks[].advanced.blockEntity.enabled", "toggle", "false", "blockentity", "BlockEntity support")
            .AddGenerator("blockentity.class", "java.blockentity.class", "java_stub", "BlockEntity class stub")
            .AddGenerator("blockentity.registry", "java.blockentity.registry", "java_stub", "BlockEntityType registry")
            .AddPatch("blockentity.stub.patch", ".modstudio/generated-java/<loader>/<package>/blockentity", "java_stub", "BlockEntity stub yoziladi")
            .AddValidator("blockentity.registry.valid", "error", "blocks[].advanced.blockEntity", "exists_when_true", "BlockEntity registry bo'lishi kerak");

        Field("blockEntity.inventorySlots", "Inventory Slots", "block", "blocks[].advanced.blockEntity.inventorySlots", "integer", "9", "blockentity", "Inventory size")
            .AddGenerator("blockentity.inventory.stub", "java.blockentity.inventory", "java_stub", "inventory container stub")
            .AddValidator("blockentity.inventory.range", "error", "blocks[].advanced.blockEntity.inventorySlots", "range", "inventory slots 1..54", "1..54");
    }

    private static void RegisterItemFields()
    {
        Field("item.id", "Item ID", "item", "items[].itemId", "text", "custom_item", "item", "Item registry id")
            .AddGenerator("item.registry", "java.item.registry", "java_stub", "item register field/call stub")
            .AddGenerator("item.model", "assets.models.item", "json", "item model json")
            .AddPatch("item.registry.stub", ".modstudio/generated-java/<loader>/<package>/item", "java_stub", "registry stub yoziladi")
            .AddValidator("item.id.valid", "error", "items[].itemId", "resource_id", "valid item id");

        Field("item.displayName", "Display Name", "item", "items[].displayName", "text", "Custom Item", "item", "Item translation")
            .AddGenerator("item.lang", "assets.lang.en_us", "json", "item lang entry")
            .AddPatch("item.lang.patch", "src/main/resources/assets/<modid>/lang/en_us.json", "json_merge", "lang merge")
            .AddValidator("item.name.present", "warning", "items[].displayName", "required", "display name bo'sh bo'lmasin");

        Field("item.maxStackSize", "Max Stack Size", "item", "items[].stackSize", "integer", "64", "item", "Item stack size")
            .AddGenerator("item.stack.java", "java.item.settings", "java_stub", "maxCount/max_stack_size yoziladi")
            .AddValidator("item.stack.range", "error", "items[].stackSize", "range", "stack size 1..99", "1..99");

        Field("item.maxDamage", "Max Damage", "item", "items[].advanced.maxDamage", "integer", "0", "item", "Durability")
            .AddGenerator("item.damage.java", "java.item.settings", "java_stub", "maxDamage/max_damage component")
            .AddValidator("item.damage.stack", "error", "items[].advanced", "cross_field", "durability > 0 bo'lsa stack size 1 bo'lishi kerak");

        Field("item.fireproof", "Fireproof", "item", "items[].advanced.fireproof", "toggle", "false", "item", "Lava/fire resistant item")
            .AddGenerator("item.fireproof.java", "java.item.settings", "java_stub", "fireproof setting")
            .AddValidator("item.fireproof.food", "warning", "items[].advanced", "cross_field", "food + fireproof ataylab ekanini tekshiradi");

        Field("item.enchantability", "Enchantability", "item", "items[].advanced.enchantability", "integer", "10", "item", "Enchantability level")
            .AddGenerator("item.enchantability.java", "java.item.settings", "java_stub", "enchantability/data component")
            .AddValidator("item.enchantability.range", "warning", "items[].advanced.enchantability", "range", "0..100 tavsiya qilinadi", "0..100");

        Field("item.repairItem", "Repair Item", "item", "items[].advanced.repairItemId", "text", "minecraft:iron_ingot", "item", "Repair ingredient")
            .AddGenerator("item.repair.tag", "data.tags.items", "json", "repair material tag/descriptor")
            .AddValidator("item.repair.valid", "warning", "items[].advanced.repairItemId", "resource_id", "repair item id valid bo'lishi kerak");

        Field("item.food.enabled", "Food Item", "item", "items[].advanced.food.enabled", "toggle", "false", "food", "Food component enabled")
            .AddGenerator("item.food.java", "java.item.settings", "java_stub", "FoodComponent/DataComponent qo'shiladi")
            .AddValidator("item.food.values", "error", "items[].advanced.food", "range", "nutrition va saturation valid bo'lishi kerak");

        Field("item.food.nutrition", "Nutrition", "item", "items[].advanced.food.nutrition", "integer", "4", "food", "Food hunger points")
            .AddGenerator("item.food.nutrition", "java.food.component", "java_stub", "nutrition value")
            .AddValidator("item.food.nutrition.range", "error", "items[].advanced.food.nutrition", "range", "nutrition 0..20", "0..20");

        Field("item.food.saturation", "Saturation", "item", "items[].advanced.food.saturation", "float", "0.3", "food", "Food saturation modifier")
            .AddGenerator("item.food.saturation", "java.food.component", "java_stub", "saturation value")
            .AddValidator("item.food.saturation.range", "error", "items[].advanced.food.saturation", "range", "saturation 0..20", "0..20");

        Field("item.food.effects", "Food Effects", "item", "items[].advanced.food.statusEffects", "multiline", "", "food", "effect_id:duration:amplifier:chance")
            .AddGenerator("item.food.effects", "java.food.component", "java_stub", "status effect stubs")
            .AddValidator("item.food.effects.syntax", "warning", "items[].advanced.food.statusEffects", "syntax", "effect_id:duration:amplifier:chance formatini tekshiradi");

        Field("item.rarity", "Rarity", "item", "items[].advanced.rarity", "dropdown", "Common", "item", "Item rarity")
            .AddGenerator("item.rarity.java", "java.item.settings", "java_stub", "rarity/data component")
            .AddValidator("item.rarity.enum", "error", "items[].advanced.rarity", "enum", "Common/Uncommon/Rare/Epic", "Common|Uncommon|Rare|Epic");

        Field("item.modelType", "Model Type", "item", "items[].advanced.visual.modelType", "dropdown", "Generated", "item", "Generated/Handheld/Custom")
            .AddGenerator("item.model.parent", "assets.models.item", "json", "model parent tanlanadi")
            .AddValidator("item.model.custom_path", "warning", "items[].advanced.visual.customModelJsonPath", "exists_when_custom", "Custom model bo'lsa path kerak");

        Field("item.texture", "Texture Path", "item", "items[].advanced.visual.texturePath", "text", "custom_item", "item", "Texture id/path")
            .AddGenerator("item.model.texture", "assets.models.item", "json", "layer0 texture yoziladi")
            .AddValidator("item.texture.path", "warning", "items[].advanced.visual.texturePath", "resource_path", "texture path valid bo'lishi kerak");

        Field("item.glint", "Glint", "item", "items[].advanced.visual.hasGlint", "toggle", "false", "item", "Always glint visual")
            .AddGenerator("item.glint.class", "java.custom_item_class", "java_stub", "custom class hasGlint stub")
            .AddValidator("item.glint.custom_class", "warning", "items[].advanced.visual.hasGlint", "requires_custom_class", "glint uchun custom item class kerak");

        Field("item.useAction", "Use Action", "item", "items[].advanced.behavior.useAction", "dropdown", "None", "item", "Eat/Drink/Bow/Spear/Block/Custom")
            .AddGenerator("item.use_action.stub", "java.custom_item_class", "java_stub", "use action stub")
            .AddValidator("item.use_action.duration", "warning", "items[].advanced.behavior.useDuration", "range", "use duration valid bo'lishi kerak");

        Field("item.cooldown", "Cooldown", "item", "items[].advanced.behavior.cooldownTicks", "integer", "0", "item", "Cooldown ticks")
            .AddGenerator("item.cooldown.stub", "java.custom_item_class", "java_stub", "cooldown manager stub")
            .AddValidator("item.cooldown.range", "error", "items[].advanced.behavior.cooldownTicks", "range", "cooldown >= 0", "0..72000");

        Field("item.tooltip", "Tooltip Lines", "item", "items[].advanced.behavior.tooltipLines", "multiline", "", "item", "Tooltip text")
            .AddGenerator("item.tooltip.stub", "java.custom_item_class", "java_stub", "appendTooltip stub")
            .AddValidator("item.tooltip.length", "warning", "items[].advanced.behavior.tooltipLines", "length", "tooltip juda uzun bo'lmasin");

        Field("item.dataComponents", "Data Components", "item", "items[].advanced.components.customDataJson", "multiline", "{}", "datacomponent", "1.21+ custom data components")
            .AddGenerator("item.components.java", "java.item.components", "java_stub", "component registration/settings stub")
            .AddValidator("item.components.syntax", "warning", "items[].advanced.components.customDataJson", "json_object", "custom data JSON object bo'lishi kerak");
    }

    private static void RegisterDataFields()
    {
        Field("recipe.type", "Recipe Type", "recipe", "recipes[].pro.recipeType", "dropdown", "shaped", "recipe", "Recipe type")
            .AddGenerator("recipe.json", "data.recipes", "json", "recipe JSON output")
            .AddValidator("recipe.type.valid", "error", "recipes[].pro.recipeType", "enum", "supported recipe type");

        Field("loot.lootId", "Loot ID", "loot", "lootTables[].lootId", "text", "blocks/custom_block", "loot", "Loot table id")
            .AddGenerator("loot.json", "data.loot_tables", "json", "loot table JSON")
            .AddValidator("loot.id.valid", "error", "lootTables[].lootId", "resource_path", "loot id valid path");

        Field("tag.values", "Tag Values", "tag", "tags[].values", "multiline", "", "tag", "Tag entries")
            .AddGenerator("tag.json", "data.tags", "json", "tag JSON")
            .AddValidator("tag.values.not_empty", "warning", "tags[].values", "not_empty", "tag values bo'sh bo'lmasin");
    }

    private static void RegisterEntityFields()
    {
        Field("entity.ai.goals", "AI Goals", "entity", "entities[].advanced.aiGoalsCsv", "multiline", "wander:5", "entity-ai", "AI goals")
            .AddGenerator("entity.ai.java", "java.entity.goals", "java", "goal selector methods")
            .AddValidator("entity.ai.priority", "warning", "entities[].advanced.aiGoalsCsv", "priority_unique", "AI goal priorities conflict qilmasin");

        Field("entity.spawn.weight", "Spawn Weight", "entity", "entities[].advanced.spawnWeight", "integer", "20", "entity-spawn", "Spawn weight")
            .AddGenerator("entity.spawn.biome_mod", "java.biome_modifications", "java", "spawn rule registration")
            .AddValidator("entity.spawn.weight.range", "error", "entities[].advanced.spawnWeight", "range", "spawn weight 0..1000", "0..1000");
    }

    private static void RegisterWorldgenFields()
    {
        Field("biome.temperature", "Temperature", "biome", "biomes[].advanced.temperature", "float", "0.8", "biome", "Biome temperature")
            .AddGenerator("biome.json", "data.worldgen.biome", "json", "biome JSON")
            .AddValidator("biome.temperature.range", "warning", "biomes[].advanced.temperature", "range", "temperature -2..2", "-2..2");

        Field("dimension.height", "Height", "dimension", "worldgen.dimensions[].height", "integer", "384", "dimension", "Dimension height")
            .AddGenerator("dimension_type.json", "data.dimension_type", "json", "dimension_type JSON")
            .AddValidator("dimension.height.multiple16", "error", "worldgen.dimensions[].height", "multiple", "height 16ga bo'linishi kerak", "16");

        Field("structure.spacing", "Spacing", "structure", "worldgen.structures[].spacing", "integer", "24", "structure", "Structure set spacing")
            .AddGenerator("structure_set.json", "data.worldgen.structure_set", "json", "structure_set JSON")
            .AddValidator("structure.spacing.greater_separation", "error", "worldgen.structures[]", "cross_field", "spacing separationdan katta bo'lishi kerak");
    }

    private static void RegisterClientAssetFields()
    {
        Field("texture.id", "Texture ID", "texture", "textures[].textureId", "text", "custom_texture", "texture", "Texture id")
            .AddGenerator("texture.png", "assets.textures", "png", "PNG export")
            .AddGenerator("texture.model_link", "assets.models", "json", "texture-to-model auto link")
            .AddValidator("texture.id.valid", "error", "textures[].textureId", "resource_id", "texture id valid");

        Field("sound.id", "Sound ID", "sound", "sounds[].soundId", "text", "block.custom.hit", "sound", "Sound event id")
            .AddGenerator("sounds.json", "assets.sounds", "json", "sounds.json entry")
            .AddValidator("sound.id.valid", "warning", "sounds[].soundId", "resource_path", "sound id valid");

        Field("network.packetId", "Packet ID", "networking", "networkPackets[].packetId", "text", "sync_data", "networking", "Packet identifier")
            .AddGenerator("network.stub", "java.networking", "java_stub", "packet registration/handler stub")
            .AddValidator("network.direction.valid", "error", "networkPackets[].direction", "enum", "client_to_server/server_to_client");

        Field("keybind.id", "Keybind ID", "keybind", "keybinds[].keybindId", "text", "open_menu", "keybind", "Key mapping id")
            .AddGenerator("keybind.stub", "java.client.keybind", "java_stub", "keybind registration stub")
            .AddValidator("keybind.client_only", "warning", "keybinds[]", "side", "keybind faqat client tomonda bo'lishi kerak");
    }
}
