using System.Collections.Generic;
using System.Text;

public static class StudioFieldBindingUtility
{
    public static string BuildCompactReportForFeature(string featureType)
    {
        List<StudioFieldBinding> fields = StudioFieldRegistry.ByFeature(featureType);
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("Field binding coverage: " + featureType);
        foreach (StudioFieldBinding field in fields)
        {
            sb.AppendLine("- " + field.FormatSummary());
        }
        return sb.ToString();
    }

    public static string BuildGeneratorPlan(string fieldId)
    {
        StudioFieldBinding field = StudioFieldRegistry.Find(fieldId);
        if (field == null) return "Field topilmadi: " + fieldId;
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(field.id + " -> " + field.dataPath);
        sb.AppendLine("UI: " + field.uiType);
        sb.AppendLine("Generators:");
        if (field.generatorRules != null)
        {
            foreach (StudioFieldGeneratorRule rule in field.generatorRules)
            {
                sb.AppendLine("- " + rule.target + " [" + rule.outputKind + "] " + rule.description);
            }
        }
        sb.AppendLine("Validators:");
        if (field.validationRules != null)
        {
            foreach (StudioFieldValidationRule rule in field.validationRules)
            {
                sb.AppendLine("- " + rule.id + " [" + rule.severity + "] " + rule.description);
            }
        }
        return sb.ToString();
    }
}
