using System.IO;
using System.Text;

public static class RecipeLootTagFieldBindingCatalog
{
    public static string BuildManifestJson(string modId)
    {
        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"name\": \"Recipe/Loot/Tag Field Bindings\",");
        sb.AppendLine("  \"modId\": \"" + RecipeLootTagBindingUtility.EscapeJson(modId) + "\",");
        sb.AppendLine("  \"fields\": [");
        AppendField(sb, "recipe.recipeId", "recipes[].recipeId", "Recipe Editor Pro", "data/<modid>/recipes/<recipeId>.json", "recipe_id_valid", true);
        AppendField(sb, "recipe.type", "recipes[].pro.recipeType", "Recipe Editor Pro", "recipe.type", "recipe_type_supported", true);
        AppendField(sb, "recipe.ingredients", "recipes[].ingredients", "Recipe Editor Pro", "recipe.ingredients/key", "recipe_has_ingredients", true);
        AppendField(sb, "recipe.result", "recipes[].resultItem/resultCount", "Recipe Editor Pro", "recipe.result", "recipe_has_result", true);
        AppendField(sb, "loot.lootId", "lootTables[].lootId", "Loot Table Editor", "data/<modid>/loot_tables/**/*.json", "loot_id_valid", true);
        AppendField(sb, "loot.pools", "lootTables[].pools", "Loot Table Editor", "loot.pools", "loot_has_pools", true);
        AppendField(sb, "tag.tagId", "tags[].tagId", "Tag Editor", "data/<namespace>/tags/**/*.json", "tag_id_valid", true);
        AppendField(sb, "tag.values", "tags[].values", "Tag Editor", "tag.values", "tag_has_values", false);
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    public static void Export(string projectRoot, string modId)
    {
        if (string.IsNullOrEmpty(projectRoot)) return;
        string path = Path.Combine(projectRoot, ".modstudio/field-bindings/recipe-loot-tag-field-catalog.json");
        string dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
        File.WriteAllText(path, BuildManifestJson(modId), Encoding.UTF8);
    }

    private static void AppendField(StringBuilder sb, string id, string dataModel, string ui, string generator, string validator, bool comma)
    {
        sb.AppendLine("    {");
        sb.AppendLine("      \"id\": \"" + id + "\",");
        sb.AppendLine("      \"dataModel\": \"" + dataModel + "\",");
        sb.AppendLine("      \"ui\": \"" + ui + "\",");
        sb.AppendLine("      \"generator\": \"" + generator + "\",");
        sb.AppendLine("      \"patchEngine\": \"json_merge/write_if_missing\",");
        sb.AppendLine("      \"validator\": \"" + validator + "\"");
        sb.Append("    }");
        if (comma) sb.Append(",");
        sb.AppendLine();
    }
}
