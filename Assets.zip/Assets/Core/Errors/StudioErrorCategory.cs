/// <summary>
/// Build/crash xatolarining umumiy kategoriyalari.
/// </summary>
public enum StudioErrorCategory
{
    Unknown,
    JavaVersion,
    GradleWrapper,
    DependencyResolution,
    JavaCompile,
    MappingOrApiMismatch,
    JsonOrResource,
    ModMetadata,
    Mixin,
    MinecraftRuntime,
    Permission,
    Memory,
    Network
}

public enum StudioErrorSeverity
{
    Info,
    Warning,
    Error,
    Fatal
}
