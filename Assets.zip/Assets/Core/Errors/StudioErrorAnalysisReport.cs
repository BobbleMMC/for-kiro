using System;
using System.Collections.Generic;
using System.Text;

/// <summary>
/// Error Analyzer chiqargan yakuniy hisobot.
/// </summary>
[Serializable]
public class StudioErrorAnalysisReport
{
    public List<StudioErrorAnalysis> issues = new List<StudioErrorAnalysis>();
    public string rawSummary = string.Empty;

    public bool HasErrors()
    {
        foreach (StudioErrorAnalysis issue in issues)
        {
            if (issue.severity == StudioErrorSeverity.Error || issue.severity == StudioErrorSeverity.Fatal)
                return true;
        }
        return false;
    }

    public int ErrorCount()
    {
        int count = 0;
        foreach (StudioErrorAnalysis issue in issues)
        {
            if (issue.severity == StudioErrorSeverity.Error || issue.severity == StudioErrorSeverity.Fatal)
                count++;
        }
        return count;
    }

    public string Format()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("========== BUILD ERROR ANALYZER ==========");

        if (issues.Count == 0)
        {
            sb.AppendLine("Aniq xato pattern topilmadi. Agar build fail bo'lgan bo'lsa, logdagi birinchi 'Caused by' yoki 'Execution failed' qatorini tekshiring.");
            if (!string.IsNullOrEmpty(rawSummary)) sb.AppendLine(rawSummary);
            return sb.ToString();
        }

        sb.AppendLine($"Topilgan muammolar: {issues.Count}, jiddiy: {ErrorCount()}");
        sb.AppendLine();

        for (int i = 0; i < issues.Count; i++)
        {
            sb.AppendLine($"#{i + 1}");
            sb.AppendLine(issues[i].Format());
            sb.AppendLine();
        }

        return sb.ToString();
    }
}
