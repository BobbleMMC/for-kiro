using System.Collections.Generic;
using System.Text.RegularExpressions;

/// <summary>
/// Gradle/Minecraft loglarini o'qib, muammo turini va fix tavsiyasini chiqaradi.
/// </summary>
public static class StudioErrorAnalyzer
{
    private static readonly List<StudioErrorPattern> Patterns = new List<StudioErrorPattern>
    {
        new StudioErrorPattern
        {
            id = "java-invalid-home",
            category = StudioErrorCategory.JavaVersion,
            severity = StudioErrorSeverity.Fatal,
            regex = "JAVA_HOME is set to an invalid directory|invalid source release|Unsupported class file major version|release version \\d+ not supported",
            title = "Java versiyasi yoki JAVA_HOME noto'g'ri",
            likelyCause = "Minecraft/loader tanlangan versiyasi boshqa Java talab qilyapti yoki JAVA_HOME noto'g'ri papkaga ko'rsatgan.",
            suggestedFix = "Java 17 yoki Java 21 JDK o'rnating. 1.20.6+ va 1.21+ odatda Java 21 talab qiladi. JAVA_HOME_21 yoki JAVA_HOME ni JDK root papkasiga sozlang."
        },
        new StudioErrorPattern
        {
            id = "gradle-wrapper-missing",
            category = StudioErrorCategory.GradleWrapper,
            severity = StudioErrorSeverity.Error,
            regex = "gradlew(.bat)?' is not recognized|No such file or directory.*gradlew|gradle-wrapper.jar|Could not find or load main class org.gradle.wrapper.GradleWrapperMain",
            title = "Gradle wrapper to'liq emas",
            likelyCause = "gradlew bor, lekin wrapper jar/properties yetishmaydi yoki system Gradle topilmadi.",
            suggestedFix = "Project ichida wrapper fayllarini qayta yarating yoki system Gradle o'rnating. Keyingi scaffold export jarayonida gradlew fallback script ishlatiladi."
        },
        new StudioErrorPattern
        {
            id = "dependency-could-not-resolve",
            category = StudioErrorCategory.DependencyResolution,
            severity = StudioErrorSeverity.Error,
            regex = "Could not resolve|Could not find .*:|Unable to load Maven meta-data|Could not GET|Connection timed out|Read timed out",
            title = "Dependency yuklanmadi yoki Maven repository muammosi",
            likelyCause = "Fabric API/NeoForge/Quilt dependency versiyasi noto'g'ri, internet/repository muammosi yoki Gradle cache buzilgan.",
            suggestedFix = "VersionResolver tavsiya qilgan dependency versiyalarini tekshiring. Internetni tekshiring. Kerak bo'lsa Gradle cache clean qiling: gradle --refresh-dependencies build."
        },
        new StudioErrorPattern
        {
            id = "java-cannot-find-symbol",
            category = StudioErrorCategory.JavaCompile,
            severity = StudioErrorSeverity.Error,
            regex = "cannot find symbol|Cannot resolve symbol|package .* does not exist|class, interface, enum, or record expected|';' expected|incompatible types",
            title = "Java compile xatosi",
            likelyCause = "Generator yozgan kod tanlangan Minecraft/loader API versiyasiga mos emas yoki import/class nomi noto'g'ri.",
            suggestedFix = "Logdagi birinchi .java fayl va qatorni oching. Minecraft version/loader mosligini tekshiring, so'ng Template/Generatorni o'sha versiyaga moslang."
        },
        new StudioErrorPattern
        {
            id = "api-mapping-mismatch",
            category = StudioErrorCategory.MappingOrApiMismatch,
            severity = StudioErrorSeverity.Error,
            regex = "method_\\d+|field_\\d+|named:|intermediary|official mappings|NoSuchMethodError|NoSuchFieldError|ClassNotFoundException: net.minecraft",
            title = "Mapping/API mos kelmasligi",
            likelyCause = "Yarn/Mojmap/loader yoki Minecraft versiyasi o'zaro mos emas.",
            suggestedFix = "Compatibility Matrix natijasini tekshiring. Fabric uchun Yarn mapping, NeoForge/Forge uchun Mojmap ishlatilayotganini tasdiqlang."
        },
        new StudioErrorPattern
        {
            id = "json-resource-invalid",
            category = StudioErrorCategory.JsonOrResource,
            severity = StudioErrorSeverity.Error,
            regex = "JsonParseException|MalformedJsonException|Expected .* but was|Invalid json|Unable to parse|FileNotFoundException.*assets|missing model|Unable to load model|Unable to resolve texture",
            title = "JSON yoki asset/resource xatosi",
            likelyCause = "Model, blockstate, lang, recipe yoki texture path noto'g'ri yoki JSON sintaksisi buzilgan.",
            suggestedFix = "assets/<modid>/models, blockstates, textures va data/<modid>/recipes pathlarini tekshiring. JSONni validator bilan tekshiring."
        },
        new StudioErrorPattern
        {
            id = "metadata-invalid",
            category = StudioErrorCategory.ModMetadata,
            severity = StudioErrorSeverity.Error,
            regex = "fabric.mod.json|mods.toml|quilt.mod.json|Invalid mod id|mod id|Mod ID|Entrypoint|entrypoint",
            title = "Mod metadata xatosi",
            likelyCause = "modId, entrypoint, loader metadata yoki package/class nomi mos emas.",
            suggestedFix = "modId faqat kichik harf, raqam va underscore bo'lsin. fabric.mod.json/mods.toml entrypoint classi real Java class bilan bir xil ekanini tekshiring."
        },
        new StudioErrorPattern
        {
            id = "mixin-target-not-found",
            category = StudioErrorCategory.Mixin,
            severity = StudioErrorSeverity.Fatal,
            regex = "Critical injection failure|Mixin apply failed|could not find any targets|InjectionError|InvalidInjectionException",
            title = "Mixin target topilmadi",
            likelyCause = "Mixin yozilgan method/class tanlangan Minecraft mapping/versionda mavjud emas.",
            suggestedFix = "Mixin target methodni shu Minecraft versiyasi mappingiga qarab yangilang yoki mixinni vaqtincha o'chirib buildni tekshiring."
        },
        new StudioErrorPattern
        {
            id = "runtime-crash",
            category = StudioErrorCategory.MinecraftRuntime,
            severity = StudioErrorSeverity.Fatal,
            regex = "---- Minecraft Crash Report ----|java.lang.RuntimeException|Caused by:|Crash report saved to",
            title = "Minecraft runtime crash",
            likelyCause = "Build o'tgan, lekin o'yin ishga tushishda registry, asset, mixin yoki dependency sabab crash bo'lgan.",
            suggestedFix = "Logdagi eng birinchi 'Caused by:' qatorini tekshiring. Error Analyzer chiqargan boshqa kategoriyalarni ustuvor tuzating."
        },
        new StudioErrorPattern
        {
            id = "permission-denied",
            category = StudioErrorCategory.Permission,
            severity = StudioErrorSeverity.Error,
            regex = "Access is denied|Permission denied|UnauthorizedAccessException|used by another process",
            title = "Faylga ruxsat yo'q yoki fayl band",
            likelyCause = "Project papkasi protected joyda, fayl boshqa dasturda ochiq yoki antivirus bloklagan.",
            suggestedFix = "Projectni Documents/MinecraftMods kabi oddiy papkaga ko'chiring. Minecraft/Gradle jarayonini yoping va qayta build qiling."
        },
        new StudioErrorPattern
        {
            id = "out-of-memory",
            category = StudioErrorCategory.Memory,
            severity = StudioErrorSeverity.Error,
            regex = "OutOfMemoryError|Java heap space|GC overhead limit exceeded",
            title = "Gradle/Minecraft xotirasi yetmadi",
            likelyCause = "JVM heap kichik yoki mod/dependencylar ko'p xotira talab qilyapti.",
            suggestedFix = "gradle.properties ichida org.gradle.jvmargs=-Xmx2G yoki -Xmx4G qilib ko'ring."
        }
    };

    public static StudioErrorAnalysisReport Analyze(string log)
    {
        var report = new StudioErrorAnalysisReport();
        if (string.IsNullOrEmpty(log))
        {
            report.rawSummary = "Log bo'sh.";
            return report;
        }

        foreach (StudioErrorPattern pattern in Patterns)
        {
            if (!pattern.IsMatch(log)) continue;

            report.issues.Add(new StudioErrorAnalysis
            {
                id = pattern.id,
                category = pattern.category,
                severity = pattern.severity,
                title = pattern.title,
                likelyCause = pattern.likelyCause,
                suggestedFix = pattern.suggestedFix,
                evidence = ExtractEvidence(log, pattern.regex)
            });
        }

        if (report.issues.Count == 0)
            report.rawSummary = ExtractFallbackSummary(log);

        return report;
    }

    private static string ExtractEvidence(string log, string regex)
    {
        try
        {
            Match m = Regex.Match(log, regex, RegexOptions.IgnoreCase | RegexOptions.Multiline);
            if (m.Success)
            {
                int start = System.Math.Max(0, m.Index - 160);
                int length = System.Math.Min(log.Length - start, m.Length + 320);
                return log.Substring(start, length).Replace("\r", " ").Replace("\n", " ").Trim();
            }
        }
        catch
        {
        }

        return "Pattern topildi, lekin dalil fragmenti ajratilmadi.";
    }

    private static string ExtractFallbackSummary(string log)
    {
        string[] importantMarkers =
        {
            "Execution failed for task",
            "Caused by:",
            "BUILD FAILED",
            "Exception",
            "error:"
        };

        foreach (string marker in importantMarkers)
        {
            int idx = log.IndexOf(marker, System.StringComparison.OrdinalIgnoreCase);
            if (idx >= 0)
            {
                int start = System.Math.Max(0, idx - 120);
                int len = System.Math.Min(log.Length - start, 900);
                return log.Substring(start, len).Trim();
            }
        }

        int tailLen = System.Math.Min(log.Length, 1200);
        return log.Substring(log.Length - tailLen, tailLen).Trim();
    }
}
