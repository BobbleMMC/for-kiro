using System;
using System.Text.RegularExpressions;

/// <summary>
/// Error Analyzer uchun regex asosidagi qoida.
/// </summary>
[Serializable]
public class StudioErrorPattern
{
    public string id;
    public StudioErrorCategory category;
    public StudioErrorSeverity severity;
    public string regex;
    public string title;
    public string likelyCause;
    public string suggestedFix;

    public bool IsMatch(string log)
    {
        if (string.IsNullOrEmpty(log) || string.IsNullOrEmpty(regex)) return false;
        return Regex.IsMatch(log, regex, RegexOptions.IgnoreCase | RegexOptions.Multiline);
    }
}
