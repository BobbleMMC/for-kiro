using System;

/// <summary>
/// Bitta topilgan build/runtime muammosi.
/// </summary>
[Serializable]
public class StudioErrorAnalysis
{
    public string id;
    public StudioErrorCategory category;
    public StudioErrorSeverity severity;
    public string title;
    public string likelyCause;
    public string suggestedFix;
    public string evidence;

    public string Format()
    {
        return $"[{severity}] {title}\nSabab: {likelyCause}\nYechim: {suggestedFix}\nDalil: {evidence}";
    }
}
