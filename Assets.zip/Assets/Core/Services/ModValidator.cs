using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;

/// <summary>
/// Project Validator — mod loyihasidagi xatoliklarni oldindan aniqlaydi.
/// Kompilatsiyadan OLDIN tekshiradi va foydalanuvchiga ogohlantirish beradi.
///
/// Tekshirishlar:
///   • ID validatsiya (Java naming rules)
///   • ID conflict detection (dublikatlar)
///   • Missing texture references
///   • Invalid recipe ingredients
///   • Versiya moslik tekshirish
///   • Hardness/resistance oqilona chegaralar
/// </summary>
public static class ModValidator
{
    // ═══════════════════════════════════════════════════════════════════════
    // VALIDATSIYA NATIJALARI
    // ═══════════════════════════════════════════════════════════════════════

    public enum ValidationSeverity
    {
        Error,       // Kompilatsiya qilmaydi
        Warning,     // Ishlaydi lekin muammo chiqishi mumkin
        Info         // Tavsiya
    }

    [System.Serializable]
    public class ValidationResult
    {
        public ValidationSeverity severity;
        public string category;     // "ID", "Recipe", "Texture", "Version"
        public string message;
        public string elementId;    // Qaysi elementda muammo

        public ValidationResult(ValidationSeverity sev, string cat, string msg, string elemId = "")
        {
            severity = sev;
            category = cat;
            message = msg;
            elementId = elemId;
        }

        public override string ToString()
        {
            string icon = severity == ValidationSeverity.Error ? "❌" : severity == ValidationSeverity.Warning ? "⚠️" : "ℹ️";
            return $"{icon} [{category}] {message}";
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ASOSIY VALIDATSIYA
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// WorkspaceData ni to'liq tekshiradi.
    /// Barcha xatoliklar, ogohlantirishlar va tavsiyalarni qaytaradi.
    /// </summary>
    public static List<ValidationResult> ValidateWorkspace(WorkspaceData workspace)
    {
        var results = new List<ValidationResult>();

        if (workspace == null)
        {
            results.Add(new ValidationResult(ValidationSeverity.Error, "System", "Workspace ma'lumotlari topilmadi!"));
            return results;
        }

        // 1. Mod ID validatsiya
        ValidateModId(workspace.modId, results);

        // 2. Element ID lar
        ValidateBlockIds(workspace.blocks, results);
        ValidateItemIds(workspace.items, results);
        ValidateToolIds(workspace.tools, results);
        ValidateArmorIds(workspace.armors, results);
        ValidateEntityIds(workspace.entities, results);

        // 3. ID conflict (dublikatlar)
        DetectIdConflicts(workspace, results);

        // 4. Recipe validatsiya
        ValidateRecipes(workspace, results);

        // 5. Qiymat chegaralari
        ValidateValueRanges(workspace, results);

        // 12-patch: Recipe Pro + Loot + Tag editorlar
        ValidateRecipeLootTagEditors(workspace, results);

        // 16-patch: GUI/Screen + Config editorlar
        ValidateGuiConfigEditors(workspace, results);

        // 17-patch: Networking + Keybind editorlari
        ValidateNetworkingKeybindEditors(workspace, results);

        // 6. Advanced editor settings
        ValidateAdvancedEditorSettings(workspace, results);

        // 7. Versiya moslik
        ValidateVersionCompatibility(workspace, results);

        // 7. 3-patch: Version Resolver + Compatibility Matrix + Dependency Resolver
        ResolvedVersionSet resolved = VersionResolver.Resolve(workspace);
        if (resolved.warnings != null)
        {
            foreach (var warning in resolved.warnings)
                results.Add(new ValidationResult(ValidationSeverity.Warning, "VersionResolver", warning));
        }

        CompatibilityReport compatibility = CompatibilityMatrix.Check(workspace, resolved);
        AddCompatibilityIssues(compatibility, results);

        DependencyResolutionResult dependencyResolution = StudioDependencyResolver.ResolveForWorkspace(workspace, resolved);
        if (dependencyResolution.issues != null)
        {
            foreach (var issue in dependencyResolution.issues)
                results.Add(new ValidationResult(ToValidationSeverity(issue.severity), issue.category, issue.message, issue.ruleId));
        }

        // 8. 2-patch: semantic StudioProject manifest validatsiyasi
        workspace.studioProject = ProjectStateManager.SyncFromWorkspace(workspace);
        results.AddRange(SemanticProjectValidator.Validate(workspace.studioProject));

        // 9. 7-patch: Asset Validator + JSON Validator.
        // Builddan oldin model JSON, blockstate, recipe, lang va texture reference muammolarini ushlaydi.
        results.AddRange(StudioAssetValidator.ValidateWorkspaceAssets(workspace));

        return results;
    }

    /// <summary>
    /// Faqat xatoliklar sonini qaytaradi (tez tekshirish).
    /// </summary>
    public static int GetErrorCount(List<ValidationResult> results)
    {
        int count = 0;
        foreach (var r in results)
            if (r.severity == ValidationSeverity.Error) count++;
        return count;
    }

    /// <summary>
    /// Natijalarni formatlangan matn sifatida qaytaradi.
    /// </summary>
    public static string FormatResults(List<ValidationResult> results)
    {
        if (results.Count == 0) return "✅ Xatoliklar topilmadi! Loyiha tayyor.";

        StringBuilder sb = new StringBuilder();
        int errors = 0, warnings = 0, infos = 0;

        foreach (var r in results)
        {
            if (r.severity == ValidationSeverity.Error) errors++;
            else if (r.severity == ValidationSeverity.Warning) warnings++;
            else infos++;

            sb.AppendLine(r.ToString());
        }

        sb.Insert(0, $"─── Tekshirish natijasi: {errors} xato, {warnings} ogohlantirish, {infos} tavsiya ───\n\n");
        return sb.ToString();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // VALIDATSIYA QOIDALARI
    // ═══════════════════════════════════════════════════════════════════════

    private static void ValidateModId(string modId, List<ValidationResult> results)
    {
        if (string.IsNullOrEmpty(modId))
        {
            results.Add(new ValidationResult(ValidationSeverity.Error, "ID", "Mod ID bo'sh! Mod ID belgilang."));
            return;
        }

        if (modId.Length < 2)
            results.Add(new ValidationResult(ValidationSeverity.Error, "ID", "Mod ID juda qisqa (minimum 2 belgi).", modId));

        if (modId.Length > 64)
            results.Add(new ValidationResult(ValidationSeverity.Error, "ID", "Mod ID juda uzun (maksimum 64 belgi).", modId));

        if (!Regex.IsMatch(modId, @"^[a-z][a-z0-9_]*$"))
            results.Add(new ValidationResult(ValidationSeverity.Error, "ID",
                $"Mod ID '{modId}' noto'g'ri! Faqat kichik harflar, raqamlar va pastki chiziq (_) ishlatish mumkin. Harf bilan boshlanishi kerak.", modId));

        // Minecraft reserved IDs
        string[] reserved = { "minecraft", "forge", "fabric", "neoforge", "quilt", "java", "realms" };
        foreach (string r in reserved)
        {
            if (modId == r)
                results.Add(new ValidationResult(ValidationSeverity.Error, "ID", $"'{modId}' — bu tizim tomonidan band qilingan ID!", modId));
        }
    }

    private static bool IsValidElementId(string id)
    {
        if (string.IsNullOrEmpty(id)) return false;
        return Regex.IsMatch(id, @"^[a-z][a-z0-9_]*$");
    }

    private static void ValidateBlockIds(List<BlockDataModel> blocks, List<ValidationResult> results)
    {
        if (blocks == null) return;
        foreach (var block in blocks)
        {
            if (!IsValidElementId(block.blockId))
                results.Add(new ValidationResult(ValidationSeverity.Error, "ID",
                    $"Blok ID '{block.blockId}' noto'g'ri! Faqat kichik harf, raqam va _ ishlatish mumkin.", block.blockId));
        }
    }

    private static void ValidateItemIds(List<ItemDataModel> items, List<ValidationResult> results)
    {
        if (items == null) return;
        foreach (var item in items)
        {
            if (!IsValidElementId(item.itemId))
                results.Add(new ValidationResult(ValidationSeverity.Error, "ID",
                    $"Item ID '{item.itemId}' noto'g'ri!", item.itemId));
        }
    }

    private static void ValidateToolIds(List<ToolDataModel> tools, List<ValidationResult> results)
    {
        if (tools == null) return;
        foreach (var tool in tools)
        {
            if (!IsValidElementId(tool.toolId))
                results.Add(new ValidationResult(ValidationSeverity.Error, "ID",
                    $"Tool ID '{tool.toolId}' noto'g'ri!", tool.toolId));
        }
    }

    private static void ValidateArmorIds(List<ArmorDataModel> armors, List<ValidationResult> results)
    {
        if (armors == null) return;
        foreach (var armor in armors)
        {
            if (!IsValidElementId(armor.armorId))
                results.Add(new ValidationResult(ValidationSeverity.Error, "ID",
                    $"Armor ID '{armor.armorId}' noto'g'ri!", armor.armorId));
        }
    }

    private static void ValidateEntityIds(List<EntityDataModel> entities, List<ValidationResult> results)
    {
        if (entities == null) return;
        foreach (var entity in entities)
        {
            if (!IsValidElementId(entity.entityId))
                results.Add(new ValidationResult(ValidationSeverity.Error, "ID",
                    $"Entity ID '{entity.entityId}' noto'g'ri!", entity.entityId));
        }
    }

    private static void DetectIdConflicts(WorkspaceData workspace, List<ValidationResult> results)
    {
        var allIds = new Dictionary<string, string>(); // id → element type

        if (workspace.blocks != null)
            foreach (var b in workspace.blocks) CheckDuplicate(allIds, b.blockId, "Block", results);
        if (workspace.items != null)
            foreach (var i in workspace.items) CheckDuplicate(allIds, i.itemId, "Item", results);
        if (workspace.tools != null)
            foreach (var t in workspace.tools) CheckDuplicate(allIds, t.toolId, "Tool", results);
        if (workspace.armors != null)
            foreach (var a in workspace.armors) CheckDuplicate(allIds, a.armorId, "Armor", results);
    }

    private static void CheckDuplicate(Dictionary<string, string> allIds, string id, string type, List<ValidationResult> results)
    {
        if (string.IsNullOrEmpty(id)) return;

        if (allIds.ContainsKey(id))
        {
            results.Add(new ValidationResult(ValidationSeverity.Error, "Conflict",
                $"ID '{id}' dublikat! Avval {allIds[id]} da, endi {type} da ishlatilgan.", id));
        }
        else
        {
            allIds[id] = type;
        }
    }

    private static void ValidateRecipes(WorkspaceData workspace, List<ValidationResult> results)
    {
        if (workspace.recipes == null) return;

        foreach (var recipe in workspace.recipes)
        {
            // Natija tekshirish
            if (string.IsNullOrEmpty(recipe.resultItem))
                results.Add(new ValidationResult(ValidationSeverity.Error, "Recipe", "Retsept natijasi bo'sh!"));

            if (recipe.resultCount < 1)
                results.Add(new ValidationResult(ValidationSeverity.Warning, "Recipe",
                    $"Retsept natija soni 0 yoki manfiy ({recipe.resultCount}).", recipe.resultItem));

            // Shaped/Shapeless — kamida 1 ta ingredient kerak
            if (recipe.recipeType == RecipeType.CraftingShaped || recipe.recipeType == RecipeType.CraftingShapeless)
            {
                bool hasIngredient = false;
                if (recipe.grid != null)
                {
                    foreach (string slot in recipe.grid)
                    {
                        if (!string.IsNullOrEmpty(slot?.Trim())) { hasIngredient = true; break; }
                    }
                }
                if (!hasIngredient)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Recipe",
                        $"Retsept '{recipe.resultItem}' uchun ingredient yo'q!", recipe.resultItem));
            }

            // Smelting — input kerak
            if (recipe.recipeType == RecipeType.Smelting || recipe.recipeType == RecipeType.Blasting ||
                recipe.recipeType == RecipeType.Smoking || recipe.recipeType == RecipeType.CampfireCooking)
            {
                if (string.IsNullOrEmpty(recipe.smeltingInput))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Recipe",
                        $"Pishirish retsepti '{recipe.resultItem}' uchun kirish materiali belgilanmagan!", recipe.resultItem));
            }
        }
    }

    private static void ValidateValueRanges(WorkspaceData workspace, List<ValidationResult> results)
    {
        if (workspace.blocks != null)
        {
            foreach (var block in workspace.blocks)
            {
                if (block.hardness < 0)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Value",
                        $"Blok '{block.blockId}' qattiqligi manfiy ({block.hardness}).", block.blockId));
                if (block.hardness > 100)
                    results.Add(new ValidationResult(ValidationSeverity.Info, "Value",
                        $"Blok '{block.blockId}' juda qattiq ({block.hardness}). Obsidian = 50.", block.blockId));
                if (block.lightLevel > 15)
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Value",
                        $"Blok '{block.blockId}' yorug'lik darajasi 15 dan oshmasligi kerak!", block.blockId));
            }
        }

        if (workspace.entities != null)
        {
            foreach (var entity in workspace.entities)
            {
                if (entity.health <= 0)
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Value",
                        $"Entity '{entity.entityId}' sog'lig'i 0 yoki manfiy!", entity.entityId));
                if (entity.health > 2048)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Value",
                        $"Entity '{entity.entityId}' sog'lig'i juda yuqori ({entity.health}). Wither = 300.", entity.entityId));
            }
        }
    }



    private static void ValidateRecipeLootTagEditors(WorkspaceData workspace, List<ValidationResult> results)
    {
        if (workspace == null) return;

        if (workspace.recipes != null)
        {
            foreach (var recipe in workspace.recipes)
            {
                if (recipe == null) continue;
                recipe.EnsureProSettings();
                var pro = recipe.pro;

                if (!string.IsNullOrWhiteSpace(pro.recipeId) && !Regex.IsMatch(pro.recipeId, @"^[a-z0-9_./:-]+$"))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "RecipePro", $"Recipe ID '{pro.recipeId}' noto'g'ri. Kichik harf, raqam, _, /, ., : ishlating.", pro.recipeId));

                if (recipe.resultCount < 1 || recipe.resultCount > 64)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "RecipePro", $"Recipe '{recipe.resultItem}' resultCount 1-64 oralig'ida bo'lishi tavsiya qilinadi.", recipe.resultItem));

                if (!string.IsNullOrWhiteSpace(pro.customJsonOverride) && !StudioJsonSyntaxValidator.LooksLikeJsonObject(pro.customJsonOverride))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "RecipePro", $"Recipe '{recipe.resultItem}' custom JSON override valid object emas.", recipe.resultItem));

                if (pro.useTagsAsIngredients && recipe.recipeType == RecipeType.CraftingShaped && recipe.grid != null)
                {
                    foreach (string slot in recipe.grid)
                    {
                        if (!string.IsNullOrWhiteSpace(slot) && slot.StartsWith("#") == false && slot.Contains(":") == false)
                        {
                            results.Add(new ValidationResult(ValidationSeverity.Info, "RecipePro", $"'{recipe.resultItem}' ingredient '{slot}' namespace yoki tag (#tag) bilan yozilsa xavfsizroq.", recipe.resultItem));
                            break;
                        }
                    }
                }
            }
        }

        if (workspace.lootTables != null)
        {
            foreach (var loot in workspace.lootTables)
            {
                if (loot == null || !loot.enabled) continue;
                if (string.IsNullOrWhiteSpace(loot.lootId) && string.IsNullOrWhiteSpace(loot.targetId))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Loot", "Loot table uchun lootId yoki targetId kerak."));
                if (!string.IsNullOrWhiteSpace(loot.customJsonOverride) && !StudioJsonSyntaxValidator.LooksLikeJsonObject(loot.customJsonOverride))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Loot", $"Loot '{loot.lootId}' custom JSON override valid object emas.", loot.lootId));
                if (loot.pools == null || loot.pools.Count == 0)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Loot", $"Loot '{loot.lootId}' pool bo'sh. Exportda default pool ishlatiladi.", loot.lootId));
            }
        }

        if (workspace.tags != null)
        {
            foreach (var tag in workspace.tags)
            {
                if (tag == null || !tag.enabled) continue;
                tag.SyncValuesFromCsv();
                if (string.IsNullOrWhiteSpace(tag.tagId))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Tag", "Tag ID bo'sh bo'lmasligi kerak."));
                if (!Regex.IsMatch(tag.tagId ?? "", @"^[a-z0-9_./:-]+$"))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Tag", $"Tag ID '{tag.tagId}' noto'g'ri.", tag.tagId));
                if ((tag.values == null || tag.values.Count == 0) && string.IsNullOrWhiteSpace(tag.customJsonOverride))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Tag", $"Tag '{tag.tagId}' ichida values yo'q.", tag.tagId));
                if (!string.IsNullOrWhiteSpace(tag.customJsonOverride) && !StudioJsonSyntaxValidator.LooksLikeJsonObject(tag.customJsonOverride))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Tag", $"Tag '{tag.tagId}' custom JSON override valid object emas.", tag.tagId));
            }
        }
    }


    private static void ValidateGuiConfigEditors(WorkspaceData workspace, List<ValidationResult> results)
    {
        if (workspace == null) return;

        if (workspace.screens != null)
        {
            foreach (var screen in workspace.screens)
            {
                if (screen == null || !screen.enabled) continue;

                if (string.IsNullOrWhiteSpace(screen.screenId) || !Regex.IsMatch(screen.screenId, @"^[a-z][a-z0-9_]*$"))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "GUI", $"Screen ID '{screen.screenId}' noto'g'ri. Kichik harf, raqam va _ ishlating.", screen.screenId));

                if (screen.width < 64 || screen.height < 64)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "GUI", $"Screen '{screen.screenId}' juda kichik ({screen.width}x{screen.height}).", screen.screenId));

                if (screen.screenType == StudioScreenType.BlockEntityContainer && string.IsNullOrWhiteSpace(screen.linkedBlockId))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "GUI", $"Screen '{screen.screenId}' container turida, lekin linkedBlockId bo'sh.", screen.screenId));

                screen.SyncSlotsFromCsv();
                if (screen.showPlayerInventory && (screen.playerInventoryX < 0 || screen.playerInventoryY < 0))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "GUI", $"Screen '{screen.screenId}' player inventory koordinatasi manfiy.", screen.screenId));

                if (screen.containerSlots > 216)
                    results.Add(new ValidationResult(ValidationSeverity.Error, "GUI", $"Screen '{screen.screenId}' containerSlots 216 dan oshmasligi kerak.", screen.screenId));

                if (screen.hasProgressBar && (screen.progressWidth <= 0 || screen.progressHeight <= 0))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "GUI", $"Screen '{screen.screenId}' progress bar o'lchami noto'g'ri.", screen.screenId));
            }
        }

        if (workspace.configs != null)
        {
            foreach (var config in workspace.configs)
            {
                if (config == null || !config.enabled) continue;

                if (string.IsNullOrWhiteSpace(config.configId) || !Regex.IsMatch(config.configId, @"^[a-z][a-z0-9_]*$"))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Config", $"Config ID '{config.configId}' noto'g'ri. Kichik harf, raqam va _ ishlating.", config.configId));

                if (string.IsNullOrWhiteSpace(config.fileName))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Config", $"Config '{config.configId}' fileName bo'sh. Export default nom ishlatadi.", config.configId));

                config.SyncEntriesFromCsv();
                if ((config.entries == null || config.entries.Count == 0) && string.IsNullOrWhiteSpace(config.customConfigText))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Config", $"Config '{config.configId}' ichida entry yo'q.", config.configId));

                if (config.format == StudioConfigFormat.Json && !string.IsNullOrWhiteSpace(config.customConfigText) && !StudioJsonSyntaxValidator.LooksLikeJsonObject(config.customConfigText))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Config", $"Config '{config.configId}' custom JSON valid object emas.", config.configId));
            }
        }
    }


    private static void ValidateNetworkingKeybindEditors(WorkspaceData workspace, List<ValidationResult> results)
    {
        if (workspace == null) return;

        HashSet<string> packetIds = new HashSet<string>();
        if (workspace.networkPackets != null)
        {
            foreach (var packet in workspace.networkPackets)
            {
                if (packet == null || !packet.enabled) continue;

                if (string.IsNullOrWhiteSpace(packet.packetId) || !Regex.IsMatch(packet.packetId, @"^[a-z][a-z0-9_./:-]*$"))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Networking", $"Packet ID '{packet.packetId}' noto'g'ri. Kichik harf, raqam, _, /, ., : ishlating.", packet.packetId));
                else if (!packetIds.Add(packet.packetId))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Networking", $"Packet ID duplicate: {packet.packetId}", packet.packetId));

                if (string.IsNullOrWhiteSpace(packet.channelPath))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Networking", $"Packet '{packet.packetId}' channelPath bo'sh. packetId fallback ishlatiladi.", packet.packetId));

                packet.SyncFieldsFromCsv();
                if (packet.payloadFields == null || packet.payloadFields.Count == 0)
                    results.Add(new ValidationResult(ValidationSeverity.Info, "Networking", $"Packet '{packet.packetId}' payload fieldlarsiz. Bu marker/trigger packet bo'lsa normal.", packet.packetId));

                if (packet.syncBlockEntity && string.IsNullOrWhiteSpace(packet.linkedBlockId))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Networking", $"Packet '{packet.packetId}' syncBlockEntity yoqilgan, lekin linkedBlockId bo'sh.", packet.packetId));

                if (packet.direction == StudioPacketDirection.ServerToClient && packet.requiresValidation)
                    results.Add(new ValidationResult(ValidationSeverity.Info, "Networking", $"Packet '{packet.packetId}' ServerToClient yo'nalishda. Server-side sender validation faqat ClientToServer uchun muhim.", packet.packetId));
            }
        }

        if (workspace.keybinds != null)
        {
            foreach (var keybind in workspace.keybinds)
            {
                if (keybind == null || !keybind.enabled) continue;

                if (string.IsNullOrWhiteSpace(keybind.keybindId) || !Regex.IsMatch(keybind.keybindId, @"^[a-z][a-z0-9_]*$"))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Keybind", $"Keybind ID '{keybind.keybindId}' noto'g'ri. Kichik harf, raqam va _ ishlating.", keybind.keybindId));

                if (string.IsNullOrWhiteSpace(keybind.defaultKey))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Keybind", $"Keybind '{keybind.keybindId}' defaultKey bo'sh.", keybind.keybindId));

                if (keybind.cooldownTicks < 0)
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Keybind", $"Keybind '{keybind.keybindId}' cooldown manfiy bo'lmasligi kerak.", keybind.keybindId));

                if (keybind.actionType == StudioKeybindActionType.SendPacket)
                {
                    if (string.IsNullOrWhiteSpace(keybind.sendPacketId))
                        results.Add(new ValidationResult(ValidationSeverity.Error, "Keybind", $"Keybind '{keybind.keybindId}' SendPacket tanlangan, lekin sendPacketId bo'sh.", keybind.keybindId));
                    else if (packetIds.Count > 0 && !packetIds.Contains(keybind.sendPacketId))
                        results.Add(new ValidationResult(ValidationSeverity.Warning, "Keybind", $"Keybind '{keybind.keybindId}' packet '{keybind.sendPacketId}' ga ulanmoqchi, lekin enabled packetlar ichida topilmadi.", keybind.keybindId));
                }

                if (keybind.actionType == StudioKeybindActionType.OpenScreen && string.IsNullOrWhiteSpace(keybind.openScreenId))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Keybind", $"Keybind '{keybind.keybindId}' OpenScreen tanlangan, lekin openScreenId bo'sh.", keybind.keybindId));
            }
        }
    }


    private static void ValidateAdvancedEditorSettings(WorkspaceData workspace, List<ValidationResult> results)
    {
        if (workspace == null) return;

        if (workspace.items != null)
        {
            foreach (var item in workspace.items)
            {
                if (item == null) continue;
                item.EnsureAdvancedSettings();
                var adv = item.advanced;

                if (item.stackSize < 1 || item.stackSize > 64)
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Item", $"Item '{item.itemId}' stack size 1-64 oralig'ida bo'lishi kerak.", item.itemId));

                if (adv.maxDamage > 0 && item.stackSize > 1)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Item", $"Durability bor item '{item.itemId}' odatda stackSize=1 bo'lishi kerak.", item.itemId));

                if (adv.food.enabled || item.isFood)
                {
                    if (adv.food.nutrition < 0 || adv.food.nutrition > 40)
                        results.Add(new ValidationResult(ValidationSeverity.Warning, "Food", $"'{item.itemId}' nutrition qiymati g'ayrioddiy: {adv.food.nutrition}.", item.itemId));
                    if (adv.food.saturation < 0)
                        results.Add(new ValidationResult(ValidationSeverity.Error, "Food", $"'{item.itemId}' saturation manfiy bo'lmasligi kerak.", item.itemId));
                }

                if (adv.visual.modelType == StudioItemModelType.Custom && string.IsNullOrEmpty(adv.visual.customModelJsonPath))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Visual", $"'{item.itemId}' custom model tanlangan, lekin model JSON path berilmagan.", item.itemId));

                if (adv.components.enableDataComponents && !string.IsNullOrEmpty(adv.components.customDataJson))
                {
                    string json = adv.components.customDataJson.Trim();
                    if (!(json.StartsWith("{") && json.EndsWith("}")))
                        results.Add(new ValidationResult(ValidationSeverity.Warning, "DataComponents", $"'{item.itemId}' customDataJson JSON obyekt ko'rinishida bo'lishi kerak.", item.itemId));
                }
            }
        }

        if (workspace.blocks != null)
        {
            foreach (var block in workspace.blocks)
            {
                if (block == null) continue;
                block.EnsureAdvancedSettings();
                var adv = block.advanced;

                if (block.lightLevel < 0 || block.lightLevel > 15)
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Block", $"Blok '{block.blockId}' light level 0-15 oralig'ida bo'lishi kerak.", block.blockId));

                if (adv.visual.renderLayer == StudioBlockRenderLayer.Translucent && adv.visual.opaque)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Render", $"'{block.blockId}' translucent render layer ishlatsa opaque=false bo'lishi tavsiya qilinadi.", block.blockId));

                if (adv.behavior.redstoneOutput && (adv.behavior.redstonePower < 0 || adv.behavior.redstonePower > 15))
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Redstone", $"'{block.blockId}' redstone power 0-15 oralig'ida bo'lishi kerak.", block.blockId));

                if (adv.behavior.flammable && adv.behavior.burnChance == 0 && adv.behavior.spreadChance == 0)
                    results.Add(new ValidationResult(ValidationSeverity.Info, "Fire", $"'{block.blockId}' flammable yoqilgan, lekin burn/spread chance 0.", block.blockId));

                if (adv.collision.noCollision && adv.collision.fullCube)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "Collision", $"'{block.blockId}' noCollision va fullCube birga tanlangan. Odatda bittasi tanlanadi.", block.blockId));

                if (adv.states.waterlogged && !adv.behavior.waterloggable)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "BlockState", $"'{block.blockId}' waterlogged state bor, lekin behavior.waterloggable o'chirilgan.", block.blockId));

                if (adv.blockEntity.enabled)
                {
                    if (adv.blockEntity.hasInventory && adv.blockEntity.inventorySlots <= 0)
                        results.Add(new ValidationResult(ValidationSeverity.Error, "BlockEntity", $"'{block.blockId}' inventory slotlari 0 dan katta bo'lishi kerak.", block.blockId));
                    if (adv.blockEntity.hasScreen && !adv.blockEntity.hasInventory)
                        results.Add(new ValidationResult(ValidationSeverity.Info, "BlockEntity", $"'{block.blockId}' screen yoqilgan, lekin inventory yo'q. Bu custom GUI bo'lishi mumkin.", block.blockId));
                }
            }
        }

        if (workspace.entities != null)
        {
            foreach (var entity in workspace.entities)
            {
                if (entity == null) continue;
                entity.EnsureAdvancedSettings();
                var adv = entity.advanced;

                if (entity.width <= 0f || entity.height <= 0f)
                    results.Add(new ValidationResult(ValidationSeverity.Error, "Entity", $"Entity '{entity.entityId}' width/height 0 dan katta bo'lishi kerak.", entity.entityId));

                if (entity.movementSpeed < 0f || entity.movementSpeed > 3f)
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "EntityAttributes", $"'{entity.entityId}' movementSpeed g'ayrioddiy: {entity.movementSpeed}.", entity.entityId));

                if (entity.followRange < 0f)
                    results.Add(new ValidationResult(ValidationSeverity.Error, "EntityAttributes", $"'{entity.entityId}' followRange manfiy bo'lmasligi kerak.", entity.entityId));

                if (adv.attributes.scale <= 0f)
                    results.Add(new ValidationResult(ValidationSeverity.Error, "EntityAttributes", $"'{entity.entityId}' scale 0 dan katta bo'lishi kerak.", entity.entityId));

                if (adv.spawn.naturalSpawn)
                {
                    if (adv.spawn.spawnWeight < 0)
                        results.Add(new ValidationResult(ValidationSeverity.Error, "EntitySpawn", $"'{entity.entityId}' spawnWeight manfiy bo'lmasligi kerak.", entity.entityId));
                    if (adv.spawn.minGroup < 1 || adv.spawn.maxGroup < 1 || adv.spawn.minGroup > adv.spawn.maxGroup)
                        results.Add(new ValidationResult(ValidationSeverity.Error, "EntitySpawn", $"'{entity.entityId}' group size noto'g'ri: {adv.spawn.minGroup}-{adv.spawn.maxGroup}.", entity.entityId));
                    if (adv.spawn.minY > adv.spawn.maxY)
                        results.Add(new ValidationResult(ValidationSeverity.Error, "EntitySpawn", $"'{entity.entityId}' minY maxY dan katta bo'lmasligi kerak.", entity.entityId));
                    if (adv.spawn.minLight < 0 || adv.spawn.maxLight > 15 || adv.spawn.minLight > adv.spawn.maxLight)
                        results.Add(new ValidationResult(ValidationSeverity.Error, "EntitySpawn", $"'{entity.entityId}' light range 0-15 oralig'ida va min<=max bo'lishi kerak.", entity.entityId));
                    if (adv.spawn.dimension == StudioEntityDimensionPreset.Custom && string.IsNullOrWhiteSpace(adv.spawn.customDimensionId))
                        results.Add(new ValidationResult(ValidationSeverity.Warning, "EntitySpawn", $"'{entity.entityId}' custom dimension tanlangan, lekin ID berilmagan.", entity.entityId));
                }

                if (adv.visual.rendererType == StudioEntityRendererType.GeckoLib && string.IsNullOrWhiteSpace(adv.visual.animationJsonPath))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "EntityRenderer", $"'{entity.entityId}' GeckoLib renderer tanlangan, lekin animation JSON path bo'sh.", entity.entityId));

                if (adv.visual.rendererType == StudioEntityRendererType.CustomRenderer && string.IsNullOrWhiteSpace(adv.visual.customRendererClass))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "EntityRenderer", $"'{entity.entityId}' custom renderer tanlangan, lekin class nomi berilmagan.", entity.entityId));

                if (!IsHexColor(adv.visual.spawnEggPrimaryHex) || !IsHexColor(adv.visual.spawnEggSecondaryHex))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "SpawnEgg", $"'{entity.entityId}' spawn egg ranglari 6 xonali HEX bo'lishi tavsiya qilinadi.", entity.entityId));

                if (adv.behavior.bossBar && entity.mobCategory != MobCategory.Boss)
                    results.Add(new ValidationResult(ValidationSeverity.Info, "EntityBehavior", $"'{entity.entityId}' bossBar yoqilgan, lekin category Boss emas.", entity.entityId));

                if (adv.behavior.tameable && string.IsNullOrWhiteSpace(adv.behavior.tameItemId))
                    results.Add(new ValidationResult(ValidationSeverity.Warning, "EntityBehavior", $"'{entity.entityId}' tameable yoqilgan, lekin tame item ID bo'sh.", entity.entityId));
            }
        }

    }



    private static bool IsHexColor(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        value = value.Trim().TrimStart('#');
        if (value.Length != 6) return false;
        for (int i = 0; i < value.Length; i++)
        {
            char c = value[i];
            bool ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
            if (!ok) return false;
        }
        return true;
    }

    private static void AddCompatibilityIssues(CompatibilityReport report, List<ValidationResult> results)
    {
        if (report == null || report.issues == null) return;
        foreach (var issue in report.issues)
        {
            results.Add(new ValidationResult(
                ToValidationSeverity(issue.severity),
                issue.category,
                issue.message,
                issue.ruleId));
        }
    }

    private static ValidationSeverity ToValidationSeverity(CompatibilitySeverity severity)
    {
        if (severity == CompatibilitySeverity.Error) return ValidationSeverity.Error;
        if (severity == CompatibilitySeverity.Warning) return ValidationSeverity.Warning;
        return ValidationSeverity.Info;
    }

    private static void ValidateVersionCompatibility(WorkspaceData workspace, List<ValidationResult> results)
    {
        string version = workspace.mcVersion;
        string loader = workspace.modloader;

        var vData = StudioDatabase.GetVersionData(version);
        if (vData == null)
        {
            results.Add(new ValidationResult(ValidationSeverity.Warning, "Version",
                $"Minecraft versiyasi '{version}' bazada topilmadi. Noto'g'ri versiya bo'lishi mumkin."));
            return;
        }

        // Modloader moslik
        if (vData.supportedModloaders != null && !vData.supportedModloaders.Contains(loader))
        {
            results.Add(new ValidationResult(ValidationSeverity.Error, "Version",
                $"'{loader}' modloader Minecraft {version} uchun qo'llab-quvvatlanmaydi! " +
                $"Mavjud: {string.Join(", ", vData.supportedModloaders)}"));
        }

        // Java versiya ogohlantirish
        if (vData.requiredJavaVersion >= 21 && (version == "1.20.6" || version.StartsWith("1.21") || version.StartsWith("1.22")))
        {
            results.Add(new ValidationResult(ValidationSeverity.Info, "Version",
                $"Minecraft {version} Java {vData.requiredJavaVersion} talab qiladi. Tizimingizda mavjudligini tekshiring."));
        }
    }
}
