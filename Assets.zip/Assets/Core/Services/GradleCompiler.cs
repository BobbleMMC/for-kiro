using System;
using System.IO;
using System.Text;
using UnityEngine;

/// <summary>
/// Backward-compatible facade.
/// Eski UI hali GradleCompiler.RunMinecraftClient(...) chaqirishi mumkin,
/// ichkarida esa 6-patch Build Runner + Error Analyzer ishlaydi.
/// </summary>
public class GradleCompiler
{
    private readonly Action<string> _onLogReceived;
    private readonly Action<string> _onErrorReceived;
    private readonly GradleBuildRunner _runner;
    private readonly StringBuilder _lastLog = new StringBuilder();
    private StudioBuildResult _lastResult;

    public bool IsRunning
    {
        get { return _runner != null && _runner.IsRunning; }
    }

    public GradleCompiler(Action<string> onLogReceived, Action<string> onErrorReceived)
    {
        _onLogReceived = onLogReceived;
        _onErrorReceived = onErrorReceived;
        _runner = new GradleBuildRunner(HandleLog, HandleError, HandleCompleted);
    }

    public void RunMinecraftClient(string projectPath, int targetJavaVersion)
    {
        RunGradleTask(projectPath, targetJavaVersion, StudioBuildTask.RunClient);
    }

    public void RunBuild(string projectPath, int targetJavaVersion)
    {
        RunGradleTask(projectPath, targetJavaVersion, StudioBuildTask.Build);
    }

    public void RunDataGen(string projectPath, int targetJavaVersion)
    {
        RunGradleTask(projectPath, targetJavaVersion, StudioBuildTask.RunData);
    }

    public void RunGenSources(string projectPath, int targetJavaVersion)
    {
        RunGradleTask(projectPath, targetJavaVersion, StudioBuildTask.GenSources);
    }

    public void RunClean(string projectPath, int targetJavaVersion)
    {
        RunGradleTask(projectPath, targetJavaVersion, StudioBuildTask.Clean);
    }

    public void RunCustomTask(string projectPath, int targetJavaVersion, string customTask)
    {
        RunGradleTask(projectPath, targetJavaVersion, StudioBuildTask.Custom, customTask);
    }

    public void RunGradleTask(string projectPath, int targetJavaVersion, StudioBuildTask task, string customTask = "")
    {
        if (string.IsNullOrEmpty(projectPath) || !Directory.Exists(projectPath))
        {
            _onErrorReceived?.Invoke($"[BuildRunner] Loyiha papkasi topilmadi: {projectPath}");
            return;
        }

        if (IsRunning)
        {
            _onLogReceived?.Invoke("[BuildRunner] Gradle allaqachon ishlayapti. Kerak bo'lsa Stop tugmasini bosing.");
            return;
        }

        _lastLog.Length = 0;
        _lastResult = null;

        var request = new StudioBuildRequest
        {
            projectPath = projectPath,
            targetJavaVersion = targetJavaVersion,
            task = task,
            customTask = customTask,
            noDaemon = true,
            stacktrace = true,
            info = false
        };

        _onLogReceived?.Invoke($"[BuildRunner] {request.GetGradleTaskName()} boshlandi...");
        _runner.Run(request);
    }

    public void StopProcess()
    {
        if (_runner == null)
        {
            _onLogReceived?.Invoke("[BuildRunner] Runner hali ishga tushmagan.");
            return;
        }

        _runner.Stop();
    }

    public StudioErrorAnalysisReport AnalyzeLastLog()
    {
        if (_lastResult != null && _lastResult.analysis != null)
            return _lastResult.analysis;

        return StudioErrorAnalyzer.Analyze(_lastLog.ToString());
    }

    public StudioBuildResult GetLastResult()
    {
        return _lastResult;
    }

    public string GetLastLog()
    {
        if (_lastResult != null && !string.IsNullOrEmpty(_lastResult.combinedLog))
            return _lastResult.combinedLog;
        return _lastLog.ToString();
    }

    private void HandleLog(string line)
    {
        if (!string.IsNullOrEmpty(line)) _lastLog.AppendLine(line);
        _onLogReceived?.Invoke(line);
    }

    private void HandleError(string line)
    {
        if (!string.IsNullOrEmpty(line)) _lastLog.AppendLine(line);
        _onErrorReceived?.Invoke(line);
    }

    private void HandleCompleted(StudioBuildResult result)
    {
        _lastResult = result;
        if (result != null)
        {
            _onLogReceived?.Invoke(result.GetSummary());

            if (result.analysis != null && result.analysis.HasErrors())
            {
                _onErrorReceived?.Invoke(result.analysis.Format());
            }
            else if (result.analysis != null)
            {
                _onLogReceived?.Invoke(result.analysis.Format());
            }
        }
    }

    public static string FindJavaPath(int version)
    {
        return StudioGradleEnvironmentProbe.FindJavaHome(version);
    }
}
