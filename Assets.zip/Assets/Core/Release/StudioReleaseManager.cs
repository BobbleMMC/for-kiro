using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using UnityEngine;

public static class StudioReleaseManager
{
    public static StudioReleaseReport Analyze(WorkspaceData workspace, string projectPath, string releaseVersion)
    {
        var report = new StudioReleaseReport
        {
            projectPath = projectPath,
            releaseVersion = NormalizeVersion(releaseVersion)
        };

        if (workspace == null)
        {
            report.AddIssue(new StudioReleaseIssue("error", "WORKSPACE_NULL", "Workspace ma'lumotlari topilmadi.", "", "Unity oynasini qayta oching yoki project.mstudio faylini tekshiring."));
            return report;
        }

        if (string.IsNullOrWhiteSpace(projectPath) || !Directory.Exists(projectPath))
        {
            report.AddIssue(new StudioReleaseIssue("error", "PROJECT_FOLDER_MISSING", "Export qilingan Minecraft mod project papkasi topilmadi.", projectPath, "Avval project papkasini tanlang va Save/Export qiling."));
            return report;
        }

        string modId = NormalizeModId(workspace.modId);
        string loader = (workspace.modloader ?? "Fabric").Trim().ToLowerInvariant();

        CheckRequiredFile(report, Path.Combine(projectPath, "build.gradle"), "GRADLE_BUILD_MISSING", "build.gradle topilmadi.", "Save/Export qilib scaffold fayllarini qayta yarating.");
        CheckRequiredFile(report, Path.Combine(projectPath, "settings.gradle"), "SETTINGS_GRADLE_MISSING", "settings.gradle topilmadi.", "Save/Export qilib scaffold fayllarini qayta yarating.");
        CheckRequiredFile(report, Path.Combine(projectPath, "gradle.properties"), "GRADLE_PROPERTIES_MISSING", "gradle.properties topilmadi.", "Save/Export qilib scaffold fayllarini qayta yarating.");

        if (loader.Contains("fabric"))
        {
            CheckRequiredFile(report, Path.Combine(projectPath, "src", "main", "resources", "fabric.mod.json"), "FABRIC_METADATA_MISSING", "fabric.mod.json topilmadi.", "Fabric metadata generator/export qismini qayta ishga tushiring.");
        }
        else if (loader.Contains("quilt"))
        {
            CheckRequiredFile(report, Path.Combine(projectPath, "src", "main", "resources", "quilt.mod.json"), "QUILT_METADATA_MISSING", "quilt.mod.json topilmadi.", "Quilt metadata generator/export qismini qayta ishga tushiring.");
        }
        else
        {
            CheckRequiredFile(report, Path.Combine(projectPath, "src", "main", "resources", "META-INF", "mods.toml"), "FORGE_METADATA_MISSING", "mods.toml topilmadi.", "Forge/NeoForge scaffold hali to'liq yaratilmagan bo'lishi mumkin.");
        }

        string resourcesRoot = Path.Combine(projectPath, "src", "main", "resources");
        CheckRequiredDirectory(report, resourcesRoot, "RESOURCES_ROOT_MISSING", "src/main/resources papkasi topilmadi.", "Save/Export qiling.");
        CheckRequiredDirectory(report, Path.Combine(resourcesRoot, "assets", modId), "ASSETS_NAMESPACE_MISSING", $"assets/{modId} namespace papkasi topilmadi.", "Asset pipeline yoki export jarayonini qayta ishga tushiring.");

        CheckOptionalDoc(report, Path.Combine(projectPath, "README.md"), "README_MISSING", "README.md release uchun kerak.", "Generate Release Docs tugmasini bosing.");
        CheckOptionalDoc(report, Path.Combine(projectPath, "CHANGELOG.md"), "CHANGELOG_MISSING", "CHANGELOG.md release tarixini saqlash uchun kerak.", "Generate Release Docs tugmasini bosing.");
        CheckOptionalDoc(report, Path.Combine(projectPath, "LICENSE"), "LICENSE_MISSING", "LICENSE fayli topilmadi.", "Generate Release Docs tugmasini bosing yoki o'zingiz tanlagan license qo'shing.");

        DetectArtifacts(report, projectPath);

        if (!HasUsableJar(report))
        {
            report.AddIssue(new StudioReleaseIssue("error", "JAR_MISSING", "build/libs ichida release .jar topilmadi.", Path.Combine(projectPath, "build", "libs"), "Avval Build Jar tugmasini bosing, build muvaffaqiyatli tugagandan keyin Release Package qiling."));
        }

        return report;
    }

    public static StudioReleaseReport CreateMissingReleaseDocs(WorkspaceData workspace, string projectPath, string releaseVersion)
    {
        Directory.CreateDirectory(projectPath);

        string modName = SafeText(workspace != null ? workspace.modName : "Minecraft Mod", "Minecraft Mod");
        string modId = NormalizeModId(workspace != null ? workspace.modId : "mymod");
        string mcVersion = SafeText(workspace != null ? workspace.mcVersion : "unknown", "unknown");
        string loader = SafeText(workspace != null ? workspace.modloader : "unknown", "unknown");
        string version = NormalizeVersion(releaseVersion);

        string readmePath = Path.Combine(projectPath, "README.md");
        if (!File.Exists(readmePath))
        {
            File.WriteAllText(readmePath, BuildReadme(modName, modId, mcVersion, loader, version), Encoding.UTF8);
        }

        string changelogPath = Path.Combine(projectPath, "CHANGELOG.md");
        if (!File.Exists(changelogPath))
        {
            File.WriteAllText(changelogPath, BuildChangelog(version), Encoding.UTF8);
        }

        string licensePath = Path.Combine(projectPath, "LICENSE");
        if (!File.Exists(licensePath))
        {
            File.WriteAllText(licensePath, BuildAllRightsReservedLicense(modName), Encoding.UTF8);
        }

        return Analyze(workspace, projectPath, version);
    }

    public static StudioReleaseReport CreateReleasePackage(WorkspaceData workspace, string projectPath, string releaseVersion)
    {
        string version = NormalizeVersion(releaseVersion);

        // Public release package ichida docs bo'lishi kerak. Yo'q bo'lsa xavfsiz placeholder yaratamiz.
        if (!string.IsNullOrWhiteSpace(projectPath) && Directory.Exists(projectPath))
        {
            CreateMissingReleaseDocs(workspace, projectPath, version);
        }

        var report = Analyze(workspace, projectPath, version);

        if (report.HasBlockingIssues())
        {
            return report;
        }

        string modId = NormalizeModId(workspace != null ? workspace.modId : "mymod");
        string releaseRoot = Path.Combine(projectPath, ".modstudio", "releases");
        Directory.CreateDirectory(releaseRoot);

        string stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string releaseFolder = Path.Combine(releaseRoot, $"{modId}-{version}-{stamp}");
        Directory.CreateDirectory(releaseFolder);
        report.releaseFolderPath = releaseFolder;

        string jarPath = FindLatestJar(projectPath);
        if (!string.IsNullOrEmpty(jarPath))
        {
            File.Copy(jarPath, Path.Combine(releaseFolder, Path.GetFileName(jarPath)), true);
        }

        CopyIfExists(Path.Combine(projectPath, "README.md"), Path.Combine(releaseFolder, "README.md"));
        CopyIfExists(Path.Combine(projectPath, "CHANGELOG.md"), Path.Combine(releaseFolder, "CHANGELOG.md"));
        CopyIfExists(Path.Combine(projectPath, "LICENSE"), Path.Combine(releaseFolder, "LICENSE"));

        File.WriteAllText(Path.Combine(releaseFolder, "QUALITY_REPORT.txt"), report.FormatDetails(), Encoding.UTF8);
        File.WriteAllText(Path.Combine(releaseFolder, "RELEASE_NOTES.md"), BuildReleaseNotes(workspace, version, report), Encoding.UTF8);
        File.WriteAllText(Path.Combine(releaseFolder, "release-manifest.json"), BuildReleaseManifest(workspace, version, report, jarPath), Encoding.UTF8);

        string zipPath = releaseFolder + ".zip";
        if (File.Exists(zipPath)) File.Delete(zipPath);
        ZipFile.CreateFromDirectory(releaseFolder, zipPath, System.IO.Compression.CompressionLevel.Optimal, false);

        report.packagePath = zipPath;
        report.artifacts.Clear();
        DetectArtifacts(report, projectPath);
        var zipInfo = new FileInfo(zipPath);
        report.AddArtifact(new StudioReleaseArtifact("release_zip", zipInfo.Name, zipInfo.FullName, MakeRelative(projectPath, zipInfo.FullName), zipInfo.Length));

        return report;
    }

    private static void CheckRequiredFile(StudioReleaseReport report, string path, string code, string message, string fix)
    {
        if (!File.Exists(path)) report.AddIssue(new StudioReleaseIssue("error", code, message, path, fix, true));
        else AddArtifact(report, "required_file", path);
    }

    private static void CheckRequiredDirectory(StudioReleaseReport report, string path, string code, string message, string fix)
    {
        if (!Directory.Exists(path)) report.AddIssue(new StudioReleaseIssue("error", code, message, path, fix, true));
    }

    private static void CheckOptionalDoc(StudioReleaseReport report, string path, string code, string message, string fix)
    {
        if (!File.Exists(path)) report.AddIssue(new StudioReleaseIssue("warning", code, message, path, fix, true));
        else AddArtifact(report, "release_doc", path);
    }

    private static void DetectArtifacts(StudioReleaseReport report, string projectPath)
    {
        string buildLibs = Path.Combine(projectPath, "build", "libs");
        if (Directory.Exists(buildLibs))
        {
            foreach (string jar in Directory.GetFiles(buildLibs, "*.jar", SearchOption.TopDirectoryOnly))
            {
                if (IsUsableJar(jar)) AddArtifact(report, "jar", jar);
            }
        }

        string releases = Path.Combine(projectPath, ".modstudio", "releases");
        if (Directory.Exists(releases))
        {
            foreach (string zip in Directory.GetFiles(releases, "*.zip", SearchOption.TopDirectoryOnly).OrderByDescending(File.GetLastWriteTimeUtc).Take(5))
            {
                AddArtifact(report, "release_zip", zip);
            }
        }
    }

    private static void AddArtifact(StudioReleaseReport report, string type, string path)
    {
        var fi = new FileInfo(path);
        report.AddArtifact(new StudioReleaseArtifact(type, fi.Name, fi.FullName, MakeRelative(report.projectPath, fi.FullName), fi.Exists ? fi.Length : 0));
    }

    private static bool HasUsableJar(StudioReleaseReport report)
    {
        return report.artifacts.Any(a => a != null && string.Equals(a.type, "jar", StringComparison.OrdinalIgnoreCase));
    }

    private static string FindLatestJar(string projectPath)
    {
        string buildLibs = Path.Combine(projectPath, "build", "libs");
        if (!Directory.Exists(buildLibs)) return "";
        return Directory.GetFiles(buildLibs, "*.jar", SearchOption.TopDirectoryOnly)
            .Where(IsUsableJar)
            .OrderByDescending(File.GetLastWriteTimeUtc)
            .FirstOrDefault() ?? "";
    }

    private static bool IsUsableJar(string jarPath)
    {
        string name = Path.GetFileName(jarPath).ToLowerInvariant();
        if (name.Contains("-sources")) return false;
        if (name.Contains("-javadoc")) return false;
        if (name.Contains("-dev")) return false;
        return true;
    }

    private static void CopyIfExists(string src, string dst)
    {
        if (File.Exists(src)) File.Copy(src, dst, true);
    }

    private static string BuildReadme(string modName, string modId, string mcVersion, string loader, string version)
    {
        return $@"# {modName}

**Mod ID:** `{modId}`  
**Version:** `{version}`  
**Minecraft:** `{mcVersion}`  
**Loader:** `{loader}`

## Description

This mod was generated with Mod Studio Desktop.

## Installation

1. Install the matching Minecraft mod loader.
2. Copy the generated `.jar` file into your Minecraft `mods` folder.
3. Launch Minecraft and test the mod.

## Release checklist

- Build completed successfully.
- Metadata files are valid.
- Required resources are included.
- Changelog and license are included.
";
    }

    private static string BuildChangelog(string version)
    {
        return $@"# Changelog

## {version} - {DateTime.Now:yyyy-MM-dd}

- Initial generated release candidate.
- Generated by Mod Studio Desktop Release Manager.
";
    }

    private static string BuildAllRightsReservedLicense(string modName)
    {
        return $@"All Rights Reserved

Copyright (c) {DateTime.Now:yyyy} {modName}

This file is a placeholder license generated by Mod Studio Desktop.
Replace it with your intended license before public release.
";
    }

    private static string BuildReleaseNotes(WorkspaceData workspace, string version, StudioReleaseReport report)
    {
        string modName = SafeText(workspace != null ? workspace.modName : "Minecraft Mod", "Minecraft Mod");
        var sb = new StringBuilder();
        sb.AppendLine($"# {modName} {version}");
        sb.AppendLine();
        sb.AppendLine(report.FormatSummary());
        sb.AppendLine();
        sb.AppendLine("## Artifacts");
        foreach (var artifact in report.artifacts.Where(a => a != null && a.type == "jar"))
        {
            sb.AppendLine("- " + artifact.name + " - " + artifact.FormatSize());
        }
        sb.AppendLine();
        sb.AppendLine("## Notes");
        sb.AppendLine("Review LICENSE, README, and CHANGELOG before publishing to Modrinth/CurseForge.");
        return sb.ToString();
    }

    private static string BuildReleaseManifest(WorkspaceData workspace, string version, StudioReleaseReport report, string jarPath)
    {
        string modName = JsonEscape(SafeText(workspace != null ? workspace.modName : "Minecraft Mod", "Minecraft Mod"));
        string modId = JsonEscape(NormalizeModId(workspace != null ? workspace.modId : "mymod"));
        string mcVersion = JsonEscape(SafeText(workspace != null ? workspace.mcVersion : "unknown", "unknown"));
        string loader = JsonEscape(SafeText(workspace != null ? workspace.modloader : "unknown", "unknown"));
        string jarName = JsonEscape(string.IsNullOrEmpty(jarPath) ? "" : Path.GetFileName(jarPath));

        return $@"{{
  ""studioReleaseVersion"": ""1.0.0"",
  ""createdAt"": ""{DateTime.UtcNow:O}"",
  ""mod"": {{
    ""name"": ""{modName}"",
    ""modId"": ""{modId}"",
    ""version"": ""{JsonEscape(version)}"",
    ""minecraftVersion"": ""{mcVersion}"",
    ""loader"": ""{loader}""
  }},
  ""qualityGate"": ""{(report.HasBlockingIssues() ? "failed" : "ready")}"",
  ""jar"": ""{jarName}"",
  ""errors"": {report.ErrorCount()},
  ""warnings"": {report.WarningCount()}
}}
";
    }

    private static string NormalizeVersion(string version)
    {
        version = (version ?? "").Trim();
        return string.IsNullOrEmpty(version) ? "1.0.0" : version;
    }

    private static string NormalizeModId(string modId)
    {
        modId = (modId ?? "mymod").Trim().ToLowerInvariant();
        if (string.IsNullOrEmpty(modId)) modId = "mymod";
        var chars = modId.Select(c => char.IsLetterOrDigit(c) || c == '_' || c == '-' ? c : '_').ToArray();
        return new string(chars);
    }

    private static string SafeText(string value, string fallback)
    {
        return string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
    }

    private static string JsonEscape(string value)
    {
        return (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
    }

    private static string MakeRelative(string root, string fullPath)
    {
        try
        {
            Uri rootUri = new Uri(AppendDirectorySeparatorChar(Path.GetFullPath(root)));
            Uri fileUri = new Uri(Path.GetFullPath(fullPath));
            return Uri.UnescapeDataString(rootUri.MakeRelativeUri(fileUri).ToString()).Replace('/', Path.DirectorySeparatorChar);
        }
        catch
        {
            return fullPath;
        }
    }

    private static string AppendDirectorySeparatorChar(string path)
    {
        if (!path.EndsWith(Path.DirectorySeparatorChar.ToString())) return path + Path.DirectorySeparatorChar;
        return path;
    }
}
