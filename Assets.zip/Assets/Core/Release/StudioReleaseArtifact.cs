using System;

[Serializable]
public class StudioReleaseArtifact
{
    public string type;
    public string name;
    public string absolutePath;
    public string relativePath;
    public long sizeBytes;

    public StudioReleaseArtifact() { }

    public StudioReleaseArtifact(string type, string name, string absolutePath, string relativePath, long sizeBytes)
    {
        this.type = type;
        this.name = name;
        this.absolutePath = absolutePath;
        this.relativePath = relativePath;
        this.sizeBytes = sizeBytes;
    }

    public string FormatSize()
    {
        if (sizeBytes < 1024) return sizeBytes + " B";
        if (sizeBytes < 1024 * 1024) return (sizeBytes / 1024f).ToString("0.0") + " KB";
        return (sizeBytes / (1024f * 1024f)).ToString("0.0") + " MB";
    }

    public string Format()
    {
        return $"{type}: {name} ({FormatSize()})\n{relativePath}";
    }
}
