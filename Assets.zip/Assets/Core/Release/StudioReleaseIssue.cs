using System;

[Serializable]
public class StudioReleaseIssue
{
    public string code;
    public string severity; // error, warning, info
    public string message;
    public string filePath;
    public string suggestedFix;
    public bool fixable;

    public StudioReleaseIssue() { }

    public StudioReleaseIssue(string severity, string code, string message, string filePath = "", string suggestedFix = "", bool fixable = false)
    {
        this.severity = severity;
        this.code = code;
        this.message = message;
        this.filePath = filePath;
        this.suggestedFix = suggestedFix;
        this.fixable = fixable;
    }

    public bool IsError()
    {
        return string.Equals(severity, "error", StringComparison.OrdinalIgnoreCase);
    }

    public string Format()
    {
        string icon = IsError() ? "❌" : string.Equals(severity, "warning", StringComparison.OrdinalIgnoreCase) ? "⚠️" : "ℹ️";
        string path = string.IsNullOrEmpty(filePath) ? "" : $"\n   Fayl: {filePath}";
        string fix = string.IsNullOrEmpty(suggestedFix) ? "" : $"\n   Tavsiya: {suggestedFix}";
        return $"{icon} [{severity}] {code}: {message}{path}{fix}";
    }
}
