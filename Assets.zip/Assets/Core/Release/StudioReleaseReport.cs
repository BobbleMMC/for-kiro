using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

[Serializable]
public class StudioReleaseReport
{
    public string projectPath;
    public string releaseVersion;
    public string packagePath;
    public string releaseFolderPath;
    public List<StudioReleaseIssue> issues = new List<StudioReleaseIssue>();
    public List<StudioReleaseArtifact> artifacts = new List<StudioReleaseArtifact>();

    public int ErrorCount()
    {
        return issues.Count(i => i != null && i.IsError());
    }

    public int WarningCount()
    {
        return issues.Count(i => i != null && string.Equals(i.severity, "warning", StringComparison.OrdinalIgnoreCase));
    }

    public bool HasBlockingIssues()
    {
        return ErrorCount() > 0;
    }

    public void AddIssue(StudioReleaseIssue issue)
    {
        if (issue != null) issues.Add(issue);
    }

    public void AddArtifact(StudioReleaseArtifact artifact)
    {
        if (artifact != null) artifacts.Add(artifact);
    }

    public string FormatSummary()
    {
        string gate = HasBlockingIssues() ? "FAILED" : "READY";
        return $"Release Gate: {gate} | Errors: {ErrorCount()} | Warnings: {WarningCount()} | Artifacts: {artifacts.Count} | Version: {releaseVersion}";
    }

    public string FormatDetails()
    {
        var sb = new StringBuilder();
        sb.AppendLine("=== Mod Studio Release Report ===");
        sb.AppendLine(FormatSummary());
        sb.AppendLine($"Project: {projectPath}");
        if (!string.IsNullOrEmpty(packagePath)) sb.AppendLine($"Package: {packagePath}");
        if (!string.IsNullOrEmpty(releaseFolderPath)) sb.AppendLine($"Release folder: {releaseFolderPath}");
        sb.AppendLine();

        sb.AppendLine("Issues:");
        if (issues.Count == 0) sb.AppendLine("  No issues found.");
        foreach (var issue in issues) sb.AppendLine(issue.Format());

        sb.AppendLine();
        sb.AppendLine("Artifacts:");
        if (artifacts.Count == 0) sb.AppendLine("  No artifacts detected yet.");
        foreach (var artifact in artifacts) sb.AppendLine("- " + artifact.Format());

        return sb.ToString();
    }
}
