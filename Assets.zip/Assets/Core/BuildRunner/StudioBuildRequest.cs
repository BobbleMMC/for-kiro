using System;
using System.Collections.Generic;

/// <summary>
/// Build Runner uchun bitta command so'rovi.
/// </summary>
[Serializable]
public class StudioBuildRequest
{
    public string projectPath;
    public int targetJavaVersion = 17;
    public StudioBuildTask task = StudioBuildTask.Build;
    public string customTask = string.Empty;
    public bool noDaemon = true;
    public bool stacktrace = false;
    public bool info = false;
    public List<string> extraArguments = new List<string>();

    public string GetGradleTaskName()
    {
        return StudioBuildTaskUtility.ToGradleTask(task, customTask);
    }
}
