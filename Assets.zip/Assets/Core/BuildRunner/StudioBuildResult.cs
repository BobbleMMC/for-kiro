using System;

/// <summary>
/// Gradle jarayoni yakuniy natijasi.
/// </summary>
[Serializable]
public class StudioBuildResult
{
    public bool success;
    public bool wasStopped;
    public int exitCode;
    public string taskName;
    public string projectPath;
    public string gradleCommand;
    public string javaHome;
    public string combinedLog;
    public DateTime startedAt;
    public DateTime finishedAt;
    public StudioErrorAnalysisReport analysis;

    public string GetSummary()
    {
        string status = success ? "MUVAFFAQIYATLI" : (wasStopped ? "TO'XTATILDI" : "XATO");
        double seconds = Math.Max(0, (finishedAt - startedAt).TotalSeconds);
        return $"[BuildRunner] {taskName} => {status} | exitCode={exitCode} | {seconds:0.0}s";
    }
}
