using System.Text;

/// <summary>
/// Gradle stdout/stderr loglarini bitta joyga yig'adi.
/// </summary>
public class StudioBuildLogBuffer
{
    private readonly StringBuilder _builder = new StringBuilder();

    public void AppendLine(string line)
    {
        if (string.IsNullOrEmpty(line)) return;
        _builder.AppendLine(line);
    }

    public void Clear()
    {
        _builder.Length = 0;
    }

    public override string ToString()
    {
        return _builder.ToString();
    }
}
