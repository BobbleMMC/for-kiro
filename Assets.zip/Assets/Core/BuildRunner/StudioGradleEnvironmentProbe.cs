using System;
using System.IO;
using UnityEngine;

/// <summary>
/// Java/Gradle muhitini topish va command tanlash.
/// </summary>
public static class StudioGradleEnvironmentProbe
{
    public static bool IsWindows()
    {
        return Application.platform == RuntimePlatform.WindowsEditor ||
               Application.platform == RuntimePlatform.WindowsPlayer;
    }

    public static string ResolveGradleExecutable(string projectPath)
    {
        if (string.IsNullOrEmpty(projectPath)) return "gradle";

        string winWrapper = Path.Combine(projectPath, "gradlew.bat");
        string unixWrapper = Path.Combine(projectPath, "gradlew");

        if (IsWindows() && File.Exists(winWrapper)) return "gradlew.bat";
        if (!IsWindows() && File.Exists(unixWrapper)) return "./gradlew";

        // 4-patch gradlew fallback yozgan bo'lsa ham, wrapper yo'q holatda system gradle ishlatiladi.
        return "gradle";
    }

    public static string FindJavaHome(int version)
    {
        string envName = $"JAVA_HOME_{version}";
        string versionedJavaHome = Environment.GetEnvironmentVariable(envName);
        if (!string.IsNullOrEmpty(versionedJavaHome) && Directory.Exists(versionedJavaHome))
            return versionedJavaHome;

        string stdJavaHome = Environment.GetEnvironmentVariable("JAVA_HOME");
        if (!string.IsNullOrEmpty(stdJavaHome) && Directory.Exists(stdJavaHome))
        {
            string lowered = stdJavaHome.ToLowerInvariant();
            if (lowered.Contains(version.ToString()) || lowered.Contains($"jdk-{version}") || lowered.Contains($"jdk{version}"))
                return stdJavaHome;
        }

        if (IsWindows())
        {
            string[] searchRoots =
            {
                @"C:\Program Files\Java",
                @"C:\Program Files\Eclipse Adoptium",
                @"C:\Program Files\BellSoft",
                @"C:\Program Files\Microsoft",
                @"C:\Program Files\Semeru",
                @"C:\Program Files (x86)\Java"
            };

            foreach (string root in searchRoots)
            {
                string found = FindJdkUnderRoot(root, version);
                if (!string.IsNullOrEmpty(found)) return found;
            }
        }
        else
        {
            string[] unixCandidates =
            {
                $"/Library/Java/JavaVirtualMachines/openjdk-{version}.jdk/Contents/Home",
                $"/Library/Java/JavaVirtualMachines/temurin-{version}.jdk/Contents/Home",
                $"/Library/Java/JavaVirtualMachines/zulu-{version}.jdk/Contents/Home",
                $"/usr/lib/jvm/java-{version}-openjdk-amd64",
                $"/usr/lib/jvm/java-{version}-openjdk",
                $"/usr/lib/jvm/jdk-{version}"
            };

            foreach (string p in unixCandidates)
                if (Directory.Exists(p)) return p;
        }

        return !string.IsNullOrEmpty(stdJavaHome) && Directory.Exists(stdJavaHome) ? stdJavaHome : string.Empty;
    }

    private static string FindJdkUnderRoot(string root, int version)
    {
        if (!Directory.Exists(root)) return string.Empty;

        try
        {
            string[] dirs = Directory.GetDirectories(root);
            foreach (string dir in dirs)
            {
                string name = Path.GetFileName(dir).ToLowerInvariant();
                if (name.Contains(version.ToString()) || name.Contains($"jdk-{version}") || name.Contains($"jdk{version}"))
                    return dir;
            }
        }
        catch
        {
            // Permission error bo'lsa, boshqa papkalarni tekshirishda davom etiladi.
        }

        return string.Empty;
    }
}
