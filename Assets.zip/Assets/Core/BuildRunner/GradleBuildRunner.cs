using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

/// <summary>
/// Gradle commandlarini ishga tushiradi, loglarni capture qiladi va yakunda ErrorAnalyzer'ga yuboradi.
/// </summary>
public class GradleBuildRunner
{
    private Process _process;
    private readonly Action<string> _onLog;
    private readonly Action<string> _onError;
    private readonly Action<StudioBuildResult> _onCompleted;

    public bool IsRunning
    {
        get { return _process != null && !_process.HasExited; }
    }

    public GradleBuildRunner(Action<string> onLog, Action<string> onError, Action<StudioBuildResult> onCompleted)
    {
        _onLog = onLog;
        _onError = onError;
        _onCompleted = onCompleted;
    }

    public async void Run(StudioBuildRequest request)
    {
        StudioBuildResult result = await RunAsync(request);
        _onCompleted?.Invoke(result);
    }

    public async Task<StudioBuildResult> RunAsync(StudioBuildRequest request)
    {
        var result = new StudioBuildResult();
        result.startedAt = DateTime.Now;
        result.projectPath = request != null ? request.projectPath : string.Empty;
        result.taskName = request != null ? request.GetGradleTaskName() : "build";
        result.exitCode = -1;

        var logBuffer = new StudioBuildLogBuffer();

        if (request == null)
        {
            result.finishedAt = DateTime.Now;
            result.combinedLog = "Build request null.";
            result.analysis = StudioErrorAnalyzer.Analyze(result.combinedLog);
            return result;
        }

        if (string.IsNullOrEmpty(request.projectPath) || !Directory.Exists(request.projectPath))
        {
            string msg = $"[BuildRunner] Loyiha papkasi topilmadi: {request.projectPath}";
            _onError?.Invoke(msg);
            logBuffer.AppendLine(msg);
            result.finishedAt = DateTime.Now;
            result.combinedLog = logBuffer.ToString();
            result.analysis = StudioErrorAnalyzer.Analyze(result.combinedLog);
            return result;
        }

        if (IsRunning)
        {
            string msg = "[BuildRunner] Gradle jarayoni allaqachon ishlayapti. Avval Stop bosing.";
            _onError?.Invoke(msg);
            logBuffer.AppendLine(msg);
            result.finishedAt = DateTime.Now;
            result.combinedLog = logBuffer.ToString();
            result.analysis = StudioErrorAnalyzer.Analyze(result.combinedLog);
            return result;
        }

        string gradleExecutable = StudioGradleEnvironmentProbe.ResolveGradleExecutable(request.projectPath);
        string javaHome = StudioGradleEnvironmentProbe.FindJavaHome(request.targetJavaVersion);
        result.javaHome = javaHome;

        string arguments = BuildGradleArguments(request);
        result.gradleCommand = gradleExecutable + " " + arguments;

        try
        {
            _process = new Process();
            _process.StartInfo.WorkingDirectory = request.projectPath;
            _process.StartInfo.CreateNoWindow = true;
            _process.StartInfo.UseShellExecute = false;
            _process.StartInfo.RedirectStandardOutput = true;
            _process.StartInfo.RedirectStandardError = true;
            _process.StartInfo.StandardOutputEncoding = Encoding.UTF8;
            _process.StartInfo.StandardErrorEncoding = Encoding.UTF8;

            if (StudioGradleEnvironmentProbe.IsWindows())
            {
                _process.StartInfo.FileName = "cmd.exe";
                _process.StartInfo.Arguments = $"/c {gradleExecutable} {arguments}";
            }
            else
            {
                _process.StartInfo.FileName = "/bin/bash";
                _process.StartInfo.Arguments = $"-c \"{gradleExecutable} {arguments}\"";
            }

            if (!string.IsNullOrEmpty(javaHome) && Directory.Exists(javaHome))
            {
                _process.StartInfo.EnvironmentVariables["JAVA_HOME"] = javaHome;
                _process.StartInfo.EnvironmentVariables["PATH"] = Path.Combine(javaHome, "bin") + Path.PathSeparator + _process.StartInfo.EnvironmentVariables["PATH"];
                _onLog?.Invoke($"[BuildRunner] JAVA_HOME: {javaHome}");
            }
            else
            {
                _onLog?.Invoke($"[BuildRunner] Java {request.targetJavaVersion} topilmadi. System default Java ishlatiladi.");
            }

            _onLog?.Invoke($"[BuildRunner] Command: {result.gradleCommand}");

            _process.OutputDataReceived += (sender, e) =>
            {
                if (string.IsNullOrEmpty(e.Data)) return;
                logBuffer.AppendLine(e.Data);
                _onLog?.Invoke(e.Data);
            };

            _process.ErrorDataReceived += (sender, e) =>
            {
                if (string.IsNullOrEmpty(e.Data)) return;
                logBuffer.AppendLine(e.Data);
                _onError?.Invoke(e.Data);
            };

            _process.Start();
            _process.BeginOutputReadLine();
            _process.BeginErrorReadLine();

            await Task.Run(() => _process.WaitForExit());

            result.exitCode = _process.ExitCode;
            result.success = result.exitCode == 0;
            result.finishedAt = DateTime.Now;
            result.combinedLog = logBuffer.ToString();
            result.analysis = StudioErrorAnalyzer.Analyze(result.combinedLog);
            return result;
        }
        catch (Exception ex)
        {
            string msg = $"[BuildRunner] Gradle jarayonini ishga tushirishda xato: {ex.Message}";
            _onError?.Invoke(msg);
            logBuffer.AppendLine(msg);
            result.finishedAt = DateTime.Now;
            result.combinedLog = logBuffer.ToString();
            result.analysis = StudioErrorAnalyzer.Analyze(result.combinedLog);
            return result;
        }
        finally
        {
            if (_process != null && _process.HasExited)
            {
                _process.Dispose();
                _process = null;
            }
        }
    }

    public void Stop()
    {
        if (!IsRunning)
        {
            _onLog?.Invoke("[BuildRunner] To'xtatiladigan Gradle jarayoni yo'q.");
            return;
        }

        try
        {
            _process.Kill();
            _onLog?.Invoke("[BuildRunner] Gradle jarayoni majburiy to'xtatildi.");
        }
        catch (Exception ex)
        {
            _onError?.Invoke($"[BuildRunner] Jarayonni to'xtatishda xato: {ex.Message}");
        }
    }

    private static string BuildGradleArguments(StudioBuildRequest request)
    {
        StringBuilder args = new StringBuilder();
        if (request.noDaemon) args.Append("--no-daemon ");
        if (request.stacktrace) args.Append("--stacktrace ");
        if (request.info) args.Append("--info ");
        args.Append(request.GetGradleTaskName());

        if (request.extraArguments != null)
        {
            foreach (string extra in request.extraArguments)
            {
                if (!string.IsNullOrWhiteSpace(extra)) args.Append(" ").Append(extra.Trim());
            }
        }

        return args.ToString().Trim();
    }
}
