using System;

/// <summary>
/// Gradle orqali bajariladigan asosiy build/test vazifalari.
/// </summary>
public enum StudioBuildTask
{
    Build,
    RunClient,
    RunData,
    GenSources,
    Clean,
    Custom
}

public static class StudioBuildTaskUtility
{
    public static string ToGradleTask(StudioBuildTask task, string customTask)
    {
        if (task == StudioBuildTask.Custom && !string.IsNullOrEmpty(customTask)) return customTask.Trim();

        switch (task)
        {
            case StudioBuildTask.RunClient:
                return "runClient";
            case StudioBuildTask.RunData:
                return "runData";
            case StudioBuildTask.GenSources:
                return "genSources";
            case StudioBuildTask.Clean:
                return "clean";
            case StudioBuildTask.Build:
            default:
                return "build";
        }
    }
}
