using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

public static class StudioAssetBrowserScanner
{
    public static string GetResourcesRoot(string projectPath)
    {
        if (string.IsNullOrEmpty(projectPath)) projectPath = Environment.CurrentDirectory;
        return Path.Combine(projectPath, "src", "main", "resources");
    }

    public static StudioAssetBrowserReport Scan(WorkspaceData workspace, string projectPath)
    {
        if (workspace == null) workspace = new WorkspaceData();
        string modId = StudioAssetBrowserUtility.NormalizeModId(workspace.modId);
        string resourcesRoot = GetResourcesRoot(projectPath);

        var report = new StudioAssetBrowserReport
        {
            projectPath = projectPath,
            resourcesRoot = resourcesRoot,
            entries = new List<StudioAssetBrowserEntry>()
        };

        var byPath = new Dictionary<string, StudioAssetBrowserEntry>(StringComparer.OrdinalIgnoreCase);

        AddMetadata(report, byPath, projectPath, "build.gradle", "Gradle build file");
        AddMetadata(report, byPath, projectPath, "settings.gradle", "Gradle settings");
        AddMetadata(report, byPath, projectPath, "gradle.properties", "Gradle properties");
        AddMetadata(report, byPath, projectPath, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "fabric.mod.json"), "Fabric metadata");
        AddMetadata(report, byPath, projectPath, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "META-INF", "mods.toml"), "Forge/NeoForge metadata");
        AddExpected(report, byPath, projectPath, modId, "lang", "lang", "en_us", "English language file", StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "lang", "en_us.json"), $"{modId}:lang/en_us");

        foreach (var block in workspace.blocks ?? new List<BlockDataModel>())
        {
            string id = StudioAssetBrowserUtility.NormalizeId(block.blockId, "custom_block");
            string name = string.IsNullOrEmpty(block.displayName) ? id : block.displayName;
            string texture = StudioAssetBrowserUtility.NormalizeId(string.IsNullOrEmpty(block.texturePath) ? id : block.texturePath, id);
            AddExpected(report, byPath, projectPath, modId, "blockstate", "block", id, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "blockstates", id + ".json"), $"{modId}:blockstates/{id}");
            AddExpected(report, byPath, projectPath, modId, "model", "block", id, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "models", "block", id + ".json"), $"{modId}:block/{id}");
            AddExpected(report, byPath, projectPath, modId, "model", "item", id, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "models", "item", id + ".json"), $"{modId}:item/{id}");
            AddExpected(report, byPath, projectPath, modId, "texture", "block", texture, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "textures", "block", texture + ".png"), $"{modId}:block/{texture}");
        }

        foreach (var item in workspace.items ?? new List<ItemDataModel>())
        {
            string id = StudioAssetBrowserUtility.NormalizeId(item.itemId, "custom_item");
            string name = string.IsNullOrEmpty(item.displayName) ? id : item.displayName;
            AddExpected(report, byPath, projectPath, modId, "model", "item", id, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "models", "item", id + ".json"), $"{modId}:item/{id}");
            AddExpected(report, byPath, projectPath, modId, "texture", "item", id, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "textures", "item", id + ".png"), $"{modId}:item/{id}");
        }

        foreach (var tool in workspace.tools ?? new List<ToolDataModel>())
        {
            string id = StudioAssetBrowserUtility.NormalizeId(tool.toolId, "custom_tool");
            string name = string.IsNullOrEmpty(tool.displayName) ? id : tool.displayName;
            AddExpected(report, byPath, projectPath, modId, "model", "item", id, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "models", "item", id + ".json"), $"{modId}:item/{id}");
            AddExpected(report, byPath, projectPath, modId, "texture", "item", id, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "textures", "item", id + ".png"), $"{modId}:item/{id}");
        }

        foreach (var armor in workspace.armors ?? new List<ArmorDataModel>())
        {
            string id = StudioAssetBrowserUtility.NormalizeId(armor.armorId, "custom_armor");
            string name = string.IsNullOrEmpty(armor.displayName) ? id : armor.displayName;
            AddExpected(report, byPath, projectPath, modId, "model", "item", id, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "models", "item", id + ".json"), $"{modId}:item/{id}");
            AddExpected(report, byPath, projectPath, modId, "texture", "item", id, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "assets", modId, "textures", "item", id + ".png"), $"{modId}:item/{id}");
        }

        int recipeIndex = 0;
        foreach (var recipe in workspace.recipes ?? new List<RecipeDataModel>())
        {
            string id = StudioAssetBrowserUtility.NormalizeId(string.IsNullOrEmpty(recipe.resultItem) ? $"recipe_{recipeIndex}" : recipe.resultItem, $"recipe_{recipeIndex}");
            AddExpected(report, byPath, projectPath, modId, "recipe", "data", id, recipe.recipeType.ToString(), StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "data", modId, "recipes", id + ".json"), $"{modId}:recipes/{id}");
            recipeIndex++;
        }

        foreach (var biome in workspace.biomes ?? new List<BiomeDataModel>())
        {
            string id = StudioAssetBrowserUtility.NormalizeId(biome.biomeId, "custom_biome");
            string name = string.IsNullOrEmpty(biome.displayName) ? id : biome.displayName;
            AddExpected(report, byPath, projectPath, modId, "biome", "worldgen", id, name, StudioAssetBrowserUtility.CombineRelative("src", "main", "resources", "data", modId, "worldgen", "biome", id + ".json"), $"{modId}:worldgen/biome/{id}");
        }

        ScanExistingResources(report, byPath, projectPath, resourcesRoot, modId);
        report.entries = report.entries.OrderBy(e => e.exists ? 1 : 0).ThenBy(e => e.assetType).ThenBy(e => e.relativePath).ToList();
        return report;
    }

    private static void AddMetadata(StudioAssetBrowserReport report, Dictionary<string, StudioAssetBrowserEntry> byPath, string projectPath, string relativePath, string name)
    {
        AddExpected(report, byPath, projectPath, "", "metadata", "project", Path.GetFileName(relativePath), name, relativePath, relativePath);
    }

    private static void AddExpected(StudioAssetBrowserReport report, Dictionary<string, StudioAssetBrowserEntry> byPath, string projectPath, string modId, string assetType, string resourceKind, string id, string name, string relativePath, string resourceLocation)
    {
        string normalizedRelative = StudioAssetBrowserUtility.ToUnitySlash(relativePath);
        if (byPath.TryGetValue(normalizedRelative, out var existing))
        {
            existing.origin = existing.origin.Contains("workspace") ? existing.origin : existing.origin + ", workspace";
            return;
        }

        string absolute = Path.GetFullPath(Path.Combine(projectPath ?? "", normalizedRelative.Replace('/', Path.DirectorySeparatorChar)));
        var file = new FileInfo(absolute);
        var entry = new StudioAssetBrowserEntry
        {
            id = id,
            displayName = name,
            assetType = assetType,
            resourceKind = resourceKind,
            origin = "workspace",
            relativePath = normalizedRelative,
            absolutePath = absolute,
            resourceLocation = resourceLocation,
            exists = file.Exists,
            sizeBytes = file.Exists ? file.Length : 0,
            lastModifiedUtc = file.Exists ? file.LastWriteTimeUtc.ToString("yyyy-MM-dd HH:mm:ss") : "-",
            warning = file.Exists ? "" : "Fayl hali yaratilmagan yoki export qilinmagan."
        };

        report.entries.Add(entry);
        byPath[normalizedRelative] = entry;
    }

    private static void ScanExistingResources(StudioAssetBrowserReport report, Dictionary<string, StudioAssetBrowserEntry> byPath, string projectPath, string resourcesRoot, string modId)
    {
        if (!Directory.Exists(projectPath)) return;

        var scanRoots = new List<string>();
        if (Directory.Exists(resourcesRoot)) scanRoots.Add(resourcesRoot);
        string rootAssets = Path.Combine(projectPath, "assets");
        if (Directory.Exists(rootAssets)) scanRoots.Add(rootAssets);

        foreach (string root in scanRoots.Distinct())
        {
            foreach (string file in Directory.GetFiles(root, "*.*", SearchOption.AllDirectories))
            {
                string ext = Path.GetExtension(file).ToLowerInvariant();
                if (ext != ".json" && ext != ".png" && ext != ".mcmeta" && ext != ".toml" && ext != ".properties") continue;

                string rel = MakeRelativePath(projectPath, file);
                if (byPath.TryGetValue(rel, out var expected))
                {
                    var info = new FileInfo(file);
                    expected.exists = true;
                    expected.sizeBytes = info.Length;
                    expected.lastModifiedUtc = info.LastWriteTimeUtc.ToString("yyyy-MM-dd HH:mm:ss");
                    expected.warning = "";
                    continue;
                }

                var detected = CreateDetectedEntry(projectPath, file, rel, modId);
                report.entries.Add(detected);
                byPath[rel] = detected;
            }
        }
    }

    private static string MakeRelativePath(string basePath, string fullPath)
    {
        try
        {
            if (string.IsNullOrEmpty(basePath)) return StudioAssetBrowserUtility.ToUnitySlash(fullPath);
            string root = Path.GetFullPath(basePath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string file = Path.GetFullPath(fullPath);
            if (file.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            {
                return StudioAssetBrowserUtility.ToUnitySlash(file.Substring(root.Length));
            }
        }
        catch { }
        return StudioAssetBrowserUtility.ToUnitySlash(fullPath);
    }

    private static StudioAssetBrowserEntry CreateDetectedEntry(string projectPath, string file, string rel, string modId)
    {
        var info = new FileInfo(file);
        string ext = Path.GetExtension(file).ToLowerInvariant();
        string type = "detected";
        string kind = "file";

        if (ext == ".png") { type = "texture"; kind = rel.Contains("/block/") ? "block" : rel.Contains("/item/") ? "item" : "texture"; }
        else if (rel.Contains("/models/")) { type = "model"; kind = rel.Contains("/block/") ? "block" : "item"; }
        else if (rel.Contains("/blockstates/")) { type = "blockstate"; kind = "block"; }
        else if (rel.Contains("/lang/")) { type = "lang"; kind = "lang"; }
        else if (rel.Contains("/recipes/")) { type = "recipe"; kind = "data"; }
        else if (rel.Contains("/worldgen/biome/")) { type = "biome"; kind = "worldgen"; }
        else if (ext == ".toml" || ext == ".properties" || rel.EndsWith("fabric.mod.json")) { type = "metadata"; kind = "project"; }

        return new StudioAssetBrowserEntry
        {
            id = Path.GetFileNameWithoutExtension(file),
            displayName = Path.GetFileName(file),
            assetType = type,
            resourceKind = kind,
            origin = "detected",
            relativePath = rel,
            absolutePath = file,
            resourceLocation = BuildResourceLocation(rel, modId),
            exists = true,
            sizeBytes = info.Length,
            lastModifiedUtc = info.LastWriteTimeUtc.ToString("yyyy-MM-dd HH:mm:ss"),
            warning = "Workspace modelida alohida feature sifatida ro'yxatdan o'tmagan fayl."
        };
    }

    private static string BuildResourceLocation(string rel, string modId)
    {
        string path = StudioAssetBrowserUtility.ToUnitySlash(rel);
        string marker = $"assets/{modId}/";
        int idx = path.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
        if (idx >= 0)
        {
            string sub = path.Substring(idx + marker.Length);
            string noExt = Path.ChangeExtension(sub, null);
            return $"{modId}:{noExt}";
        }
        return path;
    }
}
