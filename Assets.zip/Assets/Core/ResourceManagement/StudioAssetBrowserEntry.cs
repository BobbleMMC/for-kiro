using System;
using System.IO;
using UnityEngine;

[Serializable]
public class StudioAssetBrowserEntry
{
    public string id;
    public string displayName;
    public string assetType;      // texture, model, blockstate, lang, recipe, biome, metadata, detected
    public string resourceKind;   // block, item, recipe, lang, metadata, etc.
    public string origin;         // workspace, generated, detected
    public string relativePath;
    public string absolutePath;
    public string resourceLocation;
    public bool exists;
    public long sizeBytes;
    public string lastModifiedUtc;
    public string warning;

    public string GetIcon()
    {
        switch ((assetType ?? "").ToLowerInvariant())
        {
            case "texture": return "🖼️";
            case "model": return "📦";
            case "blockstate": return "🧱";
            case "lang": return "🌐";
            case "recipe": return "📜";
            case "biome": return "🌲";
            case "metadata": return "⚙️";
            default: return "📄";
        }
    }

    public string GetStatusText()
    {
        string state = exists ? "mavjud" : "missing";
        string size = exists ? StudioAssetBrowserUtility.FormatBytes(sizeBytes) : "";
        string type = string.IsNullOrEmpty(assetType) ? "asset" : assetType;
        return string.IsNullOrEmpty(size) ? $"{type} • {state}" : $"{type} • {state} • {size}";
    }

    public string FormatDetails()
    {
        return
            $"ID: {id}\n" +
            $"Nomi: {displayName}\n" +
            $"Turi: {assetType} / {resourceKind}\n" +
            $"Holati: {(exists ? "Mavjud" : "Missing")}\n" +
            $"Manba: {origin}\n" +
            $"Resource ID: {resourceLocation}\n" +
            $"Relative path: {relativePath}\n" +
            $"Full path: {absolutePath}\n" +
            $"Size: {StudioAssetBrowserUtility.FormatBytes(sizeBytes)}\n" +
            $"Last modified UTC: {lastModifiedUtc}\n" +
            (string.IsNullOrEmpty(warning) ? "" : $"Ogohlantirish: {warning}\n");
    }
}
