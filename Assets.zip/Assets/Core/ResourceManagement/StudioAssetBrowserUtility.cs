using System;
using System.IO;
using System.Text.RegularExpressions;

public static class StudioAssetBrowserUtility
{
    public static string NormalizeId(string value, string fallback)
    {
        string raw = string.IsNullOrWhiteSpace(value) ? fallback : value.Trim().ToLowerInvariant();
        raw = Regex.Replace(raw, "[^a-z0-9_./-]", "_");
        raw = raw.Replace(" ", "_");
        while (raw.Contains("__")) raw = raw.Replace("__", "_");
        return string.IsNullOrEmpty(raw) ? fallback : raw;
    }

    public static string NormalizeModId(string modId)
    {
        return NormalizeId(modId, "mymod").Replace("/", "_").Replace(".", "_").Replace("-", "_");
    }

    public static string ToUnitySlash(string path)
    {
        return (path ?? "").Replace('\\', '/');
    }

    public static string CombineRelative(params string[] parts)
    {
        return ToUnitySlash(Path.Combine(parts));
    }

    public static string FormatBytes(long bytes)
    {
        if (bytes <= 0) return "0 B";
        string[] units = { "B", "KB", "MB", "GB" };
        double value = bytes;
        int unit = 0;
        while (value >= 1024 && unit < units.Length - 1)
        {
            value /= 1024;
            unit++;
        }
        return $"{value:0.#} {units[unit]}";
    }
}
