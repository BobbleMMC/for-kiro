using System;
using System.Collections.Generic;
using System.Linq;

[Serializable]
public class StudioAssetBrowserReport
{
    public string projectPath;
    public string resourcesRoot;
    public List<StudioAssetBrowserEntry> entries = new List<StudioAssetBrowserEntry>();

    public int TotalCount => entries != null ? entries.Count : 0;
    public int ExistingCount => entries != null ? entries.Count(e => e.exists) : 0;
    public int MissingCount => entries != null ? entries.Count(e => !e.exists) : 0;
    public int TextureCount => entries != null ? entries.Count(e => e.assetType == "texture") : 0;
    public int ModelCount => entries != null ? entries.Count(e => e.assetType == "model") : 0;
    public int JsonCount => entries != null ? entries.Count(e => e.relativePath != null && e.relativePath.EndsWith(".json", StringComparison.OrdinalIgnoreCase)) : 0;

    public string FormatSummary()
    {
        return $"Assets: {TotalCount} ta | Mavjud: {ExistingCount} ta | Missing: {MissingCount} ta | Texture: {TextureCount} ta | Model: {ModelCount} ta | JSON: {JsonCount} ta";
    }
}
