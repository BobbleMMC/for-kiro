using System;

public enum TextureValidationSeverity
{
    Info,
    Warning,
    Error
}

[Serializable]
public class TextureValidationIssue
{
    public TextureValidationSeverity severity = TextureValidationSeverity.Info;
    public string code = "INFO";
    public string message = string.Empty;
    public string suggestion = string.Empty;

    public TextureValidationIssue() { }

    public TextureValidationIssue(TextureValidationSeverity severity, string code, string message, string suggestion = "")
    {
        this.severity = severity;
        this.code = code;
        this.message = message;
        this.suggestion = suggestion;
    }

    public override string ToString()
    {
        return "[" + severity + "] " + code + ": " + message + (string.IsNullOrWhiteSpace(suggestion) ? string.Empty : " | Fix: " + suggestion);
    }
}
