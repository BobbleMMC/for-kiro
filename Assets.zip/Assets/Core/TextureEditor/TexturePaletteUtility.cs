using System.Collections.Generic;
using UnityEngine;

public static class TexturePaletteUtility
{
    public static Color32 ParseColor(string html, Color32 fallback)
    {
        if (string.IsNullOrWhiteSpace(html)) return fallback;
        Color color;
        if (ColorUtility.TryParseHtmlString(html.Trim(), out color)) return color;
        return fallback;
    }

    public static string ToHtml(Color32 color, bool includeAlpha = true)
    {
        return includeAlpha ? ("#" + ColorUtility.ToHtmlStringRGBA(color)) : ("#" + ColorUtility.ToHtmlStringRGB(color));
    }

    public static List<Color32> ParsePalette(IEnumerable<string> htmlColors)
    {
        List<Color32> colors = new List<Color32>();
        if (htmlColors == null) return colors;
        foreach (string html in htmlColors)
        {
            if (string.IsNullOrWhiteSpace(html)) continue;
            colors.Add(ParseColor(html, new Color32(255, 255, 255, 255)));
        }
        return colors;
    }
}
