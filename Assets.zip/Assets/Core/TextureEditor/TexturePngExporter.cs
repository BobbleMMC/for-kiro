using System.IO;
using UnityEngine;

public static class TexturePngExporter
{
    public static bool Export(TextureCanvasState canvas, string absolutePath, bool pixelPerfect, out string error)
    {
        error = string.Empty;
        if (canvas == null)
        {
            error = "Canvas null.";
            return false;
        }
        if (string.IsNullOrWhiteSpace(absolutePath))
        {
            error = "Export path bo‘sh.";
            return false;
        }

        try
        {
            string directory = Path.GetDirectoryName(absolutePath);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
            Texture2D texture = canvas.ToTexture2D(pixelPerfect ? FilterMode.Point : FilterMode.Bilinear);
            byte[] png = texture.EncodeToPNG();
            Object.DestroyImmediate(texture);
            File.WriteAllBytes(absolutePath, png);
            return true;
        }
        catch (System.Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }

    public static bool ExportMcmeta(string pngPath, int frameTimeTicks, out string error)
    {
        error = string.Empty;
        try
        {
            string mcmetaPath = pngPath + ".mcmeta";
            string json = "{\n  \"animation\": {\n    \"frametime\": " + Mathf.Max(1, frameTimeTicks) + "\n  }\n}";
            File.WriteAllText(mcmetaPath, json);
            return true;
        }
        catch (System.Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }
}
