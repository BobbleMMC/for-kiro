using System;
using System.Collections.Generic;

public enum TextureProceduralPattern
{
    Checker,
    Noise,
    GradientHorizontal,
    GradientVertical,
    Ore,
    Stone,
    Planks,
    Metal,
    Fabric,
    GuiPanel,
    ParticleSpark,
    PotionIcon,
    ArmorLayer
}

public enum TextureAnimationLayout
{
    VerticalStrip,
    HorizontalStrip,
    Grid
}

[Serializable]
public class TextureEditorAdvancedSettings
{
    public TextureProceduralPattern proceduralPattern = TextureProceduralPattern.Ore;
    public TextureAnimationLayout animationLayout = TextureAnimationLayout.VerticalStrip;
    public int proceduralSeed = 1337;
    public float proceduralStrength = 0.65f;
    public bool proceduralUseSecondaryColor = true;
    public int animationFrameTimeTicks = 2;
    public bool animationInterpolate = false;
    public bool animationGenerateMcmeta = true;
    public int maxPaletteColors = 16;
    public bool validatePowerOfTwo = true;
    public bool validateMinecraftPath = true;
    public bool validateTransparentPixels = true;
    public bool validatePaletteLimit = false;
    public List<string> recentProceduralPresets = new List<string>();

    public void ClampValues()
    {
        if (proceduralSeed == 0) proceduralSeed = 1337;
        if (proceduralStrength < 0f) proceduralStrength = 0f;
        if (proceduralStrength > 1f) proceduralStrength = 1f;
        if (animationFrameTimeTicks < 1) animationFrameTimeTicks = 1;
        if (animationFrameTimeTicks > 1200) animationFrameTimeTicks = 1200;
        if (maxPaletteColors < 2) maxPaletteColors = 2;
        if (maxPaletteColors > 256) maxPaletteColors = 256;
        if (recentProceduralPresets == null) recentProceduralPresets = new List<string>();
    }
}
