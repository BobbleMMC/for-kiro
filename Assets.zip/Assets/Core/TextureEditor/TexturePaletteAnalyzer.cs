using System.Collections.Generic;
using UnityEngine;

public static class TexturePaletteAnalyzer
{
    public static List<Color32> ExtractTopColors(TextureCanvasState canvas, int maxColors, bool includeTransparent)
    {
        List<Color32> result = new List<Color32>();
        if (canvas == null) return result;
        maxColors = Mathf.Clamp(maxColors, 1, 256);
        Dictionary<uint, int> counts = new Dictionary<uint, int>();
        Color32[] pixels = canvas.CompositePixels();
        for (int i = 0; i < pixels.Length; i++)
        {
            Color32 c = pixels[i];
            if (!includeTransparent && c.a == 0) continue;
            uint key = Pack(c);
            if (!counts.ContainsKey(key)) counts[key] = 0;
            counts[key]++;
        }

        List<KeyValuePair<uint, int>> sorted = new List<KeyValuePair<uint, int>>(counts);
        sorted.Sort((a, b) => b.Value.CompareTo(a.Value));
        for (int i = 0; i < sorted.Count && result.Count < maxColors; i++) result.Add(Unpack(sorted[i].Key));
        return result;
    }

    public static List<string> ExtractTopColorHtml(TextureCanvasState canvas, int maxColors, bool includeTransparent)
    {
        List<Color32> colors = ExtractTopColors(canvas, maxColors, includeTransparent);
        List<string> html = new List<string>();
        foreach (Color32 c in colors) html.Add(ToHtml(c));
        return html;
    }

    public static List<Color32> GenerateRamp(Color32 baseColor, int steps)
    {
        steps = Mathf.Clamp(steps, 2, 32);
        List<Color32> ramp = new List<Color32>();
        Color.RGBToHSV(baseColor, out float h, out float s, out float v);
        for (int i = 0; i < steps; i++)
        {
            float t = steps <= 1 ? 0f : i / (float)(steps - 1);
            float value = Mathf.Lerp(Mathf.Max(0f, v - 0.42f), Mathf.Min(1f, v + 0.42f), t);
            Color color = Color.HSVToRGB(h, s, value);
            ramp.Add(new Color32((byte)Mathf.RoundToInt(color.r * 255f), (byte)Mathf.RoundToInt(color.g * 255f), (byte)Mathf.RoundToInt(color.b * 255f), baseColor.a));
        }
        return ramp;
    }

    public static string ToHtml(Color32 c)
    {
        return "#" + c.r.ToString("X2") + c.g.ToString("X2") + c.b.ToString("X2") + c.a.ToString("X2");
    }

    private static uint Pack(Color32 c)
    {
        return ((uint)c.r << 24) | ((uint)c.g << 16) | ((uint)c.b << 8) | c.a;
    }

    private static Color32 Unpack(uint packed)
    {
        return new Color32((byte)(packed >> 24), (byte)(packed >> 16), (byte)(packed >> 8), (byte)packed);
    }
}
