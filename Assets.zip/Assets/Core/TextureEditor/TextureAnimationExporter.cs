using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

public static class TextureAnimationExporter
{
    public static bool Export(TextureAnimationProject project, string pngPath, TextureAnimationLayout layout, bool writeMcmeta, out string error)
    {
        error = string.Empty;
        if (project == null)
        {
            error = "Animation project null.";
            return false;
        }
        project.EnsureFrames(new TextureCanvasState(16, 16), 2);
        if (string.IsNullOrWhiteSpace(pngPath))
        {
            error = "PNG path bo‘sh.";
            return false;
        }

        try
        {
            List<TextureAnimationFrameData> frames = project.frames;
            int width = frames[0].canvas.width;
            int height = frames[0].canvas.height;
            int columns = 1;
            int rows = frames.Count;
            if (layout == TextureAnimationLayout.HorizontalStrip)
            {
                columns = frames.Count;
                rows = 1;
            }
            else if (layout == TextureAnimationLayout.Grid)
            {
                columns = Mathf.CeilToInt(Mathf.Sqrt(frames.Count));
                rows = Mathf.CeilToInt(frames.Count / (float)columns);
            }

            Texture2D sheet = new Texture2D(width * columns, height * rows, TextureFormat.RGBA32, false);
            sheet.filterMode = FilterMode.Point;
            sheet.wrapMode = TextureWrapMode.Clamp;
            Color32[] empty = new Color32[sheet.width * sheet.height];
            for (int i = 0; i < empty.Length; i++) empty[i] = new Color32(0, 0, 0, 0);
            sheet.SetPixels32(empty);

            for (int i = 0; i < frames.Count; i++)
            {
                TextureCanvasState frameCanvas = frames[i].canvas;
                if (frameCanvas == null) continue;
                Color32[] pixels = frameCanvas.CompositePixels();
                int col = layout == TextureAnimationLayout.VerticalStrip ? 0 : (layout == TextureAnimationLayout.HorizontalStrip ? i : i % columns);
                int row = layout == TextureAnimationLayout.VerticalStrip ? i : (layout == TextureAnimationLayout.HorizontalStrip ? 0 : i / columns);
                sheet.SetPixels32(col * width, sheet.height - ((row + 1) * height), width, height, pixels);
            }

            sheet.Apply(false, false);
            string dir = Path.GetDirectoryName(pngPath);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            File.WriteAllBytes(pngPath, sheet.EncodeToPNG());
            Object.DestroyImmediate(sheet);

            if (writeMcmeta)
            {
                File.WriteAllText(pngPath + ".mcmeta", BuildMcmeta(project));
            }
            return true;
        }
        catch (System.Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }

    public static string BuildMcmeta(TextureAnimationProject project)
    {
        project.EnsureFrames(new TextureCanvasState(16, 16), 2);
        bool sameTime = true;
        int firstTime = Mathf.Max(1, project.frames[0].frameTimeTicks);
        for (int i = 0; i < project.frames.Count; i++)
        {
            if (Mathf.Max(1, project.frames[i].frameTimeTicks) != firstTime) sameTime = false;
        }

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"animation\": {");
        if (sameTime)
        {
            sb.AppendLine("    \"frametime\": " + firstTime);
        }
        else
        {
            sb.AppendLine("    \"frames\": [");
            for (int i = 0; i < project.frames.Count; i++)
            {
                sb.Append("      { \"index\": ").Append(i).Append(", \"time\": ").Append(Mathf.Max(1, project.frames[i].frameTimeTicks)).Append(" }");
                if (i < project.frames.Count - 1) sb.Append(",");
                sb.AppendLine();
            }
            sb.AppendLine("    ]");
        }
        sb.AppendLine("  }");
        sb.AppendLine("}");
        return sb.ToString();
    }
}
