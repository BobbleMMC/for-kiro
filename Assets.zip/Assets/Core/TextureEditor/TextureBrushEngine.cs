using System.Collections.Generic;
using UnityEngine;

public static class TextureBrushEngine
{
    public static void ApplyTool(TextureCanvasState canvas, TextureEditorToolSettings settings, Vector2Int start, Vector2Int end, Color32 primary, Color32 secondary)
    {
        if (canvas == null || settings == null) return;
        canvas.EnsureLayer();
        if (canvas.ActiveLayer.locked) return;
        settings.ClampValues();

        switch (settings.activeTool)
        {
            case StudioTextureToolType.Eraser:
                PaintBrush(canvas, settings, end.x, end.y, new Color32(0, 0, 0, 0));
                break;
            case StudioTextureToolType.FillBucket:
                FloodFill(canvas, end.x, end.y, primary, settings.alphaLock, settings.opacity);
                break;
            case StudioTextureToolType.Line:
                DrawLine(canvas, settings, start, end, primary);
                break;
            case StudioTextureToolType.Rectangle:
                DrawRectangle(canvas, settings, start, end, primary, false);
                break;
            case StudioTextureToolType.FilledRectangle:
                DrawRectangle(canvas, settings, start, end, primary, true);
                break;
            case StudioTextureToolType.Ellipse:
                DrawEllipse(canvas, settings, start, end, primary, false);
                break;
            case StudioTextureToolType.FilledEllipse:
                DrawEllipse(canvas, settings, start, end, primary, true);
                break;
            case StudioTextureToolType.ReplaceColor:
                ReplaceColor(canvas, canvas.GetPixel(end.x, end.y), primary, settings.opacity);
                break;
            case StudioTextureToolType.Noise:
                ApplyNoise(canvas, settings, end.x, end.y, primary);
                break;
            case StudioTextureToolType.Shade:
            case StudioTextureToolType.Darken:
                ModifyBrush(canvas, settings, end.x, end.y, -settings.toolStrength, 0f);
                break;
            case StudioTextureToolType.Dodge:
            case StudioTextureToolType.Lighten:
                ModifyBrush(canvas, settings, end.x, end.y, settings.toolStrength, 0f);
                break;
            case StudioTextureToolType.Saturate:
                ModifyBrush(canvas, settings, end.x, end.y, 0f, settings.toolStrength);
                break;
            case StudioTextureToolType.Desaturate:
                ModifyBrush(canvas, settings, end.x, end.y, 0f, -settings.toolStrength);
                break;
            case StudioTextureToolType.AlphaBrush:
                PaintBrush(canvas, settings, end.x, end.y, primary);
                break;
            case StudioTextureToolType.Pencil:
            default:
                PaintBrush(canvas, settings, end.x, end.y, primary);
                break;
        }
    }

    public static void MirrorActiveLayer(TextureCanvasState canvas, bool horizontal, bool vertical)
    {
        if (canvas == null) return;
        canvas.EnsureLayer();
        TextureLayerData layer = canvas.ActiveLayer;
        if (layer.locked) return;
        Color32[] copy = (Color32[])layer.pixels.Clone();
        for (int y = 0; y < canvas.height; y++)
        {
            for (int x = 0; x < canvas.width; x++)
            {
                int sx = horizontal ? canvas.width - 1 - x : x;
                int sy = vertical ? canvas.height - 1 - y : y;
                layer.pixels[canvas.ToIndex(x, y)] = copy[canvas.ToIndex(sx, sy)];
            }
        }
    }

    public static void RotateActiveLayer90(TextureCanvasState canvas)
    {
        if (canvas == null) return;
        canvas.EnsureLayer();
        if (canvas.width != canvas.height) return;
        TextureLayerData layer = canvas.ActiveLayer;
        if (layer.locked) return;
        Color32[] copy = (Color32[])layer.pixels.Clone();
        int size = canvas.width;
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                layer.pixels[canvas.ToIndex(size - 1 - y, x)] = copy[canvas.ToIndex(x, y)];
            }
        }
    }

    private static void PaintBrush(TextureCanvasState canvas, TextureEditorToolSettings settings, int centerX, int centerY, Color32 color)
    {
        int radius = Mathf.Max(0, settings.brushSize - 1);
        for (int y = centerY - radius; y <= centerY + radius; y++)
        {
            for (int x = centerX - radius; x <= centerX + radius; x++)
            {
                if (!IsInsideBrush(settings, centerX, centerY, x, y)) continue;
                PlotSymmetric(canvas, settings, x, y, color);
            }
        }
    }

    private static void ModifyBrush(TextureCanvasState canvas, TextureEditorToolSettings settings, int centerX, int centerY, float valueDelta, float saturationDelta)
    {
        int radius = Mathf.Max(0, settings.brushSize - 1);
        for (int y = centerY - radius; y <= centerY + radius; y++)
        {
            for (int x = centerX - radius; x <= centerX + radius; x++)
            {
                if (!IsInsideBrush(settings, centerX, centerY, x, y) || !canvas.IsInside(x, y)) continue;
                Color32 current = canvas.GetPixel(x, y);
                Color.RGBToHSV(current, out float h, out float s, out float v);
                v = Mathf.Clamp01(v + valueDelta);
                s = Mathf.Clamp01(s + saturationDelta);
                Color color = Color.HSVToRGB(h, s, v);
                Color32 modified = new Color32((byte)Mathf.RoundToInt(color.r * 255f), (byte)Mathf.RoundToInt(color.g * 255f), (byte)Mathf.RoundToInt(color.b * 255f), current.a);
                canvas.SetPixel(x, y, modified, true, settings.opacity);
            }
        }
    }

    private static bool IsInsideBrush(TextureEditorToolSettings settings, int cx, int cy, int x, int y)
    {
        int dx = Mathf.Abs(x - cx);
        int dy = Mathf.Abs(y - cy);
        int r = Mathf.Max(0, settings.brushSize - 1);
        switch (settings.brushShape)
        {
            case StudioTextureBrushShape.Circle: return dx * dx + dy * dy <= r * r + 1;
            case StudioTextureBrushShape.Diamond: return dx + dy <= r;
            case StudioTextureBrushShape.HorizontalLine: return dy == 0 && dx <= r;
            case StudioTextureBrushShape.VerticalLine: return dx == 0 && dy <= r;
            case StudioTextureBrushShape.Square:
            default: return dx <= r && dy <= r;
        }
    }

    private static void PlotSymmetric(TextureCanvasState canvas, TextureEditorToolSettings settings, int x, int y, Color32 color)
    {
        canvas.SetPixel(x, y, color, settings.alphaLock, settings.opacity);
        if (settings.symmetryX) canvas.SetPixel(canvas.width - 1 - x, y, color, settings.alphaLock, settings.opacity);
        if (settings.symmetryY) canvas.SetPixel(x, canvas.height - 1 - y, color, settings.alphaLock, settings.opacity);
        if (settings.symmetryX && settings.symmetryY) canvas.SetPixel(canvas.width - 1 - x, canvas.height - 1 - y, color, settings.alphaLock, settings.opacity);
    }

    private static void DrawLine(TextureCanvasState canvas, TextureEditorToolSettings settings, Vector2Int start, Vector2Int end, Color32 color)
    {
        int x0 = start.x, y0 = start.y, x1 = end.x, y1 = end.y;
        int dx = Mathf.Abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
        int dy = -Mathf.Abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
        int err = dx + dy;
        while (true)
        {
            PaintBrush(canvas, settings, x0, y0, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }

    private static void DrawRectangle(TextureCanvasState canvas, TextureEditorToolSettings settings, Vector2Int a, Vector2Int b, Color32 color, bool filled)
    {
        int minX = Mathf.Min(a.x, b.x), maxX = Mathf.Max(a.x, b.x);
        int minY = Mathf.Min(a.y, b.y), maxY = Mathf.Max(a.y, b.y);
        for (int y = minY; y <= maxY; y++)
        {
            for (int x = minX; x <= maxX; x++)
            {
                if (filled || x == minX || x == maxX || y == minY || y == maxY) canvas.SetPixel(x, y, color, settings.alphaLock, settings.opacity);
            }
        }
    }

    private static void DrawEllipse(TextureCanvasState canvas, TextureEditorToolSettings settings, Vector2Int a, Vector2Int b, Color32 color, bool filled)
    {
        float minX = Mathf.Min(a.x, b.x), maxX = Mathf.Max(a.x, b.x);
        float minY = Mathf.Min(a.y, b.y), maxY = Mathf.Max(a.y, b.y);
        float cx = (minX + maxX) * 0.5f;
        float cy = (minY + maxY) * 0.5f;
        float rx = Mathf.Max(0.5f, (maxX - minX) * 0.5f);
        float ry = Mathf.Max(0.5f, (maxY - minY) * 0.5f);
        for (int y = Mathf.FloorToInt(minY); y <= Mathf.CeilToInt(maxY); y++)
        {
            for (int x = Mathf.FloorToInt(minX); x <= Mathf.CeilToInt(maxX); x++)
            {
                float n = ((x - cx) * (x - cx)) / (rx * rx) + ((y - cy) * (y - cy)) / (ry * ry);
                if (filled ? n <= 1.0f : Mathf.Abs(n - 1.0f) <= 0.18f)
                {
                    canvas.SetPixel(x, y, color, settings.alphaLock, settings.opacity);
                }
            }
        }
    }

    private static void FloodFill(TextureCanvasState canvas, int x, int y, Color32 replacement, bool alphaLock, float opacity)
    {
        if (!canvas.IsInside(x, y)) return;
        Color32 target = canvas.GetPixel(x, y);
        if (SameColor(target, replacement)) return;

        Queue<Vector2Int> queue = new Queue<Vector2Int>();
        bool[] visited = new bool[canvas.width * canvas.height];
        queue.Enqueue(new Vector2Int(x, y));
        while (queue.Count > 0)
        {
            Vector2Int p = queue.Dequeue();
            if (!canvas.IsInside(p.x, p.y)) continue;
            int index = canvas.ToIndex(p.x, p.y);
            if (visited[index]) continue;
            visited[index] = true;
            if (!SameColor(canvas.GetPixel(p.x, p.y), target)) continue;
            canvas.SetPixel(p.x, p.y, replacement, alphaLock, opacity);
            queue.Enqueue(new Vector2Int(p.x + 1, p.y));
            queue.Enqueue(new Vector2Int(p.x - 1, p.y));
            queue.Enqueue(new Vector2Int(p.x, p.y + 1));
            queue.Enqueue(new Vector2Int(p.x, p.y - 1));
        }
    }

    private static void ReplaceColor(TextureCanvasState canvas, Color32 target, Color32 replacement, float opacity)
    {
        TextureLayerData layer = canvas.ActiveLayer;
        if (layer.locked) return;
        for (int i = 0; i < layer.pixels.Length; i++)
        {
            if (SameColor(layer.pixels[i], target)) layer.pixels[i] = Lerp(layer.pixels[i], replacement, opacity);
        }
    }

    private static void ApplyNoise(TextureCanvasState canvas, TextureEditorToolSettings settings, int centerX, int centerY, Color32 color)
    {
        int radius = Mathf.Max(0, settings.brushSize - 1);
        for (int y = centerY - radius; y <= centerY + radius; y++)
        {
            for (int x = centerX - radius; x <= centerX + radius; x++)
            {
                if (!IsInsideBrush(settings, centerX, centerY, x, y)) continue;
                if (Random.value <= 0.5f) canvas.SetPixel(x, y, color, settings.alphaLock, settings.opacity);
            }
        }
    }

    private static bool SameColor(Color32 a, Color32 b)
    {
        return a.r == b.r && a.g == b.g && a.b == b.b && a.a == b.a;
    }

    private static Color32 Lerp(Color32 a, Color32 b, float t)
    {
        t = Mathf.Clamp01(t);
        return new Color32(
            (byte)Mathf.RoundToInt(Mathf.Lerp(a.r, b.r, t)),
            (byte)Mathf.RoundToInt(Mathf.Lerp(a.g, b.g, t)),
            (byte)Mathf.RoundToInt(Mathf.Lerp(a.b, b.b, t)),
            (byte)Mathf.RoundToInt(Mathf.Lerp(a.a, b.a, t))
        );
    }
}
