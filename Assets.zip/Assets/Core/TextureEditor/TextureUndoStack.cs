using System.Collections.Generic;

public class TextureUndoStack
{
    private readonly Stack<TextureCanvasState> undo = new Stack<TextureCanvasState>();
    private readonly Stack<TextureCanvasState> redo = new Stack<TextureCanvasState>();
    private readonly int maxSnapshots;

    public TextureUndoStack(int maxSnapshots = 64)
    {
        this.maxSnapshots = maxSnapshots < 4 ? 4 : maxSnapshots;
    }

    public void Push(TextureCanvasState state)
    {
        if (state == null) return;
        undo.Push(state.Clone());
        redo.Clear();
        TrimUndo();
    }

    public bool CanUndo { get { return undo.Count > 0; } }
    public bool CanRedo { get { return redo.Count > 0; } }

    public TextureCanvasState Undo(TextureCanvasState current)
    {
        if (!CanUndo) return current;
        if (current != null) redo.Push(current.Clone());
        return undo.Pop();
    }

    public TextureCanvasState Redo(TextureCanvasState current)
    {
        if (!CanRedo) return current;
        if (current != null) undo.Push(current.Clone());
        return redo.Pop();
    }

    public void Clear()
    {
        undo.Clear();
        redo.Clear();
    }

    private void TrimUndo()
    {
        while (undo.Count > maxSnapshots)
        {
            TextureCanvasState[] items = undo.ToArray();
            undo.Clear();
            for (int i = items.Length - 2; i >= 0; i--)
            {
                undo.Push(items[i]);
            }
        }
    }
}
