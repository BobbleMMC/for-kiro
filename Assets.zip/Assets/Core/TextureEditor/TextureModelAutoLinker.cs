using System;
using System.IO;
using System.Text;

public static class TextureModelAutoLinker
{
    public static TextureModelLinkReport LinkAfterMinecraftExport(TextureEditorToolSettings settings, string minecraftProjectRoot, string modId)
    {
        TextureModelLinkReport report = new TextureModelLinkReport();
        report.modId = SafeId(modId, "mymod");
        report.textureId = SafeId(settings != null ? settings.textureId : "custom_texture", "custom_texture");

        if (settings == null)
        {
            report.Warn("Texture settings mavjud emas, model link o'tkazib yuborildi.");
            return report;
        }

        if (string.IsNullOrWhiteSpace(minecraftProjectRoot) || !Directory.Exists(minecraftProjectRoot))
        {
            report.Warn("Minecraft project root topilmadi, model/lang link o'tkazib yuborildi.");
            return report;
        }

        try
        {
            if (settings.targetType == StudioTextureTargetType.Item)
            {
                LinkItem(settings, minecraftProjectRoot, report.modId, report);
            }
            else if (settings.targetType == StudioTextureTargetType.Block)
            {
                LinkBlock(settings, minecraftProjectRoot, report.modId, report);
            }
            else
            {
                report.Warn("Auto model link hozircha faqat Item va Block texture uchun ishlaydi. Target: " + settings.targetType);
            }

            WriteRefreshHook(minecraftProjectRoot, report);
        }
        catch (Exception ex)
        {
            report.Error("Texture model link exception: " + ex.Message);
        }

        return report;
    }

    public static bool SupportsAutoModelLink(TextureEditorToolSettings settings)
    {
        if (settings == null) return false;
        return settings.targetType == StudioTextureTargetType.Item || settings.targetType == StudioTextureTargetType.Block;
    }

    private static void LinkItem(TextureEditorToolSettings settings, string root, string modId, TextureModelLinkReport report)
    {
        string modelName = GetModelName(settings);
        string textureRef = GetTextureReference(settings, modId);
        string modelPath = Combine(root, "src", "main", "resources", "assets", modId, "models", "item", modelName + ".json");

        string json = "{\n" +
            "  \"parent\": \"minecraft:item/generated\",\n" +
            "  \"textures\": {\n" +
            "    \"layer0\": \"" + Escape(textureRef) + "\"\n" +
            "  }\n" +
            "}\n";

        WriteGeneratedFile(root, modelPath, json, report);
        UpsertLang(root, modId, "item." + modId + "." + ToTranslationPath(modelName), GetDisplayName(settings, modelName), report);
        WriteLinkManifest(root, modId, settings, modelName, textureRef, "item", report);
    }

    private static void LinkBlock(TextureEditorToolSettings settings, string root, string modId, TextureModelLinkReport report)
    {
        string modelName = GetModelName(settings);
        string textureRef = GetTextureReference(settings, modId);

        string blockModelPath = Combine(root, "src", "main", "resources", "assets", modId, "models", "block", modelName + ".json");
        string blockModelJson = "{\n" +
            "  \"parent\": \"minecraft:block/cube_all\",\n" +
            "  \"textures\": {\n" +
            "    \"all\": \"" + Escape(textureRef) + "\"\n" +
            "  }\n" +
            "}\n";
        WriteGeneratedFile(root, blockModelPath, blockModelJson, report);

        string blockstatePath = Combine(root, "src", "main", "resources", "assets", modId, "blockstates", modelName + ".json");
        string blockstateJson = "{\n" +
            "  \"variants\": {\n" +
            "    \"\": { \"model\": \"" + Escape(modId + ":block/" + modelName) + "\" }\n" +
            "  }\n" +
            "}\n";
        WriteGeneratedFile(root, blockstatePath, blockstateJson, report);

        string itemModelPath = Combine(root, "src", "main", "resources", "assets", modId, "models", "item", modelName + ".json");
        string itemModelJson = "{\n" +
            "  \"parent\": \"" + Escape(modId + ":block/" + modelName) + "\"\n" +
            "}\n";
        WriteGeneratedFile(root, itemModelPath, itemModelJson, report);

        UpsertLang(root, modId, "block." + modId + "." + ToTranslationPath(modelName), GetDisplayName(settings, modelName), report);
        WriteLinkManifest(root, modId, settings, modelName, textureRef, "block", report);
    }

    private static void UpsertLang(string root, string modId, string key, string value, TextureModelLinkReport report)
    {
        string langPath = Combine(root, "src", "main", "resources", "assets", modId, "lang", "en_us.json");
        try
        {
            string directory = Path.GetDirectoryName(langPath);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

            if (!File.Exists(langPath))
            {
                string created = "{\n  \"" + Escape(key) + "\": \"" + Escape(value) + "\"\n}\n";
                File.WriteAllText(langPath, created, Encoding.UTF8);
                report.AddFile(langPath);
                return;
            }

            string json = File.ReadAllText(langPath);
            if (json.Contains("\"" + key + "\""))
            {
                report.Warn("Lang entry allaqachon mavjud: " + key);
                report.AddFile(langPath);
                return;
            }

            string trimmed = json.Trim();
            if (!trimmed.StartsWith("{") || !trimmed.EndsWith("}"))
            {
                report.Warn("en_us.json object formatida emas. Lang entry qo'shilmadi: " + key);
                return;
            }

            string body = trimmed.Substring(1, trimmed.Length - 2).Trim();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("{");
            if (!string.IsNullOrWhiteSpace(body))
            {
                sb.Append("  ");
                sb.Append(body);
                if (!body.EndsWith(",")) sb.Append(",");
                sb.AppendLine();
            }
            sb.AppendLine("  \"" + Escape(key) + "\": \"" + Escape(value) + "\"");
            sb.AppendLine("}");

            BackupIfNeeded(root, langPath, report);
            File.WriteAllText(langPath, sb.ToString(), Encoding.UTF8);
            report.AddFile(langPath);
        }
        catch (Exception ex)
        {
            report.Warn("Lang update bajarilmadi: " + ex.Message);
        }
    }

    private static void WriteLinkManifest(string root, string modId, TextureEditorToolSettings settings, string modelName, string textureRef, string kind, TextureModelLinkReport report)
    {
        try
        {
            string manifestPath = Combine(root, ".modstudio", "texture-links", SafeId(settings.textureId, "custom_texture") + ".link.json");
            string directory = Path.GetDirectoryName(manifestPath);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

            string json = "{\n" +
                "  \"textureId\": \"" + Escape(SafeId(settings.textureId, "custom_texture")) + "\",\n" +
                "  \"target\": \"" + Escape(kind) + "\",\n" +
                "  \"modId\": \"" + Escape(modId) + "\",\n" +
                "  \"modelName\": \"" + Escape(modelName) + "\",\n" +
                "  \"textureRef\": \"" + Escape(textureRef) + "\",\n" +
                "  \"generatedAt\": \"" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\"\n" +
                "}\n";
            File.WriteAllText(manifestPath, json, Encoding.UTF8);
            report.AddFile(manifestPath);
        }
        catch (Exception ex)
        {
            report.Warn("Texture link manifest yozilmadi: " + ex.Message);
        }
    }

    private static void WriteRefreshHook(string root, TextureModelLinkReport report)
    {
        try
        {
            string hookPath = Combine(root, ".modstudio", "asset-browser-refresh.request.json");
            string directory = Path.GetDirectoryName(hookPath);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

            StringBuilder files = new StringBuilder();
            for (int i = 0; i < report.writtenFiles.Count; i++)
            {
                files.Append("    \"").Append(Escape(report.writtenFiles[i].Replace('\\', '/'))).Append("\"");
                if (i < report.writtenFiles.Count - 1) files.Append(",");
                files.AppendLine();
            }

            string json = "{\n" +
                "  \"reason\": \"texture-model-link\",\n" +
                "  \"generatedAt\": \"" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\",\n" +
                "  \"files\": [\n" + files.ToString() + "  ]\n" +
                "}\n";
            File.WriteAllText(hookPath, json, Encoding.UTF8);
            report.AddFile(hookPath);
        }
        catch (Exception ex)
        {
            report.Warn("Asset Browser refresh hook yozilmadi: " + ex.Message);
        }
    }

    private static void WriteGeneratedFile(string root, string path, string content, TextureModelLinkReport report)
    {
        try
        {
            if (!IsInsideRoot(root, path))
            {
                report.Error("Path sandbox bloklandi: " + path);
                return;
            }

            string directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
            BackupIfNeeded(root, path, report);
            File.WriteAllText(path, content, Encoding.UTF8);
            report.AddFile(path);
        }
        catch (Exception ex)
        {
            report.Error("Fayl yozilmadi: " + path + " | " + ex.Message);
        }
    }

    private static void BackupIfNeeded(string root, string path, TextureModelLinkReport report)
    {
        try
        {
            if (!File.Exists(path)) return;
            if (!IsInsideRoot(root, path)) return;

            string relative = GetRelativePath(root, path);
            string backupPath = Combine(root, ".modstudio", "backups", "texture-link", DateTime.Now.ToString("yyyyMMdd_HHmmss"), relative);
            string directory = Path.GetDirectoryName(backupPath);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
            File.Copy(path, backupPath, true);
            report.AddFile(backupPath);
        }
        catch (Exception ex)
        {
            report.Warn("Backup olinmadi: " + ex.Message);
        }
    }

    private static string GetTextureReference(TextureEditorToolSettings settings, string modId)
    {
        string rel = TextureWorkspaceBridge.GetMinecraftTextureRelativePath(settings).Replace('\\', '/');
        if (rel.StartsWith("textures/", StringComparison.OrdinalIgnoreCase)) rel = rel.Substring("textures/".Length);
        if (rel.EndsWith(".png", StringComparison.OrdinalIgnoreCase)) rel = rel.Substring(0, rel.Length - 4);
        return SafeId(modId, "mymod") + ":" + rel;
    }

    private static string GetModelName(TextureEditorToolSettings settings)
    {
        string rel = TextureWorkspaceBridge.GetMinecraftTextureRelativePath(settings).Replace('\\', '/');
        string prefix = settings != null && settings.targetType == StudioTextureTargetType.Block ? "textures/block/" : "textures/item/";
        if (rel.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) rel = rel.Substring(prefix.Length);
        else if (rel.StartsWith("textures/", StringComparison.OrdinalIgnoreCase)) rel = rel.Substring("textures/".Length);
        if (rel.EndsWith(".png", StringComparison.OrdinalIgnoreCase)) rel = rel.Substring(0, rel.Length - 4);
        return SafePath(rel, SafeId(settings != null ? settings.textureId : "custom_texture", "custom_texture"));
    }

    private static string GetDisplayName(TextureEditorToolSettings settings, string fallbackId)
    {
        if (settings != null && !string.IsNullOrWhiteSpace(settings.displayName)) return settings.displayName.Trim();
        return Humanize(fallbackId);
    }

    private static string SafePath(string value, string fallback)
    {
        if (string.IsNullOrWhiteSpace(value)) value = fallback;
        value = value.Trim().Replace('\\', '/');
        while (value.StartsWith("/")) value = value.Substring(1);
        value = value.Replace("..", "");
        string[] parts = value.Split('/');
        for (int i = 0; i < parts.Length; i++) parts[i] = SafeId(parts[i], "part");
        return string.Join("/", parts);
    }

    private static string SafeId(string value, string fallback)
    {
        if (string.IsNullOrWhiteSpace(value)) value = fallback;
        value = value.Trim().ToLowerInvariant().Replace('\\', '/');
        StringBuilder sb = new StringBuilder();
        foreach (char c in value)
        {
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '/') sb.Append(c);
            else if (c == ' ' || c == '.') sb.Append('_');
        }
        string result = sb.ToString().Trim('_', '/', '-');
        return string.IsNullOrEmpty(result) ? fallback : result;
    }

    private static string ToTranslationPath(string modelName)
    {
        return SafePath(modelName, "custom_texture").Replace('/', '.');
    }

    private static string Humanize(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) return "Custom Texture";
        string normalized = id.Replace('/', '_').Replace('-', '_');
        string[] parts = normalized.Split('_');
        for (int i = 0; i < parts.Length; i++)
        {
            if (parts[i].Length > 0) parts[i] = char.ToUpper(parts[i][0]) + (parts[i].Length > 1 ? parts[i].Substring(1) : string.Empty);
        }
        return string.Join(" ", parts);
    }

    private static string Combine(params string[] parts)
    {
        if (parts == null || parts.Length == 0) return string.Empty;
        string path = parts[0] ?? string.Empty;
        for (int i = 1; i < parts.Length; i++) path = Path.Combine(path, parts[i] ?? string.Empty);
        return path;
    }

    private static bool IsInsideRoot(string root, string path)
    {
        try
        {
            string fullRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string fullPath = Path.GetFullPath(path);
            return fullPath.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return false;
        }
    }

    private static string GetRelativePath(string root, string path)
    {
        string fullRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
        string fullPath = Path.GetFullPath(path);
        if (fullPath.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase)) return fullPath.Substring(fullRoot.Length);
        return Path.GetFileName(path);
    }

    private static string Escape(string value)
    {
        if (value == null) return string.Empty;
        return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
    }
}
