using System.Collections.Generic;
using System.Text;

public class TextureValidationReport
{
    public List<TextureValidationIssue> issues = new List<TextureValidationIssue>();

    public int ErrorCount
    {
        get
        {
            int count = 0;
            foreach (TextureValidationIssue issue in issues) if (issue != null && issue.severity == TextureValidationSeverity.Error) count++;
            return count;
        }
    }

    public int WarningCount
    {
        get
        {
            int count = 0;
            foreach (TextureValidationIssue issue in issues) if (issue != null && issue.severity == TextureValidationSeverity.Warning) count++;
            return count;
        }
    }

    public void Add(TextureValidationSeverity severity, string code, string message, string suggestion = "")
    {
        issues.Add(new TextureValidationIssue(severity, code, message, suggestion));
    }

    public string Format()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("Texture Validation Report");
        sb.AppendLine("Errors: " + ErrorCount + " | Warnings: " + WarningCount);
        sb.AppendLine("----------------------------------------");
        if (issues.Count == 0) sb.AppendLine("OK: Muammo topilmadi.");
        foreach (TextureValidationIssue issue in issues) sb.AppendLine(issue.ToString());
        return sb.ToString();
    }
}
