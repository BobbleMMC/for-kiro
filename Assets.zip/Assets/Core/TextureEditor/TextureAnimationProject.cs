using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class TextureAnimationProject
{
    public string animationId = "animated_texture";
    public int activeFrameIndex = 0;
    public List<TextureAnimationFrameData> frames = new List<TextureAnimationFrameData>();

    public void EnsureFrames(TextureCanvasState fallback, int defaultTicks)
    {
        if (frames == null) frames = new List<TextureAnimationFrameData>();
        if (frames.Count == 0) frames.Add(new TextureAnimationFrameData("Frame 1", fallback ?? new TextureCanvasState(16, 16), defaultTicks));
        activeFrameIndex = Mathf.Clamp(activeFrameIndex, 0, frames.Count - 1);
    }

    public TextureAnimationFrameData ActiveFrame
    {
        get
        {
            EnsureFrames(new TextureCanvasState(16, 16), 2);
            return frames[activeFrameIndex];
        }
    }

    public void AddFrameFrom(TextureCanvasState source, int ticks)
    {
        EnsureFrames(source, ticks);
        frames.Add(new TextureAnimationFrameData("Frame " + (frames.Count + 1), source, ticks));
        activeFrameIndex = frames.Count - 1;
    }

    public bool DuplicateActiveFrame()
    {
        EnsureFrames(null, 2);
        TextureAnimationFrameData current = ActiveFrame;
        frames.Insert(activeFrameIndex + 1, new TextureAnimationFrameData(current.name + " Copy", current.canvas, current.frameTimeTicks));
        activeFrameIndex++;
        return true;
    }

    public bool RemoveActiveFrame()
    {
        EnsureFrames(null, 2);
        if (frames.Count <= 1) return false;
        frames.RemoveAt(activeFrameIndex);
        activeFrameIndex = Mathf.Clamp(activeFrameIndex, 0, frames.Count - 1);
        return true;
    }
}
