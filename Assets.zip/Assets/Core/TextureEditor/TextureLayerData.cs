using System;
using UnityEngine;

[Serializable]
public class TextureLayerData
{
    public string name = "Layer";
    public bool visible = true;
    public bool locked = false;
    public float opacity = 1f;
    public Color32[] pixels;

    public TextureLayerData() { }

    public TextureLayerData(string layerName, int width, int height, Color32 fill)
    {
        name = string.IsNullOrWhiteSpace(layerName) ? "Layer" : layerName;
        visible = true;
        locked = false;
        opacity = 1f;
        pixels = new Color32[Mathf.Max(1, width * height)];
        for (int i = 0; i < pixels.Length; i++) pixels[i] = fill;
    }

    public TextureLayerData Clone()
    {
        TextureLayerData clone = new TextureLayerData
        {
            name = name,
            visible = visible,
            locked = locked,
            opacity = opacity,
            pixels = pixels == null ? null : (Color32[])pixels.Clone()
        };
        return clone;
    }
}
