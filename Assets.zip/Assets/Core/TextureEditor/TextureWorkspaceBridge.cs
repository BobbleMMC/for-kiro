using System;
using System.IO;
using System.Text;
using UnityEngine;

public static class TextureWorkspaceBridge
{
    public static string SafeId(string value, string fallback)
    {
        if (string.IsNullOrWhiteSpace(value)) value = fallback;
        string safe = value.Trim().ToLowerInvariant();
        StringBuilder sb = new StringBuilder();
        foreach (char c in safe)
        {
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '/') sb.Append(c);
            else if (c == ' ' || c == '.') sb.Append('_');
        }
        string result = sb.ToString().Trim('_', '/', '-');
        return string.IsNullOrEmpty(result) ? fallback : result;
    }

    public static string GetWorkspaceModId(string fallback)
    {
        try
        {
            if (WorkspaceManager.workspace != null && !string.IsNullOrWhiteSpace(WorkspaceManager.workspace.modId))
            {
                return SafeId(WorkspaceManager.workspace.modId, fallback);
            }
        }
        catch
        {
            // WorkspaceManager may not be initialized yet.
        }
        return SafeId(fallback, "mymod");
    }

    public static string GetTextureFileName(TextureEditorToolSettings settings)
    {
        string id = SafeId(settings != null ? settings.textureId : "custom_texture", "custom_texture");
        if (id.EndsWith(".png", StringComparison.OrdinalIgnoreCase)) return id;
        return id + ".png";
    }

    public static string GetUnityTextureRelativePath(TextureEditorToolSettings settings)
    {
        string folder = GetUnityTextureFolder(settings);
        return "Assets/Textures/" + folder + "/" + GetTextureFileName(settings);
    }

    public static string GetUnityTextureAbsolutePath(TextureEditorToolSettings settings)
    {
        string folder = GetUnityTextureFolder(settings).Replace('/', Path.DirectorySeparatorChar);
        return Path.Combine(Application.dataPath, "Textures", folder, GetTextureFileName(settings));
    }

    public static string GetMinecraftTextureRelativePath(TextureEditorToolSettings settings)
    {
        if (settings == null) return "textures/item/custom_texture.png";
        string custom = NormalizeResourcePath(settings.exportPath);
        if (!string.IsNullOrWhiteSpace(custom) && custom.StartsWith("textures/", StringComparison.OrdinalIgnoreCase))
        {
            if (!custom.EndsWith(".png", StringComparison.OrdinalIgnoreCase)) custom += ".png";
            return custom;
        }
        return settings.GetMinecraftTextureFolder() + "/" + GetTextureFileName(settings);
    }

    public static string GetMinecraftTextureAbsolutePath(TextureEditorToolSettings settings, string minecraftProjectRoot, string modId)
    {
        if (string.IsNullOrWhiteSpace(minecraftProjectRoot)) return string.Empty;
        modId = SafeId(modId, "mymod");
        string rel = GetMinecraftTextureRelativePath(settings).Replace('/', Path.DirectorySeparatorChar);
        return Path.Combine(minecraftProjectRoot, "src", "main", "resources", "assets", modId, rel);
    }

    public static bool LooksLikeMinecraftProject(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path)) return false;
        return File.Exists(Path.Combine(path, "build.gradle"))
            || File.Exists(Path.Combine(path, "settings.gradle"))
            || File.Exists(Path.Combine(path, "gradlew"))
            || File.Exists(Path.Combine(path, "gradlew.bat"))
            || Directory.Exists(Path.Combine(path, "src", "main", "resources"));
    }

    public static TextureWorkspaceExportReport ExportToUnityAssets(TextureCanvasState canvas, TextureEditorToolSettings settings)
    {
        TextureWorkspaceExportReport report = NewReport(settings);
        string path = GetUnityTextureAbsolutePath(settings);
        string error;
        if (!TexturePngExporter.Export(canvas, path, settings != null && settings.pixelPerfectExport, out error))
        {
            report.Error(error);
            return report;
        }
        report.unityAssetPath = GetUnityTextureRelativePath(settings);
        report.AddFile(path);
        ExportMcmetaIfNeeded(settings, path, report);
        WriteTextureManifest(settings, report, Path.Combine(Application.dataPath, "Textures", ".modstudio", SafeId(settings.textureId, "custom_texture") + ".texture.json"));
        return report;
    }

    public static TextureWorkspaceExportReport ExportToMinecraftProject(TextureCanvasState canvas, TextureEditorToolSettings settings, string minecraftProjectRoot, string modId)
    {
        TextureWorkspaceExportReport report = NewReport(settings);
        report.modId = SafeId(modId, "mymod");

        if (string.IsNullOrWhiteSpace(minecraftProjectRoot))
        {
            report.Error("Minecraft project root tanlanmagan.");
            return report;
        }
        if (!Directory.Exists(minecraftProjectRoot))
        {
            report.Error("Minecraft project root topilmadi: " + minecraftProjectRoot);
            return report;
        }
        if (!LooksLikeMinecraftProject(minecraftProjectRoot))
        {
            report.Warn("Tanlangan papka Gradle/Minecraft projectga o‘xshamaydi. Baribir texture yoziladi.");
        }

        string path = GetMinecraftTextureAbsolutePath(settings, minecraftProjectRoot, report.modId);
        string error;
        if (!TexturePngExporter.Export(canvas, path, settings != null && settings.pixelPerfectExport, out error))
        {
            report.Error(error);
            return report;
        }

        report.minecraftResourcePath = path;
        report.AddFile(path);
        ExportMcmetaIfNeeded(settings, path, report);

        string manifestPath = Path.Combine(minecraftProjectRoot, ".modstudio", "textures", SafeId(settings.textureId, "custom_texture") + ".texture.json");
        WriteTextureManifest(settings, report, manifestPath);

        // Patch 23: texture-to-model auto-link.
        // After exporting a block/item PNG, generate/update the matching model JSON, blockstate JSON and lang entry.
        TextureModelLinkReport linkReport = TextureModelAutoLinker.LinkAfterMinecraftExport(settings, minecraftProjectRoot, report.modId);
        ApplyModelLinkReport(report, linkReport);

        return report;
    }

    public static TextureWorkspaceExportReport ExportBoth(TextureCanvasState canvas, TextureEditorToolSettings settings, string minecraftProjectRoot, string modId)
    {
        TextureWorkspaceExportReport unity = ExportToUnityAssets(canvas, settings);
        TextureWorkspaceExportReport mc = ExportToMinecraftProject(canvas, settings, minecraftProjectRoot, modId);

        TextureWorkspaceExportReport report = NewReport(settings);
        report.modId = SafeId(modId, "mymod");
        report.unityAssetPath = unity.unityAssetPath;
        report.minecraftResourcePath = mc.minecraftResourcePath;
        foreach (string file in unity.writtenFiles) report.AddFile(file);
        foreach (string file in mc.writtenFiles) report.AddFile(file);
        foreach (string warning in unity.warnings) report.Warn(warning);
        foreach (string warning in mc.warnings) report.Warn(warning);
        foreach (string error in unity.errors) report.Error(error);
        foreach (string error in mc.errors) report.Error(error);
        return report;
    }

    private static TextureWorkspaceExportReport NewReport(TextureEditorToolSettings settings)
    {
        TextureWorkspaceExportReport report = new TextureWorkspaceExportReport();
        report.textureId = SafeId(settings != null ? settings.textureId : "custom_texture", "custom_texture");
        report.modId = GetWorkspaceModId("mymod");
        return report;
    }

    private static void ApplyModelLinkReport(TextureWorkspaceExportReport exportReport, TextureModelLinkReport linkReport)
    {
        if (exportReport == null || linkReport == null) return;
        foreach (string file in linkReport.writtenFiles) exportReport.AddFile(file);
        foreach (string warning in linkReport.warnings) exportReport.Warn("Model link: " + warning);
        foreach (string error in linkReport.errors) exportReport.Error("Model link: " + error);
    }

    private static void ExportMcmetaIfNeeded(TextureEditorToolSettings settings, string pngPath, TextureWorkspaceExportReport report)
    {
        if (settings == null || !settings.generateMcmeta) return;
        string error;
        if (TexturePngExporter.ExportMcmeta(pngPath, settings.frameTimeTicks, out error)) report.AddFile(pngPath + ".mcmeta");
        else report.Warn(".mcmeta yozilmadi: " + error);
    }

    private static void WriteTextureManifest(TextureEditorToolSettings settings, TextureWorkspaceExportReport report, string manifestPath)
    {
        try
        {
            string directory = Path.GetDirectoryName(manifestPath);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
            string json = "{\n" +
                "  \"textureId\": \"" + Escape(report.textureId) + "\",\n" +
                "  \"targetType\": \"" + (settings != null ? settings.targetType.ToString() : "Item") + "\",\n" +
                "  \"minecraftPath\": \"" + Escape(GetMinecraftTextureRelativePath(settings)) + "\",\n" +
                "  \"unityAssetPath\": \"" + Escape(report.unityAssetPath) + "\",\n" +
                "  \"modId\": \"" + Escape(report.modId) + "\",\n" +
                "  \"generatedAt\": \"" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\"\n" +
                "}\n";
            File.WriteAllText(manifestPath, json);
            report.AddFile(manifestPath);
        }
        catch (Exception ex)
        {
            report.Warn("Texture manifest yozilmadi: " + ex.Message);
        }
    }

    private static string GetUnityTextureFolder(TextureEditorToolSettings settings)
    {
        if (settings == null) return "item";
        switch (settings.targetType)
        {
            case StudioTextureTargetType.Block: return "block";
            case StudioTextureTargetType.Entity: return "entity";
            case StudioTextureTargetType.Armor: return "armor";
            case StudioTextureTargetType.Gui: return "gui";
            case StudioTextureTargetType.Particle: return "particle";
            case StudioTextureTargetType.Effect: return "effect";
            case StudioTextureTargetType.Enchantment: return "enchantment";
            case StudioTextureTargetType.Dimension: return "environment";
            case StudioTextureTargetType.Item:
            default: return "item";
        }
    }

    private static string NormalizeResourcePath(string path)
    {
        if (string.IsNullOrWhiteSpace(path)) return string.Empty;
        string p = path.Trim().Replace('\\', '/');
        while (p.StartsWith("/")) p = p.Substring(1);
        p = p.Replace("..", "");
        return p;
    }

    private static string Escape(string value)
    {
        if (value == null) return string.Empty;
        return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
    }
}
