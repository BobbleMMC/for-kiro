using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class TextureCanvasState
{
    public int width = 16;
    public int height = 16;
    public int activeLayerIndex = 0;
    public List<TextureLayerData> layers = new List<TextureLayerData>();

    public TextureCanvasState() { }

    public TextureCanvasState(int canvasWidth, int canvasHeight)
    {
        Reset(canvasWidth, canvasHeight);
    }

    public void Reset(int canvasWidth, int canvasHeight)
    {
        width = Mathf.Clamp(canvasWidth, 1, 512);
        height = Mathf.Clamp(canvasHeight, 1, 512);
        activeLayerIndex = 0;
        layers = new List<TextureLayerData>
        {
            new TextureLayerData("base", width, height, new Color32(0, 0, 0, 0))
        };
    }

    public TextureLayerData ActiveLayer
    {
        get
        {
            EnsureLayer();
            return layers[Mathf.Clamp(activeLayerIndex, 0, layers.Count - 1)];
        }
    }

    public void EnsureLayer()
    {
        if (layers == null) layers = new List<TextureLayerData>();
        if (layers.Count == 0) layers.Add(new TextureLayerData("base", width, height, new Color32(0, 0, 0, 0)));
        activeLayerIndex = Mathf.Clamp(activeLayerIndex, 0, layers.Count - 1);
        foreach (TextureLayerData layer in layers)
        {
            if (layer.pixels == null || layer.pixels.Length != width * height)
            {
                layer.pixels = new Color32[width * height];
            }
        }
    }

    public void AddLayer(string layerName)
    {
        EnsureLayer();
        layers.Add(new TextureLayerData(string.IsNullOrWhiteSpace(layerName) ? "Layer " + (layers.Count + 1) : layerName, width, height, new Color32(0, 0, 0, 0)));
        activeLayerIndex = layers.Count - 1;
    }

    public bool RemoveActiveLayer()
    {
        EnsureLayer();
        if (layers.Count <= 1) return false;
        layers.RemoveAt(activeLayerIndex);
        activeLayerIndex = Mathf.Clamp(activeLayerIndex, 0, layers.Count - 1);
        return true;
    }

    public Color32 GetPixel(int x, int y)
    {
        EnsureLayer();
        if (!IsInside(x, y)) return new Color32(0, 0, 0, 0);
        return ActiveLayer.pixels[ToIndex(x, y)];
    }

    public void SetPixel(int x, int y, Color32 color, bool alphaLock, float opacity)
    {
        EnsureLayer();
        if (!IsInside(x, y)) return;
        TextureLayerData layer = ActiveLayer;
        if (layer.locked) return;

        int index = ToIndex(x, y);
        Color32 existing = layer.pixels[index];
        if (alphaLock) color.a = existing.a;
        layer.pixels[index] = Blend(existing, color, Mathf.Clamp01(opacity));
    }

    public bool IsInside(int x, int y)
    {
        return x >= 0 && y >= 0 && x < width && y < height;
    }

    public int ToIndex(int x, int y)
    {
        return y * width + x;
    }

    public Color32[] CompositePixels()
    {
        EnsureLayer();
        Color32[] output = new Color32[width * height];
        for (int i = 0; i < output.Length; i++) output[i] = new Color32(0, 0, 0, 0);

        foreach (TextureLayerData layer in layers)
        {
            if (layer == null || !layer.visible || layer.pixels == null) continue;
            float layerOpacity = Mathf.Clamp01(layer.opacity);
            for (int i = 0; i < output.Length && i < layer.pixels.Length; i++)
            {
                output[i] = Blend(output[i], layer.pixels[i], layerOpacity * (layer.pixels[i].a / 255f));
            }
        }

        return output;
    }

    public Texture2D ToTexture2D(FilterMode filterMode = FilterMode.Point)
    {
        Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
        texture.filterMode = filterMode;
        texture.wrapMode = TextureWrapMode.Clamp;
        texture.SetPixels32(CompositePixels());
        texture.Apply(false, false);
        return texture;
    }

    public TextureCanvasState Clone()
    {
        TextureCanvasState clone = new TextureCanvasState
        {
            width = width,
            height = height,
            activeLayerIndex = activeLayerIndex,
            layers = new List<TextureLayerData>()
        };
        if (layers != null)
        {
            foreach (TextureLayerData layer in layers)
            {
                clone.layers.Add(layer == null ? null : layer.Clone());
            }
        }
        clone.EnsureLayer();
        return clone;
    }

    private static Color32 Blend(Color32 baseColor, Color32 paintColor, float opacity)
    {
        opacity = Mathf.Clamp01(opacity);
        float srcA = (paintColor.a / 255f) * opacity;
        float dstA = baseColor.a / 255f;
        float outA = srcA + dstA * (1f - srcA);
        if (outA <= 0.0001f) return new Color32(0, 0, 0, 0);

        byte r = (byte)Mathf.RoundToInt(((paintColor.r / 255f) * srcA + (baseColor.r / 255f) * dstA * (1f - srcA)) / outA * 255f);
        byte g = (byte)Mathf.RoundToInt(((paintColor.g / 255f) * srcA + (baseColor.g / 255f) * dstA * (1f - srcA)) / outA * 255f);
        byte b = (byte)Mathf.RoundToInt(((paintColor.b / 255f) * srcA + (baseColor.b / 255f) * dstA * (1f - srcA)) / outA * 255f);
        byte a = (byte)Mathf.RoundToInt(outA * 255f);
        return new Color32(r, g, b, a);
    }
}
