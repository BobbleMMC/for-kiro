using System.Collections.Generic;
using UnityEngine;

public static class TextureValidator
{
    public static TextureValidationReport Validate(TextureCanvasState canvas, TextureEditorToolSettings settings, TextureEditorAdvancedSettings advanced)
    {
        TextureValidationReport report = new TextureValidationReport();
        if (canvas == null)
        {
            report.Add(TextureValidationSeverity.Error, "CANVAS_NULL", "Canvas mavjud emas.", "Texture editorni qayta oching yoki yangi canvas yarating.");
            return report;
        }
        if (settings == null) settings = new TextureEditorToolSettings();
        if (advanced == null) advanced = new TextureEditorAdvancedSettings();
        settings.ClampValues();
        advanced.ClampValues();

        if (canvas.width <= 0 || canvas.height <= 0) report.Add(TextureValidationSeverity.Error, "INVALID_SIZE", "Canvas o‘lchami noto‘g‘ri.", "16x16, 32x32 yoki 64x64 tanlang.");
        if (advanced.validatePowerOfTwo && (!IsPowerOfTwo(canvas.width) || !IsPowerOfTwo(canvas.height))) report.Add(TextureValidationSeverity.Warning, "NOT_POWER_OF_TWO", "Texture o‘lchami power-of-two emas.", "Minecraft pixel art uchun 16/32/64/128 tavsiya qilinadi.");
        if (canvas.width > 256 || canvas.height > 256) report.Add(TextureValidationSeverity.Warning, "VERY_LARGE_TEXTURE", "Texture juda katta.", "Minecraft mod uchun 16–64px ko‘proq mos.");
        if (string.IsNullOrWhiteSpace(settings.textureId)) report.Add(TextureValidationSeverity.Error, "EMPTY_TEXTURE_ID", "Texture ID bo‘sh.", "Masalan: ruby_sword yoki glowing_ore.");
        if (advanced.validateMinecraftPath && !IsSafeMinecraftId(settings.textureId)) report.Add(TextureValidationSeverity.Error, "INVALID_TEXTURE_ID", "Texture ID Minecraft resource qoidalariga mos emas.", "Faqat kichik harf, raqam, _, -, / ishlating.");

        canvas.EnsureLayer();
        if (canvas.layers == null || canvas.layers.Count == 0) report.Add(TextureValidationSeverity.Error, "NO_LAYERS", "Layer yo‘q.", "Kamida base layer bo‘lishi kerak.");
        else
        {
            int visible = 0;
            foreach (TextureLayerData layer in canvas.layers) if (layer != null && layer.visible) visible++;
            if (visible == 0) report.Add(TextureValidationSeverity.Warning, "NO_VISIBLE_LAYER", "Hech bir layer ko‘rinmayapti.", "Kamida bitta layer visible bo‘lsin.");
        }

        Color32[] pixels = canvas.CompositePixels();
        int transparent = 0;
        int opaque = 0;
        for (int i = 0; i < pixels.Length; i++)
        {
            if (pixels[i].a == 0) transparent++; else opaque++;
        }
        if (opaque == 0) report.Add(TextureValidationSeverity.Error, "EMPTY_TEXTURE", "Texture butunlay shaffof.", "Pencil yoki procedural generator bilan texture yarating.");
        if (advanced.validateTransparentPixels && transparent > 0 && settings.targetType == StudioTextureTargetType.Block) report.Add(TextureValidationSeverity.Info, "TRANSPARENT_BLOCK_PIXELS", "Block texture ichida transparent pixel bor.", "Agar block opaque bo‘lsa transparent pixel ishlatmang.");

        List<Color32> colors = TexturePaletteAnalyzer.ExtractTopColors(canvas, 512, false);
        if (advanced.validatePaletteLimit && colors.Count > advanced.maxPaletteColors) report.Add(TextureValidationSeverity.Warning, "PALETTE_TOO_LARGE", "Palette ranglari ko‘p: " + colors.Count, "Pixel art uchun " + advanced.maxPaletteColors + " ranggacha kamaytiring.");
        if (settings.generateMcmeta && settings.frameCount <= 1) report.Add(TextureValidationSeverity.Warning, "MCMETA_WITH_ONE_FRAME", ".mcmeta yoqilgan, lekin frameCount 1.", "Animation uchun kamida 2 frame kerak.");

        return report;
    }

    private static bool IsPowerOfTwo(int value)
    {
        return value > 0 && (value & (value - 1)) == 0;
    }

    private static bool IsSafeMinecraftId(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) return false;
        foreach (char c in id)
        {
            bool ok = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '/';
            if (!ok) return false;
        }
        return true;
    }
}
