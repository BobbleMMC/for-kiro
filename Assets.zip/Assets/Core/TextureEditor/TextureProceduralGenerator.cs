using UnityEngine;

public static class TextureProceduralGenerator
{
    public static void Fill(TextureCanvasState canvas, TextureProceduralPattern pattern, Color32 primary, Color32 secondary, int seed, float strength)
    {
        if (canvas == null) return;
        canvas.EnsureLayer();
        if (canvas.ActiveLayer.locked) return;
        strength = Mathf.Clamp01(strength);
        Random.InitState(seed == 0 ? 1337 : seed);

        for (int y = 0; y < canvas.height; y++)
        {
            for (int x = 0; x < canvas.width; x++)
            {
                Color32 c = GeneratePixel(pattern, x, y, canvas.width, canvas.height, primary, secondary, strength, seed);
                canvas.SetPixel(x, y, c, false, 1f);
            }
        }
    }

    private static Color32 GeneratePixel(TextureProceduralPattern pattern, int x, int y, int width, int height, Color32 primary, Color32 secondary, float strength, int seed)
    {
        switch (pattern)
        {
            case TextureProceduralPattern.Checker:
                return ((x / 4 + y / 4) % 2 == 0) ? primary : secondary;
            case TextureProceduralPattern.GradientHorizontal:
                return Lerp(primary, secondary, width <= 1 ? 0f : (float)x / (width - 1));
            case TextureProceduralPattern.GradientVertical:
                return Lerp(primary, secondary, height <= 1 ? 0f : (float)y / (height - 1));
            case TextureProceduralPattern.Ore:
                return OrePixel(x, y, primary, secondary, strength, seed);
            case TextureProceduralPattern.Stone:
                return StonePixel(x, y, primary, strength, seed);
            case TextureProceduralPattern.Planks:
                return PlankPixel(x, y, primary, secondary, strength, seed);
            case TextureProceduralPattern.Metal:
                return MetalPixel(x, y, primary, secondary, strength, seed);
            case TextureProceduralPattern.Fabric:
                return FabricPixel(x, y, primary, secondary, strength, seed);
            case TextureProceduralPattern.GuiPanel:
                return GuiPanelPixel(x, y, width, height, primary, secondary);
            case TextureProceduralPattern.ParticleSpark:
                return ParticlePixel(x, y, width, height, primary);
            case TextureProceduralPattern.PotionIcon:
                return PotionPixel(x, y, width, height, primary, secondary);
            case TextureProceduralPattern.ArmorLayer:
                return ArmorPixel(x, y, width, height, primary, secondary);
            case TextureProceduralPattern.Noise:
            default:
                return NoisePixel(x, y, primary, secondary, strength, seed);
        }
    }

    private static Color32 NoisePixel(int x, int y, Color32 primary, Color32 secondary, float strength, int seed)
    {
        float n = Hash01(x, y, seed);
        return Lerp(primary, secondary, Mathf.Lerp(0.35f, n, strength));
    }

    private static Color32 OrePixel(int x, int y, Color32 stone, Color32 ore, float strength, int seed)
    {
        float veins = Mathf.PerlinNoise((x + seed) * 0.22f, (y - seed) * 0.22f);
        float cracks = Hash01(x * 7, y * 11, seed);
        if (veins > 0.58f - strength * 0.18f && cracks > 0.22f) return Lerp(ore, new Color32(255, 255, 255, ore.a), Mathf.Clamp01((veins - 0.55f) * 1.4f));
        return StonePixel(x, y, stone, 0.5f, seed);
    }

    private static Color32 StonePixel(int x, int y, Color32 baseColor, float strength, int seed)
    {
        float n = Mathf.PerlinNoise((x + seed) * 0.31f, (y + seed) * 0.31f);
        float delta = (n - 0.5f) * 0.38f * Mathf.Clamp01(strength);
        return ShiftValue(baseColor, delta);
    }

    private static Color32 PlankPixel(int x, int y, Color32 baseColor, Color32 lineColor, float strength, int seed)
    {
        bool seam = y % 5 == 0 || (x + (y / 5) * 3) % 13 == 0;
        float n = Hash01(x, y, seed);
        Color32 c = seam ? lineColor : baseColor;
        return ShiftValue(c, (n - 0.5f) * 0.22f * strength);
    }

    private static Color32 MetalPixel(int x, int y, Color32 baseColor, Color32 highlight, float strength, int seed)
    {
        float band = Mathf.Sin((x + y) * 0.55f) * 0.5f + 0.5f;
        float noise = Hash01(x, y, seed);
        return Lerp(baseColor, highlight, Mathf.Clamp01((band * 0.35f + noise * 0.18f) * strength));
    }

    private static Color32 FabricPixel(int x, int y, Color32 baseColor, Color32 threadColor, float strength, int seed)
    {
        bool thread = x % 3 == 0 || y % 3 == 0;
        Color32 c = thread ? Lerp(baseColor, threadColor, 0.45f) : baseColor;
        return ShiftValue(c, (Hash01(x, y, seed) - 0.5f) * 0.12f * strength);
    }

    private static Color32 GuiPanelPixel(int x, int y, int width, int height, Color32 fill, Color32 border)
    {
        bool edge = x == 0 || y == 0 || x == width - 1 || y == height - 1;
        bool inner = x == 1 || y == 1 || x == width - 2 || y == height - 2;
        if (edge) return border;
        if (inner) return ShiftValue(fill, 0.16f);
        return fill;
    }

    private static Color32 ParticlePixel(int x, int y, int width, int height, Color32 color)
    {
        float cx = (width - 1) * 0.5f;
        float cy = (height - 1) * 0.5f;
        float d = Vector2.Distance(new Vector2(x, y), new Vector2(cx, cy)) / Mathf.Max(1f, Mathf.Min(width, height) * 0.5f);
        byte a = (byte)Mathf.RoundToInt(Mathf.Clamp01(1f - d) * color.a);
        return new Color32(color.r, color.g, color.b, a);
    }

    private static Color32 PotionPixel(int x, int y, int width, int height, Color32 liquid, Color32 glass)
    {
        float cx = (width - 1) * 0.5f;
        float cy = (height - 1) * 0.56f;
        float dx = (x - cx) / Mathf.Max(1f, width * 0.34f);
        float dy = (y - cy) / Mathf.Max(1f, height * 0.34f);
        float d = dx * dx + dy * dy;
        if (d > 1.05f) return new Color32(0, 0, 0, 0);
        if (d > 0.78f) return glass;
        return liquid;
    }

    private static Color32 ArmorPixel(int x, int y, int width, int height, Color32 baseColor, Color32 trim)
    {
        bool trimLine = x == 0 || x == width - 1 || y == 0 || y == height - 1 || (y % 8 == 0);
        return trimLine ? trim : baseColor;
    }

    private static float Hash01(int x, int y, int seed)
    {
        unchecked
        {
            int h = seed;
            h = h * 374761393 + x * 668265263;
            h = (h ^ (h >> 13)) * 1274126177;
            h = h + y * 1442695041;
            h = h ^ (h >> 16);
            return (h & 0x7fffffff) / 2147483647f;
        }
    }

    private static Color32 Lerp(Color32 a, Color32 b, float t)
    {
        t = Mathf.Clamp01(t);
        return new Color32(
            (byte)Mathf.RoundToInt(Mathf.Lerp(a.r, b.r, t)),
            (byte)Mathf.RoundToInt(Mathf.Lerp(a.g, b.g, t)),
            (byte)Mathf.RoundToInt(Mathf.Lerp(a.b, b.b, t)),
            (byte)Mathf.RoundToInt(Mathf.Lerp(a.a, b.a, t)));
    }

    private static Color32 ShiftValue(Color32 c, float delta)
    {
        Color.RGBToHSV(c, out float h, out float s, out float v);
        v = Mathf.Clamp01(v + delta);
        Color rgb = Color.HSVToRGB(h, s, v);
        return new Color32((byte)Mathf.RoundToInt(rgb.r * 255f), (byte)Mathf.RoundToInt(rgb.g * 255f), (byte)Mathf.RoundToInt(rgb.b * 255f), c.a);
    }
}
