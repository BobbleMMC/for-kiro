using System.Collections.Generic;

public static class TextureBrushPresetLibrary
{
    public static List<TextureBrushPreset> BuildDefaultPresets()
    {
        return new List<TextureBrushPreset>
        {
            new TextureBrushPreset("pixel_1", "Pixel Pencil 1px", StudioTextureToolType.Pencil, StudioTextureBrushShape.Square, 1, 1f, 0.2f),
            new TextureBrushPreset("pixel_2", "Pixel Pencil 2px", StudioTextureToolType.Pencil, StudioTextureBrushShape.Square, 2, 1f, 0.2f),
            new TextureBrushPreset("soft_circle", "Soft Circle Brush", StudioTextureToolType.Pencil, StudioTextureBrushShape.Circle, 3, 0.55f, 0.2f),
            new TextureBrushPreset("eraser_clean", "Clean Eraser", StudioTextureToolType.Eraser, StudioTextureBrushShape.Square, 2, 1f, 1f),
            new TextureBrushPreset("bucket_fill", "Bucket Fill", StudioTextureToolType.FillBucket, StudioTextureBrushShape.Square, 1, 1f, 1f),
            new TextureBrushPreset("line_tool", "Line Tool", StudioTextureToolType.Line, StudioTextureBrushShape.Square, 1, 1f, 0.2f),
            new TextureBrushPreset("outline_rect", "Rectangle Outline", StudioTextureToolType.Rectangle, StudioTextureBrushShape.Square, 1, 1f, 0.2f),
            new TextureBrushPreset("filled_rect", "Filled Rectangle", StudioTextureToolType.FilledRectangle, StudioTextureBrushShape.Square, 1, 1f, 0.2f),
            new TextureBrushPreset("noise_ore", "Ore Noise Brush", StudioTextureToolType.Noise, StudioTextureBrushShape.Circle, 2, 0.8f, 0.65f),
            new TextureBrushPreset("shade", "Shade / Darken", StudioTextureToolType.Shade, StudioTextureBrushShape.Circle, 2, 0.8f, 0.12f),
            new TextureBrushPreset("dodge", "Dodge / Lighten", StudioTextureToolType.Dodge, StudioTextureBrushShape.Circle, 2, 0.8f, 0.12f),
            new TextureBrushPreset("saturate", "Saturate", StudioTextureToolType.Saturate, StudioTextureBrushShape.Circle, 2, 0.7f, 0.16f),
            new TextureBrushPreset("desaturate", "Desaturate", StudioTextureToolType.Desaturate, StudioTextureBrushShape.Circle, 2, 0.7f, 0.16f),
            new TextureBrushPreset("replace", "Replace Color", StudioTextureToolType.ReplaceColor, StudioTextureBrushShape.Square, 1, 1f, 1f)
        };
    }

    public static TextureBrushPreset FindById(string id)
    {
        List<TextureBrushPreset> presets = BuildDefaultPresets();
        foreach (TextureBrushPreset preset in presets)
        {
            if (preset != null && preset.id == id) return preset;
        }
        return presets.Count > 0 ? presets[0] : null;
    }
}
