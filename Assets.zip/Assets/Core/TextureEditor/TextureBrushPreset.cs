using System;

[Serializable]
public class TextureBrushPreset
{
    public string id = "preset";
    public string displayName = "Preset";
    public StudioTextureToolType tool = StudioTextureToolType.Pencil;
    public StudioTextureBrushShape shape = StudioTextureBrushShape.Square;
    public int brushSize = 1;
    public float opacity = 1f;
    public float strength = 0.2f;
    public bool alphaLock = false;
    public bool symmetryX = false;
    public bool symmetryY = false;
    public string primaryColor = "#FFFFFFFF";
    public string secondaryColor = "#00000000";

    public TextureBrushPreset() { }

    public TextureBrushPreset(string id, string displayName, StudioTextureToolType tool, StudioTextureBrushShape shape, int brushSize, float opacity, float strength)
    {
        this.id = id;
        this.displayName = displayName;
        this.tool = tool;
        this.shape = shape;
        this.brushSize = brushSize;
        this.opacity = opacity;
        this.strength = strength;
    }

    public void ApplyTo(TextureEditorToolSettings settings)
    {
        if (settings == null) return;
        settings.activeTool = tool;
        settings.brushShape = shape;
        settings.brushSize = brushSize < 1 ? 1 : brushSize;
        settings.opacity = opacity < 0f ? 0f : (opacity > 1f ? 1f : opacity);
        settings.toolStrength = strength < 0f ? 0f : (strength > 1f ? 1f : strength);
        settings.alphaLock = alphaLock;
        settings.symmetryX = symmetryX;
        settings.symmetryY = symmetryY;
        if (!string.IsNullOrWhiteSpace(primaryColor)) settings.selectedPrimaryColor = primaryColor;
        if (!string.IsNullOrWhiteSpace(secondaryColor)) settings.selectedSecondaryColor = secondaryColor;
        settings.ClampValues();
    }
}
