using System;
using UnityEngine;

[Serializable]
public class TextureAnimationFrameData
{
    public string name = "Frame";
    public int frameTimeTicks = 2;
    public TextureCanvasState canvas;

    public TextureAnimationFrameData() { }

    public TextureAnimationFrameData(string name, TextureCanvasState source, int frameTimeTicks)
    {
        this.name = string.IsNullOrWhiteSpace(name) ? "Frame" : name;
        this.frameTimeTicks = Mathf.Max(1, frameTimeTicks);
        canvas = source == null ? new TextureCanvasState(16, 16) : source.Clone();
    }
}
