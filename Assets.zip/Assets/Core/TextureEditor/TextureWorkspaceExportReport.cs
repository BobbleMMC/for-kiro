using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class TextureWorkspaceExportReport
{
    public bool success = true;
    public string textureId = string.Empty;
    public string modId = string.Empty;
    public string unityAssetPath = string.Empty;
    public string minecraftResourcePath = string.Empty;
    public List<string> writtenFiles = new List<string>();
    public List<string> warnings = new List<string>();
    public List<string> errors = new List<string>();

    public void AddFile(string path)
    {
        if (!string.IsNullOrEmpty(path) && !writtenFiles.Contains(path)) writtenFiles.Add(path);
    }

    public void Warn(string message)
    {
        if (!string.IsNullOrEmpty(message)) warnings.Add(message);
    }

    public void Error(string message)
    {
        success = false;
        if (!string.IsNullOrEmpty(message)) errors.Add(message);
    }

    public string Format()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine(success ? "[TextureWorkspace] Export muvaffaqiyatli." : "[TextureWorkspace] Exportda xato bor.");
        if (!string.IsNullOrEmpty(textureId)) sb.AppendLine("Texture ID: " + textureId);
        if (!string.IsNullOrEmpty(modId)) sb.AppendLine("Mod ID: " + modId);
        if (!string.IsNullOrEmpty(unityAssetPath)) sb.AppendLine("Unity asset: " + unityAssetPath);
        if (!string.IsNullOrEmpty(minecraftResourcePath)) sb.AppendLine("Minecraft resource: " + minecraftResourcePath);

        if (writtenFiles.Count > 0)
        {
            sb.AppendLine("\nWritten files:");
            foreach (string file in writtenFiles) sb.AppendLine("  + " + file);
        }

        if (warnings.Count > 0)
        {
            sb.AppendLine("\nWarnings:");
            foreach (string warning in warnings) sb.AppendLine("  ! " + warning);
        }

        if (errors.Count > 0)
        {
            sb.AppendLine("\nErrors:");
            foreach (string error in errors) sb.AppendLine("  x " + error);
        }

        return sb.ToString();
    }
}
