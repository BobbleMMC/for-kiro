using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class StudioQualityGateReport
{
    public string projectRoot;
    public string generatedAtUtc;
    public bool passed;
    public readonly List<StudioQualityIssue> issues = new List<StudioQualityIssue>();

    public int ErrorCount
    {
        get
        {
            int count = 0;
            foreach (var issue in issues) if (issue.severity == StudioQualitySeverity.Error) count++;
            return count;
        }
    }

    public int WarningCount
    {
        get
        {
            int count = 0;
            foreach (var issue in issues) if (issue.severity == StudioQualitySeverity.Warning) count++;
            return count;
        }
    }

    public void Add(StudioQualitySeverity severity, string code, string message, string path = "")
    {
        issues.Add(new StudioQualityIssue(severity, code, message, path));
        passed = ErrorCount == 0;
    }

    public string FormatText()
    {
        var sb = new StringBuilder();
        sb.AppendLine("=== Mod Studio Quality Gate ===");
        sb.AppendLine("Project: " + projectRoot);
        sb.AppendLine("Generated UTC: " + generatedAtUtc);
        sb.AppendLine("Status: " + (passed ? "PASSED" : "FAILED"));
        sb.AppendLine("Errors: " + ErrorCount + " | Warnings: " + WarningCount + " | Total: " + issues.Count);
        sb.AppendLine();
        foreach (var issue in issues) sb.AppendLine(issue.ToString());
        return sb.ToString();
    }
}
