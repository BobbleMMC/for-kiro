public enum StudioQualitySeverity
{
    Info,
    Warning,
    Error
}
