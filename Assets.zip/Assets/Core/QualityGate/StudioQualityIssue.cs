using System;

[Serializable]
public class StudioQualityIssue
{
    public StudioQualitySeverity severity;
    public string code;
    public string message;
    public string path;

    public StudioQualityIssue()
    {
    }

    public StudioQualityIssue(StudioQualitySeverity severity, string code, string message, string path = "")
    {
        this.severity = severity;
        this.code = code;
        this.message = message;
        this.path = path;
    }

    public override string ToString()
    {
        return "[" + severity + "] " + code + ": " + message + (string.IsNullOrEmpty(path) ? "" : " (" + path + ")");
    }
}
