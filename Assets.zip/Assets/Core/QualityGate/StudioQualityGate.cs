using System;
using System.IO;
using System.Text;

public static class StudioQualityGate
{
    public static StudioQualityGateReport Run(string projectRoot)
    {
        var report = new StudioQualityGateReport
        {
            projectRoot = projectRoot,
            generatedAtUtc = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"),
            passed = true
        };

        if (string.IsNullOrEmpty(projectRoot) || !Directory.Exists(projectRoot))
        {
            report.Add(StudioQualitySeverity.Error, "PROJECT_ROOT_MISSING", "Project root topilmadi yoki noto'g'ri.", projectRoot);
            return report;
        }

        CheckFile(report, projectRoot, "settings.gradle", StudioQualitySeverity.Warning, "SETTINGS_GRADLE_MISSING", "settings.gradle topilmadi.");
        CheckFile(report, projectRoot, "build.gradle", StudioQualitySeverity.Warning, "BUILD_GRADLE_MISSING", "build.gradle topilmadi.");
        CheckFile(report, projectRoot, "gradle.properties", StudioQualitySeverity.Warning, "GRADLE_PROPERTIES_MISSING", "gradle.properties topilmadi.");

        string resources = Combine(projectRoot, "src/main/resources");
        if (!Directory.Exists(resources))
            report.Add(StudioQualitySeverity.Warning, "RESOURCES_MISSING", "src/main/resources topilmadi.", resources);

        string modstudio = Combine(projectRoot, ".modstudio");
        if (!Directory.Exists(modstudio))
            report.Add(StudioQualitySeverity.Warning, "MODSTUDIO_FOLDER_MISSING", ".modstudio papkasi topilmadi. Avval Save/Export qiling.", modstudio);

        CheckBindingOutputs(report, projectRoot);
        CheckGeneratedJavaStubs(report, projectRoot);
        CheckReleaseArtifacts(report, projectRoot);

        report.passed = report.ErrorCount == 0;
        return report;
    }

    private static void CheckBindingOutputs(StudioQualityGateReport report, string projectRoot)
    {
        var orchestration = StudioBindingOrchestrator.Analyze(projectRoot);
        if (orchestration.errorCount > 0)
        {
            report.Add(StudioQualitySeverity.Warning, "BINDING_OUTPUT_INCOMPLETE", "Ayrim binding generator outputlari topilmadi. Unified Binding Reportni tekshiring.", ".modstudio/reports/unified-binding-report.txt");
        }
        else
        {
            report.Add(StudioQualitySeverity.Info, "BINDING_OUTPUT_OK", "Binding outputlar mavjud.");
        }
    }

    private static void CheckGeneratedJavaStubs(StudioQualityGateReport report, string projectRoot)
    {
        string generatedJava = Combine(projectRoot, ".modstudio/generated-java");
        if (!Directory.Exists(generatedJava))
        {
            report.Add(StudioQualitySeverity.Info, "JAVA_STUBS_NOT_GENERATED", ".modstudio/generated-java topilmadi. Java stub kerak bo'lsa tegishli generatorlarni ishga tushiring.", generatedJava);
            return;
        }

        int stubCount = Directory.GetFiles(generatedJava, "*.java.stub", SearchOption.AllDirectories).Length;
        if (stubCount > 0)
            report.Add(StudioQualitySeverity.Warning, "JAVA_STUBS_PENDING", stubCount + " ta .java.stub bor. Builddan oldin Apply Java Stubs flow orqali tekshiring.", generatedJava);
        else
            report.Add(StudioQualitySeverity.Info, "JAVA_STUBS_EMPTY", "Pending Java stub topilmadi.", generatedJava);
    }

    private static void CheckReleaseArtifacts(StudioQualityGateReport report, string projectRoot)
    {
        string libs = Combine(projectRoot, "build/libs");
        if (!Directory.Exists(libs))
        {
            report.Add(StudioQualitySeverity.Info, "BUILD_LIBS_MISSING", "build/libs topilmadi. Release qilishdan oldin Build Jar qiling.", libs);
            return;
        }

        int jarCount = Directory.GetFiles(libs, "*.jar", SearchOption.TopDirectoryOnly).Length;
        if (jarCount == 0)
            report.Add(StudioQualitySeverity.Warning, "JAR_MISSING", "build/libs ichida .jar topilmadi.", libs);
        else
            report.Add(StudioQualitySeverity.Info, "JAR_FOUND", jarCount + " ta jar topildi.", libs);
    }

    private static void CheckFile(StudioQualityGateReport report, string root, string relative, StudioQualitySeverity severity, string code, string message)
    {
        string path = Combine(root, relative);
        if (!File.Exists(path)) report.Add(severity, code, message, relative);
    }

    public static string WriteReport(string projectRoot, StudioQualityGateReport report)
    {
        string dir = Combine(projectRoot, ".modstudio/reports");
        Directory.CreateDirectory(dir);
        string path = Path.Combine(dir, "studio-quality-gate.txt");
        File.WriteAllText(path, report.FormatText(), Encoding.UTF8);
        return path;
    }

    private static string Combine(string root, string relative)
    {
        return Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar).Replace('\\', Path.DirectorySeparatorChar));
    }
}
