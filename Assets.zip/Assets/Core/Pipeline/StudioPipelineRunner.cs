using System;
using System.IO;
using System.Text;

public static class StudioPipelineRunner
{
    public static StudioPipelineReport RunPreflight(string projectRoot)
    {
        var report = CreateReport(projectRoot);

        var bindingStep = new StudioPipelineStep("analyze_bindings", "Analyze Binding Outputs", "orchestration", "", true);
        try
        {
            var bindingReport = StudioBindingOrchestrator.Analyze(projectRoot);
            bindingStep.status = bindingReport.errorCount > 0 ? StudioPipelineStepStatus.Warning : StudioPipelineStepStatus.Success;
            bindingStep.message = "Modules: " + bindingReport.moduleCount + " | OK: " + bindingReport.okCount + " | Warning: " + bindingReport.warningCount + " | Error: " + bindingReport.errorCount;
            bindingStep.reportPath = StudioBindingOrchestrator.WriteReport(projectRoot, bindingReport);
        }
        catch (Exception ex)
        {
            bindingStep.status = StudioPipelineStepStatus.Failed;
            bindingStep.message = ex.Message;
        }
        report.Add(bindingStep);

        var qualityStep = new StudioPipelineStep("quality_gate", "Run Studio Quality Gate", "quality", "", true);
        try
        {
            var quality = StudioQualityGate.Run(projectRoot);
            qualityStep.status = quality.ErrorCount > 0 ? StudioPipelineStepStatus.Failed : (quality.WarningCount > 0 ? StudioPipelineStepStatus.Warning : StudioPipelineStepStatus.Success);
            qualityStep.message = "Passed: " + (quality.passed ? "yes" : "no") + " | Errors: " + quality.ErrorCount + " | Warnings: " + quality.WarningCount;
            qualityStep.reportPath = StudioQualityGate.WriteReport(projectRoot, quality);
        }
        catch (Exception ex)
        {
            qualityStep.status = StudioPipelineStepStatus.Failed;
            qualityStep.message = ex.Message;
        }
        report.Add(qualityStep);

        WriteReport(projectRoot, report, "studio-pipeline-preflight.txt");
        return report;
    }

    public static StudioPipelineReport RunGradleBuild(string projectRoot, string extraArgs)
    {
        var report = CreateReport(projectRoot);
        RunGradleStep(report, projectRoot, "gradle_build", "Gradle Build Jar", "build", extraArgs, true);
        WriteReport(projectRoot, report, "studio-pipeline-build.txt");
        return report;
    }

    public static StudioPipelineReport RunGradleTask(string projectRoot, string task, string extraArgs)
    {
        var report = CreateReport(projectRoot);
        RunGradleStep(report, projectRoot, "gradle_" + Sanitize(task), "Gradle Task: " + task, task, extraArgs, true);
        WriteReport(projectRoot, report, "studio-pipeline-gradle-" + Sanitize(task) + ".txt");
        return report;
    }

    public static StudioPipelineReport RunFullPipeline(string projectRoot, bool stopOnPreflightError, string extraGradleArgs)
    {
        var report = CreateReport(projectRoot);

        var preflight = RunPreflight(projectRoot);
        foreach (var step in preflight.steps) report.Add(step);

        if (stopOnPreflightError && preflight.failedCount > 0)
        {
            var skipped = new StudioPipelineStep("gradle_build_skipped", "Gradle Build Jar", "gradle", "build", true);
            skipped.status = StudioPipelineStepStatus.Skipped;
            skipped.message = "Preflight failed bo'lgani uchun build o'tkazib yuborildi.";
            report.Add(skipped);
            WriteReport(projectRoot, report, "studio-pipeline-full.txt");
            return report;
        }

        RunGradleStep(report, projectRoot, "gradle_build", "Gradle Build Jar", "build", extraGradleArgs, true);
        WriteReport(projectRoot, report, "studio-pipeline-full.txt");
        return report;
    }

    private static void RunGradleStep(StudioPipelineReport report, string projectRoot, string id, string displayName, string task, string extraArgs, bool required)
    {
        var step = new StudioPipelineStep(id, displayName, "gradle", task, required);
        step.startedAtUtc = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
        try
        {
            var gradle = StudioGradleTaskRunner.RunTask(projectRoot, task, extraArgs);
            step.exitCode = gradle.exitCode;
            step.logPath = gradle.logPath;
            step.message = gradle.errorSummary;
            step.status = gradle.success ? StudioPipelineStepStatus.Success : StudioPipelineStepStatus.Failed;
        }
        catch (Exception ex)
        {
            step.status = StudioPipelineStepStatus.Failed;
            step.message = ex.Message;
        }
        step.finishedAtUtc = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
        report.Add(step);
    }

    private static StudioPipelineReport CreateReport(string projectRoot)
    {
        return new StudioPipelineReport
        {
            projectRoot = projectRoot,
            generatedAtUtc = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"),
            passed = true
        };
    }

    public static string WriteReport(string projectRoot, StudioPipelineReport report, string fileName)
    {
        string dir = Path.Combine(projectRoot, ".modstudio", "reports");
        Directory.CreateDirectory(dir);
        string path = Path.Combine(dir, fileName);
        File.WriteAllText(path, report.FormatText(), Encoding.UTF8);
        WriteJson(projectRoot, report, Path.ChangeExtension(fileName, ".json"));
        return path;
    }

    private static void WriteJson(string projectRoot, StudioPipelineReport report, string fileName)
    {
        string dir = Path.Combine(projectRoot, ".modstudio", "reports");
        Directory.CreateDirectory(dir);
        string path = Path.Combine(dir, fileName);
        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"projectRoot\": \"" + Escape(report.projectRoot) + "\",");
        sb.AppendLine("  \"generatedAtUtc\": \"" + Escape(report.generatedAtUtc) + "\",");
        sb.AppendLine("  \"passed\": " + (report.passed ? "true" : "false") + ",");
        sb.AppendLine("  \"successCount\": " + report.successCount + ",");
        sb.AppendLine("  \"warningCount\": " + report.warningCount + ",");
        sb.AppendLine("  \"failedCount\": " + report.failedCount + ",");
        sb.AppendLine("  \"skippedCount\": " + report.skippedCount + ",");
        sb.AppendLine("  \"steps\": [");
        for (int i = 0; i < report.steps.Count; i++)
        {
            var s = report.steps[i];
            sb.AppendLine("    {");
            sb.AppendLine("      \"id\": \"" + Escape(s.id) + "\",");
            sb.AppendLine("      \"displayName\": \"" + Escape(s.displayName) + "\",");
            sb.AppendLine("      \"kind\": \"" + Escape(s.kind) + "\",");
            sb.AppendLine("      \"status\": \"" + Escape(s.status.ToString()) + "\",");
            sb.AppendLine("      \"gradleTask\": \"" + Escape(s.gradleTask) + "\",");
            sb.AppendLine("      \"exitCode\": " + s.exitCode + ",");
            sb.AppendLine("      \"message\": \"" + Escape(s.message) + "\",");
            sb.AppendLine("      \"logPath\": \"" + Escape(s.logPath) + "\"");
            sb.Append("    }");
            if (i < report.steps.Count - 1) sb.Append(",");
            sb.AppendLine();
        }
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
    }

    private static string Sanitize(string value)
    {
        if (string.IsNullOrEmpty(value)) return "task";
        foreach (char c in Path.GetInvalidFileNameChars()) value = value.Replace(c, '_');
        return value.Replace(':', '_').Replace(' ', '_');
    }

    private static string Escape(string value)
    {
        if (string.IsNullOrEmpty(value)) return "";
        return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "\\n");
    }
}
