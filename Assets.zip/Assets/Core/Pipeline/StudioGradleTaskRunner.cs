using System;
using System.Diagnostics;
using System.IO;
using System.Text;

public static class StudioGradleTaskRunner
{
    public static StudioPipelineGradleResult RunTask(string projectRoot, string task, string extraArgs)
    {
        var result = new StudioPipelineGradleResult
        {
            task = task,
            workingDirectory = projectRoot
        };

        if (string.IsNullOrEmpty(projectRoot) || !Directory.Exists(projectRoot))
        {
            result.success = false;
            result.exitCode = -1;
            result.errorSummary = "Project root topilmadi.";
            return result;
        }

        string executable = ResolveGradleExecutable(projectRoot);
        string args = BuildArguments(projectRoot, executable, task, extraArgs);
        result.command = executable + " " + args;

        string logDir = Path.Combine(projectRoot, ".modstudio", "build-history", DateTime.UtcNow.ToString("yyyyMMdd_HHmmss"));
        Directory.CreateDirectory(logDir);
        result.logPath = Path.Combine(logDir, "gradle-" + Sanitize(task) + ".log");

        var output = new StringBuilder();
        output.AppendLine("Command: " + result.command);
        output.AppendLine("Working directory: " + projectRoot);
        output.AppendLine("Started UTC: " + DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"));
        output.AppendLine();

        try
        {
            var psi = new ProcessStartInfo();
            psi.FileName = executable;
            psi.Arguments = args;
            psi.WorkingDirectory = projectRoot;
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.CreateNoWindow = true;

            using (var process = new Process())
            {
                process.StartInfo = psi;
                process.Start();
                string stdout = process.StandardOutput.ReadToEnd();
                string stderr = process.StandardError.ReadToEnd();
                process.WaitForExit();

                result.exitCode = process.ExitCode;
                output.AppendLine(stdout);
                if (!string.IsNullOrEmpty(stderr))
                {
                    output.AppendLine();
                    output.AppendLine("--- STDERR ---");
                    output.AppendLine(stderr);
                }
            }
        }
        catch (Exception ex)
        {
            result.exitCode = -2;
            output.AppendLine("[EXCEPTION] " + ex.Message);
        }

        output.AppendLine();
        output.AppendLine("Finished UTC: " + DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"));
        result.output = output.ToString();
        result.success = result.exitCode == 0;
        result.errorSummary = StudioBuildLogAnalyzer.Analyze(result.output);
        File.WriteAllText(result.logPath, result.output + "\n\nAnalysis: " + result.errorSummary, Encoding.UTF8);
        return result;
    }

    private static string ResolveGradleExecutable(string projectRoot)
    {
        string bat = Path.Combine(projectRoot, "gradlew.bat");
        string sh = Path.Combine(projectRoot, "gradlew");

        if (IsWindows() && File.Exists(bat)) return bat;
        if (!IsWindows() && File.Exists(sh)) return sh;
        return "gradle";
    }

    private static string BuildArguments(string projectRoot, string executable, string task, string extraArgs)
    {
        string args = string.IsNullOrEmpty(task) ? "build" : task;
        if (!string.IsNullOrEmpty(extraArgs)) args += " " + extraArgs;
        return args;
    }

    private static bool IsWindows()
    {
        PlatformID p = Environment.OSVersion.Platform;
        return p == PlatformID.Win32NT || p == PlatformID.Win32S || p == PlatformID.Win32Windows || p == PlatformID.WinCE;
    }

    private static string Sanitize(string value)
    {
        if (string.IsNullOrEmpty(value)) return "task";
        foreach (char c in Path.GetInvalidFileNameChars()) value = value.Replace(c, '_');
        return value.Replace(':', '_').Replace(' ', '_');
    }
}
