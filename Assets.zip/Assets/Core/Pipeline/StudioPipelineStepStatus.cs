using System;

[Serializable]
public enum StudioPipelineStepStatus
{
    Pending,
    Running,
    Success,
    Warning,
    Failed,
    Skipped
}
