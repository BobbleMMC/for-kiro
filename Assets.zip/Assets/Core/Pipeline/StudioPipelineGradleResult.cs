using System;

[Serializable]
public class StudioPipelineGradleResult
{
    public string task;
    public bool success;
    public int exitCode;
    public string command;
    public string workingDirectory;
    public string logPath;
    public string output;
    public string errorSummary;
}
