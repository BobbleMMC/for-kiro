using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class StudioPipelineReport
{
    public string projectRoot;
    public string generatedAtUtc;
    public bool passed;
    public int successCount;
    public int warningCount;
    public int failedCount;
    public int skippedCount;
    public readonly List<StudioPipelineStep> steps = new List<StudioPipelineStep>();

    public void Add(StudioPipelineStep step)
    {
        steps.Add(step);
        if (step.status == StudioPipelineStepStatus.Success) successCount++;
        else if (step.status == StudioPipelineStepStatus.Warning) warningCount++;
        else if (step.status == StudioPipelineStepStatus.Failed) failedCount++;
        else if (step.status == StudioPipelineStepStatus.Skipped) skippedCount++;
        passed = failedCount == 0;
    }

    public string FormatText()
    {
        var sb = new StringBuilder();
        sb.AppendLine("=== Mod Studio Pipeline Report ===");
        sb.AppendLine("Project: " + projectRoot);
        sb.AppendLine("Generated UTC: " + generatedAtUtc);
        sb.AppendLine("Passed: " + (passed ? "YES" : "NO"));
        sb.AppendLine("Success: " + successCount + " | Warning: " + warningCount + " | Failed: " + failedCount + " | Skipped: " + skippedCount);
        sb.AppendLine();

        foreach (var step in steps)
        {
            sb.AppendLine("[" + step.status.ToString().ToUpperInvariant() + "] " + step.displayName);
            if (!string.IsNullOrEmpty(step.kind)) sb.AppendLine("  Kind: " + step.kind);
            if (!string.IsNullOrEmpty(step.gradleTask)) sb.AppendLine("  Gradle task: " + step.gradleTask);
            if (!string.IsNullOrEmpty(step.message)) sb.AppendLine("  Message: " + step.message);
            if (!string.IsNullOrEmpty(step.logPath)) sb.AppendLine("  Log: " + step.logPath);
            if (!string.IsNullOrEmpty(step.reportPath)) sb.AppendLine("  Report: " + step.reportPath);
            if (step.exitCode != 0) sb.AppendLine("  Exit code: " + step.exitCode);
            sb.AppendLine();
        }

        return sb.ToString();
    }
}
