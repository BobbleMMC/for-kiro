using System;

[Serializable]
public class StudioPipelineStep
{
    public string id;
    public string displayName;
    public string kind;
    public string gradleTask;
    public bool required = true;
    public StudioPipelineStepStatus status = StudioPipelineStepStatus.Pending;
    public int exitCode = 0;
    public string startedAtUtc;
    public string finishedAtUtc;
    public string message;
    public string logPath;
    public string reportPath;

    public StudioPipelineStep()
    {
    }

    public StudioPipelineStep(string id, string displayName, string kind, string gradleTask, bool required)
    {
        this.id = id;
        this.displayName = displayName;
        this.kind = kind;
        this.gradleTask = gradleTask;
        this.required = required;
    }
}
