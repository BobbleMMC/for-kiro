using System;

public static class StudioBuildLogAnalyzer
{
    public static string Analyze(string log)
    {
        if (string.IsNullOrEmpty(log)) return "Log bo'sh.";
        string lower = log.ToLowerInvariant();

        if (lower.Contains("java_home") || lower.Contains("invalid java") || lower.Contains("unsupported class file major version"))
            return "Java/JAVA_HOME muammosi ehtimoli bor. Project Java version va system JAVA_HOME mosligini tekshiring.";

        if (lower.Contains("could not resolve") || lower.Contains("could not find") || lower.Contains("failed to resolve") || lower.Contains("maven"))
            return "Dependency yoki Maven repository muammosi ehtimoli bor. build.gradle repositories/dependencies va internet ulanishini tekshiring.";

        if (lower.Contains("compilation failed") || lower.Contains("compilejava") || lower.Contains("cannot find symbol") || lower.Contains("package") && lower.Contains("does not exist"))
            return "Java compile xatosi. .java.stub apply qilingan fayllar, importlar va loader/version API mosligini tekshiring.";

        if (lower.Contains("fabric.mod.json") || lower.Contains("mods.toml") || lower.Contains("entrypoint"))
            return "Loader metadata xatosi. fabric.mod.json/mods.toml entrypoint, mod id va main classlarni tekshiring.";

        if (lower.Contains("mixin") || lower.Contains("injection failure"))
            return "Mixin xatosi. Mapping/version mosligi va target methodlarni tekshiring.";

        if (lower.Contains("jsonparseexception") || lower.Contains("malformedjson") || lower.Contains("expected") && lower.Contains("json"))
            return "JSON resource syntax xatosi. Recipe/model/blockstate/loot/tag JSON fayllarni validator bilan tekshiring.";

        if (lower.Contains("outofmemory") || lower.Contains("java heap space"))
            return "Memory/heap yetishmayapti. gradle.properties ichida org.gradle.jvmargs qiymatini oshiring.";

        if (lower.Contains("access is denied") || lower.Contains("permission denied") || lower.Contains("being used by another process"))
            return "Permission yoki file lock muammosi. Minecraft/IDE/Explorer jar faylni band qilmaganini tekshiring.";

        if (lower.Contains("build failed"))
            return "Build failed. Log oxiridagi birinchi ERROR sababini tekshiring.";

        if (lower.Contains("build successful"))
            return "Build successful.";

        return "Aniq pattern topilmadi. To'liq Gradle logni tekshiring.";
    }
}
