using System;
using System.Collections.Generic;

/// <summary>
/// TemplateRenderContext — template ichidagi {{variable}} qiymatlarini ushlab turadi.
/// Bu oddiy va Unity-friendly engine: reflection yoki tashqi dependency ishlatmaydi.
/// </summary>
[Serializable]
public class TemplateRenderContext
{
    private readonly Dictionary<string, string> _values = new Dictionary<string, string>();

    public void Set(string key, string value)
    {
        if (string.IsNullOrEmpty(key)) return;
        _values[key] = value ?? string.Empty;
    }

    public string Get(string key, string fallback = "")
    {
        if (string.IsNullOrEmpty(key)) return fallback;
        string value;
        return _values.TryGetValue(key, out value) ? value : fallback;
    }

    public bool Has(string key)
    {
        return !string.IsNullOrEmpty(key) && _values.ContainsKey(key);
    }
}
