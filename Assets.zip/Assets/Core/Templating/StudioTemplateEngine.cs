using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

/// <summary>
/// StudioTemplateEngine — sodda, deterministic template renderer.
/// Maqsad: build.gradle, metadata JSON/TOML, wrapper va boshqa scaffold fayllarni
/// VersionResolver natijasiga qarab yaratish.
/// </summary>
public static class StudioTemplateEngine
{
    private static readonly Regex PlaceholderRegex = new Regex("\\{\\{([a-zA-Z0-9_.-]+)\\}\\}", RegexOptions.Compiled);

    public static string Render(string template, TemplateRenderContext context)
    {
        if (template == null) return string.Empty;
        if (context == null) context = new TemplateRenderContext();

        return PlaceholderRegex.Replace(template, match =>
        {
            string key = match.Groups[1].Value;
            return context.Get(key, match.Value);
        });
    }

    public static TemplateRenderResult WriteFiles(string rootPath, List<TemplateFileSpec> files, TemplateRenderContext context)
    {
        TemplateRenderResult result = new TemplateRenderResult();
        if (string.IsNullOrEmpty(rootPath))
        {
            result.AddWarning("Project path bo'sh. Template yozish bekor qilindi.");
            return result;
        }

        if (files == null || files.Count == 0)
        {
            result.AddWarning("Template fayllar ro'yxati bo'sh.");
            return result;
        }

        foreach (var file in files)
        {
            if (file == null || string.IsNullOrEmpty(file.path)) continue;

            string renderedPath = Render(file.path, context);
            string finalPath = Path.Combine(rootPath, renderedPath.Replace('/', Path.DirectorySeparatorChar));
            if (File.Exists(finalPath) && !file.overwrite)
            {
                result.AddSkipped(renderedPath);
                continue;
            }

            string rendered = Render(file.template, context);
            PatchOperation operation = new PatchOperation(
                renderedPath,
                rendered,
                string.IsNullOrEmpty(file.mergeStrategy) ? "replace" : file.mergeStrategy,
                file.description,
                true
            );

            StudioPatchResult patchResult = StudioPatchEngine.ApplyOne(rootPath, operation);
            MergePatchResult(result, patchResult, renderedPath);
        }

        return result;
    }
    private static void MergePatchResult(TemplateRenderResult result, StudioPatchResult patchResult, string path)
    {
        if (result == null || patchResult == null) return;
        foreach (var f in patchResult.writtenFiles) result.AddWritten(f);
        foreach (var f in patchResult.mergedFiles) result.AddWritten(f);
        foreach (var f in patchResult.skippedFiles) result.AddSkipped(f);
        foreach (var w in patchResult.warnings) result.AddWarning(w);
        foreach (var e in patchResult.errors) result.AddWarning("PatchEngine error: " + e);
    }
}
