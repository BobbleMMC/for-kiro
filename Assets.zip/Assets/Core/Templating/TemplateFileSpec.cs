using System;

/// <summary>
/// Bitta template fayl yozish spetsifikatsiyasi.
/// path — project rootga nisbatan path.
/// template — {{variable}} placeholderli matn.
/// </summary>
[Serializable]
public class TemplateFileSpec
{
    public string path = "";
    public string template = "";
    public string description = "";
    public bool overwrite = true;
    public string mergeStrategy = "replace";

    public TemplateFileSpec() {}

    public TemplateFileSpec(string path, string template, string description = "", bool overwrite = true, string mergeStrategy = "replace")
    {
        this.path = path ?? "";
        this.template = template ?? "";
        this.description = description ?? "";
        this.overwrite = overwrite;
        this.mergeStrategy = string.IsNullOrEmpty(mergeStrategy) ? "replace" : mergeStrategy;
    }
}
