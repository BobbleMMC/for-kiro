using System;
using System.Text;
using System.Collections.Generic;

/// <summary>
/// Template render natijasi: yozilgan, o'tkazib yuborilgan fayllar va ogohlantirishlar.
/// </summary>
[Serializable]
public class TemplateRenderResult
{
    public List<string> writtenFiles = new List<string>();
    public List<string> skippedFiles = new List<string>();
    public List<string> warnings = new List<string>();

    public int WrittenCount { get { return writtenFiles != null ? writtenFiles.Count : 0; } }
    public int WarningCount { get { return warnings != null ? warnings.Count : 0; } }

    public void AddWritten(string path)
    {
        if (!string.IsNullOrEmpty(path)) writtenFiles.Add(path);
    }

    public void AddSkipped(string path)
    {
        if (!string.IsNullOrEmpty(path)) skippedFiles.Add(path);
    }

    public void AddWarning(string warning)
    {
        if (!string.IsNullOrEmpty(warning)) warnings.Add(warning);
    }

    public string Format()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"[TemplateEngine] {WrittenCount} ta fayl yozildi, {WarningCount} ta ogohlantirish.");
        foreach (var warning in warnings)
            sb.AppendLine("! " + warning);
        return sb.ToString();
    }
}
