using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

/// <summary>
/// ScaffoldTemplateEngine — 4-patch.
/// Loader/version/dependency ma'lumotlari endi bitta joyda — VersionResolver va
/// StudioDependencyResolver natijalari asosida scaffold fayllarga yoziladi.
/// </summary>
public static class ScaffoldTemplateEngine
{
    public static TemplateRenderResult GenerateScaffold(
        string projectPath,
        WorkspaceData workspace,
        ResolvedVersionSet resolved,
        DependencyResolutionResult dependencyResolution)
    {
        TemplateRenderResult finalResult = new TemplateRenderResult();

        if (workspace == null)
        {
            finalResult.AddWarning("Workspace bo'sh. Scaffold yaratilmadi.");
            return finalResult;
        }

        if (resolved == null) resolved = VersionResolver.Resolve(workspace);
        if (dependencyResolution == null) dependencyResolution = StudioDependencyResolver.ResolveForWorkspace(workspace, resolved);

        string modId = SafeId(workspace.modId, "mymod");
        string modName = string.IsNullOrEmpty(workspace.modName) ? "My Epic Mod" : workspace.modName.Trim();
        string loader = NormalizeLoader(resolved.loader);
        string mcVersion = string.IsNullOrEmpty(resolved.minecraftVersion) ? workspace.mcVersion : resolved.minecraftVersion;
        int javaVersion = resolved.javaVersion > 0 ? resolved.javaVersion : InferJavaVersion(mcVersion);

        // VersionResolver natijasi workspacega ham qaytariladi, keyingi generatorlar bitta truth source ko'rsin.
        workspace.modId = modId;
        workspace.modName = modName;
        workspace.modloader = loader;
        workspace.mcVersion = mcVersion;

        TemplateRenderContext ctx = BuildContext(projectPath, workspace, resolved, dependencyResolution, modId, modName, loader, mcVersion, javaVersion);
        List<TemplateFileSpec> files = BuildFiles(ctx, loader);

        TemplateRenderResult renderResult = StudioTemplateEngine.WriteFiles(projectPath, files, ctx);
        Merge(finalResult, renderResult);

        Directory.CreateDirectory(Path.Combine(projectPath, "gradle", "wrapper"));
        WriteWrapperFiles(projectPath, ctx, finalResult);
        WriteScaffoldPlan(projectPath, ctx, dependencyResolution, finalResult);

        if (resolved.warnings != null)
        {
            foreach (var warning in resolved.warnings)
                finalResult.AddWarning("VersionResolver: " + warning);
        }
        if (dependencyResolution.issues != null)
        {
            foreach (var issue in dependencyResolution.issues)
                if (issue != null) finalResult.AddWarning("DependencyResolver: " + issue.ToString());
        }

        return finalResult;
    }

    private static TemplateRenderContext BuildContext(
        string projectPath,
        WorkspaceData ws,
        ResolvedVersionSet resolved,
        DependencyResolutionResult deps,
        string modId,
        string modName,
        string loader,
        string mcVersion,
        int javaVersion)
    {
        TemplateRenderContext ctx = new TemplateRenderContext();
        string packageName = "net." + modId;
        string packagePath = packageName.Replace('.', '/');

        ctx.Set("projectPath", projectPath ?? "");
        ctx.Set("modId", modId);
        ctx.Set("modName", EscapeGradle(modName));
        ctx.Set("modDescription", "A Minecraft mod generated using Mod Studio Desktop.");
        ctx.Set("modGroup", packageName);
        ctx.Set("packageName", packageName);
        ctx.Set("packagePath", packagePath);
        ctx.Set("loader", loader);
        ctx.Set("minecraftVersion", mcVersion);
        ctx.Set("javaVersion", javaVersion.ToString());
        ctx.Set("mappingVersion", SafeVersion(resolved.mappingVersion));
        ctx.Set("loaderVersion", SafeVersion(resolved.loaderVersion));
        ctx.Set("apiVersion", SafeVersion(resolved.apiVersion));
        ctx.Set("gradlePluginId", ResolvePluginId(loader, resolved.gradlePlugin));
        ctx.Set("gradlePluginVersion", ResolvePluginVersion(loader, resolved.gradlePlugin));
        ctx.Set("packFormat", GetPackFormat(mcVersion).ToString());
        ctx.Set("gradleVersion", ResolveGradleVersion(mcVersion));
        ctx.Set("repositoriesBlock", BuildRepositoriesBlock(deps));
        ctx.Set("extraDependencyLines", BuildExtraDependencyLines(deps, loader));
        ctx.Set("minecraftVersionRange", BuildMinecraftVersionRange(mcVersion));
        ctx.Set("loaderVersionRange", BuildLoaderVersionRange(loader, resolved.loaderVersion));
        ctx.Set("generationTimeUtc", DateTime.UtcNow.ToString("o"));
        return ctx;
    }

    private static List<TemplateFileSpec> BuildFiles(TemplateRenderContext ctx, string loader)
    {
        List<TemplateFileSpec> files = new List<TemplateFileSpec>();
        files.Add(new TemplateFileSpec("settings.gradle", SettingsGradleTemplate(), "Gradle settings", true, "gradle-settings-merge"));
        files.Add(new TemplateFileSpec("gradle.properties", GradlePropertiesTemplate(loader), "Gradle properties", true, "properties-merge"));
        files.Add(new TemplateFileSpec(".gitignore", GitignoreTemplate(), "Git ignore", true, "append-if-missing"));
        files.Add(new TemplateFileSpec("src/main/resources/pack.mcmeta", PackMcmetaTemplate(), "Resource pack metadata", true, "json-merge"));

        if (loader == "NeoForge")
        {
            files.Add(new TemplateFileSpec("build.gradle", NeoForgeBuildGradleTemplate(), "NeoForge build.gradle", true, "gradle-merge"));
            files.Add(new TemplateFileSpec("src/main/resources/META-INF/mods.toml", NeoForgeModsTomlTemplate(), "NeoForge mods.toml", true, "toml-merge"));
            files.Add(new TemplateFileSpec("src/main/resources/{{modId}}.mixins.json", MixinsTemplate(), "Mixin config", true, "json-merge"));
        }
        else if (loader == "Quilt")
        {
            files.Add(new TemplateFileSpec("build.gradle", QuiltBuildGradleTemplate(), "Quilt build.gradle", true, "gradle-merge"));
            files.Add(new TemplateFileSpec("src/main/resources/quilt.mod.json", QuiltModJsonTemplate(), "Quilt metadata", true, "json-merge"));
            files.Add(new TemplateFileSpec("src/main/resources/{{modId}}.mixins.json", MixinsTemplate(), "Mixin config", true, "json-merge"));
        }
        else if (loader == "Forge")
        {
            files.Add(new TemplateFileSpec("build.gradle", ForgeBuildGradleTemplate(), "Forge build.gradle", true, "gradle-merge"));
            files.Add(new TemplateFileSpec("src/main/resources/META-INF/mods.toml", ForgeModsTomlTemplate(), "Forge mods.toml", true, "toml-merge"));
            files.Add(new TemplateFileSpec("src/main/resources/{{modId}}.mixins.json", MixinsTemplate(), "Mixin config", true, "json-merge"));
        }
        else
        {
            files.Add(new TemplateFileSpec("build.gradle", FabricBuildGradleTemplate(), "Fabric build.gradle", true, "gradle-merge"));
            files.Add(new TemplateFileSpec("src/main/resources/fabric.mod.json", FabricModJsonTemplate(), "Fabric metadata", true, "json-merge"));
            files.Add(new TemplateFileSpec("src/main/resources/{{modId}}.mixins.json", MixinsTemplate(), "Mixin config", true, "json-merge"));
        }

        return files;
    }

    private static void WriteWrapperFiles(string projectPath, TemplateRenderContext ctx, TemplateRenderResult result)
    {
        string gradleVersion = ctx.Get("gradleVersion", "8.8");
        string wrapperProps =
$@"distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-{gradleVersion}-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
";
        SafeWrite(Path.Combine(projectPath, "gradle", "wrapper", "gradle-wrapper.properties"), wrapperProps, result, "gradle/wrapper/gradle-wrapper.properties");

        StringBuilder gradlewBuilder = new StringBuilder();
        gradlewBuilder.AppendLine("#!/usr/bin/env sh");
        gradlewBuilder.AppendLine("set -e");
        gradlewBuilder.AppendLine("DIRNAME=\"$(dirname \"$0\")\"");
        gradlewBuilder.AppendLine("APP_HOME=\"$(cd \"$DIRNAME\" && pwd)\"");
        gradlewBuilder.AppendLine("JAR=\"$APP_HOME/gradle/wrapper/gradle-wrapper.jar\"");
        gradlewBuilder.AppendLine("if [ -f \"$JAR\" ]; then");
        gradlewBuilder.AppendLine("  exec java -classpath \"$JAR\" org.gradle.wrapper.GradleWrapperMain \"$@\"");
        gradlewBuilder.AppendLine("fi");
        gradlewBuilder.AppendLine("if command -v gradle >/dev/null 2>&1; then");
        gradlewBuilder.AppendLine("  exec gradle \"$@\"");
        gradlewBuilder.AppendLine("fi");
        gradlewBuilder.AppendLine("echo \"Gradle wrapper jar topilmadi va system gradle ham yo'q. Gradle o'rnating yoki 'gradle wrapper' ishga tushiring.\"");
        gradlewBuilder.AppendLine("exit 1");
        SafeWrite(Path.Combine(projectPath, "gradlew"), gradlewBuilder.ToString(), result, "gradlew");

        StringBuilder gradlewBatBuilder = new StringBuilder();
        gradlewBatBuilder.AppendLine("@echo off");
        gradlewBatBuilder.AppendLine("set DIRNAME=%~dp0");
        gradlewBatBuilder.AppendLine("set APP_HOME=%DIRNAME%");
        gradlewBatBuilder.AppendLine("set WRAPPER_JAR=%APP_HOME%gradle\\wrapper\\gradle-wrapper.jar");
        gradlewBatBuilder.AppendLine("");
        gradlewBatBuilder.AppendLine("if exist \"%WRAPPER_JAR%\" goto runWrapper");
        gradlewBatBuilder.AppendLine("where gradle >nul 2>nul");
        gradlewBatBuilder.AppendLine("if %ERRORLEVEL%==0 goto runSystemGradle");
        gradlewBatBuilder.AppendLine("");
        gradlewBatBuilder.AppendLine("echo Gradle wrapper jar topilmadi va system gradle ham yo'q. Gradle o'rnating yoki 'gradle wrapper' ishga tushiring.");
        gradlewBatBuilder.AppendLine("exit /b 1");
        gradlewBatBuilder.AppendLine("");
        gradlewBatBuilder.AppendLine(":runWrapper");
        gradlewBatBuilder.AppendLine("if defined JAVA_HOME (");
        gradlewBatBuilder.AppendLine("  set JAVA_EXE=%JAVA_HOME%\\bin\\java.exe");
        gradlewBatBuilder.AppendLine(") else (");
        gradlewBatBuilder.AppendLine("  set JAVA_EXE=java.exe");
        gradlewBatBuilder.AppendLine(")");
        gradlewBatBuilder.AppendLine("\"%JAVA_EXE%\" -classpath \"%WRAPPER_JAR%\" org.gradle.wrapper.GradleWrapperMain %*");
        gradlewBatBuilder.AppendLine("exit /b %ERRORLEVEL%");
        gradlewBatBuilder.AppendLine("");
        gradlewBatBuilder.AppendLine(":runSystemGradle");
        gradlewBatBuilder.AppendLine("gradle %*");
        gradlewBatBuilder.AppendLine("exit /b %ERRORLEVEL%");
        SafeWrite(Path.Combine(projectPath, "gradlew.bat"), gradlewBatBuilder.ToString(), result, "gradlew.bat");
    }

    private static void WriteScaffoldPlan(string projectPath, TemplateRenderContext ctx, DependencyResolutionResult deps, TemplateRenderResult result)
    {
        StringBuilder json = new StringBuilder();
        json.AppendLine("{");
        json.AppendLine($"  \"generatedAtUtc\": \"{ctx.Get("generationTimeUtc")}\",");
        json.AppendLine($"  \"modId\": \"{ctx.Get("modId")}\",");
        json.AppendLine($"  \"loader\": \"{ctx.Get("loader")}\",");
        json.AppendLine($"  \"minecraftVersion\": \"{ctx.Get("minecraftVersion")}\",");
        json.AppendLine($"  \"javaVersion\": {ctx.Get("javaVersion")},");
        json.AppendLine($"  \"mappingVersion\": \"{ctx.Get("mappingVersion")}\",");
        json.AppendLine($"  \"loaderVersion\": \"{ctx.Get("loaderVersion")}\",");
        json.AppendLine($"  \"apiVersion\": \"{ctx.Get("apiVersion")}\",");
        json.AppendLine("  \"dependencies\": [");
        if (deps != null && deps.dependencies != null)
        {
            for (int i = 0; i < deps.dependencies.Count; i++)
            {
                var d = deps.dependencies[i];
                string comma = i < deps.dependencies.Count - 1 ? "," : "";
                json.AppendLine($"    {{ \"id\": \"{EscapeJson(d.id)}\", \"version\": \"{EscapeJson(d.version)}\", \"required\": {(d.required ? "true" : "false")} }}{comma}");
            }
        }
        json.AppendLine("  ]");
        json.AppendLine("}");
        SafeWrite(Path.Combine(projectPath, ".modstudio", "scaffold-plan.json"), json.ToString(), result, ".modstudio/scaffold-plan.json");
    }

    private static string SettingsGradleTemplate()
    {
        return @"pluginManagement {
    repositories {
        maven { url = 'https://maven.fabricmc.net/' }
        maven { url = 'https://maven.quiltmc.org/repository/release/' }
        maven { url = 'https://maven.neoforged.net/releases' }
        maven { url = 'https://maven.minecraftforge.net/' }
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        mavenCentral()
        maven { url = 'https://maven.fabricmc.net/' }
        maven { url = 'https://maven.quiltmc.org/repository/release/' }
        maven { url = 'https://maven.neoforged.net/releases' }
        maven { url = 'https://maven.minecraftforge.net/' }
        {{repositoriesBlock}}
    }
}

rootProject.name = '{{modId}}'
";
    }

    private static string GradlePropertiesTemplate(string loader)
    {
        if (loader == "NeoForge")
        {
            return @"org.gradle.jvmargs=-Xmx3G
org.gradle.daemon=false

minecraft_version={{minecraftVersion}}
minecraft_version_range={{minecraftVersionRange}}
neoforge_version={{loaderVersion}}
neoforge_version_range={{loaderVersionRange}}
loader_version_range=[1,)

mod_id={{modId}}
mod_name={{modName}}
mod_license=MIT
mod_version=1.0.0
mod_group_id={{modGroup}}
mod_authors=ModStudio User
mod_description={{modDescription}}

maven_group={{modGroup}}
archives_base_name={{modId}}
java_version={{javaVersion}}
";
        }
        if (loader == "Forge")
        {
            return @"org.gradle.jvmargs=-Xmx3G
org.gradle.daemon=false

minecraft_version={{minecraftVersion}}
minecraft_version_range={{minecraftVersionRange}}
forge_version={{loaderVersion}}
loader_version_range=[1,)

mod_id={{modId}}
mod_name={{modName}}
mod_license=MIT
mod_version=1.0.0
mod_group_id={{modGroup}}
mod_authors=ModStudio User
mod_description={{modDescription}}

maven_group={{modGroup}}
archives_base_name={{modId}}
java_version={{javaVersion}}
";
        }
        if (loader == "Quilt")
        {
            return @"org.gradle.jvmargs=-Xmx2G -XX:MaxMetaspaceSize=512m

minecraft_version={{minecraftVersion}}
yarn_mappings={{mappingVersion}}
quilt_loader_version={{loaderVersion}}
qsl_version={{apiVersion}}

mod_version=1.0.0
maven_group={{modGroup}}
archives_base_name={{modId}}
java_version={{javaVersion}}
";
        }

        return @"org.gradle.jvmargs=-Xmx2G -XX:MaxMetaspaceSize=512m

minecraft_version={{minecraftVersion}}
yarn_mappings={{mappingVersion}}
loader_version={{loaderVersion}}
fabric_version={{apiVersion}}

mod_version=1.0.0
maven_group={{modGroup}}
archives_base_name={{modId}}
java_version={{javaVersion}}
";
    }

    private static string FabricBuildGradleTemplate()
    {
        return @"plugins {
    id 'fabric-loom' version '{{gradlePluginVersion}}'
    id 'maven-publish'
}

version = project.mod_version
group = project.maven_group

base { archivesName = project.archives_base_name }

repositories {
    mavenCentral()
    maven { url = 'https://maven.fabricmc.net/' }
    {{repositoriesBlock}}
}

loom {
    splitEnvironmentSourceSets()
    mods {
        '{{modId}}' { sourceSet sourceSets.main }
    }
    runs {
        datagen {
            inherit client
            name 'Data Generation'
            vmArg '-Dfabric-api.datagen'
            vmArg ""-Dfabric-api.datagen.output-dir=${file('src/main/generated')}""
            vmArg '-Dfabric-api.datagen.modid={{modId}}'
            runDir 'build/datagen'
        }
    }
}

sourceSets.main.resources.srcDirs += ['src/main/generated']

dependencies {
    minecraft ""com.mojang:minecraft:${project.minecraft_version}""
    mappings ""net.fabricmc:yarn:${project.yarn_mappings}:v2""
    modImplementation ""net.fabricmc:fabric-loader:${project.loader_version}""
    modImplementation ""net.fabricmc.fabric-api:fabric-api:${project.fabric_version}""
    {{extraDependencyLines}}
}

processResources {
    inputs.property 'version', project.version
    filesMatching('fabric.mod.json') { expand project.properties }
}

tasks.withType(JavaCompile).configureEach { it.options.release = project.java_version as int }

java {
    withSourcesJar()
    sourceCompatibility = JavaVersion.toVersion(project.java_version)
    targetCompatibility = JavaVersion.toVersion(project.java_version)
}
";
    }

    private static string QuiltBuildGradleTemplate()
    {
        return @"plugins {
    id 'org.quiltmc.loom' version '{{gradlePluginVersion}}'
    id 'maven-publish'
}

version = project.mod_version
group = project.maven_group
base { archivesName = project.archives_base_name }

repositories {
    mavenCentral()
    maven { url = 'https://maven.quiltmc.org/repository/release/' }
    maven { url = 'https://maven.fabricmc.net/' }
    {{repositoriesBlock}}
}

loom {
    mods { '{{modId}}' { sourceSet sourceSets.main } }
}

dependencies {
    minecraft ""com.mojang:minecraft:${project.minecraft_version}""
    mappings ""net.fabricmc:yarn:${project.yarn_mappings}:v2""
    modImplementation ""org.quiltmc:quilt-loader:${project.quilt_loader_version}""
    modImplementation ""org.quiltmc.quilted-fabric-api:quilted-fabric-api:${project.qsl_version}""
    {{extraDependencyLines}}
}

processResources {
    inputs.property 'version', project.version
    filesMatching('quilt.mod.json') { expand project.properties }
}

tasks.withType(JavaCompile).configureEach { it.options.release = project.java_version as int }
java { withSourcesJar() }
";
    }

    private static string NeoForgeBuildGradleTemplate()
    {
        return @"plugins {
    id 'net.neoforged.gradle.userdev' version '{{gradlePluginVersion}}'
    id 'maven-publish'
}

version = project.mod_version
group = project.maven_group
base { archivesName = project.archives_base_name }

java { toolchain.languageVersion = JavaLanguageVersion.of(project.java_version as int) }

runs {
    configureEach {
        systemProperty 'forge.logging.markers', 'REGISTRIES'
        systemProperty 'forge.logging.console.level', 'debug'
        modSource project.sourceSets.main
    }
    client { systemProperty 'forge.enabledGameTestNamespaces', project.mod_id }
    server {
        systemProperty 'forge.enabledGameTestNamespaces', project.mod_id
        programArgument '--nogui'
    }
    data {
        programArguments.addAll '--mod', project.mod_id, '--all', '--output', file('src/generated/resources/').absolutePath, '--existing', file('src/main/resources/').absolutePath
    }
}

sourceSets.main.resources { srcDir 'src/generated/resources' }

dependencies {
    implementation ""net.neoforged:neoforge:${project.neoforge_version}""
    {{extraDependencyLines}}
}

processResources {
    var replaceProperties = [
        minecraft_version: minecraft_version,
        minecraft_version_range: minecraft_version_range,
        neoforge_version: neoforge_version,
        neoforge_version_range: neoforge_version_range,
        loader_version_range: loader_version_range,
        mod_id: mod_id,
        mod_name: mod_name,
        mod_license: mod_license,
        mod_version: mod_version,
        mod_authors: mod_authors,
        mod_description: mod_description
    ]
    inputs.properties replaceProperties
    filesMatching(['META-INF/mods.toml']) { expand replaceProperties }
}
";
    }

    private static string ForgeBuildGradleTemplate()
    {
        return @"plugins {
    id 'net.minecraftforge.gradle' version '{{gradlePluginVersion}}'
    id 'maven-publish'
}

version = project.mod_version
group = project.maven_group
base { archivesName = project.archives_base_name }

java { toolchain.languageVersion = JavaLanguageVersion.of(project.java_version as int) }

minecraft {
    mappings channel: 'official', version: project.minecraft_version
    runs {
        client { workingDirectory project.file('run') }
        server { workingDirectory project.file('run'); args '--nogui' }
        data { workingDirectory project.file('run'); args '--mod', project.mod_id, '--all', '--output', file('src/generated/resources/'), '--existing', file('src/main/resources/') }
    }
}

sourceSets.main.resources { srcDir 'src/generated/resources' }

dependencies {
    minecraft ""net.minecraftforge:forge:${project.minecraft_version}-${project.forge_version}""
    {{extraDependencyLines}}
}

processResources {
    filesMatching(['META-INF/mods.toml']) { expand project.properties }
}
";
    }

    private static string FabricModJsonTemplate()
    {
        return @"{
  ""schemaVersion"": 1,
  ""id"": ""{{modId}}"",
  ""version"": ""${version}"",
  ""name"": ""{{modName}}"",
  ""description"": ""{{modDescription}}"",
  ""authors"": [""ModStudio User""],
  ""license"": ""MIT"",
  ""icon"": ""assets/{{modId}}/icon.png"",
  ""environment"": ""*"",
  ""entrypoints"": {
    ""main"": [""{{packageName}}.MyMod""],
    ""fabric-datagen"": [""{{packageName}}.datagen.ModDataGenerators""]
  },
  ""mixins"": [""{{modId}}.mixins.json""],
  ""depends"": {
    ""fabricloader"": "">={{loaderVersion}}"",
    ""fabric-api"": ""*"",
    ""minecraft"": ""~{{minecraftVersion}}"",
    ""java"": "">={{javaVersion}}""
  }
}
";
    }

    private static string QuiltModJsonTemplate()
    {
        return @"{
  ""schema_version"": 1,
  ""quilt_loader"": {
    ""group"": ""{{modGroup}}"",
    ""id"": ""{{modId}}"",
    ""version"": ""${version}"",
    ""metadata"": {
      ""name"": ""{{modName}}"",
      ""description"": ""{{modDescription}}"",
      ""contributors"": { ""ModStudio User"": ""Owner"" },
      ""icon"": ""assets/{{modId}}/icon.png""
    },
    ""intermediate_mappings"": ""net.fabricmc:intermediary"",
    ""entrypoints"": { ""init"": ""{{packageName}}.MyMod"" },
    ""depends"": [
      { ""id"": ""quilt_loader"", ""versions"": "">={{loaderVersion}}"" },
      { ""id"": ""quilted_fabric_api"", ""versions"": ""*"" },
      { ""id"": ""minecraft"", ""versions"": ""~{{minecraftVersion}}"" },
      { ""id"": ""java"", ""versions"": "">={{javaVersion}}"" }
    ]
  },
  ""mixin"": ""{{modId}}.mixins.json""
}
";
    }

    private static string NeoForgeModsTomlTemplate()
    {
        return @"modLoader=""javafml""
loaderVersion=""${loader_version_range}""
license=""${mod_license}""

[[mods]]
modId=""${mod_id}""
version=""${mod_version}""
displayName=""${mod_name}""
description='''${mod_description}'''

[[dependencies.${mod_id}]]
modId=""neoforge""
type=""required""
versionRange=""${neoforge_version_range}""
ordering=""NONE""
side=""BOTH""

[[dependencies.${mod_id}]]
modId=""minecraft""
type=""required""
versionRange=""${minecraft_version_range}""
ordering=""NONE""
side=""BOTH""
";
    }

    private static string ForgeModsTomlTemplate()
    {
        return @"modLoader=""javafml""
loaderVersion=""${loader_version_range}""
license=""${mod_license}""

[[mods]]
modId=""${mod_id}""
version=""${mod_version}""
displayName=""${mod_name}""
description='''${mod_description}'''

[[dependencies.${mod_id}]]
modId=""forge""
type=""required""
versionRange=""${loader_version_range}""
ordering=""NONE""
side=""BOTH""

[[dependencies.${mod_id}]]
modId=""minecraft""
type=""required""
versionRange=""${minecraft_version_range}""
ordering=""NONE""
side=""BOTH""
";
    }

    private static string MixinsTemplate()
    {
        return @"{
  ""required"": true,
  ""minVersion"": ""0.8"",
  ""package"": ""{{packageName}}.mixin"",
  ""compatibilityLevel"": ""JAVA_{{javaVersion}}"",
  ""mixins"": [],
  ""client"": [],
  ""injectors"": { ""defaultRequire"": 1 }
}
";
    }

    private static string PackMcmetaTemplate()
    {
        return @"{
  ""pack"": {
    ""pack_format"": {{packFormat}},
    ""description"": ""{{modName}} Resources""
  }
}
";
    }

    private static string GitignoreTemplate()
    {
        return @".gradle/
build/
run/
out/
*.class
*.log
.idea/
*.iml
.vscode/
.DS_Store
Thumbs.db
*.mstudio.bak
.modstudio/cache/
";
    }

    private static string BuildRepositoriesBlock(DependencyResolutionResult deps)
    {
        if (deps == null || deps.repositories == null || deps.repositories.Count == 0) return "";
        StringBuilder sb = new StringBuilder();
        foreach (var repo in deps.repositories)
        {
            if (string.IsNullOrEmpty(repo)) continue;
            sb.AppendLine("        maven { url = '" + repo.Replace("'", "") + "' }");
        }
        return sb.ToString().TrimEnd();
    }

    private static string BuildExtraDependencyLines(DependencyResolutionResult deps, string loader)
    {
        if (deps == null || deps.dependencies == null) return "";
        StringBuilder sb = new StringBuilder();
        foreach (var dep in deps.dependencies)
        {
            if (dep == null || string.IsNullOrEmpty(dep.id)) continue;
            if (dep.id == "fabric-api" || dep.id == "neoforge" || dep.id == "quilt-standard-libraries") continue;
            string notation = StudioDependencyResolver.GetGradleNotation(dep, loader);
            if (string.IsNullOrEmpty(notation)) notation = dep.gradleNotation;
            if (string.IsNullOrEmpty(notation)) continue;

            if (loader == "NeoForge" || loader == "Forge") sb.AppendLine("    implementation \"" + notation + "\"");
            else sb.AppendLine("    modImplementation \"" + notation + "\"");
        }
        return sb.ToString().TrimEnd();
    }

    private static void SafeWrite(string path, string content, TemplateRenderResult result, string logicalPath)
    {
        string projectRoot = path;
        string relativePath = logicalPath ?? Path.GetFileName(path);

        if (!string.IsNullOrEmpty(logicalPath) && path.EndsWith(logicalPath.Replace('/', Path.DirectorySeparatorChar)))
        {
            projectRoot = path.Substring(0, path.Length - logicalPath.Replace('/', Path.DirectorySeparatorChar).Length).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        }
        else
        {
            projectRoot = Path.GetDirectoryName(path);
        }

        string strategy = "replace";
        if (!string.IsNullOrEmpty(logicalPath))
        {
            string lower = logicalPath.ToLowerInvariant();
            if (lower.EndsWith(".json")) strategy = "json-merge";
            else if (lower.EndsWith(".toml")) strategy = "toml-merge";
            else if (lower.EndsWith(".properties")) strategy = "properties-merge";
            else if (lower.EndsWith(".gitignore")) strategy = "append-if-missing";
        }

        PatchOperation operation = new PatchOperation(relativePath, content ?? "", strategy, "Scaffold safe write", true);
        StudioPatchResult patchResult = StudioPatchEngine.ApplyOne(projectRoot, operation);
        if (result != null)
        {
            foreach (var f in patchResult.writtenFiles) result.AddWritten(f);
            foreach (var f in patchResult.mergedFiles) result.AddWritten(f);
            foreach (var f in patchResult.skippedFiles) result.AddSkipped(f);
            foreach (var w in patchResult.warnings) result.AddWarning(w);
            foreach (var e in patchResult.errors) result.AddWarning("PatchEngine error: " + e);
        }
    }

    private static void Merge(TemplateRenderResult target, TemplateRenderResult source)
    {
        if (target == null || source == null) return;
        foreach (var f in source.writtenFiles) target.AddWritten(f);
        foreach (var f in source.skippedFiles) target.AddSkipped(f);
        foreach (var w in source.warnings) target.AddWarning(w);
    }

    private static string SafeId(string value, string fallback)
    {
        if (string.IsNullOrEmpty(value)) return fallback;
        string v = value.Trim().ToLowerInvariant();
        StringBuilder sb = new StringBuilder();
        foreach (char c in v)
        {
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_') sb.Append(c);
        }
        if (sb.Length == 0) return fallback;
        if (sb[0] >= '0' && sb[0] <= '9') sb.Insert(0, 'm');
        return sb.ToString();
    }

    private static string NormalizeLoader(string loader)
    {
        if (string.IsNullOrEmpty(loader)) return "Fabric";
        string l = loader.Trim().ToLowerInvariant();
        if (l == "fabric") return "Fabric";
        if (l == "forge") return "Forge";
        if (l == "neoforge" || l == "neo forge") return "NeoForge";
        if (l == "quilt") return "Quilt";
        return "Fabric";
    }

    private static string SafeVersion(string value)
    {
        if (string.IsNullOrEmpty(value) || value == "recommended") return "recommended";
        return value.Trim();
    }

    private static string ResolvePluginId(string loader, string plugin)
    {
        if (!string.IsNullOrEmpty(plugin))
        {
            string[] parts = plugin.Split(' ');
            if (parts.Length > 0 && parts[0].Contains(".")) return parts[0];
            if (parts.Length > 0 && parts[0] == "fabric-loom") return "fabric-loom";
        }
        if (loader == "NeoForge") return "net.neoforged.gradle.userdev";
        if (loader == "Forge") return "net.minecraftforge.gradle";
        if (loader == "Quilt") return "org.quiltmc.loom";
        return "fabric-loom";
    }

    private static string ResolvePluginVersion(string loader, string plugin)
    {
        if (!string.IsNullOrEmpty(plugin))
        {
            string[] parts = plugin.Split(' ');
            if (parts.Length >= 2) return parts[1];
        }
        if (loader == "NeoForge") return "7.0.120";
        if (loader == "Forge") return "6.0.26";
        if (loader == "Quilt") return "1.7-SNAPSHOT";
        return "1.7-SNAPSHOT";
    }

    private static int InferJavaVersion(string mcVersion)
    {
        if (string.IsNullOrEmpty(mcVersion)) return 17;
        if (mcVersion.StartsWith("1.20.6") || mcVersion.StartsWith("1.21") || mcVersion.StartsWith("1.22")) return 21;
        return 17;
    }

    private static int GetPackFormat(string mcVersion)
    {
        switch (mcVersion)
        {
            case "1.20.1": return 15;
            case "1.20.4": return 22;
            case "1.20.6": return 32;
            case "1.21": return 34;
            case "1.21.1": return 34;
            case "1.21.3": return 35;
            case "1.21.4": return 46;
            case "1.22": return 48;
            default: return mcVersion != null && mcVersion.StartsWith("1.21") ? 34 : 15;
        }
    }

    private static string ResolveGradleVersion(string mcVersion)
    {
        if (string.IsNullOrEmpty(mcVersion)) return "8.8";
        if (mcVersion.StartsWith("1.22")) return "8.12";
        if (mcVersion == "1.21.3" || mcVersion == "1.21.4") return "8.10";
        if (mcVersion.StartsWith("1.21") || mcVersion == "1.20.6") return "8.8";
        return "8.6";
    }

    private static string BuildMinecraftVersionRange(string mcVersion)
    {
        if (string.IsNullOrEmpty(mcVersion)) return "[1.20.1,)";
        string[] parts = mcVersion.Split('.');
        if (parts.Length >= 2) return "[" + parts[0] + "." + parts[1] + ",)";
        return "[" + mcVersion + ",)";
    }

    private static string BuildLoaderVersionRange(string loader, string loaderVersion)
    {
        if (loader == "NeoForge") return "[" + SafeVersion(loaderVersion) + ",)";
        if (loader == "Forge") return "[" + SafeVersion(loaderVersion) + ",)";
        return ">=" + SafeVersion(loaderVersion);
    }

    private static string EscapeGradle(string value)
    {
        return (value ?? "").Replace("\\", "\\\\").Replace("'", "").Replace("\"", "\\\"");
    }

    private static string EscapeJson(string value)
    {
        return (value ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"");
    }
}
