using System;
using System.Collections.Generic;

/// <summary>
/// Version Resolver chiqargan yakuniy versiya to'plami.
/// Bu model build.gradle, gradle.properties, dependency resolver va validator uchun bitta truth source bo'ladi.
/// </summary>
[Serializable]
public class ResolvedVersionSet
{
    public string minecraftVersion = "1.20.1";
    public string loader = "Fabric";
    public int javaVersion = 17;
    public string mappings = "yarn";

    public string loaderVersion = "recommended";
    public string apiVersion = "recommended";
    public string gradlePlugin = "recommended";
    public string mappingVersion = "recommended";

    public bool exactMatch = true;
    public string source = "internal";
    public List<string> warnings = new List<string>();
    public List<string> notes = new List<string>();

    public string GetSummary()
    {
        return $"{loader} {minecraftVersion} | Java {javaVersion} | mappings: {mappings} | loader: {loaderVersion} | api: {apiVersion}";
    }
}
