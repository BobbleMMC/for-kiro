using System;
using System.Collections.Generic;

/// <summary>
/// Version Resolver — Minecraft version + loader asosida Java, mappings,
/// loader API va Gradle plugin versiyalarini tanlaydi.
/// Hozircha offline katalog asosida ishlaydi; keyingi patchlarda online catalog/cache qo'shiladi.
/// </summary>
public static class VersionResolver
{
    private class VersionPreset
    {
        public string minecraftVersion;
        public string loader;
        public int javaVersion;
        public string mappings;
        public string loaderVersion;
        public string apiVersion;
        public string gradlePlugin;
        public string mappingVersion;
        public string note;
    }

    private static readonly List<VersionPreset> _presets = new List<VersionPreset>
    {
        new VersionPreset { minecraftVersion = "1.20.1", loader = "Fabric", javaVersion = 17, mappings = "yarn", loaderVersion = "0.15.11", apiVersion = "0.91.0+1.20.1", gradlePlugin = "fabric-loom 1.6-SNAPSHOT", mappingVersion = "1.20.1+build.10", note = "Fabric 1.20.1 barqaror bazasi." },
        new VersionPreset { minecraftVersion = "1.20.4", loader = "Fabric", javaVersion = 17, mappings = "yarn", loaderVersion = "0.15.11", apiVersion = "0.95.7+1.20.4", gradlePlugin = "fabric-loom 1.6-SNAPSHOT", mappingVersion = "1.20.4+build.3", note = "Fabric 1.20.4 uchun asosiy preset." },
        new VersionPreset { minecraftVersion = "1.20.6", loader = "Fabric", javaVersion = 21, mappings = "yarn", loaderVersion = "0.15.11", apiVersion = "0.97.8+1.20.6", gradlePlugin = "fabric-loom 1.6-SNAPSHOT", mappingVersion = "1.20.6+build.1", note = "1.20.6 Java 21 talab qiladi." },
        new VersionPreset { minecraftVersion = "1.21", loader = "Fabric", javaVersion = 21, mappings = "yarn", loaderVersion = "0.16.9", apiVersion = "0.100.4+1.21", gradlePlugin = "fabric-loom 1.7-SNAPSHOT", mappingVersion = "1.21+build.9", note = "Fabric 1.21 MVP target." },
        new VersionPreset { minecraftVersion = "1.21.1", loader = "Fabric", javaVersion = 21, mappings = "yarn", loaderVersion = "0.16.9", apiVersion = "0.105.0+1.21.1", gradlePlugin = "fabric-loom 1.7-SNAPSHOT", mappingVersion = "1.21.1+build.3", note = "Fabric 1.21.1 barqaror preset." },
        new VersionPreset { minecraftVersion = "1.21.3", loader = "Fabric", javaVersion = 21, mappings = "yarn", loaderVersion = "0.16.9", apiVersion = "0.108.0+1.21.3", gradlePlugin = "fabric-loom 1.8-SNAPSHOT", mappingVersion = "1.21.3+build.2", note = "Fabric 1.21.3 preset." },
        new VersionPreset { minecraftVersion = "1.21.4", loader = "Fabric", javaVersion = 21, mappings = "yarn", loaderVersion = "0.16.10", apiVersion = "0.110.5+1.21.4", gradlePlugin = "fabric-loom 1.8-SNAPSHOT", mappingVersion = "1.21.4+build.1", note = "Fabric 1.21.4 preset." },

        new VersionPreset { minecraftVersion = "1.20.4", loader = "NeoForge", javaVersion = 17, mappings = "mojmap", loaderVersion = "20.4.237", apiVersion = "20.4.237", gradlePlugin = "net.neoforged.gradle.userdev 7.0.120", mappingVersion = "official", note = "NeoForge 1.20.4 preset." },
        new VersionPreset { minecraftVersion = "1.21", loader = "NeoForge", javaVersion = 21, mappings = "mojmap", loaderVersion = "21.1.77", apiVersion = "21.1.77", gradlePlugin = "net.neoforged.gradle.userdev 7.0.120", mappingVersion = "official", note = "NeoForge 1.21 preset." },
        new VersionPreset { minecraftVersion = "1.21.1", loader = "NeoForge", javaVersion = 21, mappings = "mojmap", loaderVersion = "21.1.172", apiVersion = "21.1.172", gradlePlugin = "net.neoforged.gradle.userdev 7.0.120", mappingVersion = "official", note = "NeoForge 1.21.1 preset." },
        new VersionPreset { minecraftVersion = "1.21.3", loader = "NeoForge", javaVersion = 21, mappings = "mojmap", loaderVersion = "21.3.58", apiVersion = "21.3.58", gradlePlugin = "net.neoforged.gradle.userdev 7.0.120", mappingVersion = "official", note = "NeoForge 1.21.3 preset." },
        new VersionPreset { minecraftVersion = "1.21.4", loader = "NeoForge", javaVersion = 21, mappings = "mojmap", loaderVersion = "21.4.108", apiVersion = "21.4.108", gradlePlugin = "net.neoforged.gradle.userdev 7.0.120", mappingVersion = "official", note = "NeoForge 1.21.4 preset." },

        new VersionPreset { minecraftVersion = "1.20.1", loader = "Quilt", javaVersion = 17, mappings = "yarn", loaderVersion = "0.26.4", apiVersion = "7.1.2+1.20.1", gradlePlugin = "org.quiltmc.loom 1.6-SNAPSHOT", mappingVersion = "1.20.1+build.10", note = "Quilt 1.20.1 preset." },
        new VersionPreset { minecraftVersion = "1.21", loader = "Quilt", javaVersion = 21, mappings = "yarn", loaderVersion = "0.26.4", apiVersion = "10.0.0+1.21", gradlePlugin = "org.quiltmc.loom 1.7-SNAPSHOT", mappingVersion = "1.21+build.9", note = "Quilt 1.21 preset." },
        new VersionPreset { minecraftVersion = "1.21.4", loader = "Quilt", javaVersion = 21, mappings = "yarn", loaderVersion = "0.26.4", apiVersion = "10.2.0+1.21.4", gradlePlugin = "org.quiltmc.loom 1.8-SNAPSHOT", mappingVersion = "1.21.4+build.1", note = "Quilt 1.21.4 preset." }
    };

    public static ResolvedVersionSet Resolve(WorkspaceData workspace)
    {
        string version = workspace != null && !string.IsNullOrEmpty(workspace.mcVersion) ? workspace.mcVersion : "1.20.1";
        string loader = workspace != null && !string.IsNullOrEmpty(workspace.modloader) ? workspace.modloader : "Fabric";
        return Resolve(version, loader);
    }

    public static ResolvedVersionSet Resolve(StudioProject project)
    {
        if (project != null && project.project != null)
            return Resolve(project.project.minecraftVersion, project.project.loader);
        return Resolve("1.20.1", "Fabric");
    }

    public static ResolvedVersionSet Resolve(string minecraftVersion, string loader)
    {
        string normalizedLoader = NormalizeLoader(loader);
        string normalizedVersion = string.IsNullOrEmpty(minecraftVersion) ? "1.20.1" : minecraftVersion.Trim();

        VersionPreset preset = _presets.Find(p => p.minecraftVersion == normalizedVersion && p.loader == normalizedLoader);
        if (preset != null)
            return FromPreset(preset, true);

        // Agar aniq preset yo'q bo'lsa, StudioDatabase orqali minimum xavfsiz fallback.
        MinecraftVersionData vData = StudioDatabase.GetVersionData(normalizedVersion);
        var result = new ResolvedVersionSet
        {
            minecraftVersion = normalizedVersion,
            loader = normalizedLoader,
            javaVersion = vData != null ? vData.requiredJavaVersion : InferJavaVersion(normalizedVersion),
            mappings = (normalizedLoader == "NeoForge" || normalizedLoader == "Forge") ? "mojmap" : "yarn",
            loaderVersion = "recommended",
            apiVersion = "recommended",
            gradlePlugin = ResolveDefaultGradlePlugin(normalizedLoader),
            mappingVersion = "recommended",
            exactMatch = false,
            source = "fallback"
        };

        result.warnings.Add($"{normalizedLoader} {normalizedVersion} uchun aniq preset topilmadi. 'recommended' fallback ishlatiladi.");
        if (vData == null)
            result.warnings.Add($"Minecraft {normalizedVersion} version database ichida topilmadi.");

        return result;
    }

    public static void ApplyToProject(StudioProject project, ResolvedVersionSet resolved)
    {
        if (project == null || project.project == null || resolved == null) return;

        project.project.minecraftVersion = resolved.minecraftVersion;
        project.project.loader = resolved.loader;
        project.project.javaVersion = resolved.javaVersion;
        project.project.mappings = resolved.mappings;
        project.resolvedVersions = resolved;
    }

    public static string GetSummary(ResolvedVersionSet resolved)
    {
        if (resolved == null) return "VersionResolver: natija yo'q.";
        string suffix = resolved.exactMatch ? "exact" : "fallback";
        return $"[VersionResolver] {resolved.GetSummary()} ({suffix})";
    }

    private static ResolvedVersionSet FromPreset(VersionPreset p, bool exact)
    {
        var result = new ResolvedVersionSet
        {
            minecraftVersion = p.minecraftVersion,
            loader = p.loader,
            javaVersion = p.javaVersion,
            mappings = p.mappings,
            loaderVersion = p.loaderVersion,
            apiVersion = p.apiVersion,
            gradlePlugin = p.gradlePlugin,
            mappingVersion = p.mappingVersion,
            exactMatch = exact,
            source = "preset"
        };
        if (!string.IsNullOrEmpty(p.note)) result.notes.Add(p.note);
        return result;
    }

    private static string NormalizeLoader(string loader)
    {
        if (string.IsNullOrEmpty(loader)) return "Fabric";
        string l = loader.Trim().ToLowerInvariant();
        if (l == "fabric") return "Fabric";
        if (l == "forge") return "Forge";
        if (l == "neoforge" || l == "neo forge") return "NeoForge";
        if (l == "quilt") return "Quilt";
        return loader.Trim();
    }

    private static int InferJavaVersion(string minecraftVersion)
    {
        if (string.IsNullOrEmpty(minecraftVersion)) return 17;
        if (minecraftVersion.StartsWith("1.20.6") || minecraftVersion.StartsWith("1.21") || minecraftVersion.StartsWith("1.22")) return 21;
        return 17;
    }

    private static string ResolveDefaultGradlePlugin(string loader)
    {
        if (loader == "NeoForge") return "net.neoforged.gradle.userdev";
        if (loader == "Quilt") return "org.quiltmc.loom";
        if (loader == "Forge") return "net.minecraftforge.gradle";
        return "fabric-loom";
    }
}
