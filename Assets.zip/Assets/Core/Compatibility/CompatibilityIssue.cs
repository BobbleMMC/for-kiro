using System;

public enum CompatibilitySeverity
{
    Info,
    Warning,
    Error
}

[Serializable]
public class CompatibilityIssue
{
    public CompatibilitySeverity severity = CompatibilitySeverity.Info;
    public string ruleId = "";
    public string category = "Compatibility";
    public string message = "";
    public string suggestedFix = "";
    public bool autoFixable = false;

    public CompatibilityIssue() { }

    public CompatibilityIssue(CompatibilitySeverity severity, string ruleId, string category, string message, string suggestedFix = "", bool autoFixable = false)
    {
        this.severity = severity;
        this.ruleId = ruleId;
        this.category = category;
        this.message = message;
        this.suggestedFix = suggestedFix;
        this.autoFixable = autoFixable;
    }

    public override string ToString()
    {
        string icon = severity == CompatibilitySeverity.Error ? "❌" : severity == CompatibilitySeverity.Warning ? "⚠️" : "ℹ️";
        string fix = string.IsNullOrEmpty(suggestedFix) ? "" : $" Tavsiya: {suggestedFix}";
        return $"{icon} [{category}:{ruleId}] {message}{fix}";
    }
}
