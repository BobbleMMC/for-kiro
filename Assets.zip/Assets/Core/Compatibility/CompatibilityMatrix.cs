using System;

/// <summary>
/// Compatibility Matrix — loader, Minecraft version, Java, mappings va feature talablarini tekshiradi.
/// Bu qatlam build qilishdan oldin noto'g'ri kombinatsiyalarni ushlash uchun ishlatiladi.
/// </summary>
public static class CompatibilityMatrix
{
    public static CompatibilityReport Check(WorkspaceData workspace, ResolvedVersionSet resolved)
    {
        var report = new CompatibilityReport();
        if (workspace == null)
        {
            report.Add(new CompatibilityIssue(CompatibilitySeverity.Error, "workspace-null", "System", "Workspace bo'sh."));
            return report;
        }

        if (resolved == null)
            resolved = VersionResolver.Resolve(workspace);

        string version = string.IsNullOrEmpty(workspace.mcVersion) ? resolved.minecraftVersion : workspace.mcVersion;
        string loader = string.IsNullOrEmpty(workspace.modloader) ? resolved.loader : workspace.modloader;

        MinecraftVersionData versionData = StudioDatabase.GetVersionData(version);
        if (versionData == null)
        {
            report.Add(new CompatibilityIssue(
                CompatibilitySeverity.Warning,
                "version-not-in-database",
                "Version",
                $"Minecraft {version} ichki version database ichida topilmadi.",
                "Yaqin barqaror versiyani tanlang yoki version database yangilang."));
        }
        else if (versionData.supportedModloaders != null && !versionData.supportedModloaders.Contains(loader))
        {
            report.Add(new CompatibilityIssue(
                CompatibilitySeverity.Error,
                "loader-not-supported",
                "Loader",
                $"{loader} loader Minecraft {version} uchun qo'llab-quvvatlanmaydi.",
                $"Mavjud loaderlar: {string.Join(", ", versionData.supportedModloaders)}"));
        }

        if (loader == "Forge")
        {
            report.Add(new CompatibilityIssue(
                CompatibilitySeverity.Error,
                "forge-scaffold-missing",
                "Scaffold",
                "Hozirgi scaffold generator Forge uchun to'liq buildable loyiha yozmaydi.",
                "NeoForge yoki Fabric tanlang, yoki Forge scaffold generator qo'shing."));
        }

        if ((version.StartsWith("1.20.6") || version.StartsWith("1.21") || version.StartsWith("1.22")) && resolved.javaVersion < 21)
        {
            report.Add(new CompatibilityIssue(
                CompatibilitySeverity.Error,
                "java-21-required",
                "Java",
                $"Minecraft {version} uchun Java 21 talab qilinadi, lekin resolver Java {resolved.javaVersion} qaytardi.",
                "VersionResolver presetini yoki Java sozlamasini tuzating."));
        }

        if ((loader == "Fabric" || loader == "Quilt") && resolved.mappings != "yarn")
        {
            report.Add(new CompatibilityIssue(
                CompatibilitySeverity.Warning,
                "fabric-yarn-expected",
                "Mappings",
                $"{loader} uchun odatda Yarn mappings ishlatiladi, hozir: {resolved.mappings}.",
                "Mappings qiymatini yarn qiling."));
        }

        if ((loader == "NeoForge" || loader == "Forge") && resolved.mappings != "mojmap")
        {
            report.Add(new CompatibilityIssue(
                CompatibilitySeverity.Warning,
                "mojmap-expected",
                "Mappings",
                $"{loader} uchun odatda Mojang mappings ishlatiladi, hozir: {resolved.mappings}.",
                "Mappings qiymatini mojmap qiling."));
        }

        if (!resolved.exactMatch)
        {
            report.Add(new CompatibilityIssue(
                CompatibilitySeverity.Warning,
                "resolver-fallback",
                "VersionResolver",
                $"{loader} {version} uchun aniq preset yo'q, fallback ishlatilyapti.",
                "Version catalog ichiga aniq preset qo'shing."));
        }

        CheckFeatureCompatibility(workspace, loader, version, report);
        return report;
    }

    private static void CheckFeatureCompatibility(WorkspaceData workspace, string loader, string version, CompatibilityReport report)
    {
        int entityCount = workspace.entities != null ? workspace.entities.Count : 0;
        int biomeCount = workspace.biomes != null ? workspace.biomes.Count : 0;
        int armorCount = workspace.armors != null ? workspace.armors.Count : 0;

        if (entityCount > 0 && (loader == "NeoForge" || loader == "Forge"))
        {
            report.Add(new CompatibilityIssue(
                CompatibilitySeverity.Warning,
                "entity-generator-loader-gap",
                "Feature",
                "Entity generator hozir asosan Fabric kod patternlariga yaqin. NeoForge/Forge uchun qo'shimcha template kerak bo'lishi mumkin.",
                "Entity template engine'ni loader bo'yicha ajrating."));
        }

        if (biomeCount > 0 && version.StartsWith("1.21"))
        {
            report.Add(new CompatibilityIssue(
                CompatibilitySeverity.Info,
                "biome-121-datagen-recommended",
                "WorldGen",
                "1.21+ biome/worldgen uchun qo'lda JSONdan ko'ra DataGen provider ishlatish xavfsizroq.",
                "DataGen Layer'ni yoqing."));
        }

        if (armorCount > 0 && (version.StartsWith("1.20.6") || version.StartsWith("1.21")))
        {
            report.Add(new CompatibilityIssue(
                CompatibilitySeverity.Info,
                "armor-components-note",
                "Items",
                "1.20.6+ item/armor APIlarida data component yondashuvi muhim bo'lishi mumkin.",
                "Armor generatorni version-specific template bilan tekshiring."));
        }
    }
}
