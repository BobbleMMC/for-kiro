using System;
using System.Text;
using System.Collections.Generic;

[Serializable]
public class CompatibilityReport
{
    public bool isCompatible = true;
    public int errorCount = 0;
    public int warningCount = 0;
    public List<CompatibilityIssue> issues = new List<CompatibilityIssue>();

    public void Add(CompatibilityIssue issue)
    {
        if (issue == null) return;
        issues.Add(issue);
        if (issue.severity == CompatibilitySeverity.Error)
        {
            errorCount++;
            isCompatible = false;
        }
        else if (issue.severity == CompatibilitySeverity.Warning)
        {
            warningCount++;
        }
    }

    public string Format()
    {
        if (issues == null || issues.Count == 0) return "✅ Compatibility: moslik muammosi topilmadi.";

        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"─── Compatibility Matrix: {errorCount} xato, {warningCount} ogohlantirish ───");
        foreach (var issue in issues)
            sb.AppendLine(issue.ToString());
        return sb.ToString();
    }
}
