using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public static class RecipeLootTagBindingValidator
{
    public static List<string> Validate(object workspace)
    {
        var issues = new List<string>();
        ValidateRecipes(workspace, issues);
        ValidateLootTables(workspace, issues);
        ValidateTags(workspace, issues);
        return issues;
    }

    private static void ValidateRecipes(object workspace, List<string> issues)
    {
        object listObj = RecipeLootTagBindingUtility.GetMemberValue(workspace, "recipes");
        int count = 0;
        foreach (object recipe in RecipeLootTagBindingUtility.AsEnumerable(listObj))
        {
            count++;
            string id = FirstString(recipe, new string[] { "recipeId", "id", "name" }, "");
            if (!IsValidId(id)) issues.Add("Recipe #" + count + " has invalid id: " + id);

            string result = FirstString(recipe, new string[] { "resultItem", "outputItem", "result", "output" }, "");
            if (string.IsNullOrEmpty(result)) issues.Add("Recipe " + id + " has no result item.");
        }
    }

    private static void ValidateLootTables(object workspace, List<string> issues)
    {
        object listObj = RecipeLootTagBindingUtility.GetMemberValue(workspace, "lootTables");
        int count = 0;
        foreach (object loot in RecipeLootTagBindingUtility.AsEnumerable(listObj))
        {
            count++;
            string id = FirstString(loot, new string[] { "lootId", "id", "name" }, "");
            if (!IsValidId(id)) issues.Add("Loot table #" + count + " has invalid id: " + id);
        }
    }

    private static void ValidateTags(object workspace, List<string> issues)
    {
        object listObj = RecipeLootTagBindingUtility.GetMemberValue(workspace, "tags");
        int count = 0;
        foreach (object tag in RecipeLootTagBindingUtility.AsEnumerable(listObj))
        {
            count++;
            string id = FirstString(tag, new string[] { "tagId", "id", "name" }, "");
            if (!IsValidId(id)) issues.Add("Tag #" + count + " has invalid id: " + id);

            string values = FirstString(tag, new string[] { "valuesCsv", "valuesText", "values" }, "");
            if (RecipeLootTagBindingUtility.SplitCsvOrLines(values).Count == 0)
            {
                object valuesObj = RecipeLootTagBindingUtility.GetMemberValue(tag, "values");
                bool hasListValues = false;
                foreach (object ignored in RecipeLootTagBindingUtility.AsEnumerable(valuesObj)) { hasListValues = true; break; }
                if (!hasListValues) issues.Add("Tag " + id + " has no values.");
            }
        }
    }

    private static string FirstString(object target, string[] names, string fallback)
    {
        for (int i = 0; i < names.Length; i++)
        {
            string v = RecipeLootTagBindingUtility.GetString(target, names[i], null);
            if (!string.IsNullOrEmpty(v)) return v;
        }
        return fallback;
    }

    private static bool IsValidId(string id)
    {
        if (string.IsNullOrEmpty(id)) return false;
        return Regex.IsMatch(id, "^[a-z0-9_./-]+$");
    }
}
