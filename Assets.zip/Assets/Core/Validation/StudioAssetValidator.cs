using System;
using System.IO;
using System.Collections.Generic;

public static class StudioAssetValidator
{
    public static List<ModValidator.ValidationResult> ValidateWorkspaceAssets(WorkspaceData workspace)
    {
        var converted = new List<ModValidator.ValidationResult>();
        foreach (var issue in Validate(workspace))
        {
            converted.Add(new ModValidator.ValidationResult(ToModSeverity(issue.severity), issue.category, issue.message, issue.elementId));
        }
        return converted;
    }

    public static List<StudioAssetIssue> Validate(WorkspaceData workspace)
    {
        var issues = new List<StudioAssetIssue>();

        if (workspace == null)
        {
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "Asset", "NULL_WORKSPACE", "Workspace null bo'lgani uchun asset tekshiruv bajarilmadi."));
            return issues;
        }

        string modId = string.IsNullOrWhiteSpace(workspace.modId) ? "mymod" : workspace.modId.Trim();

        ValidateTextureReferences(workspace, issues);
        ValidateGeneratedJson(workspace, modId, issues);
        ValidateLangCoverage(workspace, modId, issues);
        ValidateRecipeReferences(workspace, modId, issues);
        ValidateExportedFilesIfPresent(workspace, modId, issues);

        if (issues.Count == 0)
        {
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Info, "Asset", "ASSET_CHECK_OK", "Asset/JSON/lang/recipe tekshiruvlarida jiddiy muammo topilmadi."));
        }

        return issues;
    }

    private static ModValidator.ValidationSeverity ToModSeverity(StudioAssetIssueSeverity severity)
    {
        if (severity == StudioAssetIssueSeverity.Error) return ModValidator.ValidationSeverity.Error;
        if (severity == StudioAssetIssueSeverity.Warning) return ModValidator.ValidationSeverity.Warning;
        return ModValidator.ValidationSeverity.Info;
    }

    private static void ValidateTextureReferences(WorkspaceData workspace, List<StudioAssetIssue> issues)
    {
        if (workspace.blocks != null)
        {
            foreach (var block in workspace.blocks)
            {
                if (block == null) continue;
                string texturePath = StudioResourceIdUtility.NormalizeTexturePath(block.texturePath);

                if (string.IsNullOrWhiteSpace(texturePath))
                {
                    issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "Texture", "MISSING_BLOCK_TEXTURE_REF", $"Blok '{block.blockId}' uchun texturePath bo'sh.", block.blockId, $"textures/block/{block.blockId}.png", true));
                    continue;
                }

                if (!StudioResourceIdUtility.IsValidResourceLocation(texturePath, true))
                {
                    issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "Texture", "INVALID_BLOCK_TEXTURE_REF", $"Blok '{block.blockId}' texturePath noto'g'ri: '{block.texturePath}'. Faqat kichik harf, raqam, _, -, / ishlating.", block.blockId, $"textures/block/{texturePath}.png", true));
                }

                if (!texturePath.Equals(texturePath.ToLowerInvariant()))
                {
                    issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Warning, "Texture", "UPPERCASE_TEXTURE_PATH", $"Blok '{block.blockId}' texturePath ichida katta harf bor. Minecraft resource path kichik harflarni yaxshi ko'radi.", block.blockId));
                }
            }
        }

        ValidateGeneratedItemTextureGroup("Item", workspace.items, issues);
        ValidateGeneratedToolTextureGroup(workspace.tools, issues);
        ValidateGeneratedArmorTextureGroup(workspace.armors, issues);
        ValidateEntityTextureHints(workspace, issues);
    }

    private static void ValidateGeneratedItemTextureGroup(string label, List<ItemDataModel> items, List<StudioAssetIssue> issues)
    {
        if (items == null) return;
        foreach (var item in items)
        {
            if (item == null) continue;
            if (!StudioResourceIdUtility.IsValidLocalId(item.itemId)) continue;
            // Item model generator layer0 = itemId. Fayl exportdan keyin textures/item/<id>.png bo'lishi kerak.
            if (string.IsNullOrWhiteSpace(item.displayName))
                issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Warning, "Lang", "EMPTY_DISPLAY_NAME", $"Item '{item.itemId}' displayName bo'sh.", item.itemId, $"lang/en_us.json", true));
        }
    }

    private static void ValidateGeneratedToolTextureGroup(List<ToolDataModel> tools, List<StudioAssetIssue> issues)
    {
        if (tools == null) return;
        foreach (var tool in tools)
        {
            if (tool == null) continue;
            if (string.IsNullOrWhiteSpace(tool.displayName))
                issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Warning, "Lang", "EMPTY_DISPLAY_NAME", $"Tool '{tool.toolId}' displayName bo'sh.", tool.toolId, "lang/en_us.json", true));
        }
    }

    private static void ValidateGeneratedArmorTextureGroup(List<ArmorDataModel> armors, List<StudioAssetIssue> issues)
    {
        if (armors == null) return;
        foreach (var armor in armors)
        {
            if (armor == null) continue;
            if (string.IsNullOrWhiteSpace(armor.displayName))
                issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Warning, "Lang", "EMPTY_DISPLAY_NAME", $"Armor '{armor.armorId}' displayName bo'sh.", armor.armorId, "lang/en_us.json", true));
        }
    }

    private static void ValidateEntityTextureHints(WorkspaceData workspace, List<StudioAssetIssue> issues)
    {
        if (workspace.entities == null) return;
        foreach (var entity in workspace.entities)
        {
            if (entity == null) continue;
            if (string.IsNullOrWhiteSpace(entity.displayName))
                issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Warning, "Lang", "EMPTY_DISPLAY_NAME", $"Entity '{entity.entityId}' displayName bo'sh.", entity.entityId, "lang/en_us.json", true));

            if (entity.width <= 0 || entity.height <= 0)
                issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "EntityAsset", "INVALID_ENTITY_SIZE", $"Entity '{entity.entityId}' width/height 0 dan katta bo'lishi kerak.", entity.entityId));
        }
    }

    private static void ValidateGeneratedJson(WorkspaceData workspace, string modId, List<StudioAssetIssue> issues)
    {
        foreach (var spec in BuildExpectedJsonSpecs(workspace, modId))
        {
            var jsonIssues = StudioJsonSyntaxValidator.ValidateJsonText(spec.expectedJson, spec.relativePath, spec.elementId);
            issues.AddRange(jsonIssues);
        }
    }

    private static List<StudioGeneratedAssetSpec> BuildExpectedJsonSpecs(WorkspaceData workspace, string modId)
    {
        var specs = new List<StudioGeneratedAssetSpec>();
        string assetRoot = $"src/main/resources/assets/{modId}";
        string dataRoot = $"src/main/resources/data/{modId}";

        if (workspace.blocks != null)
        {
            foreach (var block in workspace.blocks)
            {
                if (block == null || string.IsNullOrWhiteSpace(block.blockId)) continue;
                specs.Add(new StudioGeneratedAssetSpec("blockstate", block.blockId, $"{assetRoot}/blockstates/{block.blockId}.json", SafeGenerate(() => block.GenerateBlockstatesJson())));
                specs.Add(new StudioGeneratedAssetSpec("block_model", block.blockId, $"{assetRoot}/models/block/{block.blockId}.json", SafeGenerate(() => block.GenerateBlockModelJson())));
                specs.Add(new StudioGeneratedAssetSpec("block_item_model", block.blockId, $"{assetRoot}/models/item/{block.blockId}.json", SafeGenerate(() => block.GenerateItemModelJson())));
            }
        }

        if (workspace.items != null)
            foreach (var item in workspace.items)
                if (item != null && !string.IsNullOrWhiteSpace(item.itemId))
                    specs.Add(new StudioGeneratedAssetSpec("item_model", item.itemId, $"{assetRoot}/models/item/{item.itemId}.json", SafeGenerate(() => item.GenerateItemModelJson())));

        if (workspace.tools != null)
            foreach (var tool in workspace.tools)
                if (tool != null && !string.IsNullOrWhiteSpace(tool.toolId))
                    specs.Add(new StudioGeneratedAssetSpec("tool_model", tool.toolId, $"{assetRoot}/models/item/{tool.toolId}.json", SafeGenerate(() => tool.GenerateItemModelJson())));

        if (workspace.armors != null)
            foreach (var armor in workspace.armors)
                if (armor != null && !string.IsNullOrWhiteSpace(armor.armorId))
                    specs.Add(new StudioGeneratedAssetSpec("armor_model", armor.armorId, $"{assetRoot}/models/item/{armor.armorId}.json", SafeGenerate(() => armor.GenerateItemModelJson())));

        if (workspace.recipes != null)
            foreach (var recipe in workspace.recipes)
                if (recipe != null)
                {
                    string id = string.IsNullOrWhiteSpace(recipe.resultItem) ? "unknown_recipe" : recipe.resultItem.Trim();
                    specs.Add(new StudioGeneratedAssetSpec("recipe", id, $"{dataRoot}/recipes/{id}_recipe.json", SafeGenerate(() => recipe.GenerateRecipeJson())));
                }

        if (workspace.biomes != null)
            foreach (var biome in workspace.biomes)
                if (biome != null && !string.IsNullOrWhiteSpace(biome.biomeId))
                    specs.Add(new StudioGeneratedAssetSpec("biome", biome.biomeId, $"{dataRoot}/worldgen/biome/{biome.biomeId}.json", SafeGenerate(() => biome.GenerateFullBiomeJson())));

        return specs;
    }

    private static string SafeGenerate(Func<string> generator)
    {
        try { return generator != null ? generator() : ""; }
        catch (Exception ex) { return "{\n  \"__generation_error\": \"" + EscapeJson(ex.Message) + "\"\n}"; }
    }

    private static string EscapeJson(string value)
    {
        if (string.IsNullOrEmpty(value)) return "";
        return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", " ").Replace("\r", " ");
    }

    private static void ValidateLangCoverage(WorkspaceData workspace, string modId, List<StudioAssetIssue> issues)
    {
        if (workspace.blocks != null)
            foreach (var block in workspace.blocks)
                if (block != null) CheckLangName("block", block.blockId, block.displayName, modId, issues);

        if (workspace.items != null)
            foreach (var item in workspace.items)
                if (item != null) CheckLangName("item", item.itemId, item.displayName, modId, issues);

        if (workspace.tools != null)
            foreach (var tool in workspace.tools)
                if (tool != null) CheckLangName("item", tool.toolId, tool.displayName, modId, issues);

        if (workspace.armors != null)
            foreach (var armor in workspace.armors)
                if (armor != null) CheckLangName("item", armor.armorId, armor.displayName, modId, issues);

        if (workspace.entities != null)
            foreach (var entity in workspace.entities)
                if (entity != null) CheckLangName("entity", entity.entityId, entity.displayName, modId, issues);

        if (workspace.biomes != null)
            foreach (var biome in workspace.biomes)
                if (biome != null) CheckLangName("biome", biome.biomeId, biome.displayName, modId, issues);

        if (workspace.creativeTabs != null)
            foreach (var tab in workspace.creativeTabs)
                if (tab != null) CheckLangName("itemGroup", tab.tabId, tab.displayName, modId, issues);
    }

    private static void CheckLangName(string prefix, string id, string displayName, string modId, List<StudioAssetIssue> issues)
    {
        if (string.IsNullOrWhiteSpace(id)) return;
        if (string.IsNullOrWhiteSpace(displayName))
        {
            string key = $"{prefix}.{modId}.{id}";
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Warning, "Lang", "MISSING_LANG_VALUE", $"Lang key '{key}' uchun displayName bo'sh.", id, "src/main/resources/assets/" + modId + "/lang/en_us.json", true));
        }
    }

    private static void ValidateRecipeReferences(WorkspaceData workspace, string modId, List<StudioAssetIssue> issues)
    {
        if (workspace.recipes == null) return;

        var knownRefs = StudioResourceIdUtility.BuildKnownItemRefs(workspace);

        foreach (var recipe in workspace.recipes)
        {
            if (recipe == null) continue;
            string recipeId = string.IsNullOrWhiteSpace(recipe.resultItem) ? "unknown_recipe" : recipe.resultItem.Trim();

            CheckItemRef(recipe.resultItem, knownRefs, modId, recipeId, "RECIPE_RESULT_REF", "Recipe natijasi tanilmagan", issues, false);

            if (recipe.recipeType == RecipeType.CraftingShaped || recipe.recipeType == RecipeType.CraftingShapeless)
            {
                if (recipe.grid != null)
                    foreach (var slot in recipe.grid)
                        CheckItemRef(slot, knownRefs, modId, recipeId, "RECIPE_INGREDIENT_REF", "Recipe ingredient tanilmagan", issues, true);

                if (recipe.shapelessIngredients != null)
                    foreach (var ingredient in recipe.shapelessIngredients)
                        CheckItemRef(ingredient, knownRefs, modId, recipeId, "RECIPE_INGREDIENT_REF", "Shapeless ingredient tanilmagan", issues, true);
            }

            if (recipe.recipeType == RecipeType.Smelting || recipe.recipeType == RecipeType.Blasting || recipe.recipeType == RecipeType.Smoking || recipe.recipeType == RecipeType.CampfireCooking)
                CheckItemRef(recipe.smeltingInput, knownRefs, modId, recipeId, "RECIPE_COOKING_INPUT_REF", "Cooking input tanilmagan", issues, false);

            if (recipe.recipeType == RecipeType.Stonecutting)
                CheckItemRef(recipe.stonecuttingInput, knownRefs, modId, recipeId, "RECIPE_STONECUTTING_INPUT_REF", "Stonecutting input tanilmagan", issues, false);
        }
    }

    private static void CheckItemRef(string rawRef, HashSet<string> knownRefs, string modId, string recipeId, string code, string label, List<StudioAssetIssue> issues, bool emptyAllowed)
    {
        if (string.IsNullOrWhiteSpace(rawRef))
        {
            if (!emptyAllowed)
                issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Warning, "RecipeRef", "EMPTY_RECIPE_REF", $"Recipe '{recipeId}' ichida bo'sh item reference bor.", recipeId));
            return;
        }

        string value = rawRef.Trim();
        if (value.StartsWith("#"))
        {
            // Tag reference. Faqat sintaksisni tekshiramiz.
            string tag = value.Substring(1);
            if (!StudioResourceIdUtility.IsValidResourceLocation(tag, false))
                issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "RecipeRef", "INVALID_TAG_REF", $"Recipe '{recipeId}' tag reference noto'g'ri: '{value}'.", recipeId));
            return;
        }

        if (!StudioResourceIdUtility.IsValidResourceLocation(value, true))
        {
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "RecipeRef", "INVALID_ITEM_REF", $"Recipe '{recipeId}' item reference noto'g'ri: '{value}'.", recipeId));
            return;
        }

        if (StudioResourceIdUtility.LooksLikeMinecraftOrTagRef(value)) return;

        string normalized = StudioResourceIdUtility.NormalizeItemRef(value, modId);
        if (!knownRefs.Contains(value) && !knownRefs.Contains(normalized))
        {
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Warning, "RecipeRef", code, $"{label}: '{value}'. Agar bu boshqa mod itemi bo'lsa namespace bilan yozing: othermod:{value}", recipeId, "src/main/resources/data/" + modId + "/recipes", true));
        }
    }

    private static void ValidateExportedFilesIfPresent(WorkspaceData workspace, string modId, List<StudioAssetIssue> issues)
    {
        string projectPath = workspace?.studioProject?.project?.projectPath;
        if (string.IsNullOrWhiteSpace(projectPath) || !Directory.Exists(projectPath))
        {
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Info, "ExportedAssets", "NO_PROJECT_PATH", "Project path hali mavjud emas yoki tanlanmagan. Fayl mavjudligi exportdan keyin tekshiriladi."));
            return;
        }

        string resourcesRoot = Path.Combine(projectPath, "src", "main", "resources");
        if (!Directory.Exists(resourcesRoot))
        {
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Info, "ExportedAssets", "NOT_EXPORTED_YET", "src/main/resources hali yaratilmagan. Save/Exportdan keyin missing file tekshiruvi ishlaydi."));
            return;
        }

        foreach (var spec in BuildExpectedJsonSpecs(workspace, modId))
        {
            string abs = Path.Combine(projectPath, spec.relativePath.Replace('/', Path.DirectorySeparatorChar));
            if (spec.requiredAfterExport && !File.Exists(abs))
            {
                issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Warning, "ExportedAssets", "MISSING_GENERATED_JSON", $"Export qilingan projectda kutilgan JSON fayl topilmadi: {spec.relativePath}", spec.elementId, spec.relativePath, true));
            }
        }

        ValidateExpectedTexturesIfPresent(workspace, modId, projectPath, issues);
    }

    private static void ValidateExpectedTexturesIfPresent(WorkspaceData workspace, string modId, string projectPath, List<StudioAssetIssue> issues)
    {
        string assetRoot = Path.Combine(projectPath, "src", "main", "resources", "assets", modId);
        if (!Directory.Exists(assetRoot)) return;

        if (workspace.blocks != null)
        {
            foreach (var block in workspace.blocks)
            {
                if (block == null || string.IsNullOrWhiteSpace(block.blockId)) continue;
                string texture = string.IsNullOrWhiteSpace(block.texturePath) ? block.blockId : StudioResourceIdUtility.NormalizeTexturePath(block.texturePath);
                CheckPng(assetRoot, $"textures/block/{texture}.png", block.blockId, issues);
            }
        }

        if (workspace.items != null)
            foreach (var item in workspace.items)
                if (item != null && !string.IsNullOrWhiteSpace(item.itemId)) CheckPng(assetRoot, $"textures/item/{item.itemId}.png", item.itemId, issues);

        if (workspace.tools != null)
            foreach (var tool in workspace.tools)
                if (tool != null && !string.IsNullOrWhiteSpace(tool.toolId)) CheckPng(assetRoot, $"textures/item/{tool.toolId}.png", tool.toolId, issues);

        if (workspace.armors != null)
            foreach (var armor in workspace.armors)
                if (armor != null && !string.IsNullOrWhiteSpace(armor.armorId)) CheckPng(assetRoot, $"textures/item/{armor.armorId}.png", armor.armorId, issues);
    }

    private static void CheckPng(string assetRoot, string relative, string elementId, List<StudioAssetIssue> issues)
    {
        string abs = Path.Combine(assetRoot, relative.Replace('/', Path.DirectorySeparatorChar));
        if (!File.Exists(abs))
        {
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Warning, "Texture", "MISSING_TEXTURE_FILE", $"Texture PNG topilmadi: {relative}. Minecraftda purple/black missing texture chiqishi mumkin.", elementId, relative, true));
        }
    }
}
