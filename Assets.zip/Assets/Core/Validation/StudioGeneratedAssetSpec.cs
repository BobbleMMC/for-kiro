using System;

[Serializable]
public class StudioGeneratedAssetSpec
{
    public string kind = "";
    public string elementId = "";
    public string relativePath = "";
    public string expectedJson = "";
    public bool requiredAfterExport = true;

    public StudioGeneratedAssetSpec() { }

    public StudioGeneratedAssetSpec(string kind, string elementId, string relativePath, string expectedJson, bool requiredAfterExport = true)
    {
        this.kind = kind;
        this.elementId = elementId;
        this.relativePath = relativePath;
        this.expectedJson = expectedJson;
        this.requiredAfterExport = requiredAfterExport;
    }
}
