using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public static class StudioResourceIdUtility
{
    private static readonly Regex NamespaceRegex = new Regex(@"^[a-z0-9_.-]+$", RegexOptions.Compiled);
    private static readonly Regex PathRegex = new Regex(@"^[a-z0-9_./-]+$", RegexOptions.Compiled);
    private static readonly Regex LocalIdRegex = new Regex(@"^[a-z][a-z0-9_]*$", RegexOptions.Compiled);

    public static bool IsValidLocalId(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) return false;
        return LocalIdRegex.IsMatch(id.Trim());
    }

    public static bool IsValidResourceLocation(string value, bool allowLocalId = true)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        value = value.Trim();

        if (!value.Contains(":"))
            return allowLocalId && IsValidLocalId(value);

        string[] parts = value.Split(new[] { ':' }, 2);
        if (parts.Length != 2) return false;
        if (string.IsNullOrWhiteSpace(parts[0]) || string.IsNullOrWhiteSpace(parts[1])) return false;
        return NamespaceRegex.IsMatch(parts[0]) && PathRegex.IsMatch(parts[1]);
    }

    public static string NormalizeItemRef(string raw, string modId)
    {
        if (string.IsNullOrWhiteSpace(raw)) return "";
        raw = raw.Trim();
        if (raw.Contains(":")) return raw;
        if (raw.StartsWith("#")) return raw;
        return $"{modId}:{raw}";
    }

    public static string NormalizeTexturePath(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return "";
        return raw.Trim().Replace('\\', '/');
    }

    public static HashSet<string> BuildKnownItemRefs(WorkspaceData workspace)
    {
        string modId = string.IsNullOrWhiteSpace(workspace?.modId) ? "mymod" : workspace.modId.Trim();
        var refs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        if (workspace?.items != null)
            foreach (var item in workspace.items)
                AddLocal(refs, modId, item?.itemId);

        if (workspace?.tools != null)
            foreach (var tool in workspace.tools)
                AddLocal(refs, modId, tool?.toolId);

        if (workspace?.armors != null)
            foreach (var armor in workspace.armors)
                AddLocal(refs, modId, armor?.armorId);

        if (workspace?.blocks != null)
            foreach (var block in workspace.blocks)
                AddLocal(refs, modId, block?.blockId);

        return refs;
    }

    private static void AddLocal(HashSet<string> refs, string modId, string id)
    {
        if (string.IsNullOrWhiteSpace(id)) return;
        refs.Add(id.Trim());
        refs.Add($"{modId}:{id.Trim()}");
    }

    public static bool LooksLikeMinecraftOrTagRef(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        value = value.Trim();
        return value.StartsWith("minecraft:") || value.StartsWith("#minecraft:") || value.StartsWith("#c:") || value.StartsWith("c:");
    }
}
