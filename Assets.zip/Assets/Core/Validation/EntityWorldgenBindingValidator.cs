using System.Collections.Generic;

public static class EntityWorldgenBindingValidator
{
    public static List<string> Validate(object workspace)
    {
        var issues = new List<string>();
        if (workspace == null)
        {
            issues.Add("Workspace is null. Open/load a Mod Studio project first.");
            return issues;
        }

        ValidateEntities(workspace, issues);
        ValidateBiomes(workspace, issues);
        ValidateDimensions(workspace, issues);
        ValidateStructures(workspace, issues);
        return issues;
    }

    private static void ValidateEntities(object workspace, List<string> issues)
    {
        object listObj = EntityWorldgenBindingUtility.GetMemberValue(workspace, "entities");
        int index = 0;
        foreach (object entity in EntityWorldgenBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EntityWorldgenBindingUtility.GetFirstString(entity, new string[] { "entityId", "id", "name" }, string.Empty);
            if (string.IsNullOrEmpty(id)) issues.Add("Entity #" + index + " has empty id.");
            float health = EntityWorldgenBindingUtility.GetFirstFloat(entity, new string[] { "health", "maxHealth" }, 20f);
            if (health <= 0) issues.Add("Entity '" + id + "' health must be greater than 0.");
            float width = EntityWorldgenBindingUtility.GetFirstFloat(entity, new string[] { "width" }, 0.6f);
            float height = EntityWorldgenBindingUtility.GetFirstFloat(entity, new string[] { "height" }, 1.8f);
            if (width <= 0 || height <= 0) issues.Add("Entity '" + id + "' width/height must be greater than 0.");
            int minGroup = EntityWorldgenBindingUtility.GetFirstInt(EntityWorldgenBindingUtility.GetMemberValue(entity, "spawnRule"), new string[] { "minGroup", "minCount" }, 1);
            int maxGroup = EntityWorldgenBindingUtility.GetFirstInt(EntityWorldgenBindingUtility.GetMemberValue(entity, "spawnRule"), new string[] { "maxGroup", "maxCount" }, 1);
            if (minGroup > maxGroup) issues.Add("Entity '" + id + "' spawn min group is greater than max group.");
        }
    }

    private static void ValidateBiomes(object workspace, List<string> issues)
    {
        object listObj = EntityWorldgenBindingUtility.GetMemberValue(workspace, "biomes");
        int index = 0;
        foreach (object biome in EntityWorldgenBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EntityWorldgenBindingUtility.GetFirstString(biome, new string[] { "biomeId", "id", "name" }, string.Empty);
            if (string.IsNullOrEmpty(id)) issues.Add("Biome #" + index + " has empty id.");
            float temperature = EntityWorldgenBindingUtility.GetFirstFloat(biome, new string[] { "temperature" }, 0.8f);
            float downfall = EntityWorldgenBindingUtility.GetFirstFloat(biome, new string[] { "downfall" }, 0.4f);
            if (temperature < -2f || temperature > 2f) issues.Add("Biome '" + id + "' temperature is outside common safe range (-2..2).");
            if (downfall < 0f || downfall > 1f) issues.Add("Biome '" + id + "' downfall should be between 0 and 1.");
        }
    }

    private static void ValidateDimensions(object workspace, List<string> issues)
    {
        object listObj = EntityWorldgenBindingUtility.GetFirstMemberValue(workspace, new string[] { "dimensions", "worldDimensions", "dimensionSettings" });
        foreach (object dimension in EntityWorldgenBindingUtility.AsEnumerable(listObj))
        {
            string id = EntityWorldgenBindingUtility.GetFirstString(dimension, new string[] { "dimensionId", "id", "name" }, string.Empty);
            if (string.IsNullOrEmpty(id)) issues.Add("Dimension has empty id.");
            int minY = EntityWorldgenBindingUtility.GetFirstInt(dimension, new string[] { "minY" }, -64);
            int height = EntityWorldgenBindingUtility.GetFirstInt(dimension, new string[] { "height" }, 384);
            if (height <= 0) issues.Add("Dimension '" + id + "' height must be greater than 0.");
            if (minY % 16 != 0 || height % 16 != 0) issues.Add("Dimension '" + id + "' minY and height should be multiples of 16.");
        }
    }

    private static void ValidateStructures(object workspace, List<string> issues)
    {
        object listObj = EntityWorldgenBindingUtility.GetFirstMemberValue(workspace, new string[] { "structures", "worldStructures", "structureSettings" });
        foreach (object structure in EntityWorldgenBindingUtility.AsEnumerable(listObj))
        {
            string id = EntityWorldgenBindingUtility.GetFirstString(structure, new string[] { "structureId", "id", "name" }, string.Empty);
            if (string.IsNullOrEmpty(id)) issues.Add("Structure has empty id.");
            int spacing = EntityWorldgenBindingUtility.GetFirstInt(structure, new string[] { "spacing" }, 32);
            int separation = EntityWorldgenBindingUtility.GetFirstInt(structure, new string[] { "separation" }, 8);
            if (spacing <= separation) issues.Add("Structure '" + id + "' spacing must be greater than separation.");
        }
    }
}
