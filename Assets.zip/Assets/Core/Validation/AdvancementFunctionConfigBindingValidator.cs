using System.Collections.Generic;

public static class AdvancementFunctionConfigBindingValidator
{
    public static List<string> Validate(object workspace)
    {
        var issues = new List<string>();
        if (workspace == null)
        {
            issues.Add("Workspace is null. Load workspace first.");
            return issues;
        }

        ValidateAdvancements(workspace, issues);
        ValidateFunctions(workspace, issues);
        ValidateConfigs(workspace, issues);
        return issues;
    }

    private static void ValidateAdvancements(object workspace, List<string> issues)
    {
        object listObj = AdvancementFunctionConfigBindingUtility.GetFirstMemberValue(workspace, new string[] { "advancements", "advancementData", "advancementList" });
        int count = 0;
        foreach (object adv in AdvancementFunctionConfigBindingUtility.AsEnumerable(listObj))
        {
            count++;
            string id = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "advancementId", "id", "name" }, string.Empty);
            if (string.IsNullOrWhiteSpace(id)) issues.Add("Advancement #" + count + " has empty ID.");
            string icon = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "iconItem", "icon", "item" }, string.Empty);
            if (string.IsNullOrWhiteSpace(icon)) issues.Add("Advancement '" + id + "' has no icon item.");
            string customJson = AdvancementFunctionConfigBindingUtility.GetFirstString(adv, new string[] { "customJsonOverride", "customJson", "jsonOverride" }, string.Empty);
            if (!string.IsNullOrWhiteSpace(customJson) && (!customJson.Trim().StartsWith("{") || !customJson.Trim().EndsWith("}")))
                issues.Add("Advancement '" + id + "' custom JSON must be a JSON object.");
        }
    }

    private static void ValidateFunctions(object workspace, List<string> issues)
    {
        object listObj = AdvancementFunctionConfigBindingUtility.GetFirstMemberValue(workspace, new string[] { "functions", "functionFiles", "mcFunctions", "commandFunctions" });
        int count = 0;
        foreach (object fn in AdvancementFunctionConfigBindingUtility.AsEnumerable(listObj))
        {
            count++;
            string id = AdvancementFunctionConfigBindingUtility.GetFirstString(fn, new string[] { "functionId", "id", "name" }, string.Empty);
            if (string.IsNullOrWhiteSpace(id)) issues.Add("Function #" + count + " has empty ID.");
            string commands = AdvancementFunctionConfigBindingUtility.GetFirstString(fn, new string[] { "commandsText", "commands", "body" }, string.Empty);
            if (string.IsNullOrWhiteSpace(commands)) issues.Add("Function '" + id + "' has no commands.");
        }
    }

    private static void ValidateConfigs(object workspace, List<string> issues)
    {
        object listObj = AdvancementFunctionConfigBindingUtility.GetFirstMemberValue(workspace, new string[] { "configs", "configFiles", "configuration" });
        int count = 0;
        foreach (object cfg in AdvancementFunctionConfigBindingUtility.AsEnumerable(listObj))
        {
            count++;
            string id = AdvancementFunctionConfigBindingUtility.GetFirstString(cfg, new string[] { "configId", "id", "name" }, string.Empty);
            string fileName = AdvancementFunctionConfigBindingUtility.GetFirstString(cfg, new string[] { "fileName", "path" }, string.Empty);
            if (string.IsNullOrWhiteSpace(id)) issues.Add("Config #" + count + " has empty ID.");
            if (string.IsNullOrWhiteSpace(fileName)) issues.Add("Config '" + id + "' has empty file name.");
            string entries = AdvancementFunctionConfigBindingUtility.GetFirstString(cfg, new string[] { "entriesCsv", "entries", "configEntries" }, string.Empty);
            string custom = AdvancementFunctionConfigBindingUtility.GetFirstString(cfg, new string[] { "customConfigText", "customText", "overrideText" }, string.Empty);
            if (string.IsNullOrWhiteSpace(entries) && string.IsNullOrWhiteSpace(custom))
                issues.Add("Config '" + id + "' has no entries and no custom config text.");
        }
    }
}
