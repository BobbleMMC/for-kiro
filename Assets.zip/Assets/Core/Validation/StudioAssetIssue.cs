using System;

public enum StudioAssetIssueSeverity
{
    Error,
    Warning,
    Info
}

[Serializable]
public class StudioAssetIssue
{
    public StudioAssetIssueSeverity severity = StudioAssetIssueSeverity.Info;
    public string category = "Asset";
    public string code = "ASSET_INFO";
    public string message = "";
    public string elementId = "";
    public string filePath = "";
    public bool fixable = false;

    public StudioAssetIssue() { }

    public StudioAssetIssue(StudioAssetIssueSeverity severity, string category, string code, string message, string elementId = "", string filePath = "", bool fixable = false)
    {
        this.severity = severity;
        this.category = category;
        this.code = code;
        this.message = message;
        this.elementId = elementId;
        this.filePath = filePath;
        this.fixable = fixable;
    }

    public override string ToString()
    {
        string icon = severity == StudioAssetIssueSeverity.Error ? "❌" : severity == StudioAssetIssueSeverity.Warning ? "⚠️" : "ℹ️";
        string location = string.IsNullOrEmpty(filePath) ? "" : $" ({filePath})";
        return $"{icon} [{category}/{code}] {message}{location}";
    }
}
