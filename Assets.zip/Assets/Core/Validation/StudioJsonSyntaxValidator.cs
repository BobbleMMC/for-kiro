using System;
using System.Collections.Generic;

public static class StudioJsonSyntaxValidator
{
    public static List<StudioAssetIssue> ValidateJsonText(string json, string filePath, string elementId = "")
    {
        var issues = new List<StudioAssetIssue>();

        if (string.IsNullOrWhiteSpace(json))
        {
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "JSON", "EMPTY_JSON", "JSON matni bo'sh.", elementId, filePath));
            return issues;
        }

        bool inString = false;
        bool escaped = false;
        var stack = new Stack<char>();

        for (int i = 0; i < json.Length; i++)
        {
            char c = json[i];

            if (inString)
            {
                if (escaped)
                {
                    escaped = false;
                    continue;
                }
                if (c == '\\')
                {
                    escaped = true;
                    continue;
                }
                if (c == '"')
                    inString = false;
                continue;
            }

            if (c == '"')
            {
                inString = true;
                continue;
            }

            if (c == '{' || c == '[')
            {
                stack.Push(c);
                continue;
            }

            if (c == '}' || c == ']')
            {
                if (stack.Count == 0)
                {
                    issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "JSON", "UNMATCHED_CLOSING_BRACKET", $"JSON ichida ortiqcha yopuvchi belgi bor: '{c}' index {i}.", elementId, filePath));
                    return issues;
                }

                char open = stack.Pop();
                bool ok = (open == '{' && c == '}') || (open == '[' && c == ']');
                if (!ok)
                {
                    issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "JSON", "MISMATCHED_BRACKET", $"JSON bracket mos emas: '{open}' '{c}' index {i}.", elementId, filePath));
                    return issues;
                }
            }
        }

        if (inString)
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "JSON", "UNCLOSED_STRING", "JSON ichida string yopilmagan.", elementId, filePath));

        if (stack.Count > 0)
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "JSON", "UNCLOSED_BRACKET", "JSON ichida bracket yopilmagan.", elementId, filePath));

        // Basic trailing-comma detection. Full JSON parser emas, lekin eng ko'p uchraydigan xatoni ushlaydi.
        if (ContainsTrailingComma(json))
            issues.Add(new StudioAssetIssue(StudioAssetIssueSeverity.Error, "JSON", "TRAILING_COMMA", "JSON ichida trailing comma bor. Minecraft JSON buni qabul qilmaydi.", elementId, filePath, true));

        return issues;
    }

    public static bool LooksLikeJsonObject(string json)
    {
        if (string.IsNullOrWhiteSpace(json)) return false;
        string trimmed = json.Trim();
        if (!trimmed.StartsWith("{") || !trimmed.EndsWith("}")) return false;
        return ValidateJsonText(trimmed, "inline-json").Count == 0;
    }

    private static bool ContainsTrailingComma(string json)
    {
        bool inString = false;
        bool escaped = false;
        for (int i = 0; i < json.Length; i++)
        {
            char c = json[i];
            if (inString)
            {
                if (escaped) { escaped = false; continue; }
                if (c == '\\') { escaped = true; continue; }
                if (c == '"') inString = false;
                continue;
            }

            if (c == '"') { inString = true; continue; }
            if (c != ',') continue;

            int j = i + 1;
            while (j < json.Length && char.IsWhiteSpace(json[j])) j++;
            if (j < json.Length && (json[j] == '}' || json[j] == ']'))
                return true;
        }
        return false;
    }
}
