using System.Collections.Generic;

public static class EquipmentGameplayBindingValidator
{
    public static List<string> Validate(object workspace)
    {
        var issues = new List<string>();
        if (workspace == null)
        {
            issues.Add("Workspace is null. Open/load a Mod Studio project first.");
            return issues;
        }

        ValidateTools(workspace, issues);
        ValidateArmors(workspace, issues);
        ValidateFoodsAndDataComponents(workspace, issues);
        ValidateEffects(workspace, issues);
        ValidateEnchantments(workspace, issues);
        ValidateSounds(workspace, issues);
        ValidateParticles(workspace, issues);
        return issues;
    }

    private static void ValidateTools(object workspace, List<string> issues)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "tools", "toolItems", "weapons" });
        int index = 0;
        foreach (object tool in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(tool, new string[] { "toolId", "itemId", "id", "name" }, string.Empty);
            if (string.IsNullOrEmpty(id)) issues.Add("Tool #" + index + " has empty id.");
            int durability = EquipmentGameplayBindingUtility.GetFirstInt(tool, new string[] { "durability", "maxDamage" }, 250);
            if (durability <= 0) issues.Add("Tool '" + id + "' durability must be greater than 0.");
            float miningSpeed = EquipmentGameplayBindingUtility.GetFirstFloat(tool, new string[] { "miningSpeed", "speed" }, 6f);
            if (miningSpeed < 0) issues.Add("Tool '" + id + "' mining speed cannot be negative.");
            int enchantability = EquipmentGameplayBindingUtility.GetFirstInt(tool, new string[] { "enchantability" }, 14);
            if (enchantability < 0) issues.Add("Tool '" + id + "' enchantability cannot be negative.");
        }
    }

    private static void ValidateArmors(object workspace, List<string> issues)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "armors", "armorItems", "armorSets" });
        int index = 0;
        foreach (object armor in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(armor, new string[] { "armorId", "itemId", "id", "name" }, string.Empty);
            if (string.IsNullOrEmpty(id)) issues.Add("Armor #" + index + " has empty id.");
            string slot = EquipmentGameplayBindingUtility.GetFirstString(armor, new string[] { "slot", "armorSlot", "equipmentSlot" }, "chestplate").ToLowerInvariant();
            if (slot != "helmet" && slot != "chestplate" && slot != "leggings" && slot != "boots") issues.Add("Armor '" + id + "' slot should be helmet/chestplate/leggings/boots.");
            int protection = EquipmentGameplayBindingUtility.GetFirstInt(armor, new string[] { "protection", "defense" }, 5);
            if (protection < 0 || protection > 50) issues.Add("Armor '" + id + "' protection should be between 0 and 50.");
            float toughness = EquipmentGameplayBindingUtility.GetFirstFloat(armor, new string[] { "toughness", "armorToughness" }, 0f);
            if (toughness < 0) issues.Add("Armor '" + id + "' toughness cannot be negative.");
        }
    }

    private static void ValidateFoodsAndDataComponents(object workspace, List<string> issues)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "items", "itemData", "customItems" });
        int index = 0;
        foreach (object item in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(item, new string[] { "itemId", "id", "name" }, "item_" + index);
            object advanced = EquipmentGameplayBindingUtility.GetAdvanced(item);
            object foodObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(advanced, new string[] { "food", "foodSettings" });
            bool foodEnabled = EquipmentGameplayBindingUtility.GetFirstBool(advanced, new string[] { "isFood", "foodEnabled" }, false) || EquipmentGameplayBindingUtility.GetFirstBool(foodObj, new string[] { "enabled", "isFood" }, false);
            if (foodEnabled)
            {
                int nutrition = EquipmentGameplayBindingUtility.GetFirstInt(foodObj, new string[] { "nutrition", "hunger" }, EquipmentGameplayBindingUtility.GetFirstInt(advanced, new string[] { "nutrition" }, 4));
                float saturation = EquipmentGameplayBindingUtility.GetFirstFloat(foodObj, new string[] { "saturation", "saturationModifier" }, EquipmentGameplayBindingUtility.GetFirstFloat(advanced, new string[] { "saturation" }, 0.3f));
                if (nutrition < 0 || nutrition > 50) issues.Add("Food item '" + id + "' nutrition should be between 0 and 50.");
                if (saturation < 0f || saturation > 20f) issues.Add("Food item '" + id + "' saturation should be between 0 and 20.");
            }

            string components = EquipmentGameplayBindingUtility.GetFirstString(advanced, new string[] { "dataComponentsJson", "customDataComponents", "dataComponents" }, string.Empty);
            if (!string.IsNullOrWhiteSpace(components))
            {
                string trimmed = components.Trim();
                if (!trimmed.StartsWith("{") || !trimmed.EndsWith("}")) issues.Add("Item '" + id + "' custom data components must be a JSON object.");
            }
        }
    }

    private static void ValidateEffects(object workspace, List<string> issues)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "effects", "potions", "statusEffects" });
        int index = 0;
        foreach (object effect in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(effect, new string[] { "effectId", "potionId", "id", "name" }, string.Empty);
            if (string.IsNullOrEmpty(id)) issues.Add("Effect #" + index + " has empty id.");
            string category = EquipmentGameplayBindingUtility.GetFirstString(effect, new string[] { "category", "effectCategory" }, "neutral").ToLowerInvariant();
            if (category != "beneficial" && category != "harmful" && category != "neutral") issues.Add("Effect '" + id + "' category should be beneficial/harmful/neutral.");
        }
    }

    private static void ValidateEnchantments(object workspace, List<string> issues)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "enchantments", "enchantmentSettings" });
        int index = 0;
        foreach (object enchantment in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(enchantment, new string[] { "enchantmentId", "id", "name" }, string.Empty);
            if (string.IsNullOrEmpty(id)) issues.Add("Enchantment #" + index + " has empty id.");
            int maxLevel = EquipmentGameplayBindingUtility.GetFirstInt(enchantment, new string[] { "maxLevel", "levels" }, 1);
            if (maxLevel < 1 || maxLevel > 255) issues.Add("Enchantment '" + id + "' max level should be between 1 and 255.");
        }
    }

    private static void ValidateSounds(object workspace, List<string> issues)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "sounds", "soundEvents" });
        int index = 0;
        foreach (object sound in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(sound, new string[] { "soundId", "id", "name" }, string.Empty);
            if (string.IsNullOrEmpty(id)) issues.Add("Sound #" + index + " has empty id.");
            string file = EquipmentGameplayBindingUtility.GetFirstString(sound, new string[] { "file", "soundFile", "path" }, string.Empty);
            if (string.IsNullOrEmpty(file)) issues.Add("Sound '" + id + "' should have at least one sound file path.");
        }
    }

    private static void ValidateParticles(object workspace, List<string> issues)
    {
        object listObj = EquipmentGameplayBindingUtility.GetFirstMemberValue(workspace, new string[] { "particles", "particleSettings" });
        int index = 0;
        foreach (object particle in EquipmentGameplayBindingUtility.AsEnumerable(listObj))
        {
            index++;
            string id = EquipmentGameplayBindingUtility.GetFirstString(particle, new string[] { "particleId", "id", "name" }, string.Empty);
            if (string.IsNullOrEmpty(id)) issues.Add("Particle #" + index + " has empty id.");
        }
    }
}
