using System;

[Serializable]
public class BlockBindingIssue
{
    public string severity = "warning";
    public string blockId = string.Empty;
    public string fieldId = string.Empty;
    public string message = string.Empty;
    public string suggestedFix = string.Empty;

    public BlockBindingIssue() { }

    public BlockBindingIssue(string severity, string blockId, string fieldId, string message, string suggestedFix = "")
    {
        this.severity = string.IsNullOrEmpty(severity) ? "warning" : severity;
        this.blockId = blockId ?? string.Empty;
        this.fieldId = fieldId ?? string.Empty;
        this.message = message ?? string.Empty;
        this.suggestedFix = suggestedFix ?? string.Empty;
    }

    public override string ToString()
    {
        string prefix = string.IsNullOrEmpty(blockId) ? "[block]" : "[" + blockId + "]";
        string field = string.IsNullOrEmpty(fieldId) ? "" : " " + fieldId + ":";
        string fix = string.IsNullOrEmpty(suggestedFix) ? "" : " | Fix: " + suggestedFix;
        return severity.ToUpperInvariant() + " " + prefix + field + " " + message + fix;
    }
}
