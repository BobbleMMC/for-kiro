using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class BlockBoundGenerationReport
{
    public string projectRoot = string.Empty;
    public string modId = string.Empty;
    public string loader = string.Empty;
    public int blocksProcessed;
    public int filesWritten;
    public int filesSkipped;
    public int backupsCreated;
    public List<string> generatedFiles = new List<string>();
    public List<BlockBindingIssue> issues = new List<BlockBindingIssue>();

    public bool HasErrors()
    {
        if (issues == null) return false;
        for (int i = 0; i < issues.Count; i++)
        {
            if (issues[i] != null && string.Equals(issues[i].severity, "error", StringComparison.OrdinalIgnoreCase)) return true;
        }
        return false;
    }

    public void AddFile(string path)
    {
        if (string.IsNullOrEmpty(path)) return;
        generatedFiles.Add(path);
        filesWritten++;
    }

    public void AddIssue(string severity, string blockId, string fieldId, string message, string fix = "")
    {
        issues.Add(new BlockBindingIssue(severity, blockId, fieldId, message, fix));
    }

    public string Format()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("=== Block Real Binding Report ===");
        sb.AppendLine("Project: " + projectRoot);
        sb.AppendLine("Mod ID: " + modId);
        sb.AppendLine("Loader: " + loader);
        sb.AppendLine("Blocks processed: " + blocksProcessed);
        sb.AppendLine("Files written: " + filesWritten);
        sb.AppendLine("Files skipped: " + filesSkipped);
        sb.AppendLine("Backups created: " + backupsCreated);
        if (issues != null && issues.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Issues:");
            foreach (BlockBindingIssue issue in issues) sb.AppendLine("- " + issue);
        }
        if (generatedFiles != null && generatedFiles.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Generated files:");
            foreach (string file in generatedFiles) sb.AppendLine("- " + file);
        }
        return sb.ToString();
    }
}
