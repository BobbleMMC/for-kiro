using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public static class BlockBindingGenerator
{
    public static BlockBoundGenerationReport GenerateWorkspace(WorkspaceData workspace, string projectRoot, bool overwriteExisting = true, bool backupExisting = true)
    {
        BlockBoundGenerationReport report = BlockBindingValidator.ValidateWorkspace(workspace, projectRoot);
        if (report.HasErrors()) return report;

        if (workspace == null || workspace.blocks == null) return report;
        string modId = BlockBindingPathUtility.SanitizeModId(workspace.modId);
        string loader = string.IsNullOrEmpty(workspace.modloader) ? "fabric" : workspace.modloader.ToLowerInvariant();
        report.modId = modId;
        report.loader = loader;
        report.projectRoot = projectRoot;

        Directory.CreateDirectory(projectRoot);
        string backupRoot = null;
        if (backupExisting)
        {
            backupRoot = BlockBindingPathUtility.SafeCombineUnderRoot(projectRoot, ".modstudio", "backups", "block-binding", DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Directory.CreateDirectory(backupRoot);
        }

        foreach (BlockDataModel block in workspace.blocks)
        {
            if (block == null) continue;
            block.EnsureAdvancedSettings();
            GenerateBlock(workspace, block, projectRoot, modId, loader, overwriteExisting, backupRoot, report);
        }

        WriteReport(projectRoot, report);
        return report;
    }

    public static void GenerateBlock(WorkspaceData workspace, BlockDataModel block, string projectRoot, string modId, string loader, bool overwriteExisting, string backupRoot, BlockBoundGenerationReport report)
    {
        string id = BlockBindingPathUtility.NormalizeResourceId(block.blockId, "custom_block");
        string texture = ResolveTexturePath(block);

        WriteFile(projectRoot, report, backupRoot, overwriteExisting,
            "src/main/resources/assets/" + modId + "/blockstates/" + id + ".json",
            GenerateBlockstateJson(block, modId, id));

        WriteFile(projectRoot, report, backupRoot, overwriteExisting,
            "src/main/resources/assets/" + modId + "/models/block/" + id + ".json",
            GenerateBlockModelJson(block, modId, texture));

        WriteFile(projectRoot, report, backupRoot, overwriteExisting,
            "src/main/resources/assets/" + modId + "/models/item/" + id + ".json",
            GenerateBlockItemModelJson(modId, id));

        MergeLang(projectRoot, report, backupRoot, overwriteExisting, modId, "block." + modId + "." + id, string.IsNullOrEmpty(block.displayName) ? id : block.displayName);

        GenerateToolTags(block, projectRoot, modId, id, overwriteExisting, backupRoot, report);
        GenerateJavaStubs(block, projectRoot, modId, loader, id, overwriteExisting, backupRoot, report);
        WriteBindingManifest(block, projectRoot, modId, id, overwriteExisting, backupRoot, report);
    }

    private static string ResolveTexturePath(BlockDataModel block)
    {
        if (block == null) return "custom_block";
        block.EnsureAdvancedSettings();
        if (block.advanced != null && block.advanced.visual != null && !string.IsNullOrEmpty(block.advanced.visual.sideTexture)) return block.advanced.visual.sideTexture;
        if (!string.IsNullOrEmpty(block.texturePath)) return block.texturePath;
        return BlockBindingPathUtility.NormalizeResourceId(block.blockId, "custom_block");
    }

    private static string GenerateBlockstateJson(BlockDataModel block, string modId, string id)
    {
        bool waterlogged = IsWaterlogged(block);
        bool lit = block.advanced != null && block.advanced.states != null && block.advanced.states.lit;
        bool powered = block.advanced != null && block.advanced.states != null && block.advanced.states.powered;
        if (!waterlogged && !lit && !powered)
        {
            return "{\n" +
                   "  \"variants\": {\n" +
                   "    \"\": { \"model\": \"" + modId + ":block/" + id + "\" }\n" +
                   "  }\n" +
                   "}\n";
        }

        List<string> stateParts = new List<string>();
        if (waterlogged) stateParts.Add("waterlogged");
        if (lit) stateParts.Add("lit");
        if (powered) stateParts.Add("powered");

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"variants\": {");
        List<string> variants = BuildBooleanVariants(stateParts, 0, "");
        for (int i = 0; i < variants.Count; i++)
        {
            sb.Append("    \"").Append(variants[i]).Append("\": { \"model\": \"").Append(modId).Append(":block/").Append(id).Append("\" }");
            if (i < variants.Count - 1) sb.Append(",");
            sb.AppendLine();
        }
        sb.AppendLine("  }");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static List<string> BuildBooleanVariants(List<string> names, int index, string current)
    {
        List<string> result = new List<string>();
        if (index >= names.Count)
        {
            result.Add(current.Trim(','));
            return result;
        }
        string prefix = string.IsNullOrEmpty(current) ? "" : current + ",";
        result.AddRange(BuildBooleanVariants(names, index + 1, prefix + names[index] + "=false"));
        result.AddRange(BuildBooleanVariants(names, index + 1, prefix + names[index] + "=true"));
        return result;
    }

    private static string GenerateBlockModelJson(BlockDataModel block, string modId, string texture)
    {
        string top = texture;
        string bottom = texture;
        if (block.advanced != null && block.advanced.visual != null)
        {
            if (!string.IsNullOrEmpty(block.advanced.visual.topTexture)) top = block.advanced.visual.topTexture;
            if (!string.IsNullOrEmpty(block.advanced.visual.bottomTexture)) bottom = block.advanced.visual.bottomTexture;
        }
        if (top != texture || bottom != texture)
        {
            return "{\n" +
                   "  \"parent\": \"minecraft:block/cube_bottom_top\",\n" +
                   "  \"textures\": {\n" +
                   "    \"side\": \"" + modId + ":block/" + texture + "\",\n" +
                   "    \"top\": \"" + modId + ":block/" + top + "\",\n" +
                   "    \"bottom\": \"" + modId + ":block/" + bottom + "\"\n" +
                   "  }\n" +
                   "}\n";
        }
        return "{\n" +
               "  \"parent\": \"minecraft:block/cube_all\",\n" +
               "  \"textures\": {\n" +
               "    \"all\": \"" + modId + ":block/" + texture + "\"\n" +
               "  }\n" +
               "}\n";
    }

    private static string GenerateBlockItemModelJson(string modId, string id)
    {
        return "{\n  \"parent\": \"" + modId + ":block/" + id + "\"\n}\n";
    }

    private static bool IsWaterlogged(BlockDataModel block)
    {
        if (block == null || block.advanced == null) return false;
        bool a = block.advanced.behavior != null && block.advanced.behavior.waterloggable;
        bool b = block.advanced.states != null && block.advanced.states.waterlogged;
        return a || b;
    }

    private static void GenerateToolTags(BlockDataModel block, string projectRoot, string modId, string id, bool overwriteExisting, string backupRoot, BlockBoundGenerationReport report)
    {
        if (block.advanced == null || block.advanced.behavior == null || !block.advanced.behavior.requiresTool) return;
        string tag = string.IsNullOrEmpty(block.advanced.behavior.requiredToolTag) ? "mineable/pickaxe" : block.advanced.behavior.requiredToolTag;
        string tagPath = tag.Trim().Replace("minecraft:", "");
        WriteTagJson(projectRoot, report, backupRoot, overwriteExisting, "src/main/resources/data/minecraft/tags/blocks/" + tagPath + ".json", modId + ":" + id);

        string needs = MiningLevelToNeedsTag(block.advanced.behavior.miningLevel);
        if (!string.IsNullOrEmpty(needs))
        {
            WriteTagJson(projectRoot, report, backupRoot, overwriteExisting, "src/main/resources/data/minecraft/tags/blocks/" + needs + ".json", modId + ":" + id);
        }
    }

    private static string MiningLevelToNeedsTag(int level)
    {
        if (level <= 0) return string.Empty;
        if (level == 1) return "needs_stone_tool";
        if (level == 2) return "needs_iron_tool";
        if (level >= 3) return "needs_diamond_tool";
        return string.Empty;
    }

    private static void WriteTagJson(string projectRoot, BlockBoundGenerationReport report, string backupRoot, bool overwriteExisting, string relativePath, string value)
    {
        string fullPath = BlockBindingPathUtility.SafeCombineUnderRoot(projectRoot, relativePath);
        string content;
        if (File.Exists(fullPath))
        {
            string existing = File.ReadAllText(fullPath);
            if (existing.Contains("\"" + value + "\"")) return;
            int arrayEnd = existing.LastIndexOf(']');
            if (arrayEnd >= 0)
            {
                string before = existing.Substring(0, arrayEnd).TrimEnd();
                string after = existing.Substring(arrayEnd);
                string comma = before.EndsWith("[") ? "" : ",";
                content = before + comma + "\n    \"" + value + "\"\n  " + after;
            }
            else content = BuildSimpleTag(value);
        }
        else content = BuildSimpleTag(value);
        WriteFileAbsolute(projectRoot, report, backupRoot, overwriteExisting, fullPath, content);
    }

    private static string BuildSimpleTag(string value)
    {
        return "{\n  \"replace\": false,\n  \"values\": [\n    \"" + value + "\"\n  ]\n}\n";
    }

    private static void MergeLang(string projectRoot, BlockBoundGenerationReport report, string backupRoot, bool overwriteExisting, string modId, string key, string value)
    {
        string rel = "src/main/resources/assets/" + modId + "/lang/en_us.json";
        string fullPath = BlockBindingPathUtility.SafeCombineUnderRoot(projectRoot, rel);
        string content;
        if (File.Exists(fullPath))
        {
            string existing = File.ReadAllText(fullPath).Trim();
            if (existing.Contains("\"" + key + "\"")) return;
            int lastBrace = existing.LastIndexOf('}');
            if (lastBrace > 0)
            {
                string before = existing.Substring(0, lastBrace).TrimEnd();
                string comma = before.EndsWith("{") ? "" : ",";
                content = before + comma + "\n  \"" + BlockBindingPathUtility.EscapeJson(key) + "\": \"" + BlockBindingPathUtility.EscapeJson(value) + "\"\n}\n";
            }
            else content = BuildLang(key, value);
        }
        else content = BuildLang(key, value);
        WriteFileAbsolute(projectRoot, report, backupRoot, overwriteExisting, fullPath, content);
    }

    private static string BuildLang(string key, string value)
    {
        return "{\n  \"" + BlockBindingPathUtility.EscapeJson(key) + "\": \"" + BlockBindingPathUtility.EscapeJson(value) + "\"\n}\n";
    }

    private static void GenerateJavaStubs(BlockDataModel block, string projectRoot, string modId, string loader, string id, bool overwriteExisting, string backupRoot, BlockBoundGenerationReport report)
    {
        string pkgPath = BlockBindingPathUtility.PackagePath(modId).Replace('\\', '/');
        string className = BlockBindingPathUtility.ToClassName(id, "Block");
        string relBase = ".modstudio/generated-java/" + loader + "/" + pkgPath;
        WriteFile(projectRoot, report, backupRoot, overwriteExisting, relBase + "/block/" + className + ".java.stub", GenerateBlockClassStub(block, modId, id, className));

        if (block.advanced != null && block.advanced.visual != null && (block.advanced.visual.transparent || block.advanced.visual.renderLayer != StudioBlockRenderLayer.Solid))
        {
            WriteFile(projectRoot, report, backupRoot, overwriteExisting, relBase + "/client/ModBlockRenderLayers.java.stub", GenerateRenderLayerStub(modId, id, block));
        }

        if (block.advanced != null && block.advanced.blockEntity != null && block.advanced.blockEntity.enabled)
        {
            string beClass = BlockBindingPathUtility.ToClassName(id, "BlockEntity");
            WriteFile(projectRoot, report, backupRoot, overwriteExisting, relBase + "/blockentity/" + beClass + ".java.stub", GenerateBlockEntityStub(modId, id, beClass, block));
            WriteFile(projectRoot, report, backupRoot, overwriteExisting, relBase + "/blockentity/ModBlockEntities.java.stub", GenerateBlockEntityRegistryStub(modId, id, beClass));
        }
    }

    private static string GenerateBlockClassStub(BlockDataModel block, string modId, string id, string className)
    {
        bool water = IsWaterlogged(block);
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("package " + BlockBindingPathUtility.JavaPackage(modId) + ".block;");
        sb.AppendLine();
        sb.AppendLine("// ModStudio generated stub. Review imports and mappings before applying to src/main/java.");
        sb.AppendLine("// Field binding: block.waterlogged/light/transparent/requiresTool/blockEntity");
        sb.AppendLine("public class " + className + " extends Block" + (water ? " implements Waterloggable" : "") + " {");
        if (water) sb.AppendLine("    public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;");
        sb.AppendLine("    public " + className + "(Settings settings) {");
        sb.AppendLine("        super(settings");
        sb.AppendLine("            .strength(" + FormatFloat(block.hardness) + "f, " + FormatFloat(block.resistance) + "f)");
        if (block.lightLevel > 0) sb.AppendLine("            .luminance(state -> " + block.lightLevel + ")");
        if (block.advanced != null && block.advanced.behavior != null && block.advanced.behavior.requiresTool) sb.AppendLine("            // .requiresTool() // uncomment for target mapping/loader");
        if (block.advanced != null && block.advanced.collision != null && block.advanced.collision.noCollision) sb.AppendLine("            // .noCollision() // enable when using matching mapping");
        sb.AppendLine("        );");
        if (water) sb.AppendLine("        setDefaultState(getStateManager().getDefaultState().with(WATERLOGGED, false));");
        sb.AppendLine("    }");
        if (water)
        {
            sb.AppendLine();
            sb.AppendLine("    // Waterlogged behavior stub:");
            sb.AppendLine("    // - append WATERLOGGED in appendProperties(StateManager.Builder<Block, BlockState>)");
            sb.AppendLine("    // - set WATERLOGGED based on FluidState in getPlacementState(ItemPlacementContext)");
            sb.AppendLine("    // - schedule fluid tick in getStateForNeighborUpdate(...)");
            sb.AppendLine("    // - return Fluids.WATER.getStill(false) in getFluidState when WATERLOGGED=true");
        }
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string GenerateRenderLayerStub(string modId, string id, BlockDataModel block)
    {
        string layer = "cutout";
        if (block.advanced != null && block.advanced.visual != null && block.advanced.visual.renderLayer == StudioBlockRenderLayer.Translucent) layer = "translucent";
        return "package " + BlockBindingPathUtility.JavaPackage(modId) + ".client;\n\n" +
               "// Register render layer for transparent/cutout block.\n" +
               "public final class ModBlockRenderLayers {\n" +
               "    public static void register() {\n" +
               "        // BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks." + id.ToUpperInvariant() + ", RenderLayer.get" + (layer == "translucent" ? "Translucent" : "Cutout") + "());\n" +
               "    }\n" +
               "}\n";
    }

    private static string GenerateBlockEntityStub(string modId, string id, string className, BlockDataModel block)
    {
        int slots = block.advanced != null && block.advanced.blockEntity != null ? block.advanced.blockEntity.inventorySlots : 0;
        return "package " + BlockBindingPathUtility.JavaPackage(modId) + ".blockentity;\n\n" +
               "// BlockEntity stub for " + id + "\n" +
               "public class " + className + " extends BlockEntity {\n" +
               "    // inventorySlots: " + slots + "\n" +
               "    // syncToClient: " + (block.advanced.blockEntity.syncToClient ? "true" : "false") + "\n" +
               "    public " + className + "(BlockPos pos, BlockState state) {\n" +
               "        super(ModBlockEntities." + id.ToUpperInvariant() + ", pos, state);\n" +
               "    }\n" +
               "}\n";
    }

    private static string GenerateBlockEntityRegistryStub(string modId, string id, string beClass)
    {
        return "package " + BlockBindingPathUtility.JavaPackage(modId) + ".blockentity;\n\n" +
               "// Registry stub. Merge with your real ModBlockEntities registry.\n" +
               "public final class ModBlockEntities {\n" +
               "    // public static BlockEntityType<" + beClass + "> " + id.ToUpperInvariant() + ";\n" +
               "}\n";
    }

    private static void WriteBindingManifest(BlockDataModel block, string projectRoot, string modId, string id, bool overwriteExisting, string backupRoot, BlockBoundGenerationReport report)
    {
        string json = "{\n" +
            "  \"schema\": \"modstudio.block-binding.v1\",\n" +
            "  \"blockId\": \"" + id + "\",\n" +
            "  \"fields\": [\n" +
            "    \"block.id\",\n" +
            "    \"block.displayName\",\n" +
            "    \"block.hardness\",\n" +
            "    \"block.blastResistance\",\n" +
            "    \"block.lightLevel\",\n" +
            "    \"block.requiresTool\",\n" +
            "    \"block.transparent\",\n" +
            "    \"block.waterlogged\",\n" +
            "    \"block.blockEntity\"\n" +
            "  ],\n" +
            "  \"generatedAt\": \"" + DateTime.UtcNow.ToString("o") + "\"\n" +
            "}\n";
        WriteFile(projectRoot, report, backupRoot, overwriteExisting, ".modstudio/block-binding/" + id + ".binding.json", json);
    }

    private static void WriteReport(string projectRoot, BlockBoundGenerationReport report)
    {
        string dir = BlockBindingPathUtility.SafeCombineUnderRoot(projectRoot, ".modstudio", "reports");
        Directory.CreateDirectory(dir);
        string txt = Path.Combine(dir, "block-binding-report.txt");
        File.WriteAllText(txt, report.Format(), Encoding.UTF8);
        report.AddFile(txt);
    }

    private static void WriteFile(string projectRoot, BlockBoundGenerationReport report, string backupRoot, bool overwriteExisting, string relativePath, string content)
    {
        string full = BlockBindingPathUtility.SafeCombineUnderRoot(projectRoot, relativePath);
        WriteFileAbsolute(projectRoot, report, backupRoot, overwriteExisting, full, content);
    }

    private static void WriteFileAbsolute(string projectRoot, BlockBoundGenerationReport report, string backupRoot, bool overwriteExisting, string fullPath, string content)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(fullPath));
        if (File.Exists(fullPath))
        {
            if (!overwriteExisting)
            {
                report.filesSkipped++;
                return;
            }
            if (!string.IsNullOrEmpty(backupRoot))
            {
                string rel = BlockBindingPathUtility.Relative(projectRoot, fullPath);
                string backup = Path.Combine(backupRoot, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(backup));
                File.Copy(fullPath, backup, true);
                report.backupsCreated++;
            }
        }
        File.WriteAllText(fullPath, content ?? string.Empty, Encoding.UTF8);
        report.AddFile(fullPath);
    }

    private static string FormatFloat(float value)
    {
        return value.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);
    }
}
