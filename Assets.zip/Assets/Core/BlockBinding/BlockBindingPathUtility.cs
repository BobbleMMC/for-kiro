using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

public static class BlockBindingPathUtility
{
    public static string NormalizeResourceId(string value, string fallback)
    {
        if (string.IsNullOrEmpty(value)) value = fallback;
        value = value == null ? fallback : value.Trim().ToLowerInvariant();
        value = Regex.Replace(value, "[^a-z0-9_./-]", "_");
        value = value.Replace(' ', '_');
        value = value.Trim('_', '/', '.', '-');
        if (string.IsNullOrEmpty(value)) value = fallback;
        if (!Regex.IsMatch(value, "^[a-z0-9_./-]+$")) value = fallback;
        return value;
    }

    public static string ToClassName(string id, string suffix = "")
    {
        id = NormalizeResourceId(id, "custom_block");
        string[] parts = id.Split(new[] { '_', '-', '/', '.' }, StringSplitOptions.RemoveEmptyEntries);
        StringBuilder sb = new StringBuilder();
        foreach (string p in parts)
        {
            if (string.IsNullOrEmpty(p)) continue;
            sb.Append(char.ToUpperInvariant(p[0]));
            if (p.Length > 1) sb.Append(p.Substring(1));
        }
        if (sb.Length == 0) sb.Append("CustomBlock");
        sb.Append(suffix ?? string.Empty);
        return sb.ToString();
    }

    public static string SanitizeModId(string value)
    {
        value = NormalizeResourceId(value, "mymod");
        value = value.Replace("/", "_").Replace(".", "_").Replace("-", "_");
        if (!Regex.IsMatch(value, "^[a-z][a-z0-9_]*$")) value = "mymod";
        return value;
    }

    public static string SafeCombineUnderRoot(string root, params string[] parts)
    {
        if (string.IsNullOrEmpty(root)) throw new ArgumentException("Project root is empty.");
        string fullRoot = Path.GetFullPath(root);
        string path = fullRoot;
        foreach (string part in parts)
        {
            if (string.IsNullOrEmpty(part)) continue;
            path = Path.Combine(path, part.Replace('/', Path.DirectorySeparatorChar).Replace('\\', Path.DirectorySeparatorChar));
        }
        string full = Path.GetFullPath(path);
        if (!full.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("Path sandbox blocked: " + full);
        }
        return full;
    }

    public static string PackagePath(string modId)
    {
        return Path.Combine("com", "modstudio", SanitizeModId(modId));
    }

    public static string JavaPackage(string modId)
    {
        return "com.modstudio." + SanitizeModId(modId);
    }

    public static string EscapeJson(string value)
    {
        if (value == null) return string.Empty;
        return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n");
    }

    public static string Relative(string root, string path)
    {
        try
        {
            Uri rootUri = new Uri(Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar);
            Uri pathUri = new Uri(Path.GetFullPath(path));
            return Uri.UnescapeDataString(rootUri.MakeRelativeUri(pathUri).ToString()).Replace('/', Path.DirectorySeparatorChar);
        }
        catch { return path; }
    }
}
