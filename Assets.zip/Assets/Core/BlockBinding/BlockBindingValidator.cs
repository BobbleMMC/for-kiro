using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public static class BlockBindingValidator
{
    public static BlockBoundGenerationReport ValidateWorkspace(WorkspaceData workspace, string projectRoot = "")
    {
        BlockBoundGenerationReport report = new BlockBoundGenerationReport();
        report.projectRoot = projectRoot ?? string.Empty;
        report.modId = ResolveModId(workspace);
        report.loader = ResolveLoader(workspace);

        if (workspace == null)
        {
            report.AddIssue("error", "", "workspace", "WorkspaceData null.", "Avval Mod Studio loyihasini oching yoki yangi loyiha yarating.");
            return report;
        }

        if (workspace.blocks == null || workspace.blocks.Count == 0)
        {
            report.AddIssue("warning", "", "blocks", "Workspace ichida block yo'q.", "Block Editor orqali kamida bitta block qo'shing.");
            return report;
        }

        HashSet<string> ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (BlockDataModel block in workspace.blocks)
        {
            ValidateBlock(block, report, ids);
        }
        report.blocksProcessed = workspace.blocks.Count;
        return report;
    }

    public static void ValidateBlock(BlockDataModel block, BlockBoundGenerationReport report, HashSet<string> ids = null)
    {
        if (block == null)
        {
            report.AddIssue("error", "", "block", "BlockDataModel null.");
            return;
        }

        block.EnsureAdvancedSettings();
        string id = BlockBindingPathUtility.NormalizeResourceId(block.blockId, "custom_block");
        if (string.IsNullOrEmpty(block.blockId) || !Regex.IsMatch(block.blockId, "^[a-z0-9_./-]+$"))
        {
            report.AddIssue("error", id, "block.id", "Block ID invalid.", "Faqat lowercase a-z, 0-9, _, -, / ishlating.");
        }

        if (ids != null && !ids.Add(id))
        {
            report.AddIssue("error", id, "block.id", "Duplicate block id topildi.", "Har block ID unique bo'lishi kerak.");
        }

        if (block.hardness < 0 || block.hardness > 50)
        {
            report.AddIssue("error", id, "block.hardness", "Hardness 0..50 oralig'ida bo'lishi kerak.", "Qiymatni 0 va 50 orasiga qo'ying.");
        }
        if (block.resistance < 0 || block.resistance > 120)
        {
            report.AddIssue("error", id, "block.blastResistance", "Blast resistance 0..120 oralig'ida bo'lishi kerak.");
        }
        if (block.lightLevel < 0 || block.lightLevel > 15)
        {
            report.AddIssue("error", id, "block.lightLevel", "Light level 0..15 oralig'ida bo'lishi kerak.");
        }

        AdvancedBlockSettings adv = block.advanced;
        if (adv == null) return;

        if (adv.visual != null)
        {
            if (adv.visual.transparent && adv.visual.opaque)
            {
                report.AddIssue("warning", id, "block.transparent", "Transparent true, lekin opaque ham true.", "Opaque=false yoki renderLayer=Cutout/Translucent qiling.");
            }
            if (adv.visual.transparent && adv.visual.renderLayer == StudioBlockRenderLayer.Solid)
            {
                report.AddIssue("warning", id, "block.renderLayer", "Transparent block Solid render layer bilan qolgan.", "RenderLayer ni Cutout yoki Translucent qiling.");
            }
        }

        if (adv.behavior != null)
        {
            if (adv.behavior.requiresTool && string.IsNullOrEmpty(adv.behavior.requiredToolTag))
            {
                report.AddIssue("error", id, "block.requiresTool", "requiresTool true, lekin requiredToolTag bo'sh.", "mineable/pickaxe kabi tag kiriting.");
            }
            if (adv.behavior.miningLevel < 0 || adv.behavior.miningLevel > 4)
            {
                report.AddIssue("warning", id, "block.miningLevel", "Mining level odatda 0..4 oralig'ida bo'ladi.");
            }
            if (adv.behavior.waterloggable && adv.states != null && !adv.states.waterlogged)
            {
                report.AddIssue("warning", id, "block.waterlogged", "Behavior waterloggable true, lekin BlockState waterlogged false.", "Generator blockstate variantini yaratadi, UI'da states.waterlogged ham true qiling.");
            }
        }

        if (adv.collision != null)
        {
            if (adv.collision.noCollision && adv.collision.fullCube)
            {
                report.AddIssue("warning", id, "block.collision", "noCollision va fullCube birga yoqilgan.", "Bittasini tanlang.");
            }
            if (adv.collision.shapeMode == StudioBlockShapeMode.CustomVoxel && string.IsNullOrEmpty(adv.collision.voxelShape))
            {
                report.AddIssue("error", id, "block.voxelShape", "Custom voxel shape tanlangan, lekin voxelShape bo'sh.");
            }
        }

        if (adv.blockEntity != null && adv.blockEntity.enabled)
        {
            if (adv.blockEntity.hasInventory && (adv.blockEntity.inventorySlots < 1 || adv.blockEntity.inventorySlots > 54))
            {
                report.AddIssue("error", id, "blockEntity.inventorySlots", "Inventory slot 1..54 oralig'ida bo'lishi kerak.");
            }
            if (adv.blockEntity.hasScreen && !adv.blockEntity.hasInventory)
            {
                report.AddIssue("warning", id, "blockEntity.screen", "Screen yoqilgan, lekin inventory o'chirilgan.", "Container screen bo'lsa inventory/sync settingsni ham tekshiring.");
            }
        }
    }

    private static string ResolveModId(WorkspaceData workspace)
    {
        if (workspace == null) return "mymod";
        return BlockBindingPathUtility.SanitizeModId(workspace.modId);
    }

    private static string ResolveLoader(WorkspaceData workspace)
    {
        if (workspace == null || string.IsNullOrEmpty(workspace.modloader)) return "fabric";
        return workspace.modloader.ToLowerInvariant();
    }
}
