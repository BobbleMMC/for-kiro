using System;

/// <summary>
/// PatchOperation — mavjud faylga qanday o'zgarish kiritilishini bildiradi.
/// 5-patch maqsadi: scaffold/template fayllarni ko'r-ko'rona qayta yozish emas,
/// kerakli joylarda merge qilish va patchdan oldin backup olish.
/// </summary>
[Serializable]
public class PatchOperation
{
    public string relativePath = "";
    public string newContent = "";
    public string mergeStrategy = "replace";
    public string description = "";
    public bool createBackup = true;
    public bool overwriteWhenUnknown = true;

    public PatchOperation() {}

    public PatchOperation(string relativePath, string newContent, string mergeStrategy, string description = "", bool createBackup = true)
    {
        this.relativePath = relativePath ?? "";
        this.newContent = newContent ?? "";
        this.mergeStrategy = string.IsNullOrEmpty(mergeStrategy) ? "replace" : mergeStrategy;
        this.description = description ?? "";
        this.createBackup = createBackup;
    }
}
