using System;
using System.IO;

public static class FilePatchBackupManager
{
    public static string CreateBackup(string absolutePath, string rootPath, StudioPatchResult result)
    {
        if (string.IsNullOrEmpty(absolutePath) || !File.Exists(absolutePath)) return null;

        string backupRoot = Path.Combine(rootPath, ".modstudio", "backups", DateTime.UtcNow.ToString("yyyyMMdd_HHmmss"));
        Directory.CreateDirectory(backupRoot);

        string relative = StudioPatchPathUtility.GetRelativePath(rootPath, absolutePath);
        string backupPath = Path.Combine(backupRoot, relative.Replace('/', Path.DirectorySeparatorChar));
        string dir = Path.GetDirectoryName(backupPath);
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

        File.Copy(absolutePath, backupPath, true);
        if (result != null) result.AddBackup(StudioPatchPathUtility.GetRelativePath(rootPath, backupPath));
        return backupPath;
    }
}
