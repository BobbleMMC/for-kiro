using System;
using System.IO;
using System.Collections.Generic;

/// <summary>
/// StudioPatchEngine — 5-patch.
/// Bitta markaziy patch engine: file path sandbox, backup, merge strategy va write natijalarini boshqaradi.
/// </summary>
public static class StudioPatchEngine
{
    public const string StrategyReplace = "replace";
    public const string StrategyJsonMerge = "json-merge";
    public const string StrategyGradleMerge = "gradle-merge";
    public const string StrategySettingsGradleMerge = "gradle-settings-merge";
    public const string StrategyPropertiesMerge = "properties-merge";
    public const string StrategyTomlMerge = "toml-merge";
    public const string StrategyAppendIfMissing = "append-if-missing";

    public static StudioPatchResult Apply(string rootPath, List<PatchOperation> operations)
    {
        StudioPatchResult result = new StudioPatchResult();
        if (string.IsNullOrEmpty(rootPath))
        {
            result.AddError("Patch rootPath bo'sh.");
            return result;
        }
        if (operations == null || operations.Count == 0)
        {
            result.AddWarning("Patch operationlar ro'yxati bo'sh.");
            return result;
        }

        foreach (var operation in operations)
        {
            ApplyOne(rootPath, operation, result);
        }
        return result;
    }

    public static StudioPatchResult ApplyOne(string rootPath, PatchOperation operation)
    {
        StudioPatchResult result = new StudioPatchResult();
        ApplyOne(rootPath, operation, result);
        return result;
    }

    private static void ApplyOne(string rootPath, PatchOperation operation, StudioPatchResult result)
    {
        if (operation == null)
        {
            if (result != null) result.AddWarning("Bo'sh patch operation o'tkazib yuborildi.");
            return;
        }

        try
        {
            string absolutePath = StudioPatchPathUtility.ResolveInsideRoot(rootPath, operation.relativePath);
            string dir = Path.GetDirectoryName(absolutePath);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

            bool exists = File.Exists(absolutePath);
            string oldContent = exists ? File.ReadAllText(absolutePath) : "";
            string newContent = operation.newContent ?? "";
            string strategy = NormalizeStrategy(operation.mergeStrategy);
            string finalContent = Merge(oldContent, newContent, strategy);

            if (exists && oldContent == finalContent)
            {
                if (result != null) result.AddSkipped(operation.relativePath);
                return;
            }

            if (exists && operation.createBackup)
                FilePatchBackupManager.CreateBackup(absolutePath, rootPath, result);

            File.WriteAllText(absolutePath, finalContent);

            if (result != null)
            {
                if (exists && strategy != StrategyReplace) result.AddMerged(operation.relativePath);
                else result.AddWritten(operation.relativePath);
            }
        }
        catch (Exception ex)
        {
            if (result != null) result.AddError(operation.relativePath + ": " + ex.Message);
        }
    }

    private static string Merge(string oldContent, string newContent, string strategy)
    {
        if (strategy == StrategyJsonMerge) return JsonMergePatcher.Merge(oldContent, newContent);
        if (strategy == StrategyGradleMerge) return GradleMergePatcher.MergeBuildGradle(oldContent, newContent);
        if (strategy == StrategySettingsGradleMerge) return GradleMergePatcher.MergeSettingsGradle(oldContent, newContent);
        if (strategy == StrategyPropertiesMerge) return PropertiesMergePatcher.Merge(oldContent, newContent);
        if (strategy == StrategyTomlMerge) return TomlMergePatcher.Merge(oldContent, newContent);
        if (strategy == StrategyAppendIfMissing) return AppendIfMissingPatcher.MergeLines(oldContent, newContent);
        return newContent ?? "";
    }

    private static string NormalizeStrategy(string strategy)
    {
        if (string.IsNullOrEmpty(strategy)) return StrategyReplace;
        string s = strategy.Trim().ToLowerInvariant();
        if (s == "json" || s == "jsonmerge") return StrategyJsonMerge;
        if (s == "gradle" || s == "gradlemerge") return StrategyGradleMerge;
        if (s == "settings-gradle" || s == "settings.gradle" || s == "gradle-settings") return StrategySettingsGradleMerge;
        if (s == "properties" || s == "gradle-properties") return StrategyPropertiesMerge;
        if (s == "toml") return StrategyTomlMerge;
        if (s == "append" || s == "append-if-missing") return StrategyAppendIfMissing;
        return s;
    }
}
