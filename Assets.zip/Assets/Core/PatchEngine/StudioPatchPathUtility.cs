using System;
using System.IO;

public static class StudioPatchPathUtility
{
    public static string ResolveInsideRoot(string rootPath, string relativePath)
    {
        if (string.IsNullOrEmpty(rootPath)) throw new ArgumentException("rootPath bo'sh");
        if (string.IsNullOrEmpty(relativePath)) throw new ArgumentException("relativePath bo'sh");

        string rootFull = Path.GetFullPath(rootPath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
        string combined = Path.Combine(rootFull, relativePath.Replace('/', Path.DirectorySeparatorChar));
        string full = Path.GetFullPath(combined);

        if (!full.StartsWith(rootFull, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Patch workspace tashqarisiga yozishga urindi: " + relativePath);

        return full;
    }

    public static string GetRelativePath(string rootPath, string absolutePath)
    {
        if (string.IsNullOrEmpty(rootPath) || string.IsNullOrEmpty(absolutePath)) return absolutePath ?? "";
        Uri rootUri = new Uri(Path.GetFullPath(rootPath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar);
        Uri fileUri = new Uri(Path.GetFullPath(absolutePath));
        string rel = Uri.UnescapeDataString(rootUri.MakeRelativeUri(fileUri).ToString());
        return rel.Replace('\\', '/');
    }
}
