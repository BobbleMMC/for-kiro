using System;
using System.Text;
using System.Collections.Generic;

[Serializable]
public class StudioPatchResult
{
    public List<string> writtenFiles = new List<string>();
    public List<string> mergedFiles = new List<string>();
    public List<string> skippedFiles = new List<string>();
    public List<string> backupFiles = new List<string>();
    public List<string> warnings = new List<string>();
    public List<string> errors = new List<string>();

    public bool HasErrors { get { return errors != null && errors.Count > 0; } }

    public void AddWritten(string path)
    {
        if (!string.IsNullOrEmpty(path) && !writtenFiles.Contains(path)) writtenFiles.Add(path);
    }

    public void AddMerged(string path)
    {
        if (!string.IsNullOrEmpty(path) && !mergedFiles.Contains(path)) mergedFiles.Add(path);
    }

    public void AddSkipped(string path)
    {
        if (!string.IsNullOrEmpty(path) && !skippedFiles.Contains(path)) skippedFiles.Add(path);
    }

    public void AddBackup(string path)
    {
        if (!string.IsNullOrEmpty(path) && !backupFiles.Contains(path)) backupFiles.Add(path);
    }

    public void AddWarning(string message)
    {
        if (!string.IsNullOrEmpty(message)) warnings.Add(message);
    }

    public void AddError(string message)
    {
        if (!string.IsNullOrEmpty(message)) errors.Add(message);
    }

    public string Format()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("─── Patch Engine natijasi ───");
        sb.AppendLine("Written: " + writtenFiles.Count + ", Merged: " + mergedFiles.Count + ", Skipped: " + skippedFiles.Count + ", Backups: " + backupFiles.Count);
        foreach (var f in writtenFiles) sb.AppendLine("✓ Written: " + f);
        foreach (var f in mergedFiles) sb.AppendLine("↔ Merged: " + f);
        foreach (var f in skippedFiles) sb.AppendLine("- Skipped: " + f);
        foreach (var b in backupFiles) sb.AppendLine("↩ Backup: " + b);
        foreach (var w in warnings) sb.AppendLine("⚠ " + w);
        foreach (var e in errors) sb.AppendLine("✗ " + e);
        return sb.ToString();
    }
}
