using System;
using System.Text;
using System.Collections.Generic;

/// <summary>
/// JavaSourcePatcher — 5-patchdagi boshlang'ich Java patch util.
/// Hozir import qo'shish va class oxiriga method/field qo'shish uchun ishlatiladi.
/// Keyingi patchlarda AST-based engine bilan almashtirish mumkin.
/// </summary>
public static class JavaSourcePatcher
{
    public static string AddImports(string source, IEnumerable<string> imports)
    {
        if (string.IsNullOrEmpty(source)) source = "";
        if (imports == null) return source;

        StringBuilder importBlock = new StringBuilder();
        foreach (string imp in imports)
        {
            if (string.IsNullOrWhiteSpace(imp)) continue;
            string line = imp.Trim();
            if (!line.StartsWith("import ")) line = "import " + line;
            if (!line.EndsWith(";")) line += ";";
            if (source.Contains(line)) continue;
            importBlock.AppendLine(line);
        }
        if (importBlock.Length == 0) return source;

        int lastImport = source.LastIndexOf("import ", StringComparison.Ordinal);
        if (lastImport >= 0)
        {
            int insert = source.IndexOf('\n', lastImport);
            if (insert >= 0) return source.Insert(insert + 1, importBlock.ToString());
        }

        int packageEnd = source.IndexOf(';');
        if (source.TrimStart().StartsWith("package ") && packageEnd >= 0)
            return source.Insert(packageEnd + 1, "\n\n" + importBlock.ToString());

        return importBlock.ToString() + "\n" + source;
    }

    public static string AppendBeforeClassEnd(string source, string memberCode)
    {
        if (string.IsNullOrWhiteSpace(memberCode)) return source ?? "";
        if (string.IsNullOrEmpty(source)) return memberCode;
        if (source.Contains(memberCode.Trim())) return source;

        int lastBrace = source.LastIndexOf('}');
        if (lastBrace < 0) return source.TrimEnd() + "\n" + memberCode + "\n";
        return source.Insert(lastBrace, "\n" + memberCode.TrimEnd() + "\n");
    }
}
