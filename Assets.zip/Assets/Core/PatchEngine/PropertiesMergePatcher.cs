using System;
using System.Text;
using System.Collections.Generic;

public static class PropertiesMergePatcher
{
    public static string Merge(string existing, string incoming)
    {
        if (string.IsNullOrWhiteSpace(existing)) return incoming ?? "";
        if (string.IsNullOrWhiteSpace(incoming)) return existing ?? "";

        Dictionary<string, string> map = new Dictionary<string, string>();
        List<string> order = new List<string>();
        ReadProperties(existing, map, order, false);
        ReadProperties(incoming, map, order, true);

        StringBuilder sb = new StringBuilder();
        foreach (string key in order)
        {
            if (!map.ContainsKey(key)) continue;
            if (key.StartsWith("#")) sb.AppendLine(map[key]);
            else sb.AppendLine(key + "=" + map[key]);
        }
        return sb.ToString();
    }

    private static void ReadProperties(string text, Dictionary<string, string> map, List<string> order, bool incoming)
    {
        string[] lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.None);
        int commentIndex = 0;
        foreach (string raw in lines)
        {
            string line = raw.Trim();
            if (line.Length == 0) continue;
            if (line.StartsWith("#"))
            {
                if (!incoming)
                {
                    string key = "#__comment_" + commentIndex++;
                    map[key] = raw;
                    order.Add(key);
                }
                continue;
            }

            int eq = line.IndexOf('=');
            if (eq <= 0) continue;
            string keyName = line.Substring(0, eq).Trim();
            string value = line.Substring(eq + 1).Trim();
            if (!map.ContainsKey(keyName)) order.Add(keyName);
            // Incoming versiya resolver natijasi bo'lgani uchun known keylar yangilanadi.
            map[keyName] = value;
        }
    }
}
