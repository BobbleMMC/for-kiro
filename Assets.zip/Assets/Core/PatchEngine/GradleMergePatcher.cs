using System;
using System.Text;
using System.Collections.Generic;

/// <summary>
/// GradleMergePatcher — build.gradle/settings.gradle ichidagi repositories va dependencies
/// bloklariga yangi satrlarni duplicate qilmasdan qo'shadi.
/// </summary>
public static class GradleMergePatcher
{
    public static string MergeBuildGradle(string existing, string incoming)
    {
        if (string.IsNullOrWhiteSpace(existing)) return incoming ?? "";
        if (string.IsNullOrWhiteSpace(incoming)) return existing ?? "";

        string result = existing;
        result = MergeBlockLines(result, incoming, "repositories");
        result = MergeBlockLines(result, incoming, "dependencies");
        result = MergePluginLines(result, incoming);
        return result;
    }

    public static string MergeSettingsGradle(string existing, string incoming)
    {
        if (string.IsNullOrWhiteSpace(existing)) return incoming ?? "";
        if (string.IsNullOrWhiteSpace(incoming)) return existing ?? "";

        string result = existing;
        result = MergeBlockLines(result, incoming, "repositories");
        if (!ContainsSignificant(result, "rootProject.name") && ContainsSignificant(incoming, "rootProject.name"))
            result += "\n" + ExtractLineContaining(incoming, "rootProject.name") + "\n";
        return result;
    }

    private static string MergePluginLines(string existing, string incoming)
    {
        List<string> incomingLines = ExtractBlockLines(incoming, "plugins");
        if (incomingLines.Count == 0) return existing;
        if (FindBlock(existing, "plugins", out int start, out int end))
        {
            string insert = BuildMissingLines(existing, incomingLines, "    ");
            if (string.IsNullOrWhiteSpace(insert)) return existing;
            return existing.Insert(end, insert);
        }
        return incoming.TrimEnd() + "\n\n" + existing.TrimStart();
    }

    private static string MergeBlockLines(string existing, string incoming, string blockName)
    {
        List<string> incomingLines = ExtractBlockLines(incoming, blockName);
        if (incomingLines.Count == 0) return existing;

        if (!FindBlock(existing, blockName, out int start, out int end))
        {
            return existing.TrimEnd() + "\n\n" + blockName + " {\n" + BuildMissingLines("", incomingLines, "    ") + "}\n";
        }

        string missing = BuildMissingLines(existing, incomingLines, "    ");
        if (string.IsNullOrWhiteSpace(missing)) return existing;
        return existing.Insert(end, missing);
    }

    private static List<string> ExtractBlockLines(string text, string blockName)
    {
        List<string> lines = new List<string>();
        if (!FindBlock(text, blockName, out int start, out int end)) return lines;
        string block = text.Substring(start, end - start);
        string[] raw = block.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        foreach (string r in raw)
        {
            string line = r.Trim();
            if (line == "{" || line == "}" || line.StartsWith(blockName)) continue;
            if (line.StartsWith("//")) continue;
            if (line.Length == 0) continue;
            lines.Add(line);
        }
        return lines;
    }

    private static string BuildMissingLines(string existing, List<string> incomingLines, string indent)
    {
        StringBuilder sb = new StringBuilder();
        foreach (string line in incomingLines)
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            if (ContainsSignificant(existing, line)) continue;
            sb.AppendLine(indent + line.Trim());
        }
        return sb.ToString();
    }

    private static bool FindBlock(string text, string blockName, out int start, out int endBeforeClosingBrace)
    {
        start = -1;
        endBeforeClosingBrace = -1;
        if (string.IsNullOrEmpty(text) || string.IsNullOrEmpty(blockName)) return false;

        int nameIndex = text.IndexOf(blockName, StringComparison.Ordinal);
        while (nameIndex >= 0)
        {
            bool okBefore = nameIndex == 0 || !char.IsLetterOrDigit(text[nameIndex - 1]);
            int brace = text.IndexOf('{', nameIndex + blockName.Length);
            if (okBefore && brace >= 0)
            {
                int depth = 0;
                bool inString = false;
                char quote = '\0';
                for (int i = brace; i < text.Length; i++)
                {
                    char c = text[i];
                    if ((c == '\'' || c == '"') && (i == 0 || text[i - 1] != '\\'))
                    {
                        if (!inString) { inString = true; quote = c; }
                        else if (quote == c) inString = false;
                    }
                    if (inString) continue;

                    if (c == '{') depth++;
                    else if (c == '}')
                    {
                        depth--;
                        if (depth == 0)
                        {
                            start = brace + 1;
                            endBeforeClosingBrace = i;
                            return true;
                        }
                    }
                }
            }
            nameIndex = text.IndexOf(blockName, nameIndex + blockName.Length, StringComparison.Ordinal);
        }
        return false;
    }

    private static bool ContainsSignificant(string text, string line)
    {
        if (string.IsNullOrEmpty(text) || string.IsNullOrEmpty(line)) return false;
        string a = Normalize(text);
        string b = Normalize(line);
        return a.Contains(b);
    }

    private static string ExtractLineContaining(string text, string token)
    {
        string[] lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        foreach (string line in lines)
            if (line.Contains(token)) return line.Trim();
        return "";
    }

    private static string Normalize(string value)
    {
        return (value ?? "").Replace(" ", "").Replace("\t", "").Replace("\r", "").Replace("\n", "").Replace("\"", "'");
    }
}
