using System;
using System.Text;
using System.Collections.Generic;

/// <summary>
/// JsonMergePatcher — Unity ichida tashqi NuGet ishlatmasdan oddiy JSON object merge qiladi.
/// Murakkab AST emas, lekin fabric.mod.json, pack.mcmeta, mixins.json kabi fayllarda
/// top-level keylarni saqlab, yangi keylarni qo'shish uchun yetarli.
/// </summary>
public static class JsonMergePatcher
{
    public static string Merge(string existing, string incoming)
    {
        if (string.IsNullOrWhiteSpace(existing)) return incoming ?? "";
        if (string.IsNullOrWhiteSpace(incoming)) return existing ?? "";

        Dictionary<string, string> oldMap = ParseTopLevelObject(existing);
        Dictionary<string, string> newMap = ParseTopLevelObject(incoming);
        if (oldMap.Count == 0 || newMap.Count == 0) return incoming;

        foreach (var kv in newMap)
        {
            if (!oldMap.ContainsKey(kv.Key)) oldMap[kv.Key] = kv.Value;
            else if (ShouldReplaceKey(kv.Key)) oldMap[kv.Key] = kv.Value;
        }

        return BuildObject(oldMap);
    }

    private static bool ShouldReplaceKey(string key)
    {
        if (key == null) return false;
        key = key.Trim('"');
        return key == "schemaVersion" || key == "schema_version" || key == "id" || key == "version" || key == "name" || key == "description" || key == "depends" || key == "quilt_loader" || key == "pack";
    }

    private static Dictionary<string, string> ParseTopLevelObject(string json)
    {
        Dictionary<string, string> map = new Dictionary<string, string>();
        if (string.IsNullOrWhiteSpace(json)) return map;

        int start = json.IndexOf('{');
        int end = json.LastIndexOf('}');
        if (start < 0 || end <= start) return map;

        string body = json.Substring(start + 1, end - start - 1);
        List<string> entries = SplitTopLevelEntries(body);
        foreach (string entry in entries)
        {
            int colon = FindTopLevelColon(entry);
            if (colon <= 0) continue;
            string key = entry.Substring(0, colon).Trim();
            string val = entry.Substring(colon + 1).Trim();
            if (!string.IsNullOrEmpty(key)) map[key] = val;
        }
        return map;
    }

    private static List<string> SplitTopLevelEntries(string body)
    {
        List<string> entries = new List<string>();
        StringBuilder current = new StringBuilder();
        int depth = 0;
        bool inString = false;
        bool escape = false;

        for (int i = 0; i < body.Length; i++)
        {
            char c = body[i];
            current.Append(c);

            if (escape) { escape = false; continue; }
            if (c == '\\' && inString) { escape = true; continue; }
            if (c == '"') { inString = !inString; continue; }
            if (inString) continue;

            if (c == '{' || c == '[') depth++;
            else if (c == '}' || c == ']') depth--;
            else if (c == ',' && depth == 0)
            {
                string entry = current.ToString();
                entry = entry.Substring(0, entry.Length - 1).Trim();
                if (!string.IsNullOrEmpty(entry)) entries.Add(entry);
                current.Length = 0;
            }
        }

        string last = current.ToString().Trim();
        if (!string.IsNullOrEmpty(last)) entries.Add(last);
        return entries;
    }

    private static int FindTopLevelColon(string entry)
    {
        bool inString = false;
        bool escape = false;
        int depth = 0;
        for (int i = 0; i < entry.Length; i++)
        {
            char c = entry[i];
            if (escape) { escape = false; continue; }
            if (c == '\\' && inString) { escape = true; continue; }
            if (c == '"') { inString = !inString; continue; }
            if (inString) continue;
            if (c == '{' || c == '[') depth++;
            else if (c == '}' || c == ']') depth--;
            else if (c == ':' && depth == 0) return i;
        }
        return -1;
    }

    private static string BuildObject(Dictionary<string, string> map)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        int i = 0;
        foreach (var kv in map)
        {
            string comma = i < map.Count - 1 ? "," : "";
            sb.AppendLine("  " + kv.Key + ": " + kv.Value + comma);
            i++;
        }
        sb.AppendLine("}");
        return sb.ToString();
    }
}
