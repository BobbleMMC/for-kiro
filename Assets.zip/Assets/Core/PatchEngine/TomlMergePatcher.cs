using System;
using System.Text;
using System.Collections.Generic;

public static class TomlMergePatcher
{
    public static string Merge(string existing, string incoming)
    {
        if (string.IsNullOrWhiteSpace(existing)) return incoming ?? "";
        if (string.IsNullOrWhiteSpace(incoming)) return existing ?? "";

        StringBuilder sb = new StringBuilder(existing.TrimEnd());
        sb.AppendLine();

        List<string> incomingBlocks = SplitTomlBlocks(incoming);
        foreach (string block in incomingBlocks)
        {
            string normalized = Normalize(block);
            if (string.IsNullOrEmpty(normalized)) continue;
            if (Normalize(existing).Contains(normalized)) continue;
            if (LooksLikeModHeader(block) && existing.Contains("[[mods]]")) continue;
            sb.AppendLine();
            sb.AppendLine(block.Trim());
        }
        return sb.ToString();
    }

    private static List<string> SplitTomlBlocks(string toml)
    {
        List<string> blocks = new List<string>();
        StringBuilder current = new StringBuilder();
        string[] lines = toml.Split(new[] { '\r', '\n' }, StringSplitOptions.None);
        foreach (string line in lines)
        {
            if (line.TrimStart().StartsWith("[[") && current.Length > 0)
            {
                blocks.Add(current.ToString());
                current.Length = 0;
            }
            current.AppendLine(line);
        }
        if (current.Length > 0) blocks.Add(current.ToString());
        return blocks;
    }

    private static bool LooksLikeModHeader(string block)
    {
        return block.Contains("[[mods]]") && block.Contains("modId");
    }

    private static string Normalize(string value)
    {
        return (value ?? "").Replace(" ", "").Replace("\t", "").Replace("\r", "").Replace("\n", "").Replace("\"", "'");
    }
}
