using System;
using System.Text;

public static class AppendIfMissingPatcher
{
    public static string MergeLines(string existing, string incoming)
    {
        if (string.IsNullOrWhiteSpace(existing)) return incoming ?? "";
        if (string.IsNullOrWhiteSpace(incoming)) return existing ?? "";

        StringBuilder sb = new StringBuilder(existing.TrimEnd());
        string normalizedExisting = Normalize(existing);
        string[] lines = incoming.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        foreach (string raw in lines)
        {
            string line = raw.Trim();
            if (line.Length == 0) continue;
            if (normalizedExisting.Contains(Normalize(line))) continue;
            sb.AppendLine();
            sb.Append(line);
            normalizedExisting += Normalize(line);
        }
        sb.AppendLine();
        return sb.ToString();
    }

    private static string Normalize(string value)
    {
        return (value ?? "").Replace(" ", "").Replace("\t", "").Replace("\r", "").Replace("\n", "");
    }
}
