using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class StudioBindingOrchestrationReport
{
    public string projectRoot;
    public string generatedAtUtc;
    public int moduleCount;
    public int okCount;
    public int warningCount;
    public int errorCount;
    public readonly List<StudioBindingModuleStatus> modules = new List<StudioBindingModuleStatus>();

    public void Add(StudioBindingModuleStatus status)
    {
        modules.Add(status);
        moduleCount = modules.Count;
        if (status.status == "ok") okCount++;
        else if (status.status == "warning") warningCount++;
        else errorCount++;
    }

    public string FormatText()
    {
        var sb = new StringBuilder();
        sb.AppendLine("=== Mod Studio Unified Binding Report ===");
        sb.AppendLine("Project: " + projectRoot);
        sb.AppendLine("Generated UTC: " + generatedAtUtc);
        sb.AppendLine("Modules: " + moduleCount + " | OK: " + okCount + " | Warning: " + warningCount + " | Error: " + errorCount);
        sb.AppendLine();

        foreach (var module in modules)
        {
            sb.AppendLine("[" + module.status.ToUpperInvariant() + "] " + module.displayName);
            sb.AppendLine("  Report: " + (module.reportExists ? "yes" : "no"));
            sb.AppendLine("  Field catalog: " + (module.fieldCatalogExists ? "yes" : "no"));
            sb.AppendLine("  Binding folder: " + (module.bindingFolderExists ? "yes" : "no") + " (" + module.bindingFileCount + " files)");
            if (!string.IsNullOrEmpty(module.message)) sb.AppendLine("  Message: " + module.message);
            sb.AppendLine();
        }

        return sb.ToString();
    }
}
