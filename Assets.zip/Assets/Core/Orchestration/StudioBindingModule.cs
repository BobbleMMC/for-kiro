using System;

[Serializable]
public class StudioBindingModule
{
    public string id;
    public string displayName;
    public string menuName;
    public string reportRelativePath;
    public string fieldCatalogRelativePath;
    public string bindingFolderRelativePath;
    public string generatorTypeName;
    public bool isRequired;

    public StudioBindingModule()
    {
    }

    public StudioBindingModule(string id, string displayName, string reportRelativePath, string fieldCatalogRelativePath, string bindingFolderRelativePath, string generatorTypeName, bool isRequired = true)
    {
        this.id = id;
        this.displayName = displayName;
        this.reportRelativePath = reportRelativePath;
        this.fieldCatalogRelativePath = fieldCatalogRelativePath;
        this.bindingFolderRelativePath = bindingFolderRelativePath;
        this.generatorTypeName = generatorTypeName;
        this.isRequired = isRequired;
    }
}
