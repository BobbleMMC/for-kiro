using System;

[Serializable]
public class StudioBindingModuleStatus
{
    public string moduleId;
    public string displayName;
    public string status;
    public bool reportExists;
    public bool fieldCatalogExists;
    public bool bindingFolderExists;
    public int bindingFileCount;
    public string message;

    public bool IsHealthy
    {
        get { return status == "ok" || status == "warning"; }
    }
}
