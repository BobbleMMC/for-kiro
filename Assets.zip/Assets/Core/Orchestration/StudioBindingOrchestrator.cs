using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public static class StudioBindingOrchestrator
{
    public static List<StudioBindingModule> GetDefaultModules()
    {
        return new List<StudioBindingModule>
        {
            new StudioBindingModule("block", "Block Real Binding", ".modstudio/reports/block-binding-report.txt", ".modstudio/field-bindings/block-field-catalog.json", ".modstudio/block-binding", "BlockBindingGenerator"),
            new StudioBindingModule("item", "Item Real Binding", ".modstudio/reports/item-binding-report.txt", ".modstudio/field-bindings/item-field-catalog.json", ".modstudio/item-binding", "ItemBindingGenerator"),
            new StudioBindingModule("recipe_loot_tag", "Recipe / Loot / Tag Binding", ".modstudio/reports/recipe-loot-tag-binding-report.txt", ".modstudio/field-bindings/recipe-loot-tag-field-catalog.json", ".modstudio/recipe-loot-tag-binding", "RecipeLootTagBindingGenerator"),
            new StudioBindingModule("entity_worldgen", "Entity / Worldgen Binding", ".modstudio/reports/entity-worldgen-binding-report.txt", ".modstudio/field-bindings/entity-worldgen-field-catalog.json", ".modstudio/entity-worldgen-binding", "EntityWorldgenBindingGenerator"),
            new StudioBindingModule("equipment_gameplay", "Equipment / Gameplay Binding", ".modstudio/reports/equipment-gameplay-binding-report.txt", ".modstudio/field-bindings/equipment-gameplay-field-catalog.json", ".modstudio/equipment-gameplay-binding", "EquipmentGameplayBindingGenerator"),
            new StudioBindingModule("advancement_function_config", "Advancement / Function / Config Binding", ".modstudio/reports/advancement-function-config-binding-report.txt", ".modstudio/field-bindings/advancement-function-config-field-catalog.json", ".modstudio/advancement-function-config-binding", "AdvancementFunctionConfigBindingGenerator")
        };
    }

    public static StudioBindingOrchestrationReport Analyze(string projectRoot)
    {
        var report = new StudioBindingOrchestrationReport
        {
            projectRoot = projectRoot,
            generatedAtUtc = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
        };

        if (string.IsNullOrEmpty(projectRoot) || !Directory.Exists(projectRoot))
        {
            report.Add(new StudioBindingModuleStatus
            {
                moduleId = "project",
                displayName = "Project Root",
                status = "error",
                message = "Project root topilmadi yoki noto'g'ri."
            });
            return report;
        }

        foreach (var module in GetDefaultModules())
        {
            report.Add(AnalyzeModule(projectRoot, module));
        }

        return report;
    }

    private static StudioBindingModuleStatus AnalyzeModule(string projectRoot, StudioBindingModule module)
    {
        var status = new StudioBindingModuleStatus
        {
            moduleId = module.id,
            displayName = module.displayName
        };

        string reportPath = Combine(projectRoot, module.reportRelativePath);
        string catalogPath = Combine(projectRoot, module.fieldCatalogRelativePath);
        string bindingFolder = Combine(projectRoot, module.bindingFolderRelativePath);

        status.reportExists = File.Exists(reportPath);
        status.fieldCatalogExists = File.Exists(catalogPath);
        status.bindingFolderExists = Directory.Exists(bindingFolder);
        status.bindingFileCount = status.bindingFolderExists ? Directory.GetFiles(bindingFolder, "*.json", SearchOption.AllDirectories).Length : 0;

        if (status.reportExists && status.fieldCatalogExists && status.bindingFileCount > 0)
        {
            status.status = "ok";
            status.message = "Binding output mavjud.";
        }
        else if (status.reportExists || status.fieldCatalogExists || status.bindingFileCount > 0)
        {
            status.status = "warning";
            status.message = "Binding qisman yaratilgan. Generatorni qayta ishga tushirish tavsiya qilinadi.";
        }
        else
        {
            status.status = module.isRequired ? "error" : "warning";
            status.message = "Binding output topilmadi. Tegishli Binding Generator oynasidan Generate qiling.";
        }

        return status;
    }

    public static string WriteReport(string projectRoot, StudioBindingOrchestrationReport report)
    {
        string dir = Combine(projectRoot, ".modstudio/reports");
        Directory.CreateDirectory(dir);
        string path = Path.Combine(dir, "unified-binding-report.txt");
        File.WriteAllText(path, report.FormatText(), Encoding.UTF8);

        string jsonPath = Path.Combine(dir, "unified-binding-report.json");
        File.WriteAllText(jsonPath, ToSimpleJson(report), Encoding.UTF8);
        return path;
    }

    public static string WriteRunPlan(string projectRoot)
    {
        string dir = Combine(projectRoot, ".modstudio/orchestration");
        Directory.CreateDirectory(dir);
        string path = Path.Combine(dir, "binding-run-plan.json");
        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"generatedAtUtc\": \"" + Escape(DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")) + "\",");
        sb.AppendLine("  \"modules\": [");
        var modules = GetDefaultModules();
        for (int i = 0; i < modules.Count; i++)
        {
            var m = modules[i];
            sb.AppendLine("    {");
            sb.AppendLine("      \"id\": \"" + Escape(m.id) + "\",");
            sb.AppendLine("      \"displayName\": \"" + Escape(m.displayName) + "\",");
            sb.AppendLine("      \"manualMenu\": \"Mod Studio > " + Escape(m.displayName) + " Generator...\",");
            sb.AppendLine("      \"report\": \"" + Escape(m.reportRelativePath) + "\"");
            sb.Append("    }");
            if (i < modules.Count - 1) sb.Append(",");
            sb.AppendLine();
        }
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
        return path;
    }

    private static string ToSimpleJson(StudioBindingOrchestrationReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"projectRoot\": \"" + Escape(report.projectRoot) + "\",");
        sb.AppendLine("  \"generatedAtUtc\": \"" + Escape(report.generatedAtUtc) + "\",");
        sb.AppendLine("  \"moduleCount\": " + report.moduleCount + ",");
        sb.AppendLine("  \"okCount\": " + report.okCount + ",");
        sb.AppendLine("  \"warningCount\": " + report.warningCount + ",");
        sb.AppendLine("  \"errorCount\": " + report.errorCount + ",");
        sb.AppendLine("  \"modules\": [");
        for (int i = 0; i < report.modules.Count; i++)
        {
            var m = report.modules[i];
            sb.AppendLine("    {");
            sb.AppendLine("      \"id\": \"" + Escape(m.moduleId) + "\",");
            sb.AppendLine("      \"displayName\": \"" + Escape(m.displayName) + "\",");
            sb.AppendLine("      \"status\": \"" + Escape(m.status) + "\",");
            sb.AppendLine("      \"reportExists\": " + Bool(m.reportExists) + ",");
            sb.AppendLine("      \"fieldCatalogExists\": " + Bool(m.fieldCatalogExists) + ",");
            sb.AppendLine("      \"bindingFolderExists\": " + Bool(m.bindingFolderExists) + ",");
            sb.AppendLine("      \"bindingFileCount\": " + m.bindingFileCount + ",");
            sb.AppendLine("      \"message\": \"" + Escape(m.message) + "\"");
            sb.Append("    }");
            if (i < report.modules.Count - 1) sb.Append(",");
            sb.AppendLine();
        }
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string Combine(string root, string relative)
    {
        if (string.IsNullOrEmpty(relative)) return root;
        return Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar).Replace('\\', Path.DirectorySeparatorChar));
    }

    private static string Bool(bool value)
    {
        return value ? "true" : "false";
    }

    private static string Escape(string value)
    {
        if (string.IsNullOrEmpty(value)) return "";
        return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "\\n");
    }
}
