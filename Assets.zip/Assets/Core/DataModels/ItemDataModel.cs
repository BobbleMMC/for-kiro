using System;

[System.Serializable]
public class ItemDataModel
{
    public string itemId = "custom_ruby";
    public string displayName = "Ruby";
    public int stackSize = 64;
    public bool isFood = false;
    public MinecraftCreativeTab creativeTab = MinecraftCreativeTab.Misc;
    public string textureNamespace = "mymod";

    // 11-patch: professional item editor settings
    public AdvancedItemSettings advanced = new AdvancedItemSettings();

    public void EnsureAdvancedSettings()
    {
        if (advanced == null) advanced = new AdvancedItemSettings();
        advanced.NormalizeLegacy(this);
    }

    public string GenerateFabricCode()
    {
        EnsureAdvancedSettings();
        string upperId = itemId.ToUpper();
        string foodSettings = (isFood || advanced.food.enabled)
            ? $"\n            .food(new FoodComponent.Builder().hunger({advanced.food.nutrition}).saturationModifier({advanced.food.saturation}f).build())"
            : "";
        string durabilitySettings = advanced.maxDamage > 0 ? $"\n            .maxDamage({advanced.maxDamage})" : "";
        string fireproofSettings = advanced.fireproof ? "\n            .fireproof()" : "";
        
        return $@"package net.mymod.item;

import net.fabricmc.api.ModInitializer;
import net.minecraft.item.Item;
import net.minecraft.item.FoodComponent;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems implements ModInitializer {{

    // {displayName} elementi deklaratsiyasi
    public static final Item {upperId} = registerItem(""{itemId}"", 
        new Item(new Item.Settings()
            .maxCount({stackSize}){durabilitySettings}{fireproofSettings}{foodSettings}
        ));

    private static Item registerItem(String name, Item item) {{
        return Registry.register(Registries.ITEM, new Identifier(""{textureNamespace}"", name), item);
    }}

    @Override
    public void onInitialize() {{
        // {displayName} o'yinga muvaffaqiyatli yuklandi
    }}
}}";
    }

    public string GenerateLanguageJson()
    {
        return $@"{{
  ""item.{textureNamespace}.{itemId}"": ""{displayName}""
}}";
    }

    public string GenerateItemModelJson()
    {
        EnsureAdvancedSettings();
        string parent = advanced.visual.modelType == StudioItemModelType.Handheld ? "minecraft:item/handheld" : "minecraft:item/generated";
        string texture = string.IsNullOrEmpty(advanced.visual.texturePath) ? itemId : advanced.visual.texturePath;
        return $@"{{
  ""parent"": ""{parent}"",
  ""textures"": {{
    ""layer0"": ""{textureNamespace}:item/{texture}""
  }}
}}";
    }
}
