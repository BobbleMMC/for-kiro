using System;
using System.IO;
using System.Collections.Generic;

// Creative rejimdagi papkalar (Tabs) ro'yxati
public enum MinecraftCreativeTab
{
    BuildingBlocks,
    Decorations,
    Redstone,
    Transportation,
    Misc
}

[System.Serializable]
public class BlockDataModel
{
    // 1. Blokning asosiy xususiyatlari
    public string blockId = "custom_ruby_block";
    public string displayName = "Ruby Block";
    public float hardness = 5.0f;
    public float resistance = 6.0f;
    public int lightLevel = 0;
    public MinecraftCreativeTab creativeTab = MinecraftCreativeTab.BuildingBlocks;
    
    // Tekstura yo'li (masalan: "modid:block/custom_ruby_block")
    public string textureNamespace = "mymod";
    public string texturePath = "custom_ruby_block";

    // 11-patch: professional block editor settings
    public AdvancedBlockSettings advanced = new AdvancedBlockSettings();

    public void EnsureAdvancedSettings()
    {
        if (advanced == null) advanced = new AdvancedBlockSettings();
        advanced.NormalizeLegacy(this);
    }

    // 2. Blockstates JSON generatsiyasi
    public string GenerateBlockstatesJson()
    {
        return $@"{{
  ""variants"": {{
    """": {{ ""model"": ""{textureNamespace}:block/{blockId}"" }}
  }}
}}";
    }

    // 3. Block Model JSON generatsiyasi (Standart Kub shakli uchun)
    public string GenerateBlockModelJson()
    {
        EnsureAdvancedSettings();
        string sideTexture = string.IsNullOrEmpty(advanced.visual.sideTexture) ? texturePath : advanced.visual.sideTexture;
        string topTexture = string.IsNullOrEmpty(advanced.visual.topTexture) ? sideTexture : advanced.visual.topTexture;
        string bottomTexture = string.IsNullOrEmpty(advanced.visual.bottomTexture) ? sideTexture : advanced.visual.bottomTexture;

        if (!string.IsNullOrEmpty(advanced.visual.customModelJsonPath))
        {
            return $@"{{
  ""parent"": ""minecraft:block/cube_all"",
  ""textures"": {{
    ""all"": ""{textureNamespace}:block/{sideTexture}""
  }},
  ""modstudio_note"": ""Custom model path: {advanced.visual.customModelJsonPath}""
}}";
        }

        if (topTexture != sideTexture || bottomTexture != sideTexture)
        {
            return $@"{{
  ""parent"": ""minecraft:block/cube_bottom_top"",
  ""textures"": {{
    ""side"": ""{textureNamespace}:block/{sideTexture}"",
    ""top"": ""{textureNamespace}:block/{topTexture}"",
    ""bottom"": ""{textureNamespace}:block/{bottomTexture}""
  }}
}}";
        }

        return $@"{{
  ""parent"": ""minecraft:block/cube_all"",
  ""textures"": {{
    ""all"": ""{textureNamespace}:block/{sideTexture}""
  }}
}}";
    }

    // 4. Item Model JSON generatsiyasi (Inventarda blok ko'rinishi)
    public string GenerateItemModelJson()
    {
        return $@"{{
  ""parent"": ""{textureNamespace}:block/{blockId}""
}}";
    }

    // 5. Mod Manifesti va Til fayli uchun (en_us.json)
    public string GenerateLanguageJson()
    {
        return $@"{{
  ""block.{textureNamespace}.{blockId}"": ""{displayName}""
}}";
    }
}
