using System;
using System.Collections.Generic;

[System.Serializable]
public class WorkspaceData
{
    public StudioProject studioProject = new StudioProject();

    public string modId = "mymod";
    public string modName = "My Epic Mod";
    public string mcVersion = "1.20.1";
    public string modloader = "Fabric";

    public List<BlockDataModel> blocks = new List<BlockDataModel>();
    public List<ItemDataModel> items = new List<ItemDataModel>();
    public List<ToolDataModel> tools = new List<ToolDataModel>();
    public List<ArmorDataModel> armors = new List<ArmorDataModel>();
    public List<RecipeDataModel> recipes = new List<RecipeDataModel>();
    public List<LootTableDataModel> lootTables = new List<LootTableDataModel>();
    public List<TagDataModel> tags = new List<TagDataModel>();
    public List<EntityDataModel> entities = new List<EntityDataModel>();
    public List<BiomeDataModel> biomes = new List<BiomeDataModel>();

    public List<DimensionDataModel> dimensions = new List<DimensionDataModel>();
    public List<StructureDataModel> structures = new List<StructureDataModel>();

    public List<ScreenDataModel> screens = new List<ScreenDataModel>();
    public List<ConfigDataModel> configs = new List<ConfigDataModel>();

    public List<NetworkPacketDataModel> networkPackets = new List<NetworkPacketDataModel>();
    public List<KeybindDataModel> keybinds = new List<KeybindDataModel>();

    // 32-patch: Advancement + Function real binding models.
    public List<AdvancementDataModel> advancements = new List<AdvancementDataModel>();
    public List<FunctionDataModel> functions = new List<FunctionDataModel>();

    public List<CreativeTabDataModel> creativeTabs = new List<CreativeTabDataModel>();
}
