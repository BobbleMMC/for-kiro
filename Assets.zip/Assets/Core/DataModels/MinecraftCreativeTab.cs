using System;

// Shared creative tab enum used by Block/Item/Tool/Armor data models.
public enum MinecraftCreativeTab
{
    BuildingBlocks,
    Decorations,
    Redstone,
    Transportation,
    Misc
}
