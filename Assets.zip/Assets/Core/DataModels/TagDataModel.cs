using System;
using System.Text;
using System.Collections.Generic;

public enum StudioTagTargetType
{
    Blocks,
    Items,
    EntityTypes,
    Biomes,
    Fluids,
    DamageTypes,
    Functions
}

[Serializable]
public class TagDataModel
{
    public string tagId = "custom_tag";
    public string displayName = "Custom Tag";
    public StudioTagTargetType targetType = StudioTagTargetType.Items;
    public string namespaceId = "minecraft";
    public bool replace = false;
    public bool enabled = true;
    public List<string> values = new List<string>();
    public string valuesCsv = "";
    public string customJsonOverride = "";
    public string notes = "";

    public void SyncValuesFromCsv()
    {
        if (values == null) values = new List<string>();
        if (string.IsNullOrWhiteSpace(valuesCsv)) return;
        values.Clear();
        string[] parts = valuesCsv.Split(new[] { ',', '\n', '\r', ';' }, StringSplitOptions.RemoveEmptyEntries);
        foreach (string p in parts)
        {
            string v = p.Trim();
            if (!string.IsNullOrEmpty(v) && !values.Contains(v)) values.Add(v);
        }
    }

    public string GetRelativePath(string modId)
    {
        string ns = string.IsNullOrWhiteSpace(namespaceId) ? (string.IsNullOrWhiteSpace(modId) ? "mymod" : modId.Trim()) : namespaceId.Trim();
        string folder = TargetToFolder(targetType);
        string id = SanitizeTagId(tagId);
        return $"{ns}/tags/{folder}/{id}.json";
    }

    public string GenerateJson(string modId)
    {
        if (!string.IsNullOrWhiteSpace(customJsonOverride)) return customJsonOverride;
        SyncValuesFromCsv();
        if (values == null) values = new List<string>();

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine($"  \"replace\": {(replace ? "true" : "false")},");
        sb.AppendLine("  \"values\": [");
        for (int i = 0; i < values.Count; i++)
        {
            string comma = i < values.Count - 1 ? "," : "";
            sb.AppendLine($"    \"{NormalizeValue(values[i], modId)}\"{comma}");
        }
        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    public string GeneratePreview(string modId)
    {
        return GenerateJson(modId);
    }

    private static string TargetToFolder(StudioTagTargetType target)
    {
        switch (target)
        {
            case StudioTagTargetType.Blocks: return "blocks";
            case StudioTagTargetType.EntityTypes: return "entity_types";
            case StudioTagTargetType.Biomes: return "worldgen/biome";
            case StudioTagTargetType.Fluids: return "fluids";
            case StudioTagTargetType.DamageTypes: return "damage_type";
            case StudioTagTargetType.Functions: return "functions";
            default: return "items";
        }
    }

    private static string NormalizeValue(string raw, string modId)
    {
        if (string.IsNullOrWhiteSpace(raw)) return "minecraft:air";
        raw = raw.Trim();
        if (raw.StartsWith("#") || raw.Contains(":")) return raw;
        return $"{(string.IsNullOrWhiteSpace(modId) ? "mymod" : modId)}:{raw}";
    }

    private static string SanitizeTagId(string id)
    {
        if (string.IsNullOrWhiteSpace(id)) return "tag";
        id = id.Trim();
        if (id.Contains(":")) id = id.Substring(id.IndexOf(':') + 1);
        foreach (char c in System.IO.Path.GetInvalidFileNameChars()) id = id.Replace(c, '_');
        return id.ToLowerInvariant().Replace(' ', '_');
    }
}
