using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

public enum StudioLootTableType
{
    Block,
    Entity,
    Chest,
    Gameplay,
    Custom
}

public enum StudioLootEntryType
{
    Item,
    Tag,
    LootTable,
    Empty
}

[Serializable]
public class LootPoolSettings
{
    public int rolls = 1;
    public float bonusRolls = 0f;
    public StudioLootEntryType entryType = StudioLootEntryType.Item;
    public string entryId = "minecraft:diamond";
    public int minCount = 1;
    public int maxCount = 1;
    public int weight = 1;
    public bool survivesExplosion = true;
    public bool applyFortune = false;
    public bool silkTouchAlternative = false;
    public string customConditionJson = "";
    public string customFunctionJson = "";
}

[Serializable]
public class LootTableDataModel
{
    public string lootId = "custom_loot";
    public string displayName = "Custom Loot";
    public StudioLootTableType lootType = StudioLootTableType.Block;
    public string targetId = "custom_block";
    public bool enabled = true;
    public bool replaceGeneratedDefault = false;
    public List<LootPoolSettings> pools = new List<LootPoolSettings> { new LootPoolSettings() };
    public string customJsonOverride = "";
    public string notes = "";

    public string GetRelativePath(string modId)
    {
        string ns = SafeNamespace(modId);
        string id = !string.IsNullOrWhiteSpace(lootId) ? lootId : targetId;
        id = SanitizeFileId(id);

        switch (lootType)
        {
            case StudioLootTableType.Block:
                return ns + "/loot_tables/blocks/" + id + ".json";
            case StudioLootTableType.Entity:
                return ns + "/loot_tables/entities/" + id + ".json";
            case StudioLootTableType.Chest:
                return ns + "/loot_tables/chests/" + id + ".json";
            case StudioLootTableType.Gameplay:
                return ns + "/loot_tables/gameplay/" + id + ".json";
            default:
                return ns + "/loot_tables/" + id + ".json";
        }
    }

    public string GenerateJson(string modId)
    {
        if (!string.IsNullOrWhiteSpace(customJsonOverride))
        {
            return customJsonOverride.Trim();
        }

        string tableType = lootType == StudioLootTableType.Block ? "minecraft:block" : "minecraft:generic";
        List<LootPoolSettings> safePools = pools == null || pools.Count == 0
            ? new List<LootPoolSettings> { new LootPoolSettings() }
            : pools;

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"type\": \"" + EscapeJson(tableType) + "\",");
        sb.AppendLine("  \"pools\": [");

        for (int i = 0; i < safePools.Count; i++)
        {
            LootPoolSettings pool = safePools[i] ?? new LootPoolSettings();
            AppendPoolJson(sb, pool, modId, i < safePools.Count - 1);
        }

        sb.AppendLine("  ]");
        sb.AppendLine("}");
        return sb.ToString();
    }

    public string GeneratePreview(string modId)
    {
        return GenerateJson(modId);
    }

    private static void AppendPoolJson(StringBuilder sb, LootPoolSettings pool, string modId, bool addComma)
    {
        int rolls = Math.Max(1, pool.rolls);
        string bonusRolls = pool.bonusRolls.ToString("0.###", CultureInfo.InvariantCulture);

        sb.AppendLine("    {");
        sb.AppendLine("      \"rolls\": " + rolls + ",");
        sb.AppendLine("      \"bonus_rolls\": " + bonusRolls + ",");
        sb.AppendLine("      \"entries\": [");
        sb.AppendLine("        {");
        sb.AppendLine("          \"type\": \"" + EntryTypeToJson(pool.entryType) + "\"");

        if (pool.entryType == StudioLootEntryType.Item ||
            pool.entryType == StudioLootEntryType.Tag ||
            pool.entryType == StudioLootEntryType.LootTable)
        {
            sb.AppendLine(",");
            sb.AppendLine("          \"name\": \"" + EscapeJson(FormatId(pool.entryId, modId)) + "\"");
        }

        if (pool.weight > 1)
        {
            sb.AppendLine(",");
            sb.AppendLine("          \"weight\": " + pool.weight);
        }

        sb.AppendLine("        }");
        sb.AppendLine("      ]");

        List<string> functions = BuildFunctions(pool);
        if (functions.Count > 0)
        {
            sb.AppendLine(",");
            sb.AppendLine("      \"functions\": [");
            for (int i = 0; i < functions.Count; i++)
            {
                sb.AppendLine("        " + functions[i] + (i < functions.Count - 1 ? "," : ""));
            }
            sb.AppendLine("      ]");
        }

        List<string> conditions = BuildConditions(pool);
        if (conditions.Count > 0)
        {
            sb.AppendLine(",");
            sb.AppendLine("      \"conditions\": [");
            for (int i = 0; i < conditions.Count; i++)
            {
                sb.AppendLine("        " + conditions[i] + (i < conditions.Count - 1 ? "," : ""));
            }
            sb.AppendLine("      ]");
        }

        sb.AppendLine("    }" + (addComma ? "," : ""));
    }

    private static List<string> BuildFunctions(LootPoolSettings pool)
    {
        List<string> functions = new List<string>();
        int min = Math.Max(0, pool.minCount);
        int max = Math.Max(min, pool.maxCount);

        if (min != 1 || max != 1)
        {
            if (min == max)
            {
                functions.Add("{ \"function\": \"minecraft:set_count\", \"count\": " + min + " }");
            }
            else
            {
                functions.Add("{ \"function\": \"minecraft:set_count\", \"count\": { \"type\": \"minecraft:uniform\", \"min\": " + min + ".0, \"max\": " + max + ".0 } }");
            }
        }

        if (pool.applyFortune)
        {
            functions.Add("{ \"function\": \"minecraft:apply_bonus\", \"enchantment\": \"minecraft:fortune\", \"formula\": \"minecraft:ore_drops\" }");
        }

        if (pool.survivesExplosion)
        {
            functions.Add("{ \"function\": \"minecraft:explosion_decay\" }");
        }

        if (!string.IsNullOrWhiteSpace(pool.customFunctionJson))
        {
            functions.Add(pool.customFunctionJson.Trim());
        }

        return functions;
    }

    private static List<string> BuildConditions(LootPoolSettings pool)
    {
        List<string> conditions = new List<string>();

        if (pool.survivesExplosion)
        {
            conditions.Add("{ \"condition\": \"minecraft:survives_explosion\" }");
        }

        if (pool.silkTouchAlternative)
        {
            conditions.Add("{ \"condition\": \"minecraft:match_tool\", \"predicate\": { \"enchantments\": [ { \"enchantment\": \"minecraft:silk_touch\", \"levels\": { \"min\": 1 } } ] } }");
        }

        if (!string.IsNullOrWhiteSpace(pool.customConditionJson))
        {
            conditions.Add(pool.customConditionJson.Trim());
        }

        return conditions;
    }

    private static string EntryTypeToJson(StudioLootEntryType type)
    {
        switch (type)
        {
            case StudioLootEntryType.Tag:
                return "minecraft:tag";
            case StudioLootEntryType.LootTable:
                return "minecraft:loot_table";
            case StudioLootEntryType.Empty:
                return "minecraft:empty";
            default:
                return "minecraft:item";
        }
    }

    private static string FormatId(string rawId, string modId)
    {
        if (string.IsNullOrWhiteSpace(rawId))
        {
            return "minecraft:air";
        }

        string id = rawId.Trim();
        if (id.Contains(":"))
        {
            return id;
        }

        return SafeNamespace(modId) + ":" + id;
    }

    private static string SafeNamespace(string modId)
    {
        return string.IsNullOrWhiteSpace(modId) ? "mymod" : modId.Trim().ToLowerInvariant().Replace(' ', '_');
    }

    private static string SanitizeFileId(string id)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            return "loot";
        }

        string clean = id.Trim();
        if (clean.Contains(":"))
        {
            clean = clean.Substring(clean.IndexOf(':') + 1);
        }

        foreach (char invalid in Path.GetInvalidFileNameChars())
        {
            clean = clean.Replace(invalid, '_');
        }

        return clean.ToLowerInvariant().Replace(' ', '_');
    }

    private static string EscapeJson(string value)
    {
        if (value == null)
        {
            return "";
        }

        return value.Replace("\\", "\\\\").Replace("\"", "\\\"");
    }
}
