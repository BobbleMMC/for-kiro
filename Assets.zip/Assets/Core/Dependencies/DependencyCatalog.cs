using System;
using System.Collections.Generic;

/// <summary>
/// Offline dependency catalog. Keyingi patchlarda bu JSON catalog yoki online cache bo'ladi.
/// </summary>
public static class DependencyCatalog
{
    private static List<DependencyCatalogEntry> _entries;

    public static List<DependencyCatalogEntry> Entries
    {
        get
        {
            if (_entries == null) _entries = BuildDefaultCatalog();
            return _entries;
        }
    }

    public static DependencyCatalogEntry Find(string id)
    {
        return Entries.Find(e => e.id == id);
    }

    public static List<DependencyCatalogEntry> FindByFeatureTrigger(string trigger)
    {
        var list = new List<DependencyCatalogEntry>();
        foreach (var entry in Entries)
        {
            if (entry.featureTriggers != null && entry.featureTriggers.Contains(trigger))
                list.Add(entry);
        }
        return list;
    }

    private static List<DependencyCatalogEntry> BuildDefaultCatalog()
    {
        return new List<DependencyCatalogEntry>
        {
            new DependencyCatalogEntry
            {
                id = "fabric-api",
                name = "Fabric API",
                supportedLoaders = new List<string> { "Fabric" },
                featureTriggers = new List<string> { "base", "item", "block", "recipe", "entity", "biome", "datagen" },
                fabricGradleNotation = "net.fabricmc.fabric-api:fabric-api:${project.fabric_version}",
                requiredByDefault = true,
                description = "Fabric registry, events, item group va datagen uchun asosiy API."
            },
            new DependencyCatalogEntry
            {
                id = "quilt-standard-libraries",
                name = "Quilt Standard Libraries",
                supportedLoaders = new List<string> { "Quilt" },
                featureTriggers = new List<string> { "base", "item", "block", "recipe", "entity", "biome" },
                quiltGradleNotation = "org.quiltmc:qsl:${project.qsl_version}",
                requiredByDefault = true,
                description = "Quilt modlari uchun standart kutubxonalar."
            },
            new DependencyCatalogEntry
            {
                id = "neoforge",
                name = "NeoForge",
                supportedLoaders = new List<string> { "NeoForge" },
                featureTriggers = new List<string> { "base", "item", "block", "recipe", "entity", "biome" },
                neoForgeGradleNotation = "net.neoforged:neoforge:${project.neoforge_version}",
                requiredByDefault = true,
                description = "NeoForge userdev dependency."
            },
            new DependencyCatalogEntry
            {
                id = "geckolib",
                name = "GeckoLib",
                supportedLoaders = new List<string> { "Fabric", "NeoForge", "Forge" },
                featureTriggers = new List<string> { "animated_entity", "animated_armor", "animated_item" },
                fabricGradleNotation = "software.bernie.geckolib:geckolib-fabric-${project.minecraft_version}:recommended",
                neoForgeGradleNotation = "software.bernie.geckolib:geckolib-neoforge-${project.minecraft_version}:recommended",
                repository = "https://dl.cloudsmith.io/public/geckolib3/geckolib/maven/",
                description = "Entity, item va armor animatsiyalari uchun."
            },
            new DependencyCatalogEntry
            {
                id = "cloth-config",
                name = "Cloth Config",
                supportedLoaders = new List<string> { "Fabric", "Forge", "NeoForge" },
                featureTriggers = new List<string> { "config_screen" },
                fabricGradleNotation = "me.shedaniel.cloth:cloth-config-fabric:recommended",
                repository = "https://maven.shedaniel.me/",
                description = "Config UI yaratish uchun."
            },
            new DependencyCatalogEntry
            {
                id = "modmenu",
                name = "Mod Menu",
                supportedLoaders = new List<string> { "Fabric" },
                featureTriggers = new List<string> { "config_screen" },
                fabricGradleNotation = "com.terraformersmc:modmenu:recommended",
                repository = "https://maven.terraformersmc.com/releases/",
                description = "Fabric mod sozlamalarini Mod Menu orqali ochish uchun."
            }
        };
    }
}
