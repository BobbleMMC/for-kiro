using System;
using System.Text;
using System.Collections.Generic;

[Serializable]
public class DependencyResolutionResult
{
    public List<StudioProjectDependency> dependencies = new List<StudioProjectDependency>();
    public List<string> repositories = new List<string>();
    public List<CompatibilityIssue> issues = new List<CompatibilityIssue>();

    public int RequiredCount
    {
        get
        {
            int count = 0;
            foreach (var d in dependencies)
                if (d != null && d.required) count++;
            return count;
        }
    }

    public void AddDependency(StudioProjectDependency dep)
    {
        if (dep == null || string.IsNullOrEmpty(dep.id)) return;
        if (dependencies.Exists(d => d.id == dep.id)) return;
        dependencies.Add(dep);
    }

    public void AddRepository(string repository)
    {
        if (string.IsNullOrEmpty(repository)) return;
        if (!repositories.Contains(repository)) repositories.Add(repository);
    }

    public string Format()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"─── Dependency Resolver: {dependencies.Count} dependency, {repositories.Count} repository ───");
        foreach (var d in dependencies)
        {
            string req = d.required ? "required" : "optional";
            sb.AppendLine($"• {d.id} ({req}) {d.version} — {d.reason}");
        }
        foreach (var issue in issues)
            sb.AppendLine(issue.ToString());
        return sb.ToString();
    }
}
