using System;
using System.Collections.Generic;

/// <summary>
/// StudioDependencyResolver — workspace featurelariga qarab dependencylarni tanlaydi.
/// Hozir basic: base loader API + feature triggerlar.
/// Keyingi patchlarda Gradle merge va conflict resolver bilan ulanadi.
/// </summary>
public static class StudioDependencyResolver
{
    public static DependencyResolutionResult ResolveForWorkspace(WorkspaceData workspace, ResolvedVersionSet resolved)
    {
        var result = new DependencyResolutionResult();
        if (workspace == null)
        {
            result.issues.Add(new CompatibilityIssue(CompatibilitySeverity.Error, "dependency-workspace-null", "Dependencies", "Workspace bo'sh."));
            return result;
        }

        if (resolved == null) resolved = VersionResolver.Resolve(workspace);
        string loader = resolved.loader;
        string mcVersion = resolved.minecraftVersion;

        AddBaseDependency(result, loader, mcVersion, resolved);
        AddFeatureDependencies(result, workspace, loader, mcVersion, resolved);
        ValidateDependencySupport(result, loader);
        DetectDuplicates(result);

        return result;
    }

    public static void ApplyToProject(StudioProject project, DependencyResolutionResult resolution)
    {
        if (project == null || resolution == null) return;
        if (project.dependencies == null) project.dependencies = new List<StudioProjectDependency>();
        project.dependencies.Clear();
        project.dependencies.AddRange(resolution.dependencies);
        project.dependencyRepositories = resolution.repositories != null ? new List<string>(resolution.repositories) : new List<string>();
    }

    public static string GetGradleNotation(StudioProjectDependency dependency, string loader)
    {
        if (dependency == null) return "";
        if (!string.IsNullOrEmpty(dependency.gradleNotation)) return dependency.gradleNotation;

        DependencyCatalogEntry entry = DependencyCatalog.Find(dependency.id);
        if (entry == null) return "";

        if (loader == "Fabric") return entry.fabricGradleNotation;
        if (loader == "NeoForge") return entry.neoForgeGradleNotation;
        if (loader == "Quilt") return entry.quiltGradleNotation;
        return "";
    }

    private static void AddBaseDependency(DependencyResolutionResult result, string loader, string mcVersion, ResolvedVersionSet resolved)
    {
        if (loader == "Fabric")
        {
            result.AddDependency(new StudioProjectDependency
            {
                id = "fabric-api",
                name = "Fabric API",
                version = resolved.apiVersion,
                loader = loader,
                minecraftVersion = mcVersion,
                gradleNotation = "net.fabricmc.fabric-api:fabric-api:${project.fabric_version}",
                required = true,
                reason = "Base registry, lifecycle, item group va datagen API."
            });
        }
        else if (loader == "Quilt")
        {
            result.AddDependency(new StudioProjectDependency
            {
                id = "quilt-standard-libraries",
                name = "Quilt Standard Libraries",
                version = resolved.apiVersion,
                loader = loader,
                minecraftVersion = mcVersion,
                gradleNotation = "org.quiltmc:qsl:${project.qsl_version}",
                required = true,
                reason = "Quilt base API."
            });
        }
        else if (loader == "NeoForge")
        {
            result.AddDependency(new StudioProjectDependency
            {
                id = "neoforge",
                name = "NeoForge",
                version = resolved.loaderVersion,
                loader = loader,
                minecraftVersion = mcVersion,
                gradleNotation = "net.neoforged:neoforge:${project.neoforge_version}",
                required = true,
                reason = "NeoForge userdev base dependency."
            });
        }
        else
        {
            result.issues.Add(new CompatibilityIssue(CompatibilitySeverity.Warning, "unknown-loader-base-dep", "Dependencies", $"{loader} uchun base dependency aniqlanmadi."));
        }
    }

    private static void AddFeatureDependencies(DependencyResolutionResult result, WorkspaceData workspace, string loader, string mcVersion, ResolvedVersionSet resolved)
    {
        // Hozir entity generator oddiy entitylar uchun tashqi dependency talab qilmaydi.
        // Lekin animatsiya/model advanced bo'lsa GeckoLib kerak bo'lishi mumkin.
        if (workspace.entities != null && workspace.entities.Count > 0)
        {
            result.issues.Add(new CompatibilityIssue(
                CompatibilitySeverity.Info,
                "entity-advanced-animation-note",
                "Dependencies",
                "Entity qo'shilgan. Agar animatsiyali model kerak bo'lsa, GeckoLib dependency qo'shiladi.",
                "MVP 1.2 da Entity editorga 'Animated model' toggle qo'shish kerak."));
        }

        if (workspace.biomes != null && workspace.biomes.Count > 0 && loader == "Fabric")
        {
            // Fabric API allaqachon base sifatida bor; faqat sababni boyitamiz.
            StudioProjectDependency fapi = result.dependencies.Find(d => d.id == "fabric-api");
            if (fapi != null && !fapi.reason.Contains("worldgen"))
                fapi.reason += " Worldgen/biome datagen uchun ham kerak.";
        }
    }

    private static void ValidateDependencySupport(DependencyResolutionResult result, string loader)
    {
        foreach (var dep in result.dependencies)
        {
            DependencyCatalogEntry entry = DependencyCatalog.Find(dep.id);
            if (entry == null) continue;
            if (entry.supportedLoaders != null && entry.supportedLoaders.Count > 0 && !entry.supportedLoaders.Contains(loader))
            {
                result.issues.Add(new CompatibilityIssue(
                    CompatibilitySeverity.Error,
                    "dependency-loader-mismatch",
                    "Dependencies",
                    $"{dep.id} dependency {loader} loaderini qo'llab-quvvatlamaydi.",
                    $"Qo'llab-quvvatlanadigan loaderlar: {string.Join(", ", entry.supportedLoaders)}"));
            }

            if (!string.IsNullOrEmpty(entry.repository))
                result.AddRepository(entry.repository);
        }
    }

    private static void DetectDuplicates(DependencyResolutionResult result)
    {
        var seen = new HashSet<string>();
        foreach (var dep in result.dependencies)
        {
            if (dep == null || string.IsNullOrEmpty(dep.id)) continue;
            if (seen.Contains(dep.id))
            {
                result.issues.Add(new CompatibilityIssue(
                    CompatibilitySeverity.Warning,
                    "duplicate-dependency",
                    "Dependencies",
                    $"{dep.id} dependency ikki marta qo'shilgan."));
            }
            else
            {
                seen.Add(dep.id);
            }
        }
    }
}
