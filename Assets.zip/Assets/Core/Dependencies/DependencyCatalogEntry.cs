using System;
using System.Collections.Generic;

[Serializable]
public class DependencyCatalogEntry
{
    public string id = "";
    public string name = "";
    public List<string> supportedLoaders = new List<string>();
    public List<string> featureTriggers = new List<string>();
    public string fabricGradleNotation = "";
    public string neoForgeGradleNotation = "";
    public string quiltGradleNotation = "";
    public string repository = "";
    public bool requiredByDefault = false;
    public string description = "";
}
