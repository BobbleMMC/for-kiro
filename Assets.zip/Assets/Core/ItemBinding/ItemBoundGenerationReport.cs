using System;
using System.Collections.Generic;
using System.Text;

[Serializable]
public class ItemBoundGenerationReport
{
    public string modId = "mymod";
    public string loader = "fabric";
    public string projectRoot = "";
    public int scannedItems;
    public int generatedFiles;
    public int skippedFiles;
    public int backedUpFiles;
    public readonly List<ItemBindingIssue> issues = new List<ItemBindingIssue>();
    public readonly List<string> generatedPaths = new List<string>();
    public readonly List<string> skippedPaths = new List<string>();

    public void AddIssue(string severity, string itemId, string fieldId, string message, string suggestion = "")
    {
        issues.Add(new ItemBindingIssue(severity, itemId, fieldId, message, suggestion));
    }

    public bool HasErrors()
    {
        for (int i = 0; i < issues.Count; i++)
        {
            if (string.Equals(issues[i].severity, "error", StringComparison.OrdinalIgnoreCase)) return true;
        }
        return false;
    }

    public string Format()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("=== Item Real Binding Report ===");
        sb.AppendLine("Project: " + projectRoot);
        sb.AppendLine("ModId: " + modId + " | Loader: " + loader);
        sb.AppendLine("Items scanned: " + scannedItems);
        sb.AppendLine("Generated files: " + generatedFiles);
        sb.AppendLine("Skipped files: " + skippedFiles);
        sb.AppendLine("Backed up files: " + backedUpFiles);
        sb.AppendLine("Issues: " + issues.Count);
        sb.AppendLine();

        if (issues.Count > 0)
        {
            sb.AppendLine("-- Issues --");
            foreach (ItemBindingIssue issue in issues) sb.AppendLine(issue.ToString());
            sb.AppendLine();
        }

        if (generatedPaths.Count > 0)
        {
            sb.AppendLine("-- Generated --");
            foreach (string path in generatedPaths) sb.AppendLine(path);
            sb.AppendLine();
        }

        if (skippedPaths.Count > 0)
        {
            sb.AppendLine("-- Skipped --");
            foreach (string path in skippedPaths) sb.AppendLine(path);
            sb.AppendLine();
        }

        return sb.ToString();
    }
}
