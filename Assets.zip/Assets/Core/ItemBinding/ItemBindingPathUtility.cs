using System;
using System.IO;
using System.Text;

public static class ItemBindingPathUtility
{
    public static string NormalizeResourceId(string value, string fallback)
    {
        if (string.IsNullOrEmpty(value)) value = fallback;
        value = value.Trim().ToLowerInvariant();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < value.Length; i++)
        {
            char c = value[i];
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '/') sb.Append(c);
            else if (c == ' ' || c == '.') sb.Append('_');
        }
        string result = sb.ToString().Trim('_', '/', '-');
        return string.IsNullOrEmpty(result) ? fallback : result;
    }

    public static string SanitizeModId(string value)
    {
        string id = NormalizeResourceId(value, "mymod").Replace("/", "_").Replace("-", "_");
        if (id.Length == 0) return "mymod";
        if (!(id[0] >= 'a' && id[0] <= 'z')) id = "mod_" + id;
        return id;
    }

    public static string SafeCombineUnderRoot(string root, params string[] parts)
    {
        if (string.IsNullOrEmpty(root)) throw new InvalidOperationException("Project root is empty.");
        string full = Path.GetFullPath(root);
        for (int i = 0; i < parts.Length; i++) full = Path.Combine(full, parts[i].Replace('/', Path.DirectorySeparatorChar));
        full = Path.GetFullPath(full);
        string normalizedRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (!full.StartsWith(normalizedRoot, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("Path sandbox violation: " + full);
        }
        return full;
    }

    public static string ToJavaClassName(string id, string suffix)
    {
        id = NormalizeResourceId(id, "custom_item").Replace('/', '_').Replace('-', '_');
        string[] parts = id.Split('_');
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.Length; i++)
        {
            if (string.IsNullOrEmpty(parts[i])) continue;
            sb.Append(char.ToUpperInvariant(parts[i][0]));
            if (parts[i].Length > 1) sb.Append(parts[i].Substring(1));
        }
        if (sb.Length == 0) sb.Append("CustomItem");
        if (!string.IsNullOrEmpty(suffix) && !sb.ToString().EndsWith(suffix, StringComparison.OrdinalIgnoreCase)) sb.Append(suffix);
        return sb.ToString();
    }

    public static string EscapeJson(string s)
    {
        if (s == null) return "";
        return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "");
    }
}
