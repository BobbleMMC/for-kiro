using System;

[Serializable]
public class ItemBindingIssue
{
    public string severity = "warning";
    public string itemId = "";
    public string fieldId = "";
    public string message = "";
    public string suggestion = "";

    public ItemBindingIssue() { }

    public ItemBindingIssue(string severity, string itemId, string fieldId, string message, string suggestion = "")
    {
        this.severity = severity;
        this.itemId = itemId;
        this.fieldId = fieldId;
        this.message = message;
        this.suggestion = suggestion;
    }

    public override string ToString()
    {
        string s = "[" + severity.ToUpperInvariant() + "]";
        if (!string.IsNullOrEmpty(itemId)) s += " " + itemId;
        if (!string.IsNullOrEmpty(fieldId)) s += " | " + fieldId;
        s += " - " + message;
        if (!string.IsNullOrEmpty(suggestion)) s += "\n    Fix: " + suggestion;
        return s;
    }
}
