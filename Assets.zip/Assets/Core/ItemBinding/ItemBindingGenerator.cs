using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public static class ItemBindingGenerator
{
    public static ItemBoundGenerationReport GenerateWorkspace(WorkspaceData workspace, string projectRoot, bool overwriteExisting = true, bool backupExisting = true)
    {
        ItemBoundGenerationReport report = ItemBindingValidator.ValidateWorkspace(workspace, projectRoot);
        if (report.HasErrors()) return report;

        if (workspace == null || workspace.items == null) return report;
        string modId = ItemBindingPathUtility.SanitizeModId(workspace.modId);
        string loader = string.IsNullOrEmpty(workspace.modloader) ? "fabric" : workspace.modloader.ToLowerInvariant();
        report.modId = modId;
        report.loader = loader;
        report.projectRoot = projectRoot;

        Directory.CreateDirectory(projectRoot);
        string backupRoot = null;
        if (backupExisting)
        {
            backupRoot = ItemBindingPathUtility.SafeCombineUnderRoot(projectRoot, ".modstudio", "backups", "item-binding", DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Directory.CreateDirectory(backupRoot);
        }

        foreach (ItemDataModel item in workspace.items)
        {
            if (item == null) continue;
            item.EnsureAdvancedSettings();
            GenerateItem(workspace, item, projectRoot, modId, loader, overwriteExisting, backupRoot, report);
        }

        WriteReport(projectRoot, report);
        return report;
    }

    public static void GenerateItem(WorkspaceData workspace, ItemDataModel item, string projectRoot, string modId, string loader, bool overwriteExisting, string backupRoot, ItemBoundGenerationReport report)
    {
        string id = ItemBindingPathUtility.NormalizeResourceId(item.itemId, "custom_item");
        string texture = ResolveTexturePath(item);

        WriteFile(projectRoot, report, backupRoot, overwriteExisting,
            "src/main/resources/assets/" + modId + "/models/item/" + id + ".json",
            GenerateItemModelJson(item, modId, id, texture));

        MergeLang(projectRoot, report, backupRoot, overwriteExisting, modId, "item." + modId + "." + id, string.IsNullOrEmpty(item.displayName) ? id : item.displayName);

        GenerateItemTags(item, projectRoot, modId, id, overwriteExisting, backupRoot, report);
        GenerateJavaStubs(item, projectRoot, modId, loader, id, overwriteExisting, backupRoot, report);
        WriteBindingManifest(item, projectRoot, modId, loader, id, texture, overwriteExisting, backupRoot, report);
    }

    private static string ResolveTexturePath(ItemDataModel item)
    {
        if (item == null) return "custom_item";
        item.EnsureAdvancedSettings();
        if (item.advanced != null && item.advanced.visual != null && !string.IsNullOrEmpty(item.advanced.visual.texturePath)) return ItemBindingPathUtility.NormalizeResourceId(item.advanced.visual.texturePath, item.itemId);
        return ItemBindingPathUtility.NormalizeResourceId(item.itemId, "custom_item");
    }

    private static string GenerateItemModelJson(ItemDataModel item, string modId, string id, string texture)
    {
        item.EnsureAdvancedSettings();
        string parent = "minecraft:item/generated";
        if (item.advanced != null && item.advanced.visual != null)
        {
            if (item.advanced.visual.modelType == StudioItemModelType.Handheld) parent = "minecraft:item/handheld";
            if (item.advanced.visual.modelType == StudioItemModelType.Custom && !string.IsNullOrEmpty(item.advanced.visual.customModelJsonPath))
            {
                parent = item.advanced.visual.customModelJsonPath.Replace("\\", "/").Replace(".json", "");
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"parent\": \"" + ItemBindingPathUtility.EscapeJson(parent) + "\",");
        sb.AppendLine("  \"textures\": {");
        sb.AppendLine("    \"layer0\": \"" + modId + ":item/" + ItemBindingPathUtility.EscapeJson(texture) + "\"");
        sb.AppendLine("  }");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static void GenerateItemTags(ItemDataModel item, string projectRoot, string modId, string id, bool overwriteExisting, string backupRoot, ItemBoundGenerationReport report)
    {
        if (item == null || item.advanced == null) return;
        if (item.advanced.components != null && item.advanced.components.repairable && !string.IsNullOrEmpty(item.advanced.repairItemId))
        {
            string repairTag = "src/main/resources/data/" + modId + "/tags/items/repair_materials/" + id + ".json";
            WriteTagJson(projectRoot, report, backupRoot, overwriteExisting, repairTag, item.advanced.repairItemId);
        }
        if (item.advanced.behavior != null && item.advanced.behavior.hasCraftRemainder && !string.IsNullOrEmpty(item.advanced.behavior.craftRemainderItem))
        {
            string tag = "src/main/resources/data/" + modId + "/tags/items/craft_remainders/" + id + ".json";
            WriteTagJson(projectRoot, report, backupRoot, overwriteExisting, tag, item.advanced.behavior.craftRemainderItem);
        }
    }

    private static void WriteTagJson(string projectRoot, ItemBoundGenerationReport report, string backupRoot, bool overwriteExisting, string relativePath, string value)
    {
        if (string.IsNullOrEmpty(value)) return;
        if (!value.Contains(":")) value = "minecraft:" + ItemBindingPathUtility.NormalizeResourceId(value, "stick");
        string content = "{\n  \"replace\": false,\n  \"values\": [\n    \"" + ItemBindingPathUtility.EscapeJson(value) + "\"\n  ]\n}\n";
        WriteFile(projectRoot, report, backupRoot, overwriteExisting, relativePath, content);
    }

    private static void GenerateJavaStubs(ItemDataModel item, string projectRoot, string modId, string loader, string id, bool overwriteExisting, string backupRoot, ItemBoundGenerationReport report)
    {
        string packageName = "net." + modId;
        string className = ItemBindingPathUtility.ToJavaClassName(id, "Item");
        string registryStubPath = ".modstudio/generated-java/" + loader + "/" + packageName.Replace('.', '/') + "/item/ModItems_" + id + ".java.stub";
        WriteFile(projectRoot, report, backupRoot, overwriteExisting, registryStubPath, GenerateRegistryStub(item, modId, packageName, className, id, loader));

        if (NeedsCustomItemClass(item))
        {
            string customPath = ".modstudio/generated-java/" + loader + "/" + packageName.Replace('.', '/') + "/item/" + className + ".java.stub";
            WriteFile(projectRoot, report, backupRoot, overwriteExisting, customPath, GenerateCustomItemClassStub(item, packageName, className, id, loader));
        }

        string descriptorPath = ".modstudio/item-binding/" + id + ".generated-java.json";
        WriteFile(projectRoot, report, backupRoot, overwriteExisting, descriptorPath, GenerateJavaDescriptor(item, modId, loader, id, className));
    }

    private static bool NeedsCustomItemClass(ItemDataModel item)
    {
        if (item == null || item.advanced == null) return false;
        AdvancedItemSettings a = item.advanced;
        if (a.visual != null && a.visual.hasGlint) return true;
        if (a.behavior != null && (a.behavior.hasRightClickAction || a.behavior.hasInventoryTick || !string.IsNullOrEmpty(a.behavior.tooltipLines))) return true;
        if (a.food != null && a.food.enabled && !string.IsNullOrEmpty(a.food.afterEatReturnItem)) return true;
        return false;
    }

    private static string GenerateRegistryStub(ItemDataModel item, string modId, string packageName, string className, string id, string loader)
    {
        item.EnsureAdvancedSettings();
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("package " + packageName + ".item;");
        sb.AppendLine();
        sb.AppendLine("// Generated by Mod Studio Item Real Binding.");
        sb.AppendLine("// Review imports/API for your exact Minecraft + loader version before applying.");
        sb.AppendLine("import net.minecraft.item.Item;");
        sb.AppendLine("import net.minecraft.item.Rarity;");
        sb.AppendLine();
        sb.AppendLine("public final class ModItems_" + id.Replace('-', '_').Replace('/', '_') + " {");
        sb.AppendLine("    public static final String ITEM_ID = \"" + id + "\";");
        sb.AppendLine("    public static final String MOD_ID = \"" + modId + "\";");
        sb.AppendLine();
        string itemType = NeedsCustomItemClass(item) ? className : "Item";
        sb.AppendLine("    public static final " + itemType + " INSTANCE = new " + itemType + "(createSettings());");
        sb.AppendLine();
        sb.AppendLine("    public static Item.Settings createSettings() {");
        sb.AppendLine("        Item.Settings settings = new Item.Settings()");
        foreach (string line in GenerateSettingsLines(item)) sb.AppendLine("            " + line);
        sb.AppendLine("            ;");
        sb.AppendLine("        return settings;");
        sb.AppendLine("    }");
        sb.AppendLine();
        sb.AppendLine("    public static void register() {");
        sb.AppendLine("        // Fabric/Quilt example:");
        sb.AppendLine("        // Registry.register(Registries.ITEM, Identifier.of(MOD_ID, ITEM_ID), INSTANCE);");
        sb.AppendLine("        // NeoForge example:");
        sb.AppendLine("        // ITEMS.register(ITEM_ID, () -> INSTANCE);");
        sb.AppendLine("    }");
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static List<string> GenerateSettingsLines(ItemDataModel item)
    {
        List<string> lines = new List<string>();
        item.EnsureAdvancedSettings();
        int stack = item.stackSize;
        if (item.advanced != null && item.advanced.maxDamage > 0)
        {
            lines.Add(".maxDamage(" + item.advanced.maxDamage + ")");
            lines.Add(".maxCount(1)");
        }
        else lines.Add(".maxCount(" + Math.Max(1, stack) + ")");

        if (item.advanced != null)
        {
            if (item.advanced.fireproof) lines.Add(".fireproof()");
            lines.Add(".rarity(Rarity." + RarityName(item.advanced.rarity) + ")");
            if (item.advanced.food != null && item.advanced.food.enabled)
            {
                lines.Add("// TODO: Add FoodComponent/DataComponent for nutrition=" + item.advanced.food.nutrition + ", saturation=" + item.advanced.food.saturation + "f");
            }
            if (item.advanced.components != null && item.advanced.components.enableDataComponents)
            {
                lines.Add("// TODO: Add 1.21+ data components: enchantable=" + item.advanced.components.enchantable.ToString().ToLowerInvariant() + ", repairable=" + item.advanced.components.repairable.ToString().ToLowerInvariant());
            }
        }
        return lines;
    }

    private static string RarityName(StudioItemRarity rarity)
    {
        if (rarity == StudioItemRarity.Uncommon) return "UNCOMMON";
        if (rarity == StudioItemRarity.Rare) return "RARE";
        if (rarity == StudioItemRarity.Epic) return "EPIC";
        return "COMMON";
    }

    private static string GenerateCustomItemClassStub(ItemDataModel item, string packageName, string className, string id, string loader)
    {
        item.EnsureAdvancedSettings();
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("package " + packageName + ".item;");
        sb.AppendLine();
        sb.AppendLine("import net.minecraft.item.Item;");
        sb.AppendLine("import net.minecraft.item.ItemStack;");
        sb.AppendLine();
        sb.AppendLine("public class " + className + " extends Item {");
        sb.AppendLine("    public " + className + "(Settings settings) {");
        sb.AppendLine("        super(settings);");
        sb.AppendLine("    }");
        sb.AppendLine();
        if (item.advanced.visual != null && item.advanced.visual.hasGlint)
        {
            sb.AppendLine("    // Glint binding: item.advanced.visual.hasGlint");
            sb.AppendLine("    // public boolean hasGlint(ItemStack stack) { return true; }");
            sb.AppendLine();
        }
        if (item.advanced.behavior != null && item.advanced.behavior.hasRightClickAction)
        {
            sb.AppendLine("    // Right-click binding: item.advanced.behavior.hasRightClickAction");
            sb.AppendLine("    // Override use(...) for your target Minecraft version.");
            sb.AppendLine();
        }
        if (item.advanced.behavior != null && item.advanced.behavior.hasInventoryTick)
        {
            sb.AppendLine("    // Inventory tick binding: item.advanced.behavior.hasInventoryTick");
            sb.AppendLine("    // Override inventoryTick(...) for your target Minecraft version.");
            sb.AppendLine();
        }
        if (item.advanced.behavior != null && !string.IsNullOrEmpty(item.advanced.behavior.tooltipLines))
        {
            sb.AppendLine("    // Tooltip lines:");
            string[] lines = item.advanced.behavior.tooltipLines.Replace("\r", "").Split('\n');
            foreach (string line in lines)
            {
                if (!string.IsNullOrEmpty(line.Trim())) sb.AppendLine("    // - " + line.Trim());
            }
        }
        sb.AppendLine("}");
        return sb.ToString();
    }

    private static string GenerateJavaDescriptor(ItemDataModel item, string modId, string loader, string id, string className)
    {
        item.EnsureAdvancedSettings();
        return "{\n" +
               "  \"type\": \"item-java-binding\",\n" +
               "  \"id\": \"" + ItemBindingPathUtility.EscapeJson(id) + "\",\n" +
               "  \"modId\": \"" + ItemBindingPathUtility.EscapeJson(modId) + "\",\n" +
               "  \"loader\": \"" + ItemBindingPathUtility.EscapeJson(loader) + "\",\n" +
               "  \"customClass\": \"" + ItemBindingPathUtility.EscapeJson(className) + "\",\n" +
               "  \"needsCustomClass\": " + NeedsCustomItemClass(item).ToString().ToLowerInvariant() + ",\n" +
               "  \"fields\": [\n" +
               "    \"item.id\",\n" +
               "    \"item.displayName\",\n" +
               "    \"item.maxStackSize\",\n" +
               "    \"item.maxDamage\",\n" +
               "    \"item.food.enabled\",\n" +
               "    \"item.rarity\",\n" +
               "    \"item.glint\",\n" +
               "    \"item.dataComponents\"\n" +
               "  ]\n" +
               "}\n";
    }

    private static void WriteBindingManifest(ItemDataModel item, string projectRoot, string modId, string loader, string id, string texture, bool overwriteExisting, string backupRoot, ItemBoundGenerationReport report)
    {
        item.EnsureAdvancedSettings();
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"type\": \"item-binding\",");
        sb.AppendLine("  \"id\": \"" + ItemBindingPathUtility.EscapeJson(id) + "\",");
        sb.AppendLine("  \"displayName\": \"" + ItemBindingPathUtility.EscapeJson(item.displayName) + "\",");
        sb.AppendLine("  \"modId\": \"" + ItemBindingPathUtility.EscapeJson(modId) + "\",");
        sb.AppendLine("  \"loader\": \"" + ItemBindingPathUtility.EscapeJson(loader) + "\",");
        sb.AppendLine("  \"texture\": \"" + ItemBindingPathUtility.EscapeJson(texture) + "\",");
        sb.AppendLine("  \"stackSize\": " + item.stackSize + ",");
        sb.AppendLine("  \"maxDamage\": " + (item.advanced == null ? 0 : item.advanced.maxDamage) + ",");
        sb.AppendLine("  \"food\": " + (item.advanced != null && item.advanced.food != null && item.advanced.food.enabled).ToString().ToLowerInvariant() + ",");
        sb.AppendLine("  \"rarity\": \"" + (item.advanced == null ? "Common" : item.advanced.rarity.ToString()) + "\",");
        sb.AppendLine("  \"generatorTargets\": [\"assets.models.item\", \"assets.lang.en_us\", \"java.item.registry.stub\"]");
        sb.AppendLine("}");
        WriteFile(projectRoot, report, backupRoot, overwriteExisting, ".modstudio/item-binding/" + id + ".binding.json", sb.ToString());
    }

    private static void MergeLang(string projectRoot, ItemBoundGenerationReport report, string backupRoot, bool overwriteExisting, string modId, string key, string value)
    {
        string relativePath = "src/main/resources/assets/" + modId + "/lang/en_us.json";
        string fullPath = ItemBindingPathUtility.SafeCombineUnderRoot(projectRoot, relativePath);
        string entry = "\"" + ItemBindingPathUtility.EscapeJson(key) + "\": \"" + ItemBindingPathUtility.EscapeJson(value) + "\"";
        string content;
        if (File.Exists(fullPath))
        {
            string existing = File.ReadAllText(fullPath);
            if (existing.Contains("\"" + key + "\"")) return;
            int lastBrace = existing.LastIndexOf('}');
            if (lastBrace >= 0)
            {
                string before = existing.Substring(0, lastBrace).TrimEnd();
                string comma = before.EndsWith("{") ? "" : ",";
                content = before + comma + "\n  " + entry + "\n}\n";
            }
            else content = "{\n  " + entry + "\n}\n";
        }
        else content = "{\n  " + entry + "\n}\n";
        WriteFileAbsolute(projectRoot, report, backupRoot, overwriteExisting, fullPath, content);
    }

    private static void WriteReport(string projectRoot, ItemBoundGenerationReport report)
    {
        string path = ItemBindingPathUtility.SafeCombineUnderRoot(projectRoot, ".modstudio", "reports", "item-binding-report.txt");
        Directory.CreateDirectory(Path.GetDirectoryName(path));
        File.WriteAllText(path, report.Format(), Encoding.UTF8);
    }

    private static void WriteFile(string projectRoot, ItemBoundGenerationReport report, string backupRoot, bool overwriteExisting, string relativePath, string content)
    {
        string fullPath = ItemBindingPathUtility.SafeCombineUnderRoot(projectRoot, relativePath);
        WriteFileAbsolute(projectRoot, report, backupRoot, overwriteExisting, fullPath, content);
    }

    private static void WriteFileAbsolute(string projectRoot, ItemBoundGenerationReport report, string backupRoot, bool overwriteExisting, string fullPath, string content)
    {
        if (File.Exists(fullPath) && !overwriteExisting)
        {
            report.skippedFiles++;
            report.skippedPaths.Add(fullPath);
            return;
        }
        if (File.Exists(fullPath) && !string.IsNullOrEmpty(backupRoot))
        {
            string rootFull = Path.GetFullPath(projectRoot).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string rel = Path.GetFullPath(fullPath).Replace(rootFull, "");
            string backupPath = Path.Combine(backupRoot, rel);
            Directory.CreateDirectory(Path.GetDirectoryName(backupPath));
            File.Copy(fullPath, backupPath, true);
            report.backedUpFiles++;
        }
        Directory.CreateDirectory(Path.GetDirectoryName(fullPath));
        File.WriteAllText(fullPath, content, Encoding.UTF8);
        report.generatedFiles++;
        report.generatedPaths.Add(fullPath);
    }
}
