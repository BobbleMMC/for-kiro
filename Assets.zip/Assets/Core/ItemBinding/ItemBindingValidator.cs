using System;
using System.Collections.Generic;

public static class ItemBindingValidator
{
    public static ItemBoundGenerationReport ValidateWorkspace(WorkspaceData workspace, string projectRoot)
    {
        ItemBoundGenerationReport report = new ItemBoundGenerationReport();
        report.projectRoot = projectRoot;
        report.modId = ResolveModId(workspace);
        report.loader = ResolveLoader(workspace);

        if (workspace == null)
        {
            report.AddIssue("error", "", "workspace", "Workspace null.", "Mod Studio oynasida loyihani oching.");
            return report;
        }
        if (string.IsNullOrEmpty(projectRoot))
        {
            report.AddIssue("error", "", "projectRoot", "Minecraft project root bo'sh.", "Export project root tanlang.");
            return report;
        }
        if (workspace.items == null || workspace.items.Count == 0)
        {
            report.AddIssue("warning", "", "items", "Workspace ichida item yo'q.");
            return report;
        }

        report.scannedItems = workspace.items.Count;
        HashSet<string> ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (ItemDataModel item in workspace.items)
        {
            ValidateItem(item, ids, report);
        }
        return report;
    }

    public static void ValidateItem(ItemDataModel item, HashSet<string> ids, ItemBoundGenerationReport report)
    {
        if (item == null)
        {
            report.AddIssue("error", "", "item", "Null item topildi.");
            return;
        }
        item.EnsureAdvancedSettings();
        string id = ItemBindingPathUtility.NormalizeResourceId(item.itemId, "custom_item");

        if (string.IsNullOrEmpty(item.itemId)) report.AddIssue("error", id, "item.id", "Item ID bo'sh.");
        if (!IsValidResourceId(id)) report.AddIssue("error", id, "item.id", "Item ID Minecraft resource id formatiga mos emas.", "Faqat lowercase, number, _, -, / ishlating.");
        if (!ids.Add(id)) report.AddIssue("error", id, "item.id", "Duplicate item id: " + id);
        if (string.IsNullOrEmpty(item.displayName)) report.AddIssue("warning", id, "item.displayName", "Display name bo'sh.");

        if (item.stackSize < 1 || item.stackSize > 99) report.AddIssue("error", id, "item.maxStackSize", "Stack size 1..99 oralig'ida bo'lishi kerak.");

        AdvancedItemSettings adv = item.advanced;
        if (adv == null) return;

        if (adv.maxDamage < 0) report.AddIssue("error", id, "item.maxDamage", "Durability negative bo'lishi mumkin emas.");
        if (adv.maxDamage > 0 && item.stackSize != 1)
        {
            report.AddIssue("error", id, "item.maxDamage", "Durability item stack size 1 bo'lishi kerak.", "Stack size = 1 qiling yoki durabilityni 0 qiling.");
        }
        if (adv.enchantability < 0 || adv.enchantability > 100) report.AddIssue("warning", id, "item.enchantability", "Enchantability odatda 0..100 oralig'ida bo'ladi.");
        if (adv.fireproof && adv.food != null && adv.food.enabled) report.AddIssue("warning", id, "item.fireproof", "Food item fireproof bo'lishi kam uchraydi, bu ataylab qilinganini tekshiring.");

        if (adv.food != null && adv.food.enabled)
        {
            if (adv.food.nutrition < 0 || adv.food.nutrition > 20) report.AddIssue("error", id, "item.food.nutrition", "Nutrition 0..20 oralig'ida bo'lishi kerak.");
            if (adv.food.saturation < 0f || adv.food.saturation > 20f) report.AddIssue("error", id, "item.food.saturation", "Saturation 0..20 oralig'ida bo'lishi kerak.");
            if (!string.IsNullOrEmpty(adv.food.statusEffects) && !adv.food.statusEffects.Contains(":")) report.AddIssue("warning", id, "item.food.effects", "Food effects formatini tekshiring.", "effect_id:duration:amplifier:chance formatida yozing.");
        }

        if (adv.behavior != null)
        {
            if (adv.behavior.useDuration < 0 || adv.behavior.useDuration > 72000) report.AddIssue("warning", id, "item.useDuration", "Use duration juda katta/kichik.");
            if (adv.behavior.cooldownTicks < 0) report.AddIssue("error", id, "item.cooldown", "Cooldown negative bo'lishi mumkin emas.");
            if (adv.behavior.hasCraftRemainder && string.IsNullOrEmpty(adv.behavior.craftRemainderItem)) report.AddIssue("warning", id, "item.craftRemainder", "Craft remainder yoqilgan, lekin item id bo'sh.");
        }

        if (adv.visual != null)
        {
            if (adv.visual.modelType == StudioItemModelType.Custom && string.IsNullOrEmpty(adv.visual.customModelJsonPath)) report.AddIssue("warning", id, "item.customModel", "Custom model tanlangan, lekin customModelJsonPath bo'sh.");
            if (!string.IsNullOrEmpty(adv.visual.tintHex) && !IsHexColor(adv.visual.tintHex)) report.AddIssue("warning", id, "item.tint", "Tint color #RRGGBB formatida bo'lishi kerak.");
        }

        if (adv.components != null)
        {
            if (adv.components.repairable && string.IsNullOrEmpty(adv.repairItemId)) report.AddIssue("warning", id, "item.repairable", "Repairable true, lekin repairItemId bo'sh.");
            if (!string.IsNullOrEmpty(adv.components.customDataJson) && !LooksLikeJsonObject(adv.components.customDataJson)) report.AddIssue("warning", id, "item.customData", "Custom data JSON object ko'rinishida emas.");
        }
    }

    private static bool IsValidResourceId(string id)
    {
        if (string.IsNullOrEmpty(id)) return false;
        for (int i = 0; i < id.Length; i++)
        {
            char c = id[i];
            bool ok = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '/';
            if (!ok) return false;
        }
        return true;
    }

    private static bool IsHexColor(string value)
    {
        if (string.IsNullOrEmpty(value)) return false;
        if (!value.StartsWith("#")) return false;
        if (value.Length != 7 && value.Length != 9) return false;
        for (int i = 1; i < value.Length; i++)
        {
            char c = value[i];
            bool ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
            if (!ok) return false;
        }
        return true;
    }

    private static bool LooksLikeJsonObject(string value)
    {
        if (string.IsNullOrEmpty(value)) return true;
        value = value.Trim();
        return value.StartsWith("{") && value.EndsWith("}");
    }

    private static string ResolveModId(WorkspaceData workspace)
    {
        if (workspace == null) return "mymod";
        return ItemBindingPathUtility.SanitizeModId(workspace.modId);
    }

    private static string ResolveLoader(WorkspaceData workspace)
    {
        if (workspace == null || string.IsNullOrEmpty(workspace.modloader)) return "fabric";
        return workspace.modloader.ToLowerInvariant();
    }
}
