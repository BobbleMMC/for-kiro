using System;
using System.IO;
using UnityEngine;

public static class ProjectLoader
{
    public const string StudioProjectFileName = "studio.project.json";

    public static bool TryLoad(string folderPath, out StudioProject project)
    {
        project = null;
        if (string.IsNullOrEmpty(folderPath)) return false;

        string filePath = Path.Combine(folderPath, StudioProjectFileName);
        if (!File.Exists(filePath)) return false;

        try
        {
            string json = File.ReadAllText(filePath);
            project = JsonUtility.FromJson<StudioProject>(json);
            return project != null && project.project != null;
        }
        catch (Exception ex)
        {
            StudioLogger.LogError($"[ProjectLoader] studio.project.json yuklashda xatolik: {ex.Message}");
            return false;
        }
    }
}
