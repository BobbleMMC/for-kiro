using System;
using System.Collections.Generic;

/// <summary>
/// WorkspaceData va StudioProject o'rtasidagi sinxronizatsiya.
/// Hozircha UI eski WorkspaceData bilan ishlaydi, lekin saqlash/build/validator qatlamlari
/// asta-sekin StudioProject modeliga ko'chiriladi.
/// </summary>
public static class ProjectStateManager
{
    public static StudioProject CurrentProject = new StudioProject();

    public static StudioProject SyncFromWorkspace(WorkspaceData workspace, string projectPath = "")
    {
        if (workspace == null)
        {
            CurrentProject = new StudioProject();
            return CurrentProject;
        }

        if (CurrentProject == null) CurrentProject = new StudioProject();
        if (CurrentProject.project == null) CurrentProject.project = new StudioProjectInfo();
        if (CurrentProject.build == null) CurrentProject.build = new StudioProjectBuildInfo();
        if (CurrentProject.dependencies == null) CurrentProject.dependencies = new List<StudioProjectDependency>();
        if (CurrentProject.dependencyRepositories == null) CurrentProject.dependencyRepositories = new List<string>();
        if (CurrentProject.resolvedVersions == null) CurrentProject.resolvedVersions = new ResolvedVersionSet();

        CurrentProject.studioVersion = "0.3.0";
        CurrentProject.project.name = string.IsNullOrEmpty(workspace.modName) ? "My Epic Mod" : workspace.modName;
        CurrentProject.project.modId = string.IsNullOrEmpty(workspace.modId) ? "mymod" : workspace.modId.Trim();
        CurrentProject.project.packageName = $"net.{CurrentProject.project.modId}";
        CurrentProject.project.namespaceRoot = $"net.{CurrentProject.project.modId}";
        CurrentProject.project.loader = string.IsNullOrEmpty(workspace.modloader) ? "Fabric" : workspace.modloader;
        CurrentProject.project.minecraftVersion = string.IsNullOrEmpty(workspace.mcVersion) ? "1.20.1" : workspace.mcVersion;
        CurrentProject.project.projectPath = projectPath ?? "";
        CurrentProject.project.updatedAtUtc = DateTime.UtcNow.ToString("o");
        if (string.IsNullOrEmpty(CurrentProject.project.createdAtUtc))
            CurrentProject.project.createdAtUtc = CurrentProject.project.updatedAtUtc;

        // 3-patch: Version Resolver endi Java/mappings/loader API presetlarini bitta joyda tanlaydi.
        var resolved = VersionResolver.Resolve(workspace);
        VersionResolver.ApplyToProject(CurrentProject, resolved);

        CurrentProject.features = StudioFeatureBuilder.BuildFeatures(workspace);

        // 3-patch: Dependency Resolver feature va loaderga qarab base dependencylarni tanlaydi.
        var dependencyResult = StudioDependencyResolver.ResolveForWorkspace(workspace, resolved);
        StudioDependencyResolver.ApplyToProject(CurrentProject, dependencyResult);

        return CurrentProject;
    }

    public static void ApplyProjectToWorkspace(StudioProject project, WorkspaceData workspace)
    {
        if (project == null || project.project == null || workspace == null) return;

        workspace.modName = project.project.name;
        workspace.modId = project.project.modId;
        workspace.mcVersion = project.project.minecraftVersion;
        workspace.modloader = project.project.loader;
        CurrentProject = project;
    }

    public static string GetSummary()
    {
        if (CurrentProject == null || CurrentProject.project == null) return "StudioProject hali yaratilmagan.";
        int featureCount = CurrentProject.features != null ? CurrentProject.features.Count : 0;
        int depCount = CurrentProject.dependencies != null ? CurrentProject.dependencies.Count : 0;
        string resolver = CurrentProject.resolvedVersions != null ? CurrentProject.resolvedVersions.GetSummary() : $"{CurrentProject.project.loader} {CurrentProject.project.minecraftVersion}";
        return $"{CurrentProject.project.name} ({CurrentProject.project.modId}) | {resolver} | Features: {featureCount} | Dependencies: {depCount}";
    }

    private static int InferJavaVersion(string minecraftVersion)
    {
        if (string.IsNullOrEmpty(minecraftVersion)) return 17;
        if (minecraftVersion.StartsWith("1.20.6") || minecraftVersion.StartsWith("1.21") || minecraftVersion.StartsWith("1.22")) return 21;
        return 17;
    }

    private static void EnsureBaseDependencies(StudioProject project)
    {
        if (project.dependencies == null) project.dependencies = new List<StudioProjectDependency>();
        project.dependencies.Clear();

        string loader = project.project.loader;
        string version = project.project.minecraftVersion;

        if (loader == "Fabric" || loader == "Quilt")
        {
            project.dependencies.Add(new StudioProjectDependency
            {
                id = loader == "Quilt" ? "quilt-standard-libraries" : "fabric-api",
                name = loader == "Quilt" ? "Quilt Standard Libraries" : "Fabric API",
                version = "recommended",
                loader = loader,
                minecraftVersion = version,
                required = true,
                reason = "Base registry, item group, lifecycle/event API uchun kerak."
            });
        }
        else if (loader == "Forge" || loader == "NeoForge")
        {
            project.dependencies.Add(new StudioProjectDependency
            {
                id = loader.ToLowerInvariant(),
                name = loader,
                version = "recommended",
                loader = loader,
                minecraftVersion = version,
                required = true,
                reason = "Loader base API."
            });
        }
    }
}
