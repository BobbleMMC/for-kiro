using System;
using System.Collections.Generic;

/// <summary>
/// StudioProject — professional project manifest.
/// Bu model kelajakdagi desktop app uchun asosiy "truth source" bo'ladi.
/// Eski WorkspaceData UI bilan ishlashda qoladi, StudioProject esa loyiha holatini
/// semantic, dependency va build qatlamlari uchun standart formatga aylantiradi.
/// </summary>
[Serializable]
public class StudioProject
{
    public string studioVersion = "0.3.0";
    public StudioProjectInfo project = new StudioProjectInfo();
    public List<StudioProjectFeature> features = new List<StudioProjectFeature>();
    public List<StudioProjectDependency> dependencies = new List<StudioProjectDependency>();
    public StudioProjectBuildInfo build = new StudioProjectBuildInfo();

    // 3-patch: Version Resolver + Dependency Resolver natijalari.
    public ResolvedVersionSet resolvedVersions = new ResolvedVersionSet();
    public List<string> dependencyRepositories = new List<string>();

    public int FeatureCount => features != null ? features.Count : 0;
    public int DependencyCount => dependencies != null ? dependencies.Count : 0;
}

[Serializable]
public class StudioProjectInfo
{
    public string name = "My Epic Mod";
    public string modId = "mymod";
    public string packageName = "net.mymod";
    public string namespaceRoot = "net.mymod";
    public string loader = "Fabric";
    public string minecraftVersion = "1.20.1";
    public int javaVersion = 17;
    public string mappings = "yarn";
    public string projectPath = "";
    public string createdAtUtc = "";
    public string updatedAtUtc = "";
}

[Serializable]
public class StudioProjectBuildInfo
{
    public string lastStatus = "unknown";
    public string lastTask = "";
    public string lastSuccessfulBuildUtc = "";
    public string lastBuildUtc = "";
    public int errorCount = 0;
    public int warningCount = 0;
}

[Serializable]
public class StudioProjectDependency
{
    public string id = "";
    public string name = "";
    public string version = "recommended";
    public string loader = "";
    public string minecraftVersion = "";
    public string gradleNotation = "";
    public string repository = "";
    public bool required = true;
    public string reason = "";
}
