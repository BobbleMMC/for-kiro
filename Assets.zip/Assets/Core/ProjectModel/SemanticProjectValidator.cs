using System.Collections.Generic;
using System.Text.RegularExpressions;

/// <summary>
/// StudioProject semantic modeli uchun qo'shimcha validator.
/// Bu qatlam hozircha basic, keyingi patchlarda compatibility/dependency validator bilan kengayadi.
/// </summary>
public static class SemanticProjectValidator
{
    public static List<ModValidator.ValidationResult> Validate(StudioProject project)
    {
        var results = new List<ModValidator.ValidationResult>();

        if (project == null || project.project == null)
        {
            results.Add(new ModValidator.ValidationResult(ModValidator.ValidationSeverity.Error, "ProjectModel", "StudioProject manifest yaratilmagan."));
            return results;
        }

        if (string.IsNullOrEmpty(project.project.modId) || !Regex.IsMatch(project.project.modId, @"^[a-z][a-z0-9_]*$"))
        {
            results.Add(new ModValidator.ValidationResult(ModValidator.ValidationSeverity.Error, "ProjectModel", "StudioProject ichidagi modId noto'g'ri.", project.project.modId));
        }

        if (project.features == null || project.features.Count == 0)
        {
            results.Add(new ModValidator.ValidationResult(ModValidator.ValidationSeverity.Info, "ProjectModel", "Semantic feature ro'yxati bo'sh. Kamida bitta feature qo'shilsa, studio graph foydaliroq bo'ladi."));
            return results;
        }

        var ids = new Dictionary<string, StudioFeatureType>();
        foreach (var feature in project.features)
        {
            if (feature == null) continue;
            if (string.IsNullOrEmpty(feature.id))
            {
                results.Add(new ModValidator.ValidationResult(ModValidator.ValidationSeverity.Warning, "ProjectModel", "ID bo'sh semantic feature topildi."));
                continue;
            }

            string key = feature.type + ":" + feature.id;
            if (ids.ContainsKey(key))
            {
                results.Add(new ModValidator.ValidationResult(ModValidator.ValidationSeverity.Error, "ProjectModel", $"Semantic feature dublikat: {feature.type}/{feature.id}", feature.id));
            }
            else
            {
                ids[key] = feature.type;
            }

            if (feature.registries == null || feature.registries.Count == 0)
            {
                results.Add(new ModValidator.ValidationResult(ModValidator.ValidationSeverity.Warning, "ProjectModel", $"Feature '{feature.id}' registry ma'lumotiga ega emas.", feature.id));
            }

            if (feature.files == null || feature.files.Count == 0)
            {
                results.Add(new ModValidator.ValidationResult(ModValidator.ValidationSeverity.Warning, "ProjectModel", $"Feature '{feature.id}' hech qanday faylga bog'lanmagan.", feature.id));
            }
        }

        return results;
    }
}
