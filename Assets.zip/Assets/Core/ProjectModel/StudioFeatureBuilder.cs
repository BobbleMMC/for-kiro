using System;
using System.Collections.Generic;

/// <summary>
/// Eski WorkspaceData ichidagi block/item/tool/... ro'yxatlarini professional
/// StudioProjectFeature semantic modeliga aylantiradi.
/// </summary>
public static class StudioFeatureBuilder
{
    public static List<StudioProjectFeature> BuildFeatures(WorkspaceData workspace)
    {
        var features = new List<StudioProjectFeature>();
        if (workspace == null) return features;

        string modId = SafeModId(workspace.modId);
        string loader = workspace.modloader;
        string version = workspace.mcVersion;

        if (workspace.blocks != null)
        {
            foreach (var block in workspace.blocks)
            {
                if (block == null || string.IsNullOrEmpty(block.blockId)) continue;
                var feature = CreateBase(block.blockId, block.displayName, StudioFeatureType.Block, loader, version);
                feature.registries.Add("block");
                feature.registries.Add("item");
                feature.files.Add(new StudioFeatureFileRef("java", $"src/main/java/net/{modId}/block/ModBlocks.java"));
                feature.files.Add(new StudioFeatureFileRef("blockstate", $"src/main/resources/assets/{modId}/blockstates/{block.blockId}.json"));
                feature.files.Add(new StudioFeatureFileRef("model", $"src/main/resources/assets/{modId}/models/block/{block.blockId}.json"));
                feature.files.Add(new StudioFeatureFileRef("model", $"src/main/resources/assets/{modId}/models/item/{block.blockId}.json"));
                feature.files.Add(new StudioFeatureFileRef("texture", $"src/main/resources/assets/{modId}/textures/block/{block.texturePath}.png", false));
                feature.files.Add(new StudioFeatureFileRef("lang", $"src/main/resources/assets/{modId}/lang/en_us.json"));
                features.Add(feature);
            }
        }

        if (workspace.items != null)
        {
            foreach (var item in workspace.items)
            {
                if (item == null || string.IsNullOrEmpty(item.itemId)) continue;
                var feature = CreateBase(item.itemId, item.displayName, StudioFeatureType.Item, loader, version);
                feature.registries.Add("item");
                feature.files.Add(new StudioFeatureFileRef("java", $"src/main/java/net/{modId}/item/ModItems.java"));
                feature.files.Add(new StudioFeatureFileRef("model", $"src/main/resources/assets/{modId}/models/item/{item.itemId}.json"));
                feature.files.Add(new StudioFeatureFileRef("texture", $"src/main/resources/assets/{modId}/textures/item/{item.itemId}.png", false));
                feature.files.Add(new StudioFeatureFileRef("lang", $"src/main/resources/assets/{modId}/lang/en_us.json"));
                features.Add(feature);
            }
        }

        if (workspace.tools != null)
        {
            foreach (var tool in workspace.tools)
            {
                if (tool == null || string.IsNullOrEmpty(tool.toolId)) continue;
                var feature = CreateBase(tool.toolId, tool.displayName, StudioFeatureType.Tool, loader, version);
                feature.registries.Add("item");
                feature.files.Add(new StudioFeatureFileRef("java", $"src/main/java/net/{modId}/item/ModItems.java"));
                feature.files.Add(new StudioFeatureFileRef("model", $"src/main/resources/assets/{modId}/models/item/{tool.toolId}.json"));
                feature.files.Add(new StudioFeatureFileRef("texture", $"src/main/resources/assets/{modId}/textures/item/{tool.toolId}.png", false));
                feature.files.Add(new StudioFeatureFileRef("lang", $"src/main/resources/assets/{modId}/lang/en_us.json"));
                features.Add(feature);
            }
        }

        if (workspace.armors != null)
        {
            foreach (var armor in workspace.armors)
            {
                if (armor == null || string.IsNullOrEmpty(armor.armorId)) continue;
                var feature = CreateBase(armor.armorId, armor.displayName, StudioFeatureType.Armor, loader, version);
                feature.registries.Add("item");
                feature.files.Add(new StudioFeatureFileRef("java", $"src/main/java/net/{modId}/item/ModItems.java"));
                feature.files.Add(new StudioFeatureFileRef("model", $"src/main/resources/assets/{modId}/models/item/{armor.armorId}.json"));
                feature.files.Add(new StudioFeatureFileRef("texture", $"src/main/resources/assets/{modId}/textures/item/{armor.armorId}.png", false));
                feature.files.Add(new StudioFeatureFileRef("lang", $"src/main/resources/assets/{modId}/lang/en_us.json"));
                features.Add(feature);
            }
        }

        if (workspace.recipes != null)
        {
            foreach (var recipe in workspace.recipes)
            {
                if (recipe == null || string.IsNullOrEmpty(recipe.resultItem)) continue;
                string recipeId = recipe.resultItem.Contains(":") ? recipe.resultItem.Split(':')[1] : recipe.resultItem;
                var feature = CreateBase($"{recipeId}_recipe", $"{recipeId} Recipe", StudioFeatureType.Recipe, loader, version);
                feature.registries.Add("recipe");
                feature.files.Add(new StudioFeatureFileRef("data", $"src/main/resources/data/{modId}/recipes/{recipeId}_recipe.json"));
                features.Add(feature);
            }
        }

        if (workspace.entities != null)
        {
            foreach (var entity in workspace.entities)
            {
                if (entity == null || string.IsNullOrEmpty(entity.entityId)) continue;
                var feature = CreateBase(entity.entityId, entity.displayName, StudioFeatureType.Entity, loader, version);
                feature.registries.Add("entity_type");
                feature.files.Add(new StudioFeatureFileRef("java", $"src/main/java/net/{modId}/entity/ModEntities.java"));
                feature.files.Add(new StudioFeatureFileRef("lang", $"src/main/resources/assets/{modId}/lang/en_us.json"));
                features.Add(feature);
            }
        }

        if (workspace.biomes != null)
        {
            foreach (var biome in workspace.biomes)
            {
                if (biome == null || string.IsNullOrEmpty(biome.biomeId)) continue;
                var feature = CreateBase(biome.biomeId, biome.displayName, StudioFeatureType.Biome, loader, version);
                feature.registries.Add("worldgen/biome");
                feature.files.Add(new StudioFeatureFileRef("data", $"src/main/resources/data/{modId}/worldgen/biome/{biome.biomeId}.json"));
                feature.files.Add(new StudioFeatureFileRef("lang", $"src/main/resources/assets/{modId}/lang/en_us.json"));
                features.Add(feature);
            }
        }

        if (workspace.creativeTabs != null)
        {
            foreach (var tab in workspace.creativeTabs)
            {
                if (tab == null || string.IsNullOrEmpty(tab.tabId)) continue;
                var feature = CreateBase(tab.tabId, tab.displayName, StudioFeatureType.CreativeTab, loader, version);
                feature.registries.Add("item_group");
                feature.files.Add(new StudioFeatureFileRef("java", $"src/main/java/net/{modId}/item/ModItemGroup.java"));
                feature.files.Add(new StudioFeatureFileRef("lang", $"src/main/resources/assets/{modId}/lang/en_us.json"));
                features.Add(feature);
            }
        }

        return features;
    }

    private static StudioProjectFeature CreateBase(string id, string displayName, StudioFeatureType type, string loader, string version)
    {
        return new StudioProjectFeature
        {
            id = id,
            displayName = string.IsNullOrEmpty(displayName) ? id : displayName,
            type = type,
            side = StudioFeatureSide.Common,
            loader = loader,
            minecraftVersion = version,
            generatedByStudio = true
        };
    }

    private static string SafeModId(string modId)
    {
        return string.IsNullOrEmpty(modId) ? "mymod" : modId.Trim();
    }
}
