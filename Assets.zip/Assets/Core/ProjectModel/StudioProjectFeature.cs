using System;
using System.Collections.Generic;

public enum StudioFeatureType
{
    Block,
    Item,
    Tool,
    Armor,
    Recipe,
    Entity,
    Biome,
    CreativeTab,
    Texture,
    Model,
    Unknown
}

public enum StudioFeatureSide
{
    Common,
    ClientOnly,
    ServerOnly
}

/// <summary>
/// Har bir block/item/mob/biome va boshqa feature uchun semantic index.
/// Bu class orqali studio "qaysi obyekt qaysi Java/assets/data fayllarga bog'langan"
/// degan savolga javob bera oladi.
/// </summary>
[Serializable]
public class StudioProjectFeature
{
    public string id = "";
    public string displayName = "";
    public StudioFeatureType type = StudioFeatureType.Unknown;
    public StudioFeatureSide side = StudioFeatureSide.Common;
    public string loader = "";
    public string minecraftVersion = "";
    public List<string> registries = new List<string>();
    public List<string> requires = new List<string>();
    public List<StudioFeatureFileRef> files = new List<StudioFeatureFileRef>();
    public bool generatedByStudio = true;
    public string notes = "";
}

[Serializable]
public class StudioFeatureFileRef
{
    public string kind = "";      // java, asset, data, texture, model, lang, blockstate
    public string path = "";
    public bool generated = true;

    public StudioFeatureFileRef() { }

    public StudioFeatureFileRef(string kind, string path, bool generated = true)
    {
        this.kind = kind;
        this.path = path;
        this.generated = generated;
    }
}
