using System;
using System.IO;
using UnityEngine;

public static class ProjectSaver
{
    public const string StudioProjectFileName = "studio.project.json";

    public static bool Save(string folderPath, StudioProject project)
    {
        if (string.IsNullOrEmpty(folderPath) || project == null) return false;

        try
        {
            Directory.CreateDirectory(folderPath);
            string filePath = Path.Combine(folderPath, StudioProjectFileName);
            string json = JsonUtility.ToJson(project, true);
            File.WriteAllText(filePath, json);
            StudioLogger.Log($"[ProjectSaver] Studio project manifest saqlandi: {filePath}");
            return true;
        }
        catch (Exception ex)
        {
            StudioLogger.LogError($"[ProjectSaver] studio.project.json saqlashda xatolik: {ex.Message}");
            return false;
        }
    }
}
