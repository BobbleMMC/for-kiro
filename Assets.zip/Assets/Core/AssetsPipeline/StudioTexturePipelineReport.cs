using System;
using System.Collections.Generic;
using System.Text;

/// <summary>
/// Texture pipeline export/auto-fix natijasi.
/// </summary>
[Serializable]
public class StudioTexturePipelineReport
{
    public List<string> copied = new List<string>();
    public List<string> generated = new List<string>();
    public List<string> skipped = new List<string>();
    public List<string> warnings = new List<string>();
    public List<string> errors = new List<string>();

    public bool HasErrors => errors != null && errors.Count > 0;

    public void AddCopied(string path) { if (!copied.Contains(path)) copied.Add(path); }
    public void AddGenerated(string path) { if (!generated.Contains(path)) generated.Add(path); }
    public void AddSkipped(string path) { if (!skipped.Contains(path)) skipped.Add(path); }
    public void AddWarning(string message) { if (!string.IsNullOrEmpty(message)) warnings.Add(message); }
    public void AddError(string message) { if (!string.IsNullOrEmpty(message)) errors.Add(message); }

    public string Format()
    {
        var sb = new StringBuilder();
        sb.AppendLine("[TexturePipeline] Hisobot");
        sb.AppendLine("  Copied: " + copied.Count);
        sb.AppendLine("  Placeholder: " + generated.Count);
        sb.AppendLine("  Skipped: " + skipped.Count);
        if (warnings.Count > 0)
        {
            sb.AppendLine("  Warnings:");
            foreach (var w in warnings) sb.AppendLine("   - " + w);
        }
        if (errors.Count > 0)
        {
            sb.AppendLine("  Errors:");
            foreach (var e in errors) sb.AppendLine("   - " + e);
        }
        return sb.ToString();
    }
}
