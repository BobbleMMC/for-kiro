using System;

/// <summary>
/// StudioTextureSlot — mod elementi uchun kutiladigan PNG texture joylashuvi.
/// Masalan: block.custom_block -> assets/modid/textures/block/custom_block.png
/// </summary>
[Serializable]
public class StudioTextureSlot
{
    public string elementId;
    public string elementType;
    public string textureName;
    public string resourceReference;
    public string relativeExportPath;
    public string unityLibraryPath;
    public bool sourceFound;
    public bool generatedPlaceholder;

    public StudioTextureSlot() { }

    public StudioTextureSlot(string elementType, string elementId, string textureName, string modId, string folder)
    {
        this.elementType = elementType;
        this.elementId = elementId;
        this.textureName = textureName;
        this.resourceReference = modId + ":" + folder + "/" + textureName;
        this.relativeExportPath = "src/main/resources/assets/" + modId + "/textures/" + folder + "/" + textureName + ".png";
        this.unityLibraryPath = "Assets/Textures/" + folder + "/" + textureName + ".png";
    }
}
