using System;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;

/// <summary>
/// StudioTexturePipeline — painter, texture library va export qilingan Minecraft resource papkalarini bog'laydi.
/// 8-patch vazifalari:
///   • texture nomlarini Minecraft resource path qoidalariga mos normalizatsiya qilish
///   • Assets/Textures kutubxonasidan export projectga PNG ko'chirish
///   • missing PNG uchun 16x16 placeholder yaratish
///   • block.texturePath ni eksportdan oldin xavfsiz qiymatga keltirish
/// </summary>
public static class StudioTexturePipeline
{
    private static readonly Regex InvalidResourceChars = new Regex("[^a-z0-9_./-]", RegexOptions.Compiled);

    public static string NormalizeTextureName(string raw, string fallback)
    {
        string value = string.IsNullOrWhiteSpace(raw) ? fallback : raw.Trim();
        value = value.Replace("\\", "/");
        value = value.Replace(".png", "").Replace(".PNG", "");
        value = value.ToLowerInvariant();
        value = InvalidResourceChars.Replace(value, "_");
        while (value.Contains("//")) value = value.Replace("//", "/");
        value = value.Trim('/');
        if (string.IsNullOrWhiteSpace(value)) value = string.IsNullOrWhiteSpace(fallback) ? "texture" : fallback.ToLowerInvariant();
        return value;
    }

    public static List<StudioTextureSlot> BuildExpectedSlots(WorkspaceData workspace)
    {
        var slots = new List<StudioTextureSlot>();
        if (workspace == null) return slots;

        string modId = NormalizeResourcePart(workspace.modId, "mymod");

        if (workspace.blocks != null)
        {
            foreach (var block in workspace.blocks)
            {
                if (block == null) continue;
                string id = NormalizeResourcePart(block.blockId, "custom_block");
                string texture = NormalizeTextureName(block.texturePath, id);
                block.blockId = id;
                block.texturePath = texture;
                block.textureNamespace = modId;
                slots.Add(new StudioTextureSlot("block", id, texture, modId, "block"));
            }
        }

        if (workspace.items != null)
        {
            foreach (var item in workspace.items)
            {
                if (item == null) continue;
                string id = NormalizeResourcePart(item.itemId, "custom_item");
                item.itemId = id;
                item.textureNamespace = modId;
                slots.Add(new StudioTextureSlot("item", id, id, modId, "item"));
            }
        }

        if (workspace.tools != null)
        {
            foreach (var tool in workspace.tools)
            {
                if (tool == null) continue;
                string id = NormalizeResourcePart(tool.toolId, "custom_tool");
                tool.toolId = id;
                tool.textureNamespace = modId;
                slots.Add(new StudioTextureSlot("tool", id, id, modId, "item"));
            }
        }

        if (workspace.armors != null)
        {
            foreach (var armor in workspace.armors)
            {
                if (armor == null) continue;
                string id = NormalizeResourcePart(armor.armorId, "custom_armor");
                armor.armorId = id;
                armor.textureNamespace = modId;
                slots.Add(new StudioTextureSlot("armor", id, id, modId, "item"));
            }
        }

        return slots;
    }

    public static StudioTexturePipelineReport EnsureExportTextures(string projectPath, WorkspaceData workspace, bool createMissingPlaceholders)
    {
        var report = new StudioTexturePipelineReport();
        if (string.IsNullOrWhiteSpace(projectPath))
        {
            report.AddError("Project path bo'sh. Texture export bekor qilindi.");
            return report;
        }

        var slots = BuildExpectedSlots(workspace);
        foreach (var slot in slots)
        {
            try
            {
                string exportPath = Path.Combine(projectPath, slot.relativeExportPath.Replace('/', Path.DirectorySeparatorChar));
                Directory.CreateDirectory(Path.GetDirectoryName(exportPath));

                if (File.Exists(exportPath))
                {
                    slot.sourceFound = true;
                    report.AddSkipped(slot.relativeExportPath + " mavjud");
                    continue;
                }

                string source = FindSourceTexture(slot);
                if (!string.IsNullOrEmpty(source) && File.Exists(source))
                {
                    File.Copy(source, exportPath, true);
                    slot.sourceFound = true;
                    report.AddCopied(slot.relativeExportPath);
                    continue;
                }

                if (createMissingPlaceholders)
                {
                    WritePlaceholderTexture(exportPath, slot);
                    slot.generatedPlaceholder = true;
                    report.AddGenerated(slot.relativeExportPath);
                }
                else
                {
                    report.AddWarning("Texture topilmadi: " + slot.relativeExportPath);
                }
            }
            catch (Exception ex)
            {
                report.AddError(slot.relativeExportPath + " yozilmadi: " + ex.Message);
            }
        }

        return report;
    }

    public static string SavePainterTextureToUnityLibrary(string filename, Color[] pixels, string targetFolder)
    {
        string folder = NormalizeTargetFolder(targetFolder);
        string textureName = NormalizeTextureName(filename, "custom_texture");
        string unityPath = Path.Combine("Assets", "Textures", folder, textureName + ".png").Replace('\\', '/');
        WritePixelsToPng(unityPath, pixels);
        return unityPath;
    }

    public static string SavePainterTextureToExportProject(string projectPath, WorkspaceData workspace, string filename, Color[] pixels, string targetFolder)
    {
        if (workspace == null) workspace = new WorkspaceData();
        string modId = NormalizeResourcePart(workspace.modId, "mymod");
        string folder = NormalizeTargetFolder(targetFolder);
        string textureName = NormalizeTextureName(filename, "custom_texture");
        string exportPath = Path.Combine(projectPath, "src/main/resources/assets", modId, "textures", folder, textureName + ".png");
        WritePixelsToPng(exportPath, pixels);
        return exportPath;
    }

    public static void WritePixelsToPng(string path, Color[] pixels)
    {
        if (pixels == null || pixels.Length != 256)
            throw new ArgumentException("Texture painter faqat 16x16 = 256 piksel qabul qiladi.");

        Directory.CreateDirectory(Path.GetDirectoryName(path));
        Texture2D tex = new Texture2D(16, 16, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Point;
        tex.wrapMode = TextureWrapMode.Clamp;
        tex.SetPixels(pixels);
        tex.Apply();
        File.WriteAllBytes(path, tex.EncodeToPNG());

        if (Application.isEditor)
            UnityEngine.Object.DestroyImmediate(tex);
        else
            UnityEngine.Object.Destroy(tex);
    }

    public static void WritePlaceholderTexture(string path, StudioTextureSlot slot)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path));
        Texture2D tex = new Texture2D(16, 16, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Point;
        tex.wrapMode = TextureWrapMode.Clamp;

        Color a = new Color(0.75f, 0.0f, 0.95f, 1f);
        Color b = Color.black;
        Color accent = PickAccent(slot != null ? slot.elementType : "texture");

        for (int y = 0; y < 16; y++)
        {
            for (int x = 0; x < 16; x++)
            {
                bool checker = ((x / 4) + (y / 4)) % 2 == 0;
                Color c = checker ? a : b;

                // Element turiga qarab kichik rangli ramka: block/item/tool/armor farqlanadi.
                if (x == 0 || y == 0 || x == 15 || y == 15) c = accent;
                tex.SetPixel(x, y, c);
            }
        }

        tex.Apply();
        File.WriteAllBytes(path, tex.EncodeToPNG());

        if (Application.isEditor)
            UnityEngine.Object.DestroyImmediate(tex);
        else
            UnityEngine.Object.Destroy(tex);
    }

    private static string FindSourceTexture(StudioTextureSlot slot)
    {
        if (slot == null) return null;

        string folder = slot.relativeExportPath.Contains("/textures/block/") ? "block" : "item";
        string name = slot.textureName;
        var candidates = new List<string>
        {
            Path.Combine("Assets", "Textures", folder, name + ".png"),
            Path.Combine("Assets", "Textures", name + ".png"),
            Path.Combine("Assets", "Textures", slot.elementId + ".png"),
            Path.Combine("Assets", "Textures", folder, slot.elementId + ".png")
        };

        foreach (var c in candidates)
        {
            string normalized = c.Replace('\\', Path.DirectorySeparatorChar).Replace('/', Path.DirectorySeparatorChar);
            if (File.Exists(normalized)) return normalized;
        }

        return null;
    }

    private static string NormalizeResourcePart(string raw, string fallback)
    {
        string value = NormalizeTextureName(raw, fallback);
        value = value.Replace("/", "_").Replace(".", "_").Replace("-", "_");
        if (string.IsNullOrWhiteSpace(value)) value = fallback;
        return value;
    }

    private static string NormalizeTargetFolder(string targetFolder)
    {
        if (string.IsNullOrWhiteSpace(targetFolder)) return "block";
        string value = targetFolder.Trim().ToLowerInvariant();
        if (value.Contains("item") || value.Contains("tool") || value.Contains("armor")) return "item";
        return "block";
    }

    private static Color PickAccent(string elementType)
    {
        switch ((elementType ?? string.Empty).ToLowerInvariant())
        {
            case "item": return new Color(0.25f, 0.65f, 1f, 1f);
            case "tool": return new Color(1f, 0.65f, 0.15f, 1f);
            case "armor": return new Color(0.45f, 0.85f, 0.95f, 1f);
            default: return new Color(0.35f, 1f, 0.35f, 1f);
        }
    }
}
