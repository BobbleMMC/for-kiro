@echo off
setlocal
set SCRIPT_DIR=%~dp0
where powershell >nul 2>nul
if errorlevel 1 (
  echo PowerShell topilmadi. PatchContent\Assets papkasini Unity project root ichiga qo'lda ko'chiring.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%RUN_PATCH12_FORCE_INSTALL.ps1"
pause
