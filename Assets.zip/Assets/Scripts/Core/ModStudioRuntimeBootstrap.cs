using System.Collections;
using UnityEngine;
using UnityEngine.UIElements;

/// <summary>
/// Desktop build/play mode uchun xavfsiz bootstrap.
/// Agar sahnada UIDocument yo'q bo'lsa, runtime UI avtomatik yaratiladi.
/// </summary>
public class ModStudioRuntimeBootstrap : MonoBehaviour
{
    private static bool _created;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void EnsureRuntimeUi()
    {
        if (_created) return;

        UIDocument existing = UnityEngine.Object.FindFirstObjectByType<UIDocument>();
        if (existing != null) return;

        GameObject go = new GameObject("ModStudio_RuntimeUI");
        UnityEngine.Object.DontDestroyOnLoad(go);

        UIDocument document = go.AddComponent<UIDocument>();
        PanelSettings panelSettings = ScriptableObject.CreateInstance<PanelSettings>();
        panelSettings.name = "ModStudio_RuntimePanelSettings";
        document.panelSettings = panelSettings;

        ModStudioRuntimeUiController controller = go.AddComponent<ModStudioRuntimeUiController>();
        controller.mainTree = Resources.Load<VisualTreeAsset>("UI/ModStudioEditor");
        controller.mainStyle = Resources.Load<StyleSheet>("UI/ModStudioEditor");

        _created = true;
    }
}

public class ModStudioRuntimeUiController : MonoBehaviour
{
    public VisualTreeAsset mainTree;
    public StyleSheet mainStyle;

    private UIDocument _document;

    private IEnumerator Start()
    {
        _document = GetComponent<UIDocument>();
        yield return null;
        BuildUi();
    }

    private void BuildUi()
    {
        if (_document == null || _document.rootVisualElement == null) return;

        VisualElement root = _document.rootVisualElement;
        root.Clear();
        root.style.flexGrow = 1f;

        if (mainStyle != null) root.styleSheets.Add(mainStyle);
        if (mainTree != null) mainTree.CloneTree(root);

        if (root.Q<VisualElement>("toolbar-panel") == null)
        {
            BuildFallback(root);
        }

        WireButton(root, "btn-new", "Yangi loyiha");
        WireButton(root, "btn-save", "Saqlash");
        WireButton(root, "btn-validate", "Tekshirish");
        WireButton(root, "btn-build", "Build Jar");
        WireButton(root, "btn-run", "Run Client");
        WireButton(root, "btn-stop", "Stop");
        WireButton(root, "btn-analyze-log", "Analyze Log");

        Label projectPath = root.Q<Label>("label-project-path");
        if (projectPath != null) projectPath.text = "Desktop app mode";

        ScrollView tree = root.Q<ScrollView>("project-tree-container");
        if (tree != null && tree.childCount == 0)
        {
            tree.Add(new Label("PROJECT"));
            tree.Add(new Label("🧱 Blocks"));
            tree.Add(new Label("📦 Items"));
            tree.Add(new Label("🎁 Loot Tables"));
            tree.Add(new Label("🚀 Release"));
        }

        TextField code = root.Q<TextField>("code-field");
        if (code != null && string.IsNullOrEmpty(code.value))
        {
            code.value = "// Mod Studio desktop app ishga tushdi\n";
        }
    }

    private static void BuildFallback(VisualElement root)
    {
        VisualElement app = new VisualElement { name = "app-container" };
        app.style.flexGrow = 1f;
        app.style.backgroundColor = new Color(0.12f, 0.12f, 0.12f);
        root.Add(app);

        VisualElement toolbar = new VisualElement { name = "toolbar-panel" };
        toolbar.style.flexDirection = FlexDirection.Row;
        toolbar.style.minHeight = 40f;
        toolbar.style.alignItems = Align.Center;
        toolbar.style.paddingLeft = 8f;
        toolbar.style.backgroundColor = new Color(0.17f, 0.17f, 0.17f);
        app.Add(toolbar);

        toolbar.Add(new Button { name = "btn-new", text = "Yangi Loyiha" });
        toolbar.Add(new Button { name = "btn-save", text = "Saqlash" });
        toolbar.Add(new Button { name = "btn-validate", text = "Tekshirish" });
        toolbar.Add(new Button { name = "btn-build", text = "Build Jar" });
        toolbar.Add(new Button { name = "btn-run", text = "Run Client" });
        toolbar.Add(new Button { name = "btn-stop", text = "Stop" });

        Label status = new Label("Mod Studio desktop app tayyor") { name = "label-project-path" };
        status.style.color = Color.gray;
        status.style.marginLeft = 12f;
        toolbar.Add(status);

        VisualElement body = new VisualElement();
        body.style.flexGrow = 1f;
        body.style.flexDirection = FlexDirection.Row;
        app.Add(body);

        ScrollView tree = new ScrollView { name = "project-tree-container" };
        tree.style.width = 240f;
        body.Add(tree);

        ScrollView form = new ScrollView { name = "editor-form-scroll" };
        form.style.flexGrow = 1f;
        form.Add(new Label("Mod Studio panel yuklandi"));
        body.Add(form);

        TextField code = new TextField { name = "code-field", multiline = true };
        code.style.width = 420f;
        body.Add(code);
    }

    private static void WireButton(VisualElement root, string name, string label)
    {
        Button button = root.Q<Button>(name);
        if (button == null) return;
        button.clicked += delegate { Debug.Log("[Mod Studio] " + label + " bosildi."); };
    }
}
