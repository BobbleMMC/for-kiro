$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Find-ProjectRoot($dir) {
    $candidates = @(
        $dir,
        (Resolve-Path (Join-Path $dir "..")).Path,
        (Resolve-Path (Join-Path $dir "..\..")).Path
    ) | Select-Object -Unique

    foreach ($candidate in $candidates) {
        if (Test-Path (Join-Path $candidate "Assets")) {
            return $candidate
        }
    }
    return $null
}

$projectRoot = Find-ProjectRoot $scriptDir
if (-not $projectRoot) {
    Write-Host "[ERROR] Unity project root topilmadi. Scriptni Assets papkasi yonida yoki project root ichida ishga tushiring." -ForegroundColor Red
    exit 1
}

$sourceAssets = Join-Path $scriptDir "PatchContent\Assets"
if (-not (Test-Path $sourceAssets)) {
    Write-Host "[ERROR] PatchContent\Assets topilmadi. Zip to'liq extract qilinganini tekshiring." -ForegroundColor Red
    exit 1
}

Write-Host "[INFO] Project root: $projectRoot" -ForegroundColor Cyan
Write-Host "[INFO] Source assets: $sourceAssets" -ForegroundColor Cyan

$files = @(
    "Core\DataModels\BlockDataModel.cs",
    "Core\DataModels\ItemDataModel.cs",
    "Core\DataModels\MinecraftCreativeTab.cs",
    "Core\EditorSettings\AdvancedItemSettings.cs",
    "Core\EditorSettings\AdvancedBlockSettings.cs",
    "Core\EditorSettings\RecipeProSettings.cs",
    "Core\Services\ModValidator.cs",
    "Core\Validation\StudioJsonSyntaxValidator.cs"
)

foreach ($rel in $files) {
    $src = Join-Path $sourceAssets $rel
    $dst = Join-Path (Join-Path $projectRoot "Assets") $rel
    if (-not (Test-Path $src)) {
        Write-Host "[ERROR] Source missing: $src" -ForegroundColor Red
        exit 1
    }
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    Copy-Item -Force $src $dst
    Write-Host "[OK] Installed: Assets\$rel" -ForegroundColor Green
}

# Remove accidental nested duplicate install that can happen when zip is extracted inside Assets.
$nested = Join-Path $projectRoot "Assets\Assets"
if (Test-Path $nested) {
    Write-Host "[CLEAN] Removing accidental nested Assets\Assets" -ForegroundColor Yellow
    Remove-Item -Recurse -Force $nested
}

# Remove old non-canonical duplicates if present. Correct location is Assets/Core/...
$badDirs = @(
    "ProjectModel", "Services", "DataModels", "Generation", "Compatibility", "Dependencies", "Versioning", "EditorSettings", "Validation"
)
foreach ($dirName in $badDirs) {
    $bad = Join-Path (Join-Path $projectRoot "Assets") $dirName
    if (Test-Path $bad) {
        Write-Host "[CLEAN] Removing non-canonical duplicate: Assets\$dirName" -ForegroundColor Yellow
        Remove-Item -Recurse -Force $bad
    }
}

# Verification
$required = @(
    @{Path="Core\DataModels\BlockDataModel.cs"; Text="class BlockDataModel"},
    @{Path="Core\DataModels\ItemDataModel.cs"; Text="class ItemDataModel"},
    @{Path="Core\DataModels\MinecraftCreativeTab.cs"; Text="enum MinecraftCreativeTab"},
    @{Path="Core\Services\ModValidator.cs"; Text="static class ModValidator"}
)

$failed = $false
foreach ($r in $required) {
    $p = Join-Path (Join-Path $projectRoot "Assets") $r.Path
    if (-not (Test-Path $p)) {
        Write-Host "[FAIL] Missing after install: Assets\$($r.Path)" -ForegroundColor Red
        $failed = $true
        continue
    }
    $content = Get-Content $p -Raw
    if ($content -notmatch [regex]::Escape($r.Text)) {
        Write-Host "[FAIL] Invalid file content: Assets\$($r.Path)" -ForegroundColor Red
        $failed = $true
    } else {
        Write-Host "[VERIFY] OK: Assets\$($r.Path)" -ForegroundColor Green
    }
}

if ($failed) {
    Write-Host "[RESULT] Install tugadi, lekin verify fail bo'ldi." -ForegroundColor Red
    exit 1
}

Write-Host "[RESULT] Patch12 force install muvaffaqiyatli tugadi." -ForegroundColor Green
Write-Host "Endi Unity'ni oching. Agar Library cache eski bo'lsa: Unity yopiq holda Library\ScriptAssemblies papkasini o'chirib qayta oching." -ForegroundColor Cyan
