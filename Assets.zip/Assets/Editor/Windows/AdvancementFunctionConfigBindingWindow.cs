#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEngine;

public class AdvancementFunctionConfigBindingWindow : EditorWindow
{
    private string projectRoot = string.Empty;
    private string modId = "mymod";
    private Vector2 scroll;
    private string reportText = "Click Load Workspace, then Validate or Generate.";
    private object workspace;

    [MenuItem("Mod Studio/Advancement Function Config Binding Generator...")]
    public static void Open()
    {
        GetWindow<AdvancementFunctionConfigBindingWindow>("Adv/Func/Config Binding");
    }

    [MenuItem("Tools/Mod Studio/Advancement Function Config Binding Generator...")]
    public static void OpenFromTools()
    {
        Open();
    }

    private void OnEnable()
    {
        TryLoadWorkspace();
        TryAutofillProjectRoot();
        TryAutofillModId();
    }

    private void OnGUI()
    {
        EditorGUILayout.LabelField("Advancement / Function / Config Real Binding", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox("Advancement Editor, Function Editor va Config Editor fieldlarini DataModel + Generator/PatchEngine + Validator + Binding manifest zanjiriga ulaydi.", MessageType.Info);

        using (new EditorGUILayout.VerticalScope("box"))
        {
            EditorGUILayout.LabelField("Project", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                projectRoot = EditorGUILayout.TextField("Project Root", projectRoot);
                if (GUILayout.Button("Browse", GUILayout.Width(80)))
                {
                    string selected = EditorUtility.OpenFolderPanel("Select exported Minecraft project root", string.IsNullOrEmpty(projectRoot) ? Application.dataPath : projectRoot, string.Empty);
                    if (!string.IsNullOrEmpty(selected)) projectRoot = selected;
                }
            }
            modId = EditorGUILayout.TextField("Mod ID", modId);
        }

        using (new EditorGUILayout.HorizontalScope())
        {
            if (GUILayout.Button("Load Workspace", GUILayout.Height(28))) TryLoadWorkspace();
            if (GUILayout.Button("Validate", GUILayout.Height(28))) Validate();
            if (GUILayout.Button("Generate Binding", GUILayout.Height(28))) Generate();
        }

        using (new EditorGUILayout.HorizontalScope())
        {
            if (GUILayout.Button("Open Project", GUILayout.Height(24))) OpenFolder(projectRoot);
            if (GUILayout.Button("Open Report", GUILayout.Height(24))) OpenFolder(Path.Combine(projectRoot, ".modstudio/reports"));
            if (GUILayout.Button("Export Field Catalog", GUILayout.Height(24))) ExportFieldCatalog();
        }

        EditorGUILayout.Space();
        EditorGUILayout.LabelField("Report", EditorStyles.boldLabel);
        scroll = EditorGUILayout.BeginScrollView(scroll);
        EditorGUILayout.TextArea(reportText, GUILayout.ExpandHeight(true));
        EditorGUILayout.EndScrollView();
    }

    private void TryLoadWorkspace()
    {
        workspace = GetStaticMember("WorkspaceManager", "workspace");
        if (workspace != null)
        {
            reportText = "Workspace loaded from WorkspaceManager.workspace";
            TryAutofillModId();
        }
        else
        {
            reportText = "WorkspaceManager.workspace not found. Generate can still export field catalog, but no advancement/function/config objects will be generated.";
        }
    }

    private void TryAutofillProjectRoot()
    {
        object pathObj = GetStaticMember("WorkspaceManager", "ProjectPath");
        string path = pathObj as string;
        if (!string.IsNullOrEmpty(path))
        {
            projectRoot = path;
            return;
        }

        object currentPathObj = GetStaticMember("WorkspaceManager", "currentProjectPath");
        string currentPath = currentPathObj as string;
        if (!string.IsNullOrEmpty(currentPath)) projectRoot = currentPath;
    }

    private void TryAutofillModId()
    {
        if (workspace == null) return;
        string fromWorkspace = AdvancementFunctionConfigBindingUtility.GetFirstString(workspace, new string[] { "modId" }, null);
        if (!string.IsNullOrEmpty(fromWorkspace))
        {
            modId = fromWorkspace;
            return;
        }

        object projectSettings = AdvancementFunctionConfigBindingUtility.GetMemberValue(workspace, "project");
        string fromProject = AdvancementFunctionConfigBindingUtility.GetFirstString(projectSettings, new string[] { "modId" }, null);
        if (!string.IsNullOrEmpty(fromProject)) modId = fromProject;
    }

    private void Validate()
    {
        TryLoadWorkspace();
        List<string> issues = AdvancementFunctionConfigBindingValidator.Validate(workspace);
        if (issues.Count == 0)
        {
            reportText = "Advancement/Function/Config validation passed. No serious binding issue found.";
            return;
        }

        reportText = "Advancement/Function/Config validation issues:\n";
        for (int i = 0; i < issues.Count; i++) reportText += "- " + issues[i] + "\n";
    }

    private void Generate()
    {
        TryLoadWorkspace();
        if (string.IsNullOrEmpty(projectRoot))
        {
            EditorUtility.DisplayDialog("Project root kerak", "Avval exported Minecraft project root tanlang.", "OK");
            return;
        }

        AdvancementFunctionConfigBindingReport report = AdvancementFunctionConfigBindingGenerator.Generate(workspace, projectRoot, modId);
        AdvancementFunctionConfigFieldBindingCatalog.Export(projectRoot, modId);
        reportText = report.Format();
        AssetDatabase.Refresh();
    }

    private void ExportFieldCatalog()
    {
        if (string.IsNullOrEmpty(projectRoot))
        {
            EditorUtility.DisplayDialog("Project root kerak", "Avval project root tanlang.", "OK");
            return;
        }
        AdvancementFunctionConfigFieldBindingCatalog.Export(projectRoot, modId);
        reportText = "Field binding catalog exported to .modstudio/field-bindings/advancement-function-config-field-catalog.json";
    }

    private static void OpenFolder(string path)
    {
        if (string.IsNullOrEmpty(path) || !Directory.Exists(path)) return;
        EditorUtility.RevealInFinder(path);
    }

    private static object GetStaticMember(string typeName, string memberName)
    {
        Type type = FindType(typeName);
        if (type == null) return null;
        const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;
        FieldInfo field = type.GetField(memberName, flags);
        if (field != null) return field.GetValue(null);
        PropertyInfo prop = type.GetProperty(memberName, flags);
        if (prop != null && prop.GetIndexParameters().Length == 0) return prop.GetValue(null, null);
        return null;
    }

    private static Type FindType(string name)
    {
        Type direct = Type.GetType(name);
        if (direct != null) return direct;
        Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
        for (int i = 0; i < assemblies.Length; i++)
        {
            Type type = assemblies[i].GetType(name);
            if (type != null) return type;
        }
        return null;
    }
}
#endif
