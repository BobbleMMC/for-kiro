using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

public class JavaStubApplyWindow : EditorWindow
{
    private const string PrefProjectRoot = "ModStudio.JavaStubApply.ProjectRoot";
    private TextField projectPathField;
    private Toggle overwriteToggle;
    private Toggle backupToggle;
    private Label statusLabel;
    private ScrollView outputScroll;
    private Label outputText;

    [MenuItem("Mod Studio/Apply Java Stubs...")]
    public static void Open()
    {
        JavaStubApplyWindow window = GetWindow<JavaStubApplyWindow>();
        window.titleContent = new GUIContent("Apply Java Stubs");
        window.minSize = new Vector2(720, 520);
        window.Show();
    }

    public void CreateGUI()
    {
        VisualElement root = rootVisualElement;
        root.style.paddingLeft = 10;
        root.style.paddingRight = 10;
        root.style.paddingTop = 10;
        root.style.paddingBottom = 10;

        Label title = new Label("Apply Java Stubs");
        title.style.unityFontStyleAndWeight = FontStyle.Bold;
        title.style.fontSize = 18;
        root.Add(title);

        Label help = new Label("Preview and apply .modstudio/generated-java/*.java.stub files into src/main/java with backup and sandbox checks.");
        help.style.whiteSpace = WhiteSpace.Normal;
        help.style.marginBottom = 8;
        root.Add(help);

        VisualElement pathRow = new VisualElement();
        pathRow.style.flexDirection = FlexDirection.Row;
        pathRow.style.marginBottom = 6;
        root.Add(pathRow);

        projectPathField = new TextField("Minecraft project root");
        projectPathField.value = LoadDefaultProjectRoot();
        projectPathField.style.flexGrow = 1;
        pathRow.Add(projectPathField);

        Button browse = new Button(BrowseProjectRoot) { text = "Browse" };
        browse.style.marginLeft = 6;
        pathRow.Add(browse);

        overwriteToggle = new Toggle("Overwrite existing Java files");
        overwriteToggle.value = false;
        root.Add(overwriteToggle);

        backupToggle = new Toggle("Backup existing files before overwrite");
        backupToggle.value = true;
        root.Add(backupToggle);

        VisualElement buttonRow = new VisualElement();
        buttonRow.style.flexDirection = FlexDirection.Row;
        buttonRow.style.marginTop = 8;
        buttonRow.style.marginBottom = 8;
        root.Add(buttonRow);

        Button scan = new Button(Preview) { text = "Scan / Preview" };
        scan.style.marginRight = 6;
        buttonRow.Add(scan);

        Button apply = new Button(Apply) { text = "Apply to src/main/java" };
        apply.style.marginRight = 6;
        buttonRow.Add(apply);

        Button openReports = new Button(OpenReports) { text = "Open Reports" };
        openReports.style.marginRight = 6;
        buttonRow.Add(openReports);

        Button openGenerated = new Button(OpenGenerated) { text = "Open Generated Stubs" };
        buttonRow.Add(openGenerated);

        statusLabel = new Label("Ready.");
        statusLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
        statusLabel.style.marginTop = 4;
        statusLabel.style.marginBottom = 4;
        root.Add(statusLabel);

        outputScroll = new ScrollView(ScrollViewMode.VerticalAndHorizontal);
        outputScroll.style.flexGrow = 1;
        outputScroll.style.borderTopWidth = 1;
        outputScroll.style.borderBottomWidth = 1;
        outputScroll.style.borderLeftWidth = 1;
        outputScroll.style.borderRightWidth = 1;
        outputScroll.style.paddingLeft = 6;
        outputScroll.style.paddingRight = 6;
        outputScroll.style.paddingTop = 6;
        outputScroll.style.paddingBottom = 6;
        root.Add(outputScroll);

        outputText = new Label();
        outputText.style.whiteSpace = WhiteSpace.Pre;
        outputText.text = "Click Scan / Preview after running Mod Studio Save/Export.";
        outputScroll.Add(outputText);
    }

    private void BrowseProjectRoot()
    {
        string start = GetProjectRoot();
        if (string.IsNullOrEmpty(start) || !Directory.Exists(start)) start = Application.dataPath;
        string selected = EditorUtility.OpenFolderPanel("Select exported Minecraft project root", start, "");
        if (!string.IsNullOrEmpty(selected))
        {
            projectPathField.value = selected;
            SaveProjectRoot(selected);
        }
    }

    private void Preview()
    {
        JavaStubApplyRequest request = BuildRequest(true);
        JavaStubApplyResult result = JavaStubApplier.Preview(request);
        SaveProjectRoot(request.projectRoot);
        RenderResult(result, true);
    }

    private void Apply()
    {
        JavaStubApplyRequest previewRequest = BuildRequest(true);
        JavaStubApplyResult preview = JavaStubApplier.Preview(previewRequest);
        if (preview.errors.Count > 0)
        {
            RenderResult(preview, true);
            EditorUtility.DisplayDialog("Apply Java Stubs", "Preview failed. Fix errors first.", "OK");
            return;
        }

        if (preview.WillWriteCount == 0)
        {
            RenderResult(preview, true);
            EditorUtility.DisplayDialog("Apply Java Stubs", "No files to apply. Check generated stubs or overwrite setting.", "OK");
            return;
        }

        string message = "This will write " + preview.WillWriteCount + " Java file(s) into src/main/java.";
        if (overwriteToggle.value) message += "\nExisting files may be overwritten.";
        if (backupToggle.value) message += "\nA backup will be created under .modstudio/backups.";

        bool ok = EditorUtility.DisplayDialog("Apply Java Stubs", message, "Apply", "Cancel");
        if (!ok) return;

        JavaStubApplyRequest request = BuildRequest(false);
        JavaStubApplyResult result = JavaStubApplier.Apply(request);
        SaveProjectRoot(request.projectRoot);
        RenderResult(result, false);

        if (result.success)
            EditorUtility.DisplayDialog("Apply Java Stubs", "Java stubs applied. Check src/main/java and run Gradle build.", "OK");
        else
            EditorUtility.DisplayDialog("Apply Java Stubs", "Apply finished with errors. See report.", "OK");
    }

    private void OpenReports()
    {
        string root = GetProjectRoot();
        string reports = Path.Combine(root, ".modstudio", "reports");
        if (!Directory.Exists(reports)) Directory.CreateDirectory(reports);
        EditorUtility.RevealInFinder(reports);
    }

    private void OpenGenerated()
    {
        string root = GetProjectRoot();
        string generated = Path.Combine(root, ".modstudio", "generated-java");
        if (!Directory.Exists(generated))
        {
            EditorUtility.DisplayDialog("Generated stubs not found", "Run Mod Studio Save/Export first.\n\n" + generated, "OK");
            return;
        }
        EditorUtility.RevealInFinder(generated);
    }

    private JavaStubApplyRequest BuildRequest(bool dryRun)
    {
        return JavaStubApplyRequest.Create(GetProjectRoot(), overwriteToggle.value, backupToggle.value, dryRun);
    }

    private void RenderResult(JavaStubApplyResult result, bool preview)
    {
        if (result == null) return;
        statusLabel.text = (preview ? "Preview" : "Apply") + ": discovered " + result.DiscoveredCount + ", write " + result.WillWriteCount + ", skipped " + result.SkippedCount + ", errors " + result.errors.Count;
        outputText.text = result.FormatSummary();
    }

    private string GetProjectRoot()
    {
        return projectPathField == null ? LoadDefaultProjectRoot() : (projectPathField.value ?? "").Trim();
    }

    private string LoadDefaultProjectRoot()
    {
        string saved = EditorPrefs.GetString(PrefProjectRoot, "");
        if (!string.IsNullOrEmpty(saved)) return saved;

        // Reasonable default for exported project if user exports inside Unity project root.
        string unityRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        return unityRoot;
    }

    private void SaveProjectRoot(string root)
    {
        if (!string.IsNullOrWhiteSpace(root)) EditorPrefs.SetString(PrefProjectRoot, root.Trim());
    }
}
