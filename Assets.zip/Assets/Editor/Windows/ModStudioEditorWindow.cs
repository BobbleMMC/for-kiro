using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

/// <summary>
/// Stable desktop UI shell for Mod Studio.
/// This patch intentionally builds editor panels in C# instead of cloning UXML snippets.
/// Reason: some Unity versions render uie:HelpBox / nested snippet layouts incorrectly,
/// causing overlapping controls. The stable shell keeps all editor pages visible and usable.
/// </summary>
public class ModStudioEditorWindow : EditorWindow
{
    private readonly List<Button> _treeButtons = new List<Button>();
    private ScrollView _tree;
    private ScrollView _form;
    private ScrollView _terminal;
    private TextField _code;
    private Label _header;
    private Label _pathLabel;
    private string _projectPath = string.Empty;

    private static readonly List<EditorPage> Pages = new List<EditorPage>
    {
        new EditorPage("project", "CORE", "⚙ Project Settings", "Project Settings Editor", "Mod project metadata, loader, versions, build and release defaults."),
        new EditorPage("config", "CORE", "🧾 Config Editor", "Config Editor", "Common/client/server config files, defaults, validation and schema preview."),

        new EditorPage("item", "ITEMS / BLOCKS", "📦 Advanced Item", "Advanced Item Editor", "Stack, rarity, durability, food, behavior, model and data component settings."),
        new EditorPage("block", "ITEMS / BLOCKS", "🧱 Advanced Block", "Advanced Block Editor", "Strength, rendering, collision, state, behavior and block entity entry settings."),
        new EditorPage("blockstate", "ITEMS / BLOCKS", "🔁 BlockState Editor", "BlockState Editor", "Variants, multipart rules, state properties and model mapping."),
        new EditorPage("blockentity", "ITEMS / BLOCKS", "📦 BlockEntity Editor", "BlockEntity Editor", "Inventory, fluid, energy, ticker, sync, screen and renderer hooks."),
        new EditorPage("tool-material", "ITEMS / BLOCKS", "⚒ Tool Material", "Tool Material Editor", "Mining speed, durability, attack, repair ingredient and effective tags."),
        new EditorPage("armor-material", "ITEMS / BLOCKS", "🛡 Armor Material", "Armor Material Editor", "Protection, toughness, repair, equip sound, trim and set bonus settings."),
        new EditorPage("food", "ITEMS / BLOCKS", "🍖 Food Editor", "Food Editor", "Nutrition, saturation, eating behavior, effects and remainder item."),
        new EditorPage("datacomponent", "ITEMS / BLOCKS", "🧬 Data Components", "Data Component Editor", "1.21+ item/block component data, custom data and typed values."),

        new EditorPage("recipe", "DATA", "🍳 Recipe Pro", "Recipe Editor Pro", "Shaped, shapeless, furnace, stonecutting, smithing and custom recipes."),
        new EditorPage("loot", "DATA", "🎁 Loot Table", "Loot Table Editor", "Block/entity/chest/gameplay loot pools, conditions and functions."),
        new EditorPage("tag", "DATA", "🏷 Tag Editor", "Tag Editor", "Block, item, entity, biome, fluid, damage and function tags."),
        new EditorPage("advancement", "DATA", "🏆 Advancement", "Advancement Editor", "Criteria, rewards, display, parent and JSON preview."),
        new EditorPage("function", "DATA", "📜 Function", "Function Editor", "mcfunction files, load/tick tags and command chains."),

        new EditorPage("entity-ai", "ENTITIES", "🤖 Entity AI", "Entity AI Editor", "AI goals, target goals, sensors, behavior flags and task priorities."),
        new EditorPage("entity-spawn", "ENTITIES", "🥚 Entity Spawn", "Entity Spawn Editor", "Spawn egg, biome rules, light, height, group size and spawn weights."),
        new EditorPage("effect", "ENTITIES", "🧪 Effect / Potion", "Effect / Potion Editor", "Mob effects, potion variants, duration, amplifier and attributes."),
        new EditorPage("enchantment", "ENTITIES", "✨ Enchantment", "Enchantment Editor", "Levels, rarity, applicable tags, exclusivity and effect hooks."),

        new EditorPage("biome", "WORLDGEN", "🌍 Biome Pro", "Biome Pro Editor", "Climate, colors, particles, music, spawns, features and tags."),
        new EditorPage("dimension", "WORLDGEN", "🌌 Dimension", "Dimension Editor", "Dimension type, generator, biome source and world rules."),
        new EditorPage("structure", "WORLDGEN", "🏛 Structure", "Structure Editor", "Jigsaw, spacing, terrain adaptation, pools and structure sets."),

        new EditorPage("texture", "CLIENT / ASSETS", "🎨 Texture Editor", "Texture Editor Pro", "Pixel-art tools, layers, palette, animation and Minecraft export settings."),
        new EditorPage("sound", "CLIENT / ASSETS", "🔊 Sound", "Sound Editor", "Sound events, variants, subtitles, categories, pitch and volume."),
        new EditorPage("particle", "CLIENT / ASSETS", "✨ Particle", "Particle Editor", "Textures, lifetime, motion, gravity, color, scale and emitters."),
        new EditorPage("gui", "CLIENT / ASSETS", "🖥 GUI / Screen", "GUI / Screen Editor", "Screens, menus, slots, bars, buttons, labels and sync properties."),
        new EditorPage("networking", "CLIENT / ASSETS", "📡 Networking", "Networking Editor", "Packets, payload fields, direction, handlers and validation."),
        new EditorPage("keybind", "CLIENT / ASSETS", "⌨ Keybind", "Keybind Editor", "Key mappings, categories, on-press/on-hold behavior and packets."),

        new EditorPage("asset-browser", "MANAGEMENT", "🗃 Asset Browser", "Asset Browser", "Scan resources, missing files, generated assets and export status."),
        new EditorPage("release", "MANAGEMENT", "🚀 Release Manager", "Release Manager", "Build gate, metadata, README, changelog, license and release package.")
    };

    [MenuItem("Mod Studio/Open Editor", priority = 0)]
    [MenuItem("Tools/Mod Studio/Open Editor", priority = 0)]
    public static void OpenEditor()
    {
        ModStudioEditorWindow window = GetWindow<ModStudioEditorWindow>();
        window.titleContent = new GUIContent("Mod Studio");
        window.minSize = new Vector2(1180f, 760f);
        window.Show();
        window.Focus();
    }

    [MenuItem("Mod Studio/Rebuild Stable UI", priority = 20)]
    public static void RebuildOpenWindow()
    {
        ModStudioEditorWindow window = GetWindow<ModStudioEditorWindow>();
        window.BuildUi();
        window.Show();
        window.Focus();
    }

    private void CreateGUI()
    {
        BuildUi();
    }

    private void OnEnable()
    {
        titleContent = new GUIContent("Mod Studio");
    }

    private void BuildUi()
    {
        VisualElement root = rootVisualElement;
        root.Clear();
        root.style.flexGrow = 1f;
        root.style.backgroundColor = ColorFromHex("#1e1e1e");

        VisualElement app = new VisualElement { name = "modstudio-stable-app" };
        app.style.flexGrow = 1f;
        app.style.backgroundColor = ColorFromHex("#1e1e1e");
        root.Add(app);

        BuildToolbar(app);
        BuildBody(app);
        PopulateProjectTree();
        SelectPage(Pages[0], null);
        Log("[UI] Stable desktop UI yuklandi. UXML overlap muammosi chetlab o'tildi.");
    }

    private void BuildToolbar(VisualElement parent)
    {
        VisualElement toolbar = new VisualElement { name = "toolbar-panel" };
        toolbar.style.height = 38f;
        toolbar.style.flexShrink = 0f;
        toolbar.style.flexDirection = FlexDirection.Row;
        toolbar.style.alignItems = Align.Center;
        toolbar.style.paddingLeft = 6f;
        toolbar.style.paddingRight = 6f;
        toolbar.style.backgroundColor = ColorFromHex("#2d2d2d");
        parent.Add(toolbar);

        AddToolbarButton(toolbar, "Yangi Loyiha", delegate { Log("[Project] Yangi loyiha flow Project Core bilan ulanadi."); });
        AddToolbarButton(toolbar, "Saqlash", delegate { Log("[Save] UI shell saqlandi. Real WorkspaceManager hook keyingi integratsiyada ulanadi."); });
        AddToolbarButton(toolbar, "Tekshirish", delegate { Log("[Validate] " + Pages.Count + " ta editor sahifasi UI’da mavjud."); });
        AddToolbarButton(toolbar, "📁 Papkani Tanlash", SelectProjectFolder);
        AddToolbarButton(toolbar, "Build Jar", delegate { Log("[Build] Build Runner mavjud bo‘lsa shu tugmaga ulanadi."); });
        AddToolbarButton(toolbar, "Run Client", delegate { Log("[RunClient] Export/build hook keyingi bosqichda ulanadi."); }, "#2e7d32");
        AddToolbarButton(toolbar, "Stop", delegate { Log("[Stop] Gradle process stop hook keyingi integratsiyada ulanadi."); });
        AddToolbarButton(toolbar, "Analyze Log", delegate { Log("[Analyze] Error Analyzer hook keyingi integratsiyada ulanadi."); });

        _pathLabel = new Label("Project path tanlanmagan");
        _pathLabel.style.flexGrow = 1f;
        _pathLabel.style.unityTextAlign = TextAnchor.MiddleRight;
        _pathLabel.style.color = ColorFromHex("#999999");
        _pathLabel.style.fontSize = 10f;
        toolbar.Add(_pathLabel);
    }

    private static void AddToolbarButton(VisualElement parent, string text, Action clicked, string color = null)
    {
        Button button = new Button(clicked) { text = text };
        button.style.height = 26f;
        button.style.marginRight = 5f;
        button.style.paddingLeft = 8f;
        button.style.paddingRight = 8f;
        button.style.backgroundColor = ColorFromHex(color ?? "#3c3c3c");
        button.style.color = Color.white;
        button.style.borderTopLeftRadius = 3f;
        button.style.borderTopRightRadius = 3f;
        button.style.borderBottomLeftRadius = 3f;
        button.style.borderBottomRightRadius = 3f;
        parent.Add(button);
    }

    private void BuildBody(VisualElement parent)
    {
        VisualElement body = new VisualElement();
        body.style.flexGrow = 1f;
        body.style.flexDirection = FlexDirection.Row;
        parent.Add(body);

        VisualElement leftPanel = new VisualElement();
        leftPanel.style.width = 250f;
        leftPanel.style.flexShrink = 0f;
        leftPanel.style.backgroundColor = ColorFromHex("#1b1b1c");
        leftPanel.style.borderRightWidth = 1f;
        leftPanel.style.borderRightColor = ColorFromHex("#333333");
        body.Add(leftPanel);

        AddPanelHeader(leftPanel, "LOYIHA DARAXTI");
        _tree = new ScrollView();
        _tree.style.flexGrow = 1f;
        leftPanel.Add(_tree);

        VisualElement center = new VisualElement();
        center.style.flexGrow = 1f;
        center.style.flexDirection = FlexDirection.Column;
        center.style.backgroundColor = ColorFromHex("#202020");
        body.Add(center);

        _header = new Label("Editor");
        _header.style.height = 30f;
        _header.style.flexShrink = 0f;
        _header.style.paddingLeft = 10f;
        _header.style.unityTextAlign = TextAnchor.MiddleLeft;
        _header.style.color = ColorFromHex("#cfcfcf");
        _header.style.unityFontStyleAndWeight = FontStyle.Bold;
        _header.style.backgroundColor = ColorFromHex("#252526");
        center.Add(_header);

        _form = new ScrollView();
        _form.style.flexGrow = 1f;
        _form.style.paddingLeft = 18f;
        _form.style.paddingRight = 18f;
        _form.style.paddingTop = 14f;
        _form.style.paddingBottom = 18f;
        center.Add(_form);

        VisualElement right = new VisualElement();
        right.style.width = 520f;
        right.style.flexShrink = 0f;
        right.style.flexDirection = FlexDirection.Column;
        right.style.borderLeftWidth = 1f;
        right.style.borderLeftColor = ColorFromHex("#333333");
        body.Add(right);

        AddPanelHeader(right, "JAVA / JSON PREVIEW");
        _code = new TextField { multiline = true };
        _code.style.flexGrow = 1f;
        _code.style.minHeight = 310f;
        _code.style.backgroundColor = ColorFromHex("#1e1e1e");
        _code.style.color = ColorFromHex("#d4d4d4");
        _code.style.fontSize = 12f;
        right.Add(_code);

        AddPanelHeader(right, "BUILD / GRADLE TERMINALI");
        _terminal = new ScrollView();
        _terminal.style.height = 170f;
        _terminal.style.flexShrink = 0f;
        _terminal.style.backgroundColor = Color.black;
        _terminal.style.paddingLeft = 8f;
        _terminal.style.paddingTop = 6f;
        right.Add(_terminal);
    }

    private static void AddPanelHeader(VisualElement parent, string text)
    {
        Label label = new Label(text);
        label.style.height = 28f;
        label.style.flexShrink = 0f;
        label.style.paddingLeft = 8f;
        label.style.unityTextAlign = TextAnchor.MiddleLeft;
        label.style.color = ColorFromHex("#aeaeae");
        label.style.fontSize = 11f;
        label.style.unityFontStyleAndWeight = FontStyle.Bold;
        label.style.backgroundColor = ColorFromHex("#252526");
        parent.Add(label);
    }

    private void PopulateProjectTree()
    {
        if (_tree == null) return;
        _tree.Clear();
        _treeButtons.Clear();

        string category = string.Empty;
        foreach (EditorPage page in Pages)
        {
            if (page.Category != category)
            {
                category = page.Category;
                AddTreeCategory(category);
            }
            AddTreeButton(page);
        }
    }

    private void AddTreeCategory(string text)
    {
        Label label = new Label(text);
        label.style.color = ColorFromHex("#777777");
        label.style.fontSize = 10f;
        label.style.unityFontStyleAndWeight = FontStyle.Bold;
        label.style.marginTop = 8f;
        label.style.marginBottom = 3f;
        label.style.marginLeft = 10f;
        _tree.Add(label);
    }

    private void AddTreeButton(EditorPage page)
    {
        Button button = new Button { text = page.Label, tooltip = page.Description };
        button.style.height = 30f;
        button.style.marginLeft = 8f;
        button.style.marginRight = 8f;
        button.style.marginBottom = 4f;
        button.style.unityTextAlign = TextAnchor.MiddleLeft;
        button.style.color = ColorFromHex("#cccccc");
        button.style.backgroundColor = ColorFromHex("#242424");
        button.clicked += delegate { SelectPage(page, button); };
        _treeButtons.Add(button);
        _tree.Add(button);
    }

    private void SelectPage(EditorPage page, Button selectedButton)
    {
        foreach (Button button in _treeButtons)
        {
            button.style.backgroundColor = ColorFromHex("#242424");
            button.style.color = ColorFromHex("#cccccc");
            button.style.borderLeftWidth = 0f;
        }
        if (selectedButton != null)
        {
            selectedButton.style.backgroundColor = ColorFromHex("#3e3e42");
            selectedButton.style.color = Color.white;
            selectedButton.style.borderLeftWidth = 3f;
            selectedButton.style.borderLeftColor = ColorFromHex("#007acc");
        }

        if (_header != null) _header.text = page.Title;
        BuildStableEditorForm(page);
        WritePreview(page);
        Log("[UI] Ochildi: " + page.Title);
    }

    private void BuildStableEditorForm(EditorPage page)
    {
        _form.Clear();

        Label title = new Label(page.Title);
        title.style.fontSize = 18f;
        title.style.unityFontStyleAndWeight = FontStyle.Bold;
        title.style.color = Color.white;
        title.style.marginBottom = 8f;
        _form.Add(title);

        AddHelpCard(page.Description + "\nBu stable UI mode: UXML HelpBox/overlap muammosini chetlab o‘tish uchun C# orqali chiziladi.");

        switch (page.Id)
        {
            case "project":
                AddSection("Project Identity");
                AddText("Mod ID", "mymod"); AddText("Display Name", "My Mod"); AddText("Version", "1.0.0"); AddText("Package", "net.mymod");
                AddSection("Environment");
                AddDropdown("Loader", new List<string>{"Fabric", "NeoForge", "Forge", "Quilt"}, 0); AddText("Minecraft Version", "1.21.1"); AddInteger("Java Version", 21); AddText("Mappings", "Yarn / Mojmap / Parchment");
                AddSection("Release");
                AddText("Author", "Akmalbek"); AddText("License", "MIT"); AddMultiline("Description", "Mod tavsifi...");
                break;
            case "config":
                AddSection("Config File");
                AddText("Config ID", "common_config"); AddDropdown("Format", new List<string>{"TOML", "JSON", "Properties"}, 0); AddDropdown("Scope", new List<string>{"Common", "Client", "Server"}, 0); AddText("File Name", "mymod-common.toml"); AddToggle("Requires Restart", false);
                AddSection("Entries"); AddMultiline("Entries CSV", "enable_feature,bool,true\nmax_value,int,100"); AddToggle("Generate Schema", true); AddToggle("Sync to Client", false);
                break;
            case "item":
                AddSection("Basic"); AddText("Item ID", "ruby_ingot"); AddText("Display Name", "Ruby Ingot"); AddInteger("Max Stack Size", 64); AddDropdown("Rarity", new List<string>{"Common", "Uncommon", "Rare", "Epic"}, 0);
                AddSection("Durability / Food / Visual"); AddInteger("Max Damage", 0); AddToggle("Fireproof", false); AddToggle("Food Item", false); AddText("Texture Path", "item/ruby_ingot"); AddText("Model Parent", "item/generated");
                break;
            case "block":
                AddSection("Basic"); AddText("Block ID", "ruby_block"); AddText("Display Name", "Ruby Block"); AddFloat("Hardness", 3f); AddFloat("Blast Resistance", 6f);
                AddSection("Rendering / Behavior"); AddToggle("Opaque", true); AddInteger("Light Level", 0); AddToggle("Requires Tool", true); AddText("Mining Tool Tag", "mineable/pickaxe"); AddToggle("Waterloggable", false); AddToggle("Block Entity", false);
                break;
            case "blockstate":
                AddSection("Properties"); AddMultiline("State Properties", "facing=north,south,east,west\npowered=true,false"); AddDropdown("Blockstate Type", new List<string>{"Variants", "Multipart", "Custom JSON"}, 0); AddMultiline("Custom JSON", "{}");
                break;
            case "blockentity":
                AddSection("Storage"); AddInteger("Inventory Slots", 9); AddToggle("Fluid Tank", false); AddToggle("Energy Storage", false); AddToggle("Ticker", true); AddToggle("Client Sync", true);
                AddSection("Screen Hook"); AddText("Menu Class", "RubyBlockMenu"); AddText("Screen Class", "RubyBlockScreen");
                break;
            case "tool-material":
                AddSection("Tool Material"); AddText("Material ID", "ruby"); AddInteger("Durability", 1024); AddFloat("Mining Speed", 7f); AddFloat("Attack Damage Bonus", 3f); AddInteger("Enchantability", 18); AddText("Repair Ingredient", "mymod:ruby_ingot");
                break;
            case "armor-material":
                AddSection("Armor Material"); AddText("Material ID", "ruby"); AddInteger("Durability Multiplier", 30); AddText("Protection CSV", "3,8,6,3"); AddFloat("Toughness", 2f); AddText("Repair Ingredient", "mymod:ruby_ingot"); AddText("Equip Sound", "minecraft:item.armor.equip_diamond");
                break;
            case "food":
                AddSection("Food Component"); AddInteger("Nutrition", 4); AddFloat("Saturation", 0.4f); AddToggle("Always Edible", false); AddToggle("Fast Eating", false); AddText("Remainder Item", ""); AddMultiline("Effects CSV", "speed,200,1,0.25");
                break;
            case "datacomponent":
                AddSection("Data Components"); AddMultiline("Components", "minecraft:max_stack_size=64\nminecraft:rarity=common\nminecraft:custom_data={}"); AddToggle("Use 1.21+ Components", true);
                break;
            case "recipe":
                AddSection("Recipe Pro"); AddText("Recipe ID", "ruby_block"); AddDropdown("Type", new List<string>{"Shaped", "Shapeless", "Smelting", "Blasting", "Smoking", "Stonecutting", "Smithing"}, 0); AddText("Result", "mymod:ruby_block"); AddInteger("Count", 1); AddMultiline("Pattern / Ingredients", "RRR\nRRR\nRRR\nR=mymod:ruby_ingot");
                break;
            case "loot":
                AddSection("Loot Table"); AddText("Loot ID", "blocks/ruby_block"); AddDropdown("Type", new List<string>{"Block", "Entity", "Chest", "Gameplay", "Custom"}, 0); AddInteger("Pools", 1); AddText("Entry", "mymod:ruby_block"); AddToggle("Explosion Decay", true); AddMultiline("Conditions / Functions JSON", "{}");
                break;
            case "tag":
                AddSection("Tag"); AddDropdown("Tag Type", new List<string>{"items", "blocks", "entity_types", "biomes", "fluids", "damage_types", "functions"}, 0); AddText("Tag ID", "mineable/pickaxe"); AddToggle("Replace", false); AddMultiline("Values", "mymod:ruby_block");
                break;
            case "entity-ai":
                AddSection("AI Goals"); AddText("Entity ID", "ruby_golem"); AddMultiline("Goals", "swim:0\nmelee_attack:2\nwander:5\nlook_at_player:6"); AddMultiline("Target Goals", "revenge:1\nnearest_player:2");
                break;
            case "entity-spawn":
                AddSection("Spawn Rules"); AddText("Entity ID", "ruby_golem"); AddInteger("Spawn Weight", 20); AddInteger("Min Group", 1); AddInteger("Max Group", 3); AddText("Biome Tags", "#minecraft:is_overworld"); AddText("Spawn Egg Colors", "#aa0033,#330011");
                break;
            case "biome":
                AddSection("Climate"); AddText("Biome ID", "ruby_forest"); AddFloat("Temperature", 0.8f); AddFloat("Downfall", 0.4f); AddText("Category", "forest"); AddText("Colors", "sky=#78a7ff water=#3f76e4 grass=#59c93c");
                AddSection("Features / Spawns"); AddMultiline("Placed Features", "ore_ruby\nruby_tree"); AddMultiline("Mob Spawns", "minecraft:wolf,8,2,4");
                break;
            case "dimension":
                AddSection("Dimension"); AddText("Dimension ID", "ruby_dimension"); AddDropdown("Generator", new List<string>{"Noise", "Flat", "Debug", "Custom"}, 0); AddToggle("Has Skylight", true); AddToggle("Natural", true); AddInteger("Min Y", -64); AddInteger("Height", 384); AddFloat("Coordinate Scale", 1f);
                break;
            case "structure":
                AddSection("Structure"); AddText("Structure ID", "ruby_tower"); AddText("Start Pool", "mymod:ruby_tower/start_pool"); AddInteger("Spacing", 24); AddInteger("Separation", 8); AddInteger("Salt", 123456); AddText("Biomes", "#minecraft:is_overworld");
                break;
            case "texture":
                AddSection("Texture Tools"); AddDropdown("Target", new List<string>{"block", "item", "entity", "armor", "gui", "particle", "effect", "enchantment", "dimension"}, 0); AddText("Texture ID", "ruby_block"); AddDropdown("Tool", new List<string>{"Pencil", "Eraser", "Fill", "Line", "Rectangle", "Ellipse", "Gradient", "Noise", "Shade", "Dodge", "Clone", "Selection", "Mirror", "Rotate"}, 0); AddInteger("Brush Size", 1); AddToggle("Grid", true); AddToggle("Tile Preview", false); AddHelpCard("Real canvas: Mod Studio > Texture Editor Pro... oynasida ishlaydi.");
                break;
            case "sound":
                AddSection("Sound Event"); AddText("Sound ID", "block.ruby_block.hit"); AddText("Subtitle", "Ruby block hit"); AddDropdown("Category", new List<string>{"block", "player", "hostile", "neutral", "music", "record", "weather", "ambient", "ui"}, 0); AddFloat("Volume", 1f); AddFloat("Pitch", 1f); AddMultiline("Variants", "ruby_block_hit1.ogg\nruby_block_hit2.ogg");
                break;
            case "particle":
                AddSection("Particle"); AddText("Particle ID", "ruby_spark"); AddText("Texture", "particle/ruby_spark"); AddInteger("Lifetime", 20); AddFloat("Speed", 0.1f); AddFloat("Gravity", 0f); AddText("Color", "#ff0033"); AddFloat("Scale", 1f);
                break;
            case "gui":
                AddSection("GUI / Screen"); AddText("Screen ID", "ruby_furnace"); AddText("Menu Class", "RubyFurnaceMenu"); AddText("Screen Class", "RubyFurnaceScreen"); AddText("Background Texture", "gui/ruby_furnace"); AddMultiline("Slots CSV", "input,56,17\nfuel,56,53\noutput,116,35"); AddMultiline("Bars", "progress,79,34,24,17\nenergy,8,8,16,60");
                break;
            case "networking":
                AddSection("Packet"); AddText("Packet ID", "open_ruby_screen"); AddDropdown("Direction", new List<string>{"client_to_server", "server_to_client"}, 0); AddMultiline("Fields", "blockPos,BlockPos\nvalue,int"); AddToggle("Validate Server Side", true); AddText("Handler Class", "OpenRubyScreenPacketHandler");
                break;
            case "keybind":
                AddSection("Keybind"); AddText("Keybind ID", "open_ruby_menu"); AddText("Default Key", "R"); AddText("Category", "key.categories.mymod"); AddDropdown("Action", new List<string>{"on_press", "on_hold", "toggle"}, 0); AddText("Packet", "open_ruby_screen");
                break;
            case "advancement":
                AddSection("Advancement"); AddText("Advancement ID", "root"); AddText("Title", "Ruby Mod"); AddText("Description", "Start your ruby journey"); AddText("Icon", "mymod:ruby_ingot"); AddDropdown("Frame", new List<string>{"task", "goal", "challenge"}, 0); AddMultiline("Criteria", "has_ruby=mymod:ruby_ingot");
                break;
            case "function":
                AddSection("Function"); AddText("Function ID", "tick"); AddToggle("Add to tick tag", false); AddToggle("Add to load tag", false); AddMultiline("Commands", "say Hello from MyMod");
                break;
            case "effect":
                AddSection("Effect / Potion"); AddText("Effect ID", "ruby_power"); AddDropdown("Category", new List<string>{"beneficial", "harmful", "neutral"}, 0); AddText("Color", "#ff0033"); AddToggle("Instant", false); AddMultiline("Attribute Modifiers", "minecraft:generic.attack_damage,+2,add_value");
                break;
            case "enchantment":
                AddSection("Enchantment"); AddText("Enchantment ID", "ruby_edge"); AddInteger("Max Level", 5); AddInteger("Weight", 5); AddText("Applicable Tag", "#minecraft:swords"); AddToggle("Treasure", false); AddToggle("Curse", false); AddMultiline("Effects", "on_hit=extra_damage");
                break;
            case "asset-browser":
                AddSection("Asset Browser"); AddText("Resource Root", "src/main/resources"); AddDropdown("Filter", new List<string>{"all", "texture", "model", "blockstate", "lang", "recipe", "missing"}, 0); AddText("Search", ""); AddHelpCard("Full scanner keyingi resource-manager hook bilan ulanadi.");
                break;
            case "release":
                AddSection("Release Gate"); AddText("Version", "1.0.0"); AddToggle("Require Build Jar", true); AddToggle("Require README", true); AddToggle("Require LICENSE", true); AddText("Output", ".modstudio/releases"); AddHelpCard("Release Manager build/libs ichidagi jar va metadata bilan ishlaydi.");
                break;
            default:
                AddSection("Basic"); AddText("ID", page.Id.Replace('-', '_')); AddText("Display Name", page.Title); AddToggle("Enabled", true); AddMultiline("Notes", page.Description);
                break;
        }
    }

    private void AddHelpCard(string text)
    {
        VisualElement card = new VisualElement();
        card.style.flexShrink = 0f;
        card.style.marginBottom = 10f;
        card.style.paddingLeft = 10f;
        card.style.paddingRight = 10f;
        card.style.paddingTop = 8f;
        card.style.paddingBottom = 8f;
        card.style.backgroundColor = ColorFromHex("#253044");
        card.style.borderLeftWidth = 3f;
        card.style.borderLeftColor = ColorFromHex("#4c8dff");
        Label label = new Label(text);
        label.style.whiteSpace = WhiteSpace.Normal;
        label.style.color = ColorFromHex("#d7e7ff");
        label.style.fontSize = 11f;
        card.Add(label);
        _form.Add(card);
    }

    private void AddSection(string text)
    {
        Label section = new Label(text);
        section.style.flexShrink = 0f;
        section.style.marginTop = 10f;
        section.style.marginBottom = 6f;
        section.style.paddingTop = 5f;
        section.style.paddingBottom = 5f;
        section.style.paddingLeft = 8f;
        section.style.backgroundColor = ColorFromHex("#2a2a2a");
        section.style.color = ColorFromHex("#ffffff");
        section.style.unityFontStyleAndWeight = FontStyle.Bold;
        _form.Add(section);
    }

    private TextField AddText(string label, string value)
    {
        TextField field = new TextField(label) { value = value };
        StyleField(field);
        _form.Add(field);
        return field;
    }

    private TextField AddMultiline(string label, string value)
    {
        TextField field = new TextField(label) { value = value, multiline = true };
        StyleField(field);
        field.style.minHeight = 64f;
        _form.Add(field);
        return field;
    }

    private IntegerField AddInteger(string label, int value)
    {
        IntegerField field = new IntegerField(label) { value = value };
        StyleField(field);
        _form.Add(field);
        return field;
    }

    private FloatField AddFloat(string label, float value)
    {
        FloatField field = new FloatField(label) { value = value };
        StyleField(field);
        _form.Add(field);
        return field;
    }

    private Toggle AddToggle(string label, bool value)
    {
        Toggle field = new Toggle(label) { value = value };
        StyleField(field);
        _form.Add(field);
        return field;
    }

    private DropdownField AddDropdown(string label, List<string> choices, int index)
    {
        DropdownField field = new DropdownField(label, choices, Mathf.Clamp(index, 0, choices.Count - 1));
        StyleField(field);
        _form.Add(field);
        return field;
    }

    private static void StyleField(BaseField<string> field) { StyleBaseField(field); }
    private static void StyleField(IntegerField field) { StyleBaseField(field); }
    private static void StyleField(FloatField field) { StyleBaseField(field); }
    private static void StyleField(Toggle field) { StyleBaseField(field); }
    private static void StyleField(DropdownField field) { StyleBaseField(field); }

    private static void StyleBaseField(VisualElement field)
    {
        field.style.flexShrink = 0f;
        field.style.marginBottom = 5f;
        field.style.minHeight = 24f;
        field.style.color = Color.white;
    }

    private void WritePreview(EditorPage page)
    {
        if (_code == null) return;
        string className = ToPascalCase(page.Id) + "GeneratedPreview";
        _code.value = "// " + page.Title + "\n" +
                      "// " + page.Description + "\n" +
                      "// Stable UI mode: fields are rendered in C# to prevent UXML overlap.\n\n" +
                      "public final class " + className + " {\n" +
                      "    // Generator/PatchEngine keyingi bosqichda shu editor fieldlarini real Java/JSON fayllarga ulaydi.\n" +
                      "}\n";
    }

    private void SelectProjectFolder()
    {
        string folder = EditorUtility.OpenFolderPanel("Minecraft mod project papkasini tanlang", Application.dataPath, "");
        if (string.IsNullOrEmpty(folder)) return;
        _projectPath = folder;
        if (_pathLabel != null) _pathLabel.text = _projectPath;
        Log("[Project] Project folder: " + _projectPath);
    }

    private void Log(string message)
    {
        if (_terminal != null)
        {
            Label line = new Label(message);
            line.style.color = Color.green;
            line.style.fontSize = 12f;
            _terminal.Add(line);
            _terminal.ScrollTo(line);
        }
        Debug.Log("[Mod Studio] " + message);
    }

    private static string ToPascalCase(string value)
    {
        if (string.IsNullOrEmpty(value)) return "Editor";
        string[] parts = value.Split(new[] { '-', '_', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        string result = string.Empty;
        foreach (string part in parts)
        {
            if (string.IsNullOrEmpty(part)) continue;
            result += char.ToUpperInvariant(part[0]) + (part.Length > 1 ? part.Substring(1) : string.Empty);
        }
        return string.IsNullOrEmpty(result) ? "Editor" : result;
    }

    private static Color ColorFromHex(string hex)
    {
        if (string.IsNullOrEmpty(hex)) return Color.white;
        if (!hex.StartsWith("#")) hex = "#" + hex;
        Color color;
        return ColorUtility.TryParseHtmlString(hex, out color) ? color : Color.white;
    }

    private sealed class EditorPage
    {
        public readonly string Id;
        public readonly string Category;
        public readonly string Label;
        public readonly string Title;
        public readonly string Description;

        public EditorPage(string id, string category, string label, string title, string description)
        {
            Id = id;
            Category = category;
            Label = label;
            Title = title;
            Description = description;
        }
    }
}
