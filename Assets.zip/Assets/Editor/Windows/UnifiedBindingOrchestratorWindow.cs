#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

public class UnifiedBindingOrchestratorWindow : EditorWindow
{
    private TextField projectRootField;
    private TextField outputText;
    private StudioBindingOrchestrationReport lastBindingReport;
    private StudioQualityGateReport lastQualityReport;

    [MenuItem("Mod Studio/Unified Binding Orchestrator...")]
    public static void OpenFromModStudioMenu()
    {
        var window = GetWindow<UnifiedBindingOrchestratorWindow>();
        window.titleContent = new GUIContent("Binding Orchestrator");
        window.minSize = new Vector2(820, 560);
        window.Show();
    }

    [MenuItem("Tools/Mod Studio/Unified Binding Orchestrator...")]
    public static void OpenFromToolsMenu()
    {
        OpenFromModStudioMenu();
    }

    private void CreateGUI()
    {
        rootVisualElement.style.paddingLeft = 10;
        rootVisualElement.style.paddingRight = 10;
        rootVisualElement.style.paddingTop = 10;
        rootVisualElement.style.paddingBottom = 10;

        var title = new Label("Unified Binding Orchestrator / Quality Gate");
        title.style.unityFontStyleAndWeight = FontStyle.Bold;
        title.style.fontSize = 16;
        title.style.marginBottom = 8;
        rootVisualElement.Add(title);

        var help = new Label("Bu panel patch27-32 binding generatorlarining outputlarini bir joyda tekshiradi va release/build oldidan quality gate hisobot beradi.");
        help.style.whiteSpace = WhiteSpace.Normal;
        help.style.marginBottom = 8;
        rootVisualElement.Add(help);

        var row = new VisualElement();
        row.style.flexDirection = FlexDirection.Row;
        row.style.marginBottom = 6;
        rootVisualElement.Add(row);

        projectRootField = new TextField("Project Root");
        projectRootField.style.flexGrow = 1;
        projectRootField.value = GuessProjectRoot();
        row.Add(projectRootField);

        var browseBtn = new Button(BrowseProjectRoot) { text = "Browse" };
        browseBtn.style.width = 90;
        browseBtn.style.marginLeft = 6;
        row.Add(browseBtn);

        var buttons = new VisualElement();
        buttons.style.flexDirection = FlexDirection.Row;
        buttons.style.marginBottom = 8;
        rootVisualElement.Add(buttons);

        buttons.Add(MakeButton("Analyze Bindings", AnalyzeBindings));
        buttons.Add(MakeButton("Run Quality Gate", RunQualityGate));
        buttons.Add(MakeButton("Write Reports", WriteReports));
        buttons.Add(MakeButton("Open Reports", OpenReportsFolder));
        buttons.Add(MakeButton("Write Run Plan", WriteRunPlan));

        outputText = new TextField();
        outputText.multiline = true;
        outputText.isReadOnly = true;
        outputText.style.flexGrow = 1;
        outputText.style.whiteSpace = WhiteSpace.Normal;
        outputText.value = "Project root tanlang va Analyze Bindings yoki Run Quality Gate bosing.";
        rootVisualElement.Add(outputText);
    }

    private Button MakeButton(string text, System.Action action)
    {
        var button = new Button(action) { text = text };
        button.style.marginRight = 6;
        return button;
    }

    private void BrowseProjectRoot()
    {
        string start = Directory.Exists(projectRootField.value) ? projectRootField.value : System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
        string selected = EditorUtility.OpenFolderPanel("Minecraft Mod Project Root", start, "");
        if (!string.IsNullOrEmpty(selected)) projectRootField.value = selected;
    }

    private void AnalyzeBindings()
    {
        lastBindingReport = StudioBindingOrchestrator.Analyze(projectRootField.value);
        outputText.value = lastBindingReport.FormatText();
    }

    private void RunQualityGate()
    {
        lastQualityReport = StudioQualityGate.Run(projectRootField.value);
        outputText.value = lastQualityReport.FormatText();
    }

    private void WriteReports()
    {
        string root = projectRootField.value;
        if (!Directory.Exists(root))
        {
            EditorUtility.DisplayDialog("Project root noto'g'ri", "Project root topilmadi.", "OK");
            return;
        }

        if (lastBindingReport == null) lastBindingReport = StudioBindingOrchestrator.Analyze(root);
        if (lastQualityReport == null) lastQualityReport = StudioQualityGate.Run(root);

        string bindingPath = StudioBindingOrchestrator.WriteReport(root, lastBindingReport);
        string qualityPath = StudioQualityGate.WriteReport(root, lastQualityReport);
        outputText.value = "Reports yozildi:\n" + bindingPath + "\n" + qualityPath + "\n\n" + lastQualityReport.FormatText();
        AssetDatabase.Refresh();
    }

    private void WriteRunPlan()
    {
        string root = projectRootField.value;
        if (!Directory.Exists(root))
        {
            EditorUtility.DisplayDialog("Project root noto'g'ri", "Project root topilmadi.", "OK");
            return;
        }

        string path = StudioBindingOrchestrator.WriteRunPlan(root);
        outputText.value = "Binding run plan yozildi:\n" + path + "\n\nBu plan har bir binding generatorni qaysi tartibda qo'lda ishga tushirish kerakligini ko'rsatadi.";
        AssetDatabase.Refresh();
    }

    private void OpenReportsFolder()
    {
        string root = projectRootField.value;
        string path = Path.Combine(root, ".modstudio", "reports");
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        EditorUtility.RevealInFinder(path);
    }

    private string GuessProjectRoot()
    {
        try
        {
            string documents = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
            string defaultPath = Path.Combine(documents, "MinecraftMods", "MyMod");
            if (Directory.Exists(defaultPath)) return defaultPath;
        }
        catch
        {
            // ignored
        }
        return Application.dataPath.Replace("/Assets", "");
    }
}
#endif
