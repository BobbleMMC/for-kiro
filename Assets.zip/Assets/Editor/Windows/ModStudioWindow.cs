using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;

public class ModStudioWindow : EditorWindow
{
    public enum EditorMode
    {
        Block,
        Item,
        Tool,
        Armor,
        Recipe,
        LootTable,
        TagManager,
        Mob,
        Biome,
        Dimension,
        Structure,
        GuiScreen,
        Config,
        Networking,
        Keybind,
        CreativeTab,
        TexturePainter,
        AssetBrowser,
        ReleasePanel,
        ProjectSettings
    }

    // ── Current-index tracking (multi-element support) ──────────────────────
    private int _currentBlockIdx  = 0;
    private int _currentItemIdx   = 0;
    private int _currentToolIdx   = 0;
    private int _currentArmorIdx  = 0;
    private int _currentRecipeIdx = 0;
    private int _currentLootIdx   = 0;
    private int _currentTagIdx    = 0;
    private int _currentEntityIdx = 0;
    private int _currentBiomeIdx  = 0;
    private int _currentDimensionIdx = 0;
    private int _currentStructureIdx = 0;
    private int _currentScreenIdx = 0;
    private int _currentConfigIdx = 0;
    private int _currentNetworkPacketIdx = 0;
    private int _currentKeybindIdx = 0;
    private int _currentTabIdx    = 0;

    // Safe indexed getters — always clamps to valid range
    private BlockDataModel       _currentBlock  => WorkspaceManager.workspace.blocks     [Mathf.Clamp(_currentBlockIdx,  0, WorkspaceManager.workspace.blocks.Count     - 1)];
    private ItemDataModel        _currentItem   => WorkspaceManager.workspace.items      [Mathf.Clamp(_currentItemIdx,   0, WorkspaceManager.workspace.items.Count      - 1)];
    private ToolDataModel        _currentTool   => WorkspaceManager.workspace.tools      [Mathf.Clamp(_currentToolIdx,   0, WorkspaceManager.workspace.tools.Count      - 1)];
    private ArmorDataModel       _currentArmor  => WorkspaceManager.workspace.armors     [Mathf.Clamp(_currentArmorIdx,  0, WorkspaceManager.workspace.armors.Count     - 1)];
    private RecipeDataModel      _currentRecipe => WorkspaceManager.workspace.recipes    [Mathf.Clamp(_currentRecipeIdx, 0, WorkspaceManager.workspace.recipes.Count    - 1)];
    private LootTableDataModel   _currentLoot   => WorkspaceManager.workspace.lootTables [Mathf.Clamp(_currentLootIdx,   0, WorkspaceManager.workspace.lootTables.Count - 1)];
    private TagDataModel         _currentTag     => WorkspaceManager.workspace.tags       [Mathf.Clamp(_currentTagIdx,    0, WorkspaceManager.workspace.tags.Count       - 1)];
    private EntityDataModel      _currentEntity => WorkspaceManager.workspace.entities   [Mathf.Clamp(_currentEntityIdx, 0, WorkspaceManager.workspace.entities.Count   - 1)];
    private BiomeDataModel       _currentBiome  => WorkspaceManager.workspace.biomes     [Mathf.Clamp(_currentBiomeIdx,  0, WorkspaceManager.workspace.biomes.Count     - 1)];
    private DimensionDataModel   _currentDimension => WorkspaceManager.workspace.dimensions[Mathf.Clamp(_currentDimensionIdx, 0, WorkspaceManager.workspace.dimensions.Count - 1)];
    private StructureDataModel   _currentStructure => WorkspaceManager.workspace.structures[Mathf.Clamp(_currentStructureIdx, 0, WorkspaceManager.workspace.structures.Count - 1)];
    private ScreenDataModel      _currentScreen => WorkspaceManager.workspace.screens[Mathf.Clamp(_currentScreenIdx, 0, WorkspaceManager.workspace.screens.Count - 1)];
    private ConfigDataModel      _currentConfig => WorkspaceManager.workspace.configs[Mathf.Clamp(_currentConfigIdx, 0, WorkspaceManager.workspace.configs.Count - 1)];
    private NetworkPacketDataModel _currentNetworkPacket => WorkspaceManager.workspace.networkPackets[Mathf.Clamp(_currentNetworkPacketIdx, 0, WorkspaceManager.workspace.networkPackets.Count - 1)];
    private KeybindDataModel     _currentKeybind => WorkspaceManager.workspace.keybinds[Mathf.Clamp(_currentKeybindIdx, 0, WorkspaceManager.workspace.keybinds.Count - 1)];
    private CreativeTabDataModel _currentTab    => WorkspaceManager.workspace.creativeTabs[Mathf.Clamp(_currentTabIdx,  0, WorkspaceManager.workspace.creativeTabs.Count - 1)];

    private EditorMode _currentMode = EditorMode.Block;
    private GradleCompiler _gradleCompiler;

    // UI Elementlari
    private TextField _codePreviewField; 
    private Label _terminalLogLabel;
    
    // Tugmalar
    private Button _globalSaveBtn;
    private Button _codeLocalSaveBtn;
    private Button _runBtn;
    private Button _buildBtn;
    private Button _stopBtn;
    private Button _analyzeLogBtn;

    // Cheksiz sikldan saqlovchi xavfsizlik bayrog'i (Infinite Loop Guard)
    // Counter-based: nested chaqiruvlarni to'g'ri boshqaradi
    private int _updateGuardCount = 0;
    private bool _isUpdating
    {
        get => _updateGuardCount > 0;
        set
        {
            if (value)
                _updateGuardCount++;
            else
                _updateGuardCount = Mathf.Max(0, _updateGuardCount - 1);
        }
    }

    /// <summary>
    /// Xavfsiz guard bloki — try/finally orqali _isUpdating doim reset bo'lishini kafolatlaydi.
    /// Qo'llanilishi: using (new UpdateGuard(this)) { ... }
    /// </summary>
    private struct UpdateGuard : IDisposable
    {
        private ModStudioWindow _window;
        public UpdateGuard(ModStudioWindow window) { _window = window; _window._updateGuardCount++; }
        public void Dispose() { _window._updateGuardCount = Mathf.Max(0, _window._updateGuardCount - 1); }
    }

    // Loyiha eksport yo'li — EditorPrefs da saqlanadi (cross-platform)
    private const string PREF_KEY_PROJECT_PATH = "ModStudio_ProjectPath";
    private string _projectPath;

    private string ProjectPath
    {
        get
        {
            if (string.IsNullOrEmpty(_projectPath))
            {
                _projectPath = EditorPrefs.GetString(PREF_KEY_PROJECT_PATH, GetDefaultProjectPath());
            }
            return _projectPath;
        }
        set
        {
            _projectPath = value;
            EditorPrefs.SetString(PREF_KEY_PROJECT_PATH, value);
        }
    }

    /// <summary>
    /// OS ga mos standart loyiha papkasini qaytaradi.
    /// Windows: Documents/MinecraftMods/MyMod
    /// macOS/Linux: ~/MinecraftMods/MyMod
    /// </summary>
    private static string GetDefaultProjectPath()
    {
        string basePath;

        switch (Application.platform)
        {
            case RuntimePlatform.WindowsEditor:
            case RuntimePlatform.WindowsPlayer:
                basePath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
                break;
            case RuntimePlatform.OSXEditor:
            case RuntimePlatform.OSXPlayer:
                basePath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
                break;
            default: // Linux va boshqalar
                basePath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
                break;
        }

        return Path.Combine(basePath, "MinecraftMods", "MyMod");
    }

    /// <summary>
    /// Foydalanuvchiga loyiha papkasini tanlash dialogini ko'rsatadi.
    /// </summary>
    private void BrowseProjectFolder()
    {
        string currentPath = ProjectPath;
        string startDir = Directory.Exists(currentPath) ? currentPath : GetDefaultProjectPath();
        
        string selectedPath = EditorUtility.OpenFolderPanel(
            "Minecraft Mod Loyiha Papkasini Tanlang",
            startDir,
            ""
        );

        if (!string.IsNullOrEmpty(selectedPath))
        {
            ProjectPath = selectedPath;
            LogToTerminal($"[Loyiha] Yangi loyiha yo'li o'rnatildi: {selectedPath}");
        }
    }

    // Tekstura chizgich xususiyatlari
    private Color[] _pixels = new Color[256];
    private Texture2D _previewTexture;
    private Color _activePaintColor = Color.red;
    private string _activeTool = "pencil"; // pencil, eraser, bucket, eyedropper
    private string _paintFilename = "custom_block_texture";
    private string _paintTargetFolder = "block"; // block yoki item texture folder

    // Asset Browser holati
    private StudioAssetBrowserReport _assetBrowserReport;
    private string _assetBrowserFilter = "all";
    private string _assetBrowserSearch = "";
    private bool _assetBrowserShowMissing = true;

    // Release Manager holati
    private StudioReleaseReport _releaseReport;
    private string _releaseVersion = "1.0.0";

    [MenuItem("Mod Studio/Oynani Ochish")]
    public static void OpenWorkspace()
    {
        ModStudioWindow wnd = GetWindow<ModStudioWindow>();
        wnd.titleContent = new GUIContent("Mod Studio Desktop");
        wnd.minSize = new Vector2(1000, 650);
    }

    public static void BatchExportAll()
    {
        Debug.Log("[BatchExport] Start batch export...");
        StudioDatabase.Initialize();
        
        // Initialize workspace with dummy/default data to test export output
        WorkspaceManager.workspace = new WorkspaceData();
        WorkspaceManager.workspace.modId = "mymod";
        WorkspaceManager.workspace.modName = "My Epic Mod";
        WorkspaceManager.workspace.mcVersion = "1.20.1";
        WorkspaceManager.workspace.modloader = "Fabric";
        
        // Populate test block
        var block = new BlockDataModel {
            blockId = "custom_ruby_block",
            displayName = "Ruby Block",
            hardness = 5.0f,
            resistance = 6.0f,
            lightLevel = 15,
            creativeTab = MinecraftCreativeTab.BuildingBlocks,
            texturePath = "custom_ruby_block"
        };
        WorkspaceManager.workspace.blocks.Add(block);
        
        // Populate test item
        var item = new ItemDataModel {
            itemId = "custom_ruby",
            displayName = "Ruby",
            stackSize = 64,
            isFood = false,
            creativeTab = MinecraftCreativeTab.Misc
        };
        WorkspaceManager.workspace.items.Add(item);
        
        // Populate test tool
        var tool = new ToolDataModel {
            toolId = "ruby_pickaxe",
            displayName = "Ruby Pickaxe",
            durability = 1500,
            attackDamage = 6.0f,
            attackSpeed = -2.8f,
            miningLevel = 3,
            toolType = ToolType.Pickaxe
        };
        WorkspaceManager.workspace.tools.Add(tool);
        
        // Populate test armor
        var armor = new ArmorDataModel {
            armorId = "ruby_chestplate",
            displayName = "Ruby Chestplate",
            defense = 8,
            toughness = 2.0f,
            knockbackResistance = 0.0f,
            armorSlot = ArmorSlot.Chestplate
        };
        WorkspaceManager.workspace.armors.Add(armor);
        
        // Populate test recipe
        var recipe = new RecipeDataModel {
            resultItem = "custom_ruby_block",
            resultCount = 1,
            grid = new string[9] {
                "custom_ruby", "custom_ruby", "custom_ruby",
                "custom_ruby", "custom_ruby", "custom_ruby",
                "custom_ruby", "custom_ruby", "custom_ruby"
            }
        };
        WorkspaceManager.workspace.recipes.Add(recipe);
        
        // Save and compile/export
        string testPath = GetDefaultProjectPath();
        WorkspaceManager.SaveWorkspace(testPath);
        WorkspaceManager.CompileAndExportAll(testPath);
        Debug.Log($"[BatchExport] Batch export finished successfully! Path: {testPath}");
    }

    public void CreateGUI()
    {
        VisualElement root = rootVisualElement;

        // Ma'lumotlar bazasini ishga tushiramiz
        StudioDatabase.Initialize();

        // 1. Workspace-ni papkadan yuklaymiz yoki yangi yaratamiz
        bool loaded = WorkspaceManager.LoadWorkspace(ProjectPath);
        if (!loaded)
        {
            WorkspaceManager.workspace = new WorkspaceData();
            WorkspaceManager.SaveWorkspace(ProjectPath);
        }

        // Ma'lumotlar strukturasining izchilligini kafolatlaymiz
        VerifyWorkspaceConsistency();

        // Tekstura piksellarini boshlang'ich shovqin holatida to'ldiramiz
        InitializeDefaultPixels();

        // 2. Asosiy UXML strukturasini xavfsiz yuklash
        var visualTree = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Assets/UI/UXML/ModStudioEditor.uxml");
        if (visualTree != null) 
        {
            root.Add(visualTree.Instantiate());
        }
        else
        {
            Debug.LogError("Xato: Assets/UI/UXML/ModStudioEditor.uxml fayli topilmadi! Manzilni tekshiring.");
            return;
        }

        // 3. Asosiy USS stillarini yuklash
        var mainStyleSheet = AssetDatabase.LoadAssetAtPath<StyleSheet>("Assets/UI/Styles/ModStudioEditor.uss");
        if (mainStyleSheet != null) 
        {
            root.styleSheets.Add(mainStyleSheet);
        }

        // 4. Loyiha Daraxtini Dinamik Yaratish
        var treeContainer = root.Q<ScrollView>("project-tree-container");
        if (treeContainer != null)
        {
            treeContainer.Clear();

            // Sarlavha
            Label categoryLabel = new Label("LOYIHA ELEMENTLARI");
            categoryLabel.AddToClassList("tree-category");
            treeContainer.Add(categoryLabel);

            // Daraxt elementlari (Jami 10 ta modul)
            CreateTreeItem(treeContainer, "🧱 Blok Tahrirlovchi", EditorMode.Block);
            CreateTreeItem(treeContainer, "💎 Buyum Tahrirlovchi", EditorMode.Item);
            CreateTreeItem(treeContainer, "⚔️ Qurol Tahrirlovchi", EditorMode.Tool);
            CreateTreeItem(treeContainer, "🛡️ Zirh Tahrirlovchi", EditorMode.Armor);
            CreateTreeItem(treeContainer, "📜 Retsept Tahrirlovchi", EditorMode.Recipe);
            CreateTreeItem(treeContainer, "🎁 Loot Table Editor", EditorMode.LootTable);
            CreateTreeItem(treeContainer, "🏷️ Tag Manager", EditorMode.TagManager);
            CreateTreeItem(treeContainer, "👾 Mob Tahrirlovchi", EditorMode.Mob);
            CreateTreeItem(treeContainer, "🌲 Bioma Tahrirlovchi", EditorMode.Biome);
            CreateTreeItem(treeContainer, "🌌 Dimension Editor", EditorMode.Dimension);
            CreateTreeItem(treeContainer, "🏛️ Structure Editor", EditorMode.Structure);
            CreateTreeItem(treeContainer, "🖥️ GUI / Screen Editor", EditorMode.GuiScreen);
            CreateTreeItem(treeContainer, "🧾 Config Editor", EditorMode.Config);
            CreateTreeItem(treeContainer, "📡 Networking Editor", EditorMode.Networking);
            CreateTreeItem(treeContainer, "⌨️ Keybind Editor", EditorMode.Keybind);
            CreateTreeItem(treeContainer, "🗂️ Creative Tab Tahrir", EditorMode.CreativeTab);
            CreateTreeItem(treeContainer, "🎨 Tekstura Tahrirlovchi", EditorMode.TexturePainter);
            CreateTreeItem(treeContainer, "🗃️ Asset Browser", EditorMode.AssetBrowser);
            CreateTreeItem(treeContainer, "🚀 Release Manager", EditorMode.ReleasePanel);
            
            // Loyiha sozlamalari pastroqda alohida bo'limda turadi
            Label settingsCategory = new Label("SOZLAMALAR");
            settingsCategory.AddToClassList("tree-category");
            treeContainer.Add(settingsCategory);
            CreateTreeItem(treeContainer, "⚙️ Loyiha Sozlamalari", EditorMode.ProjectSettings);
        }

        // 5. 3D Viewport snippetini Loyiha daraxti ichiga joylashtirish
        var viewportTree = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Assets/UI/UXML/ModStudioEditor_ViewportSnippet.uxml");
        if (viewportTree != null && treeContainer != null)
        {
            VisualElement viewportVisual = viewportTree.Instantiate();
            treeContainer.Add(viewportVisual);
        }

        // 6. 3D Viewport USS stillarini asosiy oynaga ulash
        var viewportStyle = AssetDatabase.LoadAssetAtPath<StyleSheet>("Assets/UI/Styles/ModStudioEditor_Viewport.uss");
        if (viewportStyle != null) 
        {
            root.styleSheets.Add(viewportStyle);
        }

        // 7. UI elementlarini UXML ichidan qidirib topish
        _codePreviewField = root.Q<TextField>("code-field");
        _terminalLogLabel = root.Q<Label>(className: "terminal-log-text");
        
        // Tugmalarni ID bo'yicha bog'lash
        _globalSaveBtn = root.Q<Button>("btn-save");
        _codeLocalSaveBtn = root.Q<Button>("btn-code-save");
        _runBtn = root.Q<Button>("btn-run");
        _buildBtn = root.Q<Button>("btn-build");
        _stopBtn = root.Q<Button>("btn-stop");
        _analyzeLogBtn = root.Q<Button>("btn-analyze-log");

        var validateBtn = root.Q<Button>("btn-validate");
        if (validateBtn != null)
        {
            validateBtn.clicked += ValidateCurrentProject;
        }

        // 📁 Papka tanlash tugmasi va yo'l ko'rsatgich
        var browseBtn = root.Q<Button>("btn-browse");
        var pathLabel = root.Q<Label>("label-project-path");
        if (browseBtn != null)
        {
            browseBtn.clicked += () => {
                BrowseProjectFolder();
                if (pathLabel != null) pathLabel.text = ProjectPath;
            };
        }
        if (pathLabel != null) pathLabel.text = ProjectPath;

        if (_codePreviewField == null)
        {
            Debug.LogError("Xato: UXML ichida 'code-field' topilmadi!");
            return; 
        }

        // 8. TextField ichida Rich Text (ranglar) ko'rinishini faollashtirish
        var textInput = _codePreviewField.Q("unity-text-input");
        if (textInput != null)
        {
            var textElement = textInput.Q<TextElement>();
            if (textElement != null) textElement.enableRichText = true;
        }

        // 9. LOKAL KODNI SAQLASH TUGMASI LOGIKASI (Tugma bosilganda kod o'qiladi)
        if (_codeLocalSaveBtn != null)
        {
            _codeLocalSaveBtn.clicked += ExecuteTwoWaySync;
        }

        // Global saqlash tugmasi (Loyiha parametrlarini diskka yozadi va eksport qiladi)
        if (_globalSaveBtn != null)
        {
            _globalSaveBtn.clicked += SaveProjectAndExport;
        }

        // 10. Build Runner xizmatini faollashtirish (Gradle build/runClient/log analyzer)
        _gradleCompiler = new GradleCompiler(LogToTerminal, ErrorToTerminal);

        if (_buildBtn != null)
        {
            _buildBtn.clicked += BuildCurrentProject;
        }

        if (_runBtn != null)
        {
            _runBtn.clicked += RunMinecraftClientFromStudio;
        }

        if (_stopBtn != null)
        {
            _stopBtn.clicked += StopCurrentGradleProcess;
        }

        if (_analyzeLogBtn != null)
        {
            _analyzeLogBtn.clicked += AnalyzeLastGradleLog;
        }

        // 11. Boshlang'ich rejimni Blok qilib yuklaymiz
        SwitchEditorMode(EditorMode.Block);
        // ModStudioWindow.cs ichidagi CreateGUI() metodining oxiriga qo'shing:
        // UV Mapper modulini tekshirish uchun ulaymiz
        if (_globalSaveBtn != null)
        {
            _globalSaveBtn.clicked += () =>
            {
                CuboidUVMapper uvMapper = FindFirstObjectByType<CuboidUVMapper>();
                if (uvMapper != null)
                {
                    // Sinov uchun 16x16 rasm atlasidan hamma yuzaga 0 dan 16 pikselgacha to'liq rasm tushsin deymiz
                    Rect fullFace = new Rect(0, 0, 16, 16);
                    uvMapper.ApplyBlockUVs(fullFace, fullFace, fullFace, fullFace, fullFace, fullFace);
                    
                    LogToTerminal("[3D Motor] Kuboid uchun yangi UV Atlas koordinatalari muvaffaqiyatli hisoblandi.");
                }
            };
        }

        BindBlockTransformControls(root);

    }

    private void BindBlockTransformControls(VisualElement root)
    {
        if (root == null) return;

        FloatField pivotX = root.Q<FloatField>("pivot-x");
        FloatField pivotY = root.Q<FloatField>("pivot-y");
        FloatField pivotZ = root.Q<FloatField>("pivot-z");

        Slider rotX = root.Q<Slider>("rotate-x");
        Slider rotY = root.Q<Slider>("rotate-y");
        Slider rotZ = root.Q<Slider>("rotate-z");

        VoxelTransformController transformController = FindFirstObjectByType<VoxelTransformController>();
        if (transformController == null || pivotX == null || pivotY == null || pivotZ == null || rotX == null || rotY == null || rotZ == null)
        {
            return;
        }

        System.Action updatePivot = () =>
        {
            transformController.PivotPoint = new Vector3(pivotX.value, pivotY.value, pivotZ.value);
        };

        System.Action updateRotation = () =>
        {
            transformController.CurrentRotation = new Vector3(rotX.value, rotY.value, rotZ.value);
        };

        pivotX.RegisterValueChangedCallback(evt => updatePivot());
        pivotY.RegisterValueChangedCallback(evt => updatePivot());
        pivotZ.RegisterValueChangedCallback(evt => updatePivot());

        rotX.RegisterValueChangedCallback(evt => updateRotation());
        rotY.RegisterValueChangedCallback(evt => updateRotation());
        rotZ.RegisterValueChangedCallback(evt => updateRotation());
    }

    private void VerifyWorkspaceConsistency()
    {
        var ws = WorkspaceManager.workspace;
        if (ws.blocks == null || ws.blocks.Count == 0) { ws.blocks = new List<BlockDataModel>(); ws.blocks.Add(new BlockDataModel()); }
        if (ws.items == null || ws.items.Count == 0) { ws.items = new List<ItemDataModel>(); ws.items.Add(new ItemDataModel()); }
        if (ws.tools == null || ws.tools.Count == 0) { ws.tools = new List<ToolDataModel>(); ws.tools.Add(new ToolDataModel()); }
        if (ws.armors == null || ws.armors.Count == 0) { ws.armors = new List<ArmorDataModel>(); ws.armors.Add(new ArmorDataModel()); }
        if (ws.recipes == null || ws.recipes.Count == 0) { ws.recipes = new List<RecipeDataModel>(); ws.recipes.Add(new RecipeDataModel()); }
        if (ws.lootTables == null || ws.lootTables.Count == 0) { ws.lootTables = new List<LootTableDataModel>(); ws.lootTables.Add(new LootTableDataModel()); }
        if (ws.tags == null || ws.tags.Count == 0) { ws.tags = new List<TagDataModel>(); ws.tags.Add(new TagDataModel()); }
        if (ws.entities == null || ws.entities.Count == 0) { ws.entities = new List<EntityDataModel>(); ws.entities.Add(new EntityDataModel()); }
        if (ws.biomes == null || ws.biomes.Count == 0) { ws.biomes = new List<BiomeDataModel>(); ws.biomes.Add(new BiomeDataModel()); }
        if (ws.dimensions == null || ws.dimensions.Count == 0) { ws.dimensions = new List<DimensionDataModel>(); ws.dimensions.Add(new DimensionDataModel()); }
        if (ws.structures == null || ws.structures.Count == 0) { ws.structures = new List<StructureDataModel>(); ws.structures.Add(new StructureDataModel()); }
        if (ws.screens == null || ws.screens.Count == 0) { ws.screens = new List<ScreenDataModel>(); ws.screens.Add(new ScreenDataModel()); }
        if (ws.configs == null || ws.configs.Count == 0) { ws.configs = new List<ConfigDataModel>(); ws.configs.Add(new ConfigDataModel()); }
        if (ws.networkPackets == null || ws.networkPackets.Count == 0) { ws.networkPackets = new List<NetworkPacketDataModel>(); ws.networkPackets.Add(new NetworkPacketDataModel()); }
        if (ws.keybinds == null || ws.keybinds.Count == 0) { ws.keybinds = new List<KeybindDataModel>(); ws.keybinds.Add(new KeybindDataModel()); }
        if (ws.creativeTabs == null || ws.creativeTabs.Count == 0) { ws.creativeTabs = new List<CreativeTabDataModel>(); ws.creativeTabs.Add(new CreativeTabDataModel()); }
    }

    private void InitializeDefaultPixels()
    {
        System.Random rand = new System.Random(42);
        for (int i = 0; i < 256; i++)
        {
            float noise = (float)rand.NextDouble() * 0.12f;
            float baseColor = 0.5f + noise;
            _pixels[i] = new Color(baseColor, baseColor, baseColor, 1.0f);
        }
    }

    private void CreateTreeItem(VisualElement container, string labelText, EditorMode mode)
    {
        Label item = new Label(labelText);
        item.userData = mode;
        item.AddToClassList("tree-item");
        if (_currentMode == mode)
        {
            item.AddToClassList("tree-item--selected");
        }
        
        item.RegisterCallback<ClickEvent>(evt => {
            SwitchEditorMode(mode);
        });

        container.Add(item);
    }

    private void UpdateProjectTreeSelection()
    {
        var root = rootVisualElement;
        var treeContainer = root.Q<ScrollView>("project-tree-container");
        if (treeContainer == null) return;

        var items = treeContainer.Query<Label>(className: "tree-item").ToList();
        foreach (var item in items)
        {
            item.RemoveFromClassList("tree-item--selected");

            if (item.userData is EditorMode itemMode && itemMode == _currentMode)
            {
                item.AddToClassList("tree-item--selected");
            }
        }
    }

    private void SwitchEditorMode(EditorMode mode)
    {
        _currentMode = mode;
        UpdateProjectTreeSelection();

        VisualElement root = rootVisualElement;

        // 1. 3D Viewport-ni blok va tekstura chizishda ko'rsatib, boshqalarida yashirish
        var viewportContainer = root.Q<VisualElement>("viewport-3d-container");
        if (viewportContainer != null)
        {
            viewportContainer.style.display = (mode == EditorMode.Block || mode == EditorMode.TexturePainter) ? DisplayStyle.Flex : DisplayStyle.None;
        }

        UpdatePreviewMaterial();

        // 2. Markaziy formani tozalash va tegishli UXML snippetni yuklash
        var formScroll = root.Q<ScrollView>("editor-form-scroll");
        var headerLabel = root.Q<Label>("editor-header");
        if (formScroll == null) return;

        formScroll.Clear();

        string uxmlPath = "";
        string headerText = "";

        switch (mode)
        {
            case EditorMode.Block:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_BlockFields.uxml";
                headerText = "BLOK SOZLAMALARI";
                break;
            case EditorMode.Item:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_ItemFields.uxml";
                headerText = "ITEM SOZLAMALARI";
                break;
            case EditorMode.Tool:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_ToolFields.uxml";
                headerText = "QUROL SOZLAMALARI";
                break;
            case EditorMode.Armor:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_ArmorFields.uxml";
                headerText = "ZIRH SOZLAMALARI";
                break;
            case EditorMode.Recipe:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_RecipeFields.uxml";
                headerText = "VIZUAL RETSEPT TAHRIRLOVCHI";
                break;
            case EditorMode.LootTable:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_LootTableFields.uxml";
                headerText = "LOOT TABLE EDITOR / DROPS";
                break;
            case EditorMode.TagManager:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_TagManager.uxml";
                headerText = "TAG MANAGER / DATA TAGS";
                break;
            case EditorMode.Mob:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_MobFields.uxml";
                headerText = "MOB SOZLAMALARI";
                break;
            case EditorMode.Biome:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_BiomeFields.uxml";
                headerText = "BIOMA SOZLAMALARI";
                break;
            case EditorMode.Dimension:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_DimensionFields.uxml";
                headerText = "DIMENSION EDITOR / WORLD SETTINGS";
                break;
            case EditorMode.Structure:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_StructureFields.uxml";
                headerText = "STRUCTURE EDITOR / STRUCTURE SET";
                break;
            case EditorMode.GuiScreen:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_GuiScreenFields.uxml";
                headerText = "GUI / SCREEN EDITOR";
                break;
            case EditorMode.Config:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_ConfigFields.uxml";
                headerText = "CONFIG EDITOR";
                break;
            case EditorMode.Networking:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_NetworkingFields.uxml";
                headerText = "NETWORKING EDITOR / PACKETS";
                break;
            case EditorMode.Keybind:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_KeybindFields.uxml";
                headerText = "KEYBIND EDITOR / CONTROLS";
                break;
            case EditorMode.CreativeTab:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_CreativeTabFields.uxml";
                headerText = "CREATIVE TAB SOZLAMALARI";
                break;
            case EditorMode.TexturePainter:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_TexturePainter.uxml";
                headerText = "TEKSTURA CHIZGICH";
                break;
            case EditorMode.AssetBrowser:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_AssetBrowser.uxml";
                headerText = "ASSET BROWSER / RESOURCE MANAGER";
                break;
            case EditorMode.ReleasePanel:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_ReleasePanel.uxml";
                headerText = "RELEASE MANAGER / QUALITY GATE";
                break;
            case EditorMode.ProjectSettings:
                uxmlPath = "Assets/UI/UXML/ModStudioEditor_ProjectSettings.uxml";
                headerText = "LOYIHA SOZLAMALARI";
                break;
        }

        if (headerLabel != null) headerLabel.text = headerText;

        var visualTree = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(uxmlPath);
        if (visualTree != null)
        {
            // Navigatsiya bari qo'shamiz (faqat element turlari uchun — TexturePainter va ProjectSettings emas)
            bool hasNavigation = mode != EditorMode.TexturePainter && mode != EditorMode.AssetBrowser && mode != EditorMode.ReleasePanel && mode != EditorMode.ProjectSettings;
            if (hasNavigation)
            {
                formScroll.Add(CreateElementNavigationBar(mode));
            }

            formScroll.Add(visualTree.Instantiate());
        }
        else
        {
            Debug.LogError($"Xato: {uxmlPath} snippet fayli topilmadi!");
            return;
        }

        // 3. UI elementlarini bog'lash
        BindFieldsForMode(mode);

        // 4. Live Preview kodni yangilash
        OnModelChanged();
    }


    private void BindAdvancedItemFields(VisualElement root)
    {
        _currentItem.EnsureAdvancedSettings();
        AdvancedItemSettings adv = _currentItem.advanced;
        FoodItemSettings food = adv.food;
        ItemBehaviorSettings behavior = adv.behavior;
        ItemVisualSettings visual = adv.visual;
        ItemDataComponentSettings components = adv.components;

        BindDropdown(root, "dropdown-item-rarity", adv.rarity.ToString(), value => { if (Enum.TryParse(value, out StudioItemRarity parsed)) adv.rarity = parsed; });
        BindToggle(root, "toggle-item-fireproof", adv.fireproof, value => adv.fireproof = value);
        BindInteger(root, "input-item-max-damage", adv.maxDamage, value => adv.maxDamage = Mathf.Max(0, value));
        BindToggle(root, "toggle-item-enchantable", adv.enchantable, value => adv.enchantable = value);
        BindInteger(root, "input-item-enchantability", adv.enchantability, value => adv.enchantability = Mathf.Clamp(value, 0, 100));
        BindText(root, "input-item-repair", adv.repairItemId, value => adv.repairItemId = value);

        BindInteger(root, "input-food-nutrition", food.nutrition, value => food.nutrition = Mathf.Clamp(value, 0, 40));
        BindFloat(root, "input-food-saturation", food.saturation, value => food.saturation = Mathf.Max(0f, value));
        BindToggle(root, "toggle-food-always-edible", food.alwaysEdible, value => food.alwaysEdible = value);
        BindToggle(root, "toggle-food-fast", food.fastEating, value => food.fastEating = value);
        BindToggle(root, "toggle-food-when-full", food.canEatWhenFull, value => food.canEatWhenFull = value);
        BindText(root, "input-food-return-item", food.afterEatReturnItem, value => food.afterEatReturnItem = value);
        BindText(root, "input-food-effects", food.statusEffects, value => food.statusEffects = value);

        BindDropdown(root, "dropdown-item-use-action", behavior.useAction.ToString(), value => { if (Enum.TryParse(value, out StudioItemUseAction parsed)) behavior.useAction = parsed; });
        BindInteger(root, "input-item-use-duration", behavior.useDuration, value => behavior.useDuration = Mathf.Clamp(value, 0, 72000));
        BindInteger(root, "input-item-cooldown", behavior.cooldownTicks, value => behavior.cooldownTicks = Mathf.Max(0, value));
        BindToggle(root, "toggle-item-right-click", behavior.hasRightClickAction, value => behavior.hasRightClickAction = value);
        BindToggle(root, "toggle-item-inventory-tick", behavior.hasInventoryTick, value => behavior.hasInventoryTick = value);
        BindToggle(root, "toggle-item-craft-remainder", behavior.hasCraftRemainder, value => behavior.hasCraftRemainder = value);
        BindText(root, "input-item-craft-remainder", behavior.craftRemainderItem, value => behavior.craftRemainderItem = value);
        BindText(root, "input-item-tooltip", behavior.tooltipLines, value => behavior.tooltipLines = value);

        BindDropdown(root, "dropdown-item-model-type", visual.modelType.ToString(), value => { if (Enum.TryParse(value, out StudioItemModelType parsed)) visual.modelType = parsed; });
        BindText(root, "input-item-texture-path", visual.texturePath, value => visual.texturePath = value);
        BindText(root, "input-item-custom-model", visual.customModelJsonPath, value => visual.customModelJsonPath = value);
        BindToggle(root, "toggle-item-animated-texture", visual.animatedTexture, value => visual.animatedTexture = value);
        BindToggle(root, "toggle-item-glint", visual.hasGlint, value => visual.hasGlint = value);
        BindText(root, "input-item-tint", visual.tintHex, value => visual.tintHex = value);

        BindToggle(root, "toggle-item-components", components.enableDataComponents, value => components.enableDataComponents = value);
        BindToggle(root, "toggle-component-custom-name", components.customName, value => components.customName = value);
        BindToggle(root, "toggle-component-lore", components.lore, value => components.lore = value);
        BindToggle(root, "toggle-component-repairable", components.repairable, value => components.repairable = value);
        BindToggle(root, "toggle-component-attributes", components.attributeModifiers, value => components.attributeModifiers = value);
        BindText(root, "input-component-custom-data", components.customDataJson, value => components.customDataJson = value);
    }

    private void BindAdvancedBlockFields(VisualElement root)
    {
        _currentBlock.EnsureAdvancedSettings();
        AdvancedBlockSettings adv = _currentBlock.advanced;
        BlockVisualSettings visual = adv.visual;
        BlockBehaviorSettings behavior = adv.behavior;
        BlockCollisionSettings collision = adv.collision;
        BlockStateSettings states = adv.states;
        BlockEntitySettings blockEntity = adv.blockEntity;

        BindInteger(root, "input-block-light", _currentBlock.lightLevel, value => _currentBlock.lightLevel = Mathf.Clamp(value, 0, 15));
        BindDropdown(root, "dropdown-block-sound", adv.soundGroup.ToString(), value => { if (Enum.TryParse(value, out StudioBlockSoundGroup parsed)) adv.soundGroup = parsed; });
        BindInteger(root, "input-block-map-color", adv.mapColor, value => adv.mapColor = Mathf.Max(0, value));

        BindDropdown(root, "dropdown-block-render-layer", visual.renderLayer.ToString(), value => { if (Enum.TryParse(value, out StudioBlockRenderLayer parsed)) visual.renderLayer = parsed; });
        BindToggle(root, "toggle-block-opaque", visual.opaque, value => visual.opaque = value);
        BindToggle(root, "toggle-block-transparent", visual.transparent, value => visual.transparent = value);
        BindToggle(root, "toggle-block-ao", visual.ambientOcclusion, value => visual.ambientOcclusion = value);
        BindToggle(root, "toggle-block-emissive", visual.emissiveTexture, value => visual.emissiveTexture = value);
        BindText(root, "input-block-side-texture", visual.sideTexture, value => visual.sideTexture = value);
        BindText(root, "input-block-top-texture", visual.topTexture, value => visual.topTexture = value);
        BindText(root, "input-block-bottom-texture", visual.bottomTexture, value => visual.bottomTexture = value);
        BindText(root, "input-block-custom-model", visual.customModelJsonPath, value => visual.customModelJsonPath = value);
        BindText(root, "input-block-tint", visual.tintHex, value => visual.tintHex = value);

        BindToggle(root, "toggle-block-requires-tool", behavior.requiresTool, value => behavior.requiresTool = value);
        BindText(root, "input-block-tool-tag", behavior.requiredToolTag, value => behavior.requiredToolTag = value);
        BindInteger(root, "input-block-mining-level", behavior.miningLevel, value => behavior.miningLevel = Mathf.Clamp(value, 0, 10));
        BindToggle(root, "toggle-block-flammable", behavior.flammable, value => behavior.flammable = value);
        BindInteger(root, "input-block-burn-chance", behavior.burnChance, value => behavior.burnChance = Mathf.Max(0, value));
        BindInteger(root, "input-block-spread-chance", behavior.spreadChance, value => behavior.spreadChance = Mathf.Max(0, value));
        BindToggle(root, "toggle-block-random-ticks", behavior.randomTicks, value => behavior.randomTicks = value);
        BindToggle(root, "toggle-block-gravity", behavior.gravity, value => behavior.gravity = value);
        BindToggle(root, "toggle-block-redstone", behavior.redstoneOutput, value => behavior.redstoneOutput = value);
        BindInteger(root, "input-block-redstone-power", behavior.redstonePower, value => behavior.redstonePower = Mathf.Clamp(value, 0, 15));
        BindToggle(root, "toggle-block-waterloggable", behavior.waterloggable, value => { behavior.waterloggable = value; states.waterlogged = value || states.waterlogged; });

        BindDropdown(root, "dropdown-block-shape", collision.shapeMode.ToString(), value => { if (Enum.TryParse(value, out StudioBlockShapeMode parsed)) collision.shapeMode = parsed; });
        BindToggle(root, "toggle-block-full-cube", collision.fullCube, value => collision.fullCube = value);
        BindToggle(root, "toggle-block-no-collision", collision.noCollision, value => collision.noCollision = value);
        BindToggle(root, "toggle-block-custom-outline", collision.customOutlineShape, value => collision.customOutlineShape = value);
        BindText(root, "input-block-voxel-shape", collision.voxelShape, value => collision.voxelShape = value);
        BindToggle(root, "toggle-block-pathfind", collision.pathfindThrough, value => collision.pathfindThrough = value);

        BindToggle(root, "toggle-block-states", states.enabled, value => states.enabled = value);
        BindDropdown(root, "dropdown-block-state-preset", states.preset.ToString(), value => { if (Enum.TryParse(value, out StudioBlockStatePreset parsed)) states.preset = parsed; });
        BindToggle(root, "toggle-state-facing", states.facing, value => states.facing = value);
        BindToggle(root, "toggle-state-axis", states.axis, value => states.axis = value);
        BindToggle(root, "toggle-state-lit", states.lit, value => states.lit = value);
        BindToggle(root, "toggle-state-powered", states.powered, value => states.powered = value);
        BindToggle(root, "toggle-state-open", states.open, value => states.open = value);
        BindToggle(root, "toggle-state-waterlogged", states.waterlogged, value => states.waterlogged = value);
        BindText(root, "input-block-custom-states", states.customStates, value => states.customStates = value);

        BindToggle(root, "toggle-block-entity", blockEntity.enabled, value => blockEntity.enabled = value);
        BindToggle(root, "toggle-block-entity-inventory", blockEntity.hasInventory, value => blockEntity.hasInventory = value);
        BindInteger(root, "input-block-entity-slots", blockEntity.inventorySlots, value => blockEntity.inventorySlots = Mathf.Clamp(value, 0, 216));
        BindToggle(root, "toggle-block-entity-ticker", blockEntity.hasTicker, value => blockEntity.hasTicker = value);
        BindToggle(root, "toggle-block-entity-screen", blockEntity.hasScreen, value => blockEntity.hasScreen = value);
        BindToggle(root, "toggle-block-entity-sync", blockEntity.syncToClient, value => blockEntity.syncToClient = value);
        BindText(root, "input-block-entity-fields", blockEntity.customDataFields, value => blockEntity.customDataFields = value);
    }


    private LootPoolSettings GetMainLootPool()
    {
        if (_currentLoot.pools == null) _currentLoot.pools = new List<LootPoolSettings>();
        if (_currentLoot.pools.Count == 0) _currentLoot.pools.Add(new LootPoolSettings());
        if (_currentLoot.pools[0] == null) _currentLoot.pools[0] = new LootPoolSettings();
        return _currentLoot.pools[0];
    }

    private void BindLootTableFields(VisualElement root)
    {
        LootPoolSettings pool = GetMainLootPool();
        BindText(root, "input-loot-id", _currentLoot.lootId, value => _currentLoot.lootId = value);
        BindText(root, "input-loot-name", _currentLoot.displayName, value => _currentLoot.displayName = value);
        BindDropdown(root, "dropdown-loot-type", _currentLoot.lootType.ToString(), value => { if (Enum.TryParse(value, out StudioLootTableType parsed)) _currentLoot.lootType = parsed; });
        BindText(root, "input-loot-target", _currentLoot.targetId, value => _currentLoot.targetId = value);
        BindToggle(root, "toggle-loot-enabled", _currentLoot.enabled, value => _currentLoot.enabled = value);
        BindToggle(root, "toggle-loot-replace-default", _currentLoot.replaceGeneratedDefault, value => _currentLoot.replaceGeneratedDefault = value);

        BindInteger(root, "input-loot-rolls", pool.rolls, value => pool.rolls = Mathf.Max(1, value));
        BindFloat(root, "input-loot-bonus-rolls", pool.bonusRolls, value => pool.bonusRolls = Mathf.Max(0f, value));
        BindDropdown(root, "dropdown-loot-entry-type", pool.entryType.ToString(), value => { if (Enum.TryParse(value, out StudioLootEntryType parsed)) pool.entryType = parsed; });
        BindText(root, "input-loot-entry", pool.entryId, value => pool.entryId = value);
        BindInteger(root, "input-loot-min", pool.minCount, value => pool.minCount = Mathf.Max(0, value));
        BindInteger(root, "input-loot-max", pool.maxCount, value => pool.maxCount = Mathf.Max(0, value));
        BindInteger(root, "input-loot-weight", pool.weight, value => pool.weight = Mathf.Max(1, value));
        BindToggle(root, "toggle-loot-explosion", pool.survivesExplosion, value => pool.survivesExplosion = value);
        BindToggle(root, "toggle-loot-fortune", pool.applyFortune, value => pool.applyFortune = value);
        BindToggle(root, "toggle-loot-silk", pool.silkTouchAlternative, value => pool.silkTouchAlternative = value);
        BindText(root, "input-loot-condition-json", pool.customConditionJson, value => pool.customConditionJson = value);
        BindText(root, "input-loot-function-json", pool.customFunctionJson, value => pool.customFunctionJson = value);
        BindText(root, "input-loot-custom-json", _currentLoot.customJsonOverride, value => _currentLoot.customJsonOverride = value);
        BindText(root, "input-loot-notes", _currentLoot.notes, value => _currentLoot.notes = value);
    }

    private void BindTagManagerFields(VisualElement root)
    {
        BindText(root, "input-tag-id", _currentTag.tagId, value => _currentTag.tagId = value);
        BindText(root, "input-tag-name", _currentTag.displayName, value => _currentTag.displayName = value);
        BindDropdown(root, "dropdown-tag-target", _currentTag.targetType.ToString(), value => { if (Enum.TryParse(value, out StudioTagTargetType parsed)) _currentTag.targetType = parsed; });
        BindText(root, "input-tag-namespace", _currentTag.namespaceId, value => _currentTag.namespaceId = value);
        BindToggle(root, "toggle-tag-replace", _currentTag.replace, value => _currentTag.replace = value);
        BindToggle(root, "toggle-tag-enabled", _currentTag.enabled, value => _currentTag.enabled = value);
        if (string.IsNullOrWhiteSpace(_currentTag.valuesCsv) && _currentTag.values != null && _currentTag.values.Count > 0)
            _currentTag.valuesCsv = string.Join(", ", _currentTag.values);
        BindText(root, "input-tag-values", _currentTag.valuesCsv, value => { _currentTag.valuesCsv = value; _currentTag.SyncValuesFromCsv(); });
        BindText(root, "input-tag-custom-json", _currentTag.customJsonOverride, value => _currentTag.customJsonOverride = value);
        BindText(root, "input-tag-notes", _currentTag.notes, value => _currentTag.notes = value);
    }

    private void BindRecipeProFields(VisualElement root)
    {
        _currentRecipe.EnsureProSettings();
        var pro = _currentRecipe.pro;
        BindText(root, "input-recipe-id", pro.recipeId, value => pro.recipeId = value);
        BindText(root, "input-recipe-group", pro.group, value => pro.group = value);
        BindDropdown(root, "dropdown-recipe-category", pro.category.ToString(), value => { if (Enum.TryParse(value, out StudioRecipeBookCategory parsed)) pro.category = parsed; });
        BindToggle(root, "toggle-recipe-datagen", pro.useDatagenProvider, value => pro.useDatagenProvider = value);
        BindToggle(root, "toggle-recipe-normalize", pro.autoNormalizeIds, value => pro.autoNormalizeIds = value);
        BindText(root, "input-shapeless-csv", pro.shapelessIngredientsCsv, value => pro.shapelessIngredientsCsv = value);
        BindToggle(root, "toggle-recipe-tags", pro.useTagsAsIngredients, value => pro.useTagsAsIngredients = value);
        BindText(root, "input-recipe-unlock-id", pro.unlock.criterionId, value => pro.unlock.criterionId = value);
        BindDropdown(root, "dropdown-recipe-unlock-mode", pro.unlock.mode.ToString(), value => { if (Enum.TryParse(value, out StudioRecipeIngredientMode parsed)) pro.unlock.mode = parsed; });
        BindText(root, "input-recipe-unlock-target", pro.unlock.targetId, value => pro.unlock.targetId = value);
        BindToggle(root, "toggle-recipe-conditions", pro.conditions.enabled, value => pro.conditions.enabled = value);
        BindText(root, "input-recipe-condition-json", pro.conditions.conditionJson, value => pro.conditions.conditionJson = value);
        BindText(root, "input-recipe-custom-json", pro.customJsonOverride, value => pro.customJsonOverride = value);
        BindText(root, "input-recipe-notes", pro.notes, value => pro.notes = value);
    }

    private void BindText(VisualElement root, string name, string value, Action<string> setter)
    {
        var field = root.Q<TextField>(name);
        if (field == null) return;
        field.value = value ?? string.Empty;
        field.RegisterValueChangedCallback(evt => { if (!_isUpdating) { setter(evt.newValue); OnModelChanged(); } });
    }

    private void BindInteger(VisualElement root, string name, int value, Action<int> setter)
    {
        var field = root.Q<IntegerField>(name);
        if (field == null) return;
        field.value = value;
        field.RegisterValueChangedCallback(evt => { if (!_isUpdating) { setter(evt.newValue); OnModelChanged(); } });
    }

    private void BindFloat(VisualElement root, string name, float value, Action<float> setter)
    {
        var field = root.Q<FloatField>(name);
        if (field == null) return;
        field.value = value;
        field.RegisterValueChangedCallback(evt => { if (!_isUpdating) { setter(evt.newValue); OnModelChanged(); } });
    }

    private void BindToggle(VisualElement root, string name, bool value, Action<bool> setter)
    {
        var field = root.Q<Toggle>(name);
        if (field == null) return;
        field.value = value;
        field.RegisterValueChangedCallback(evt => { if (!_isUpdating) { setter(evt.newValue); OnModelChanged(); } });
    }

    private void BindDropdown(VisualElement root, string name, string value, Action<string> setter)
    {
        var field = root.Q<DropdownField>(name);
        if (field == null) return;
        if (!string.IsNullOrEmpty(value)) field.value = value;
        field.RegisterValueChangedCallback(evt => { if (!_isUpdating) { setter(evt.newValue); OnModelChanged(); } });
    }



    private void BindAdvancedBiomeFields(VisualElement root)
    {
        _currentBiome.EnsureAdvancedSettings();
        AdvancedBiomeSettings adv = _currentBiome.advanced;
        AdvancedBiomeClimateSettings climate = adv.climate;
        AdvancedBiomeEffectsSettings effects = adv.effects;
        AdvancedBiomeCarverSettings carvers = adv.carvers;
        StudioOreFeatureSettings ore = adv.ore;
        StudioVegetationFeatureSettings vegetation = adv.vegetation;
        AdvancedBiomeSpawnSettings spawns = adv.spawns;

        BindText(root, "input-biome-namespace", _currentBiome.textureNamespace, value => _currentBiome.textureNamespace = value);
        BindFloat(root, "input-biome-downfall", _currentBiome.downfall, value => { _currentBiome.downfall = Mathf.Clamp01(value); climate.downfall = _currentBiome.downfall; });
        BindDropdown(root, "dropdown-biome-category", climate.category.ToString(), value => { if (Enum.TryParse(value, out StudioBiomeCategory parsed)) climate.category = parsed; });
        BindDropdown(root, "dropdown-biome-temp-modifier", climate.temperatureModifier.ToString(), value => { if (Enum.TryParse(value, out StudioBiomeTemperatureModifier parsed)) climate.temperatureModifier = parsed; });
        BindToggle(root, "toggle-biome-force-rain", climate.forceRain, value => climate.forceRain = value);
        BindToggle(root, "toggle-biome-force-snow", climate.forceSnow, value => climate.forceSnow = value);
        BindText(root, "input-biome-tags", climate.biomeTagCsv, value => climate.biomeTagCsv = value);

        BindText(root, "input-biome-foliage", _currentBiome.foliageColor, value => _currentBiome.foliageColor = value);
        BindText(root, "input-biome-water-fog", _currentBiome.waterFogColor, value => _currentBiome.waterFogColor = value);
        BindText(root, "input-biome-particle", effects.particleId, value => effects.particleId = value);
        BindFloat(root, "input-biome-particle-probability", effects.particleProbability, value => effects.particleProbability = Mathf.Clamp01(value));

        BindText(root, "input-biome-music", effects.musicId, value => { effects.musicId = value; _currentBiome.musicId = value; });
        BindInteger(root, "input-biome-music-min", effects.musicMinDelay, value => effects.musicMinDelay = Mathf.Max(0, value));
        BindInteger(root, "input-biome-music-max", effects.musicMaxDelay, value => effects.musicMaxDelay = Mathf.Max(0, value));
        BindToggle(root, "toggle-biome-replace-music", effects.replaceCurrentMusic, value => effects.replaceCurrentMusic = value);
        BindText(root, "input-biome-ambient-loop", effects.ambientLoopSound, value => { effects.ambientLoopSound = value; _currentBiome.ambientSoundId = value; });
        BindText(root, "input-biome-mood", effects.moodSound, value => effects.moodSound = value);
        BindInteger(root, "input-biome-mood-delay", effects.moodTickDelay, value => { effects.moodTickDelay = Mathf.Max(0, value); _currentBiome.ambientMoodTickDelay = value; });
        BindText(root, "input-biome-additions", effects.additionsSound, value => effects.additionsSound = value);

        BindToggle(root, "toggle-biome-caves", carvers.caves, value => { carvers.caves = value; _currentBiome.generateCaves = value; });
        BindToggle(root, "toggle-biome-canyons", carvers.canyons, value => { carvers.canyons = value; _currentBiome.generateCanyons = value; });
        BindToggle(root, "toggle-biome-underwater-caves", carvers.underwaterCaves, value => carvers.underwaterCaves = value);
        BindText(root, "input-biome-custom-carvers", carvers.customCarversCsv, value => carvers.customCarversCsv = value);
        BindToggle(root, "toggle-biome-generate-json", adv.generateBiomeJson, value => adv.generateBiomeJson = value);
        BindToggle(root, "toggle-biome-generate-tag", adv.generateBiomeTag, value => adv.generateBiomeTag = value);

        BindToggle(root, "toggle-biome-ore-enabled", ore.enabled, value => ore.enabled = value);
        BindText(root, "input-biome-ore-block", ore.oreBlockId, value => ore.oreBlockId = value);
        BindText(root, "input-biome-ore-target", ore.targetBlockTag, value => ore.targetBlockTag = value);
        BindText(root, "input-biome-ore-feature-id", ore.placedFeatureId, value => ore.placedFeatureId = value);
        BindInteger(root, "input-biome-ore-vein", ore.veinSize, value => ore.veinSize = Mathf.Max(1, value));
        BindInteger(root, "input-biome-ore-count", ore.veinsPerChunk, value => ore.veinsPerChunk = Mathf.Max(0, value));
        BindInteger(root, "input-biome-ore-min-y", ore.minY, value => ore.minY = Mathf.Clamp(value, -128, 512));
        BindInteger(root, "input-biome-ore-max-y", ore.maxY, value => ore.maxY = Mathf.Clamp(value, -128, 512));
        BindToggle(root, "toggle-biome-ore-triangle", ore.triangleDistribution, value => ore.triangleDistribution = value);

        BindToggle(root, "toggle-biome-custom-trees", vegetation.customTrees, value => vegetation.customTrees = value);
        BindText(root, "input-biome-tree-feature", vegetation.treeFeatureId, value => vegetation.treeFeatureId = value);
        BindInteger(root, "input-biome-tree-chance", vegetation.treeChance, value => vegetation.treeChance = Mathf.Max(0, value));
        BindToggle(root, "toggle-biome-custom-flowers", vegetation.customFlowers, value => vegetation.customFlowers = value);
        BindText(root, "input-biome-flower-feature", vegetation.flowerFeatureId, value => vegetation.flowerFeatureId = value);
        BindToggle(root, "toggle-biome-custom-grass", vegetation.customGrass, value => vegetation.customGrass = value);
        BindText(root, "input-biome-grass-feature", vegetation.grassFeatureId, value => vegetation.grassFeatureId = value);

        BindToggle(root, "toggle-biome-override-spawns", spawns.overrideDefaultSpawns, value => spawns.overrideDefaultSpawns = value);
        BindToggle(root, "toggle-biome-spawn-monsters", spawns.spawnMonsters, value => spawns.spawnMonsters = value);
        BindToggle(root, "toggle-biome-spawn-creatures", spawns.spawnCreatures, value => spawns.spawnCreatures = value);
        BindToggle(root, "toggle-biome-spawn-ambient", spawns.spawnAmbient, value => spawns.spawnAmbient = value);
        BindText(root, "input-biome-custom-spawn-json", spawns.customSpawnJson, value => spawns.customSpawnJson = value);
        BindText(root, "input-biome-worldgen-notes", adv.notes, value => adv.notes = value);
    }

    private void BindAdvancedEntityFields(VisualElement root)
    {
        _currentEntity.EnsureAdvancedSettings();
        AdvancedEntitySettings adv = _currentEntity.advanced;
        EntityAdvancedAttributeSettings attr = adv.attributes;
        EntityAiGoalSettings ai = adv.ai;
        EntitySpawnAdvancedSettings spawn = adv.spawn;
        EntityVisualAdvancedSettings visual = adv.visual;
        EntityBehaviorAdvancedSettings behavior = adv.behavior;

        BindText(root, "input-entity-namespace", _currentEntity.textureNamespace, value => _currentEntity.textureNamespace = value);
        BindInteger(root, "input-entity-xp", _currentEntity.experienceReward, value => _currentEntity.experienceReward = Mathf.Max(0, value));
        BindFloat(root, "input-entity-attack-speed", _currentEntity.attackSpeed, value => _currentEntity.attackSpeed = Mathf.Max(0f, value));
        BindFloat(root, "input-entity-follow-range", _currentEntity.followRange, value => _currentEntity.followRange = Mathf.Max(0f, value));
        BindFloat(root, "input-entity-armor", _currentEntity.armor, value => _currentEntity.armor = Mathf.Max(0f, value));
        BindFloat(root, "input-entity-knockback-resistance", _currentEntity.knockbackResistance, value => _currentEntity.knockbackResistance = Mathf.Clamp01(value));

        BindFloat(root, "input-entity-armor-toughness", attr.armorToughness, value => attr.armorToughness = Mathf.Max(0f, value));
        BindFloat(root, "input-entity-attack-knockback", attr.attackKnockback, value => attr.attackKnockback = Mathf.Max(0f, value));
        BindFloat(root, "input-entity-step-height", attr.stepHeight, value => attr.stepHeight = Mathf.Max(0f, value));
        BindFloat(root, "input-entity-gravity", attr.gravity, value => attr.gravity = Mathf.Max(0f, value));
        BindFloat(root, "input-entity-scale", attr.scale, value => attr.scale = Mathf.Max(0.01f, value));
        BindToggle(root, "toggle-entity-has-gravity", attr.hasGravity, value => attr.hasGravity = value);

        BindToggle(root, "toggle-entity-ai", ai.enabled, value => ai.enabled = value);
        BindText(root, "input-entity-ai-goals", ai.goalsCsv, value => { ai.goalsCsv = value; ai.SyncToEntity(_currentEntity); });
        BindText(root, "input-entity-target-goals", ai.targetGoalsCsv, value => ai.targetGoalsCsv = value);
        BindToggle(root, "toggle-entity-open-doors", ai.canOpenDoors, value => ai.canOpenDoors = value);
        BindToggle(root, "toggle-entity-break-doors", ai.canBreakDoors, value => ai.canBreakDoors = value);
        BindToggle(root, "toggle-entity-avoids-water", ai.avoidsWater, value => ai.avoidsWater = value);
        BindToggle(root, "toggle-entity-attacks-players", ai.attacksPlayers, value => ai.attacksPlayers = value);
        BindToggle(root, "toggle-entity-attacks-villagers", ai.attacksVillagers, value => ai.attacksVillagers = value);
        BindToggle(root, "toggle-entity-panic", ai.panicWhenHurt, value => ai.panicWhenHurt = value);
        BindText(root, "input-entity-tempt-item", ai.temptItemId, value => ai.temptItemId = value);
        BindText(root, "input-entity-avoid-entity", ai.avoidEntityId, value => ai.avoidEntityId = value);
        BindText(root, "input-entity-custom-goals", ai.customGoalsCode, value => ai.customGoalsCode = value);

        BindToggle(root, "toggle-entity-natural-spawn", spawn.naturalSpawn, value => { spawn.naturalSpawn = value; spawn.SyncToEntity(_currentEntity); });
        BindToggle(root, "toggle-entity-spawn-egg", spawn.spawnEgg, value => { spawn.spawnEgg = value; spawn.SyncToEntity(_currentEntity); });
        BindDropdown(root, "dropdown-entity-dimension", spawn.dimension.ToString(), value => { if (Enum.TryParse(value, out StudioEntityDimensionPreset parsed)) spawn.dimension = parsed; });
        BindText(root, "input-entity-custom-dimension", spawn.customDimensionId, value => spawn.customDimensionId = value);
        BindText(root, "input-entity-biome-selector", spawn.biomeSelector, value => spawn.biomeSelector = value);
        BindText(root, "input-entity-biome-tags", spawn.biomeTagsCsv, value => spawn.biomeTagsCsv = value);
        BindDropdown(root, "dropdown-entity-spawn-placement", spawn.placement.ToString(), value => { if (Enum.TryParse(value, out StudioEntitySpawnPlacement parsed)) spawn.placement = parsed; });
        BindInteger(root, "input-entity-spawn-weight", spawn.spawnWeight, value => { spawn.spawnWeight = Mathf.Max(0, value); spawn.SyncToEntity(_currentEntity); });
        BindInteger(root, "input-entity-min-group", spawn.minGroup, value => { spawn.minGroup = Mathf.Max(1, value); spawn.SyncToEntity(_currentEntity); });
        BindInteger(root, "input-entity-max-group", spawn.maxGroup, value => { spawn.maxGroup = Mathf.Max(1, value); spawn.SyncToEntity(_currentEntity); });
        BindInteger(root, "input-entity-min-y", spawn.minY, value => { spawn.minY = Mathf.Clamp(value, -64, 320); spawn.SyncToEntity(_currentEntity); });
        BindInteger(root, "input-entity-max-y", spawn.maxY, value => { spawn.maxY = Mathf.Clamp(value, -64, 320); spawn.SyncToEntity(_currentEntity); });
        BindInteger(root, "input-entity-min-light", spawn.minLight, value => spawn.minLight = Mathf.Clamp(value, 0, 15));
        BindInteger(root, "input-entity-max-light", spawn.maxLight, value => spawn.maxLight = Mathf.Clamp(value, 0, 15));
        BindToggle(root, "toggle-entity-darkness", spawn.requiresDarkness, value => { spawn.requiresDarkness = value; spawn.SyncToEntity(_currentEntity); });
        BindToggle(root, "toggle-entity-grass", spawn.onlyOnGrass, value => { spawn.onlyOnGrass = value; spawn.SyncToEntity(_currentEntity); });
        BindToggle(root, "toggle-entity-despawn", spawn.despawnsNaturally, value => spawn.despawnsNaturally = value);

        BindDropdown(root, "dropdown-entity-renderer", visual.rendererType.ToString(), value => { if (Enum.TryParse(value, out StudioEntityRendererType parsed)) visual.rendererType = parsed; });
        BindText(root, "input-entity-texture", visual.texturePath, value => visual.texturePath = value);
        BindText(root, "input-entity-model", visual.modelPath, value => visual.modelPath = value);
        BindText(root, "input-entity-animation", visual.animationJsonPath, value => visual.animationJsonPath = value);
        BindText(root, "input-entity-renderer-class", visual.customRendererClass, value => visual.customRendererClass = value);
        BindFloat(root, "input-entity-shadow", visual.shadowRadius, value => visual.shadowRadius = Mathf.Max(0f, value));
        BindToggle(root, "toggle-entity-baby", visual.hasBabyVariant, value => visual.hasBabyVariant = value);
        BindToggle(root, "toggle-entity-variants", visual.variantTextures, value => visual.variantTextures = value);
        BindText(root, "input-entity-variant-textures", visual.variantTextureCsv, value => visual.variantTextureCsv = value);
        BindText(root, "input-entity-egg-primary", visual.spawnEggPrimaryHex, value => visual.spawnEggPrimaryHex = value);
        BindText(root, "input-entity-egg-secondary", visual.spawnEggSecondaryHex, value => visual.spawnEggSecondaryHex = value);
        BindToggle(root, "toggle-entity-emissive", visual.emissiveLayer, value => visual.emissiveLayer = value);

        BindToggle(root, "toggle-entity-fire-immune", behavior.fireImmune, value => behavior.fireImmune = value);
        BindToggle(root, "toggle-entity-saveable", behavior.saveable, value => behavior.saveable = value);
        BindToggle(root, "toggle-entity-summonable", behavior.summonable, value => behavior.summonable = value);
        BindToggle(root, "toggle-entity-persistent", behavior.persistent, value => behavior.persistent = value);
        BindToggle(root, "toggle-entity-pickup-loot", behavior.canPickUpLoot, value => behavior.canPickUpLoot = value);
        BindToggle(root, "toggle-entity-no-gravity", behavior.noGravity, value => behavior.noGravity = value);
        BindToggle(root, "toggle-entity-bossbar", behavior.bossBar, value => behavior.bossBar = value);
        BindToggle(root, "toggle-entity-tameable", behavior.tameable, value => behavior.tameable = value);
        BindText(root, "input-entity-tame-item", behavior.tameItemId, value => behavior.tameItemId = value);
        BindText(root, "input-entity-ambient-sound", behavior.ambientSound, value => behavior.ambientSound = value);
        BindText(root, "input-entity-hurt-sound", behavior.hurtSound, value => behavior.hurtSound = value);
        BindText(root, "input-entity-death-sound", behavior.deathSound, value => behavior.deathSound = value);
        BindText(root, "input-entity-step-sound", behavior.stepSound, value => behavior.stepSound = value);
        BindText(root, "input-entity-custom-tick", behavior.customTickCode, value => behavior.customTickCode = value);
    }



    private void BindDimensionFields(VisualElement root)
    {
        var dimension = _currentDimension;
        if (dimension == null) return;

        BindToggle(root, "toggle-dimension-enabled", dimension.enabled, value => dimension.enabled = value);
        BindText(root, "input-dimension-id", dimension.dimensionId, value => dimension.dimensionId = value);
        BindText(root, "input-dimension-name", dimension.displayName, value => dimension.displayName = value);
        BindDropdown(root, "dropdown-dimension-generator", dimension.generatorType.ToString(), value => { if (Enum.TryParse(value, out StudioDimensionGeneratorType parsed)) dimension.generatorType = parsed; });
        BindText(root, "input-dimension-biome-source", dimension.biomeSourceType, value => dimension.biomeSourceType = value);
        BindText(root, "input-dimension-fixed-biome", dimension.fixedBiomeId, value => dimension.fixedBiomeId = value);

        BindToggle(root, "toggle-dimension-skylight", dimension.hasSkylight, value => dimension.hasSkylight = value);
        BindToggle(root, "toggle-dimension-ceiling", dimension.hasCeiling, value => dimension.hasCeiling = value);
        BindToggle(root, "toggle-dimension-ultrawarm", dimension.ultraWarm, value => dimension.ultraWarm = value);
        BindToggle(root, "toggle-dimension-natural", dimension.natural, value => dimension.natural = value);
        BindToggle(root, "toggle-dimension-piglin-safe", dimension.piglinSafe, value => dimension.piglinSafe = value);
        BindToggle(root, "toggle-dimension-bed-works", dimension.bedWorks, value => dimension.bedWorks = value);
        BindToggle(root, "toggle-dimension-respawn-anchor", dimension.respawnAnchorWorks, value => dimension.respawnAnchorWorks = value);
        BindToggle(root, "toggle-dimension-raids", dimension.hasRaids, value => dimension.hasRaids = value);

        BindInteger(root, "input-dimension-min-y", dimension.minY, value => dimension.minY = value);
        BindInteger(root, "input-dimension-height", dimension.height, value => dimension.height = Mathf.Max(1, value));
        BindInteger(root, "input-dimension-logical-height", dimension.logicalHeight, value => dimension.logicalHeight = Mathf.Max(1, value));
        BindFloat(root, "input-dimension-coordinate-scale", dimension.coordinateScale, value => dimension.coordinateScale = Mathf.Max(0.01f, value));
        BindFloat(root, "input-dimension-ambient-light", dimension.ambientLight, value => dimension.ambientLight = Mathf.Clamp01(value));
        BindText(root, "input-dimension-effects", dimension.effects, value => dimension.effects = value);
        BindInteger(root, "input-dimension-monster-min-light", dimension.monsterMinLight, value => dimension.monsterMinLight = Mathf.Clamp(value, 0, 15));
        BindInteger(root, "input-dimension-monster-max-light", dimension.monsterMaxLight, value => dimension.monsterMaxLight = Mathf.Clamp(value, 0, 15));
        BindText(root, "input-dimension-custom-json", dimension.customDimensionJson, value => dimension.customDimensionJson = value);
        BindText(root, "input-dimension-type-json", dimension.customDimensionTypeJson, value => dimension.customDimensionTypeJson = value);
    }

    private void BindStructureFields(VisualElement root)
    {
        var structure = _currentStructure;
        if (structure == null) return;

        BindToggle(root, "toggle-structure-enabled", structure.enabled, value => structure.enabled = value);
        BindText(root, "input-structure-id", structure.structureId, value => structure.structureId = value);
        BindText(root, "input-structure-name", structure.displayName, value => structure.displayName = value);
        BindText(root, "input-structure-type", structure.structureType, value => structure.structureType = value);
        BindText(root, "input-structure-start-pool", structure.startPool, value => structure.startPool = value);
        BindInteger(root, "input-structure-size", structure.size, value => structure.size = Mathf.Max(1, value));
        BindInteger(root, "input-structure-max-distance", structure.maxDistanceFromCenter, value => structure.maxDistanceFromCenter = Mathf.Max(1, value));
        BindText(root, "input-structure-biomes", structure.biomes, value => structure.biomes = value);
        BindText(root, "input-structure-terrain", structure.terrainAdaptation, value => structure.terrainAdaptation = value);
        BindDropdown(root, "dropdown-structure-placement", structure.placementType.ToString(), value => { if (Enum.TryParse(value, out StudioStructurePlacementType parsed)) structure.placementType = parsed; });
        BindInteger(root, "input-structure-spacing", structure.spacing, value => structure.spacing = Mathf.Max(1, value));
        BindInteger(root, "input-structure-separation", structure.separation, value => structure.separation = Mathf.Max(0, value));
        BindInteger(root, "input-structure-salt", structure.salt, value => structure.salt = value);
        BindText(root, "input-structure-heightmap", structure.heightmap, value => structure.heightmap = value);
        BindText(root, "input-structure-custom-json", structure.customStructureJson, value => structure.customStructureJson = value);
        BindText(root, "input-structure-set-json", structure.customStructureSetJson, value => structure.customStructureSetJson = value);
    }


    private void BindGuiScreenFields(VisualElement root)
    {
        var screen = _currentScreen;
        if (screen == null) return;

        BindToggle(root, "toggle-screen-enabled", screen.enabled, value => screen.enabled = value);
        BindText(root, "input-screen-id", screen.screenId, value => screen.screenId = value);
        BindText(root, "input-screen-name", screen.displayName, value => screen.displayName = value);
        BindDropdown(root, "dropdown-screen-type", screen.screenType.ToString(), value => { if (Enum.TryParse(value, out StudioScreenType parsed)) screen.screenType = parsed; });
        BindText(root, "input-screen-linked-block", screen.linkedBlockId, value => screen.linkedBlockId = value);
        BindText(root, "input-screen-linked-entity", screen.linkedEntityId, value => screen.linkedEntityId = value);
        BindText(root, "input-screen-linked-item", screen.linkedItemId, value => screen.linkedItemId = value);

        BindInteger(root, "input-screen-width", screen.width, value => screen.width = Mathf.Clamp(value, 64, 512));
        BindInteger(root, "input-screen-height", screen.height, value => screen.height = Mathf.Clamp(value, 64, 512));
        BindText(root, "input-screen-title-key", screen.titleTranslationKey, value => screen.titleTranslationKey = value);
        BindText(root, "input-screen-bg", screen.backgroundTexture, value => screen.backgroundTexture = value);

        BindToggle(root, "toggle-screen-player-inventory", screen.showPlayerInventory, value => screen.showPlayerInventory = value);
        BindInteger(root, "input-screen-player-x", screen.playerInventoryX, value => screen.playerInventoryX = Mathf.Max(0, value));
        BindInteger(root, "input-screen-player-y", screen.playerInventoryY, value => screen.playerInventoryY = Mathf.Max(0, value));
        BindInteger(root, "input-screen-hotbar-x", screen.hotbarX, value => screen.hotbarX = Mathf.Max(0, value));
        BindInteger(root, "input-screen-hotbar-y", screen.hotbarY, value => screen.hotbarY = Mathf.Max(0, value));

        BindInteger(root, "input-screen-slots", screen.containerSlots, value => screen.containerSlots = Mathf.Clamp(value, 0, 216));
        BindText(root, "input-screen-slot-csv", screen.slotsCsv, value => { screen.slotsCsv = value; screen.SyncSlotsFromCsv(); });

        BindToggle(root, "toggle-screen-progress", screen.hasProgressBar, value => screen.hasProgressBar = value);
        BindInteger(root, "input-screen-progress-x", screen.progressX, value => screen.progressX = Mathf.Max(0, value));
        BindInteger(root, "input-screen-progress-y", screen.progressY, value => screen.progressY = Mathf.Max(0, value));
        BindInteger(root, "input-screen-progress-w", screen.progressWidth, value => screen.progressWidth = Mathf.Max(1, value));
        BindInteger(root, "input-screen-progress-h", screen.progressHeight, value => screen.progressHeight = Mathf.Max(1, value));

        BindToggle(root, "toggle-screen-energy", screen.hasEnergyBar, value => screen.hasEnergyBar = value);
        BindInteger(root, "input-screen-energy-x", screen.energyX, value => screen.energyX = Mathf.Max(0, value));
        BindInteger(root, "input-screen-energy-y", screen.energyY, value => screen.energyY = Mathf.Max(0, value));
        BindInteger(root, "input-screen-energy-w", screen.energyWidth, value => screen.energyWidth = Mathf.Max(1, value));
        BindInteger(root, "input-screen-energy-h", screen.energyHeight, value => screen.energyHeight = Mathf.Max(1, value));

        BindToggle(root, "toggle-screen-fluid", screen.hasFluidBar, value => screen.hasFluidBar = value);
        BindInteger(root, "input-screen-fluid-x", screen.fluidX, value => screen.fluidX = Mathf.Max(0, value));
        BindInteger(root, "input-screen-fluid-y", screen.fluidY, value => screen.fluidY = Mathf.Max(0, value));
        BindInteger(root, "input-screen-fluid-w", screen.fluidWidth, value => screen.fluidWidth = Mathf.Max(1, value));
        BindInteger(root, "input-screen-fluid-h", screen.fluidHeight, value => screen.fluidHeight = Mathf.Max(1, value));

        BindText(root, "input-screen-labels", screen.labelsCsv, value => screen.labelsCsv = value);
        BindText(root, "input-screen-buttons", screen.buttonsCsv, value => screen.buttonsCsv = value);
        BindToggle(root, "toggle-screen-sync", screen.syncProperties, value => screen.syncProperties = value);
        BindToggle(root, "toggle-screen-right-click", screen.openOnRightClick, value => screen.openOnRightClick = value);
        BindToggle(root, "toggle-screen-java-stubs", screen.generateJavaStubs, value => screen.generateJavaStubs = value);
        BindText(root, "input-screen-class", screen.customScreenClass, value => screen.customScreenClass = value);
        BindText(root, "input-screen-menu-class", screen.customMenuClass, value => screen.customMenuClass = value);
        BindText(root, "input-screen-packet-notes", screen.customPacketNotes, value => screen.customPacketNotes = value);
        BindText(root, "input-screen-notes", screen.notes, value => screen.notes = value);
    }

    private void BindConfigFields(VisualElement root)
    {
        var config = _currentConfig;
        if (config == null) return;

        BindToggle(root, "toggle-config-enabled", config.enabled, value => config.enabled = value);
        BindText(root, "input-config-id", config.configId, value => config.configId = value);
        BindText(root, "input-config-name", config.displayName, value => config.displayName = value);
        BindDropdown(root, "dropdown-config-format", config.format.ToString(), value => { if (Enum.TryParse(value, out StudioConfigFormat parsed)) config.format = parsed; });
        BindDropdown(root, "dropdown-config-scope", config.scope.ToString(), value => { if (Enum.TryParse(value, out StudioConfigScope parsed)) config.scope = parsed; });
        BindText(root, "input-config-file", config.fileName, value => config.fileName = value);
        BindToggle(root, "toggle-config-create", config.createDefaultFile, value => config.createDefaultFile = value);
        BindToggle(root, "toggle-config-sync", config.syncToClient, value => config.syncToClient = value);
        BindToggle(root, "toggle-config-restart", config.restartRequired, value => config.restartRequired = value);
        BindText(root, "input-config-entries", config.entriesCsv, value => { config.entriesCsv = value; config.SyncEntriesFromCsv(); });
        BindText(root, "input-config-custom-text", config.customConfigText, value => config.customConfigText = value);
        BindText(root, "input-config-notes", config.notes, value => config.notes = value);
    }


    private void BindNetworkingFields(VisualElement root)
    {
        var packet = _currentNetworkPacket;
        if (packet == null) return;

        BindToggle(root, "toggle-packet-enabled", packet.enabled, value => packet.enabled = value);
        BindText(root, "input-packet-id", packet.packetId, value => { packet.packetId = value; packet.channelPath = string.IsNullOrWhiteSpace(packet.channelPath) ? value : packet.channelPath; });
        BindText(root, "input-packet-name", packet.displayName, value => packet.displayName = value);
        BindDropdown(root, "dropdown-packet-direction", packet.direction.ToString(), value => { if (Enum.TryParse(value, out StudioPacketDirection parsed)) packet.direction = parsed; });
        BindText(root, "input-packet-namespace", packet.channelNamespace, value => packet.channelNamespace = value);
        BindText(root, "input-packet-channel", packet.channelPath, value => packet.channelPath = value);
        BindDropdown(root, "dropdown-packet-thread", packet.threadMode.ToString(), value => { if (Enum.TryParse(value, out StudioPacketThreadMode parsed)) packet.threadMode = parsed; });

        BindText(root, "input-packet-fields", packet.payloadFieldsCsv, value => { packet.payloadFieldsCsv = value; packet.SyncFieldsFromCsv(); });
        BindToggle(root, "toggle-packet-validation", packet.requiresValidation, value => packet.requiresValidation = value);
        BindToggle(root, "toggle-packet-distance", packet.checkPlayerDistance, value => packet.checkPlayerDistance = value);
        BindToggle(root, "toggle-packet-chunk", packet.checkChunkLoaded, value => packet.checkChunkLoaded = value);
        BindToggle(root, "toggle-packet-sync-blockentity", packet.syncBlockEntity, value => packet.syncBlockEntity = value);
        BindText(root, "input-packet-linked-block", packet.linkedBlockId, value => packet.linkedBlockId = value);
        BindText(root, "input-packet-linked-entity", packet.linkedEntityId, value => packet.linkedEntityId = value);
        BindText(root, "input-packet-linked-screen", packet.linkedScreenId, value => packet.linkedScreenId = value);
        BindToggle(root, "toggle-packet-java-stub", packet.generateJavaStub, value => packet.generateJavaStub = value);
        BindText(root, "input-packet-class", packet.customPacketClass, value => packet.customPacketClass = value);
        BindText(root, "input-packet-handler", packet.customHandlerClass, value => packet.customHandlerClass = value);
        BindText(root, "input-packet-notes", packet.notes, value => packet.notes = value);
    }

    private void BindKeybindFields(VisualElement root)
    {
        var keybind = _currentKeybind;
        if (keybind == null) return;

        BindToggle(root, "toggle-keybind-enabled", keybind.enabled, value => keybind.enabled = value);
        BindText(root, "input-keybind-id", keybind.keybindId, value => keybind.keybindId = value);
        BindText(root, "input-keybind-name", keybind.displayName, value => keybind.displayName = value);
        BindText(root, "input-keybind-default", keybind.defaultKey, value => keybind.defaultKey = value);
        BindText(root, "input-keybind-category", keybind.category, value => keybind.category = value);
        BindDropdown(root, "dropdown-keybind-context", keybind.conflictContext.ToString(), value => { if (Enum.TryParse(value, out StudioKeybindConflictContext parsed)) keybind.conflictContext = parsed; });
        BindDropdown(root, "dropdown-keybind-action", keybind.actionType.ToString(), value => { if (Enum.TryParse(value, out StudioKeybindActionType parsed)) keybind.actionType = parsed; });
        BindText(root, "input-keybind-packet", keybind.sendPacketId, value => keybind.sendPacketId = value);
        BindText(root, "input-keybind-screen", keybind.openScreenId, value => keybind.openScreenId = value);
        BindText(root, "input-keybind-command", keybind.command, value => keybind.command = value);
        BindInteger(root, "input-keybind-cooldown", keybind.cooldownTicks, value => keybind.cooldownTicks = Mathf.Max(0, value));
        BindToggle(root, "toggle-keybind-client-only", keybind.clientOnly, value => keybind.clientOnly = value);
        BindToggle(root, "toggle-keybind-sneak", keybind.requiresSneak, value => keybind.requiresSneak = value);
        BindToggle(root, "toggle-keybind-creative", keybind.requiresCreativeMode, value => keybind.requiresCreativeMode = value);
        BindToggle(root, "toggle-keybind-repeat", keybind.repeatWhileHeld, value => keybind.repeatWhileHeld = value);
        BindToggle(root, "toggle-keybind-java-stub", keybind.generateJavaStub, value => keybind.generateJavaStub = value);
        BindText(root, "input-keybind-handler", keybind.customHandlerClass, value => keybind.customHandlerClass = value);
        BindText(root, "input-keybind-notes", keybind.notes, value => keybind.notes = value);
    }

    private void BindFieldsForMode(EditorMode mode)
    {
        var root = rootVisualElement;
        _isUpdating = true; // Callbacklar o'rnatilayotganda cheksiz sikldan saqlaydi

        try
        {
        switch (mode)
        {
            case EditorMode.Block:
                {
                    var idF = root.Q<TextField>("input-id");
                    var nameF = root.Q<TextField>("input-name");
                    var hardS = root.Q<Slider>("slider-hardness");
                    var resS = root.Q<Slider>("slider-resistance");

                    if (idF != null) idF.value = _currentBlock.blockId;
                    if (nameF != null) nameF.value = _currentBlock.displayName;
                    if (hardS != null) hardS.value = _currentBlock.hardness;
                    if (resS != null) resS.value = _currentBlock.resistance;

                    idF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBlock.blockId = evt.newValue; OnModelChanged(); } });
                    nameF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBlock.displayName = evt.newValue; OnModelChanged(); } });
                    hardS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBlock.hardness = evt.newValue; OnModelChanged(); } });
                    resS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBlock.resistance = evt.newValue; OnModelChanged(); } });

                    BindAdvancedBlockFields(root);
                    BindBlockTransformControls(root);
                }
                break;

            case EditorMode.Item:
                {
                    var idF = root.Q<TextField>("input-item-id");
                    var nameF = root.Q<TextField>("input-item-name");
                    var stackF = root.Q<IntegerField>("input-item-stack");
                    var foodT = root.Q<Toggle>("input-item-isfood");

                    if (idF != null) idF.value = _currentItem.itemId;
                    if (nameF != null) nameF.value = _currentItem.displayName;
                    if (stackF != null) stackF.value = _currentItem.stackSize;
                    if (foodT != null) foodT.value = _currentItem.isFood;

                    idF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentItem.itemId = evt.newValue; OnModelChanged(); } });
                    nameF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentItem.displayName = evt.newValue; OnModelChanged(); } });
                    stackF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentItem.stackSize = evt.newValue; OnModelChanged(); } });
                    foodT?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentItem.isFood = evt.newValue; if (_currentItem.advanced != null && _currentItem.advanced.food != null) _currentItem.advanced.food.enabled = evt.newValue; OnModelChanged(); } });

                    BindAdvancedItemFields(root);
                }
                break;

            case EditorMode.Tool:
                {
                    var idF = root.Q<TextField>("input-tool-id");
                    var nameF = root.Q<TextField>("input-tool-name");
                    var typeF = root.Q<DropdownField>("input-tool-type");
                    var dmgS = root.Q<Slider>("slider-tool-damage");
                    var spdS = root.Q<Slider>("slider-tool-speed");
                    var durF = root.Q<IntegerField>("input-tool-durability");
                    var minL = root.Q<IntegerField>("input-tool-mininglvl");

                    if (idF != null) idF.value = _currentTool.toolId;
                    if (nameF != null) nameF.value = _currentTool.displayName;
                    if (typeF != null) typeF.value = _currentTool.toolType.ToString();
                    if (dmgS != null) dmgS.value = _currentTool.attackDamage;
                    if (spdS != null) spdS.value = _currentTool.attackSpeed;
                    if (durF != null) durF.value = _currentTool.durability;
                    if (minL != null) minL.value = _currentTool.miningLevel;

                    idF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentTool.toolId = evt.newValue; OnModelChanged(); } });
                    nameF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentTool.displayName = evt.newValue; OnModelChanged(); } });
                    typeF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { if (Enum.TryParse<ToolType>(evt.newValue, out ToolType t)) _currentTool.toolType = t; OnModelChanged(); } });
                    dmgS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentTool.attackDamage = evt.newValue; OnModelChanged(); } });
                    spdS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentTool.attackSpeed = evt.newValue; OnModelChanged(); } });
                    durF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentTool.durability = evt.newValue; OnModelChanged(); } });
                    minL?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentTool.miningLevel = evt.newValue; OnModelChanged(); } });
                }
                break;

            case EditorMode.Armor:
                {
                    var idF = root.Q<TextField>("input-armor-id");
                    var nameF = root.Q<TextField>("input-armor-name");
                    var slotF = root.Q<DropdownField>("input-armor-slot");
                    var defS = root.Q<Slider>("slider-armor-defense");
                    var tghS = root.Q<Slider>("slider-armor-toughness");
                    var knkS = root.Q<Slider>("slider-armor-knockback");

                    if (idF != null) idF.value = _currentArmor.armorId;
                    if (nameF != null) nameF.value = _currentArmor.displayName;
                    if (slotF != null) slotF.value = _currentArmor.armorSlot.ToString();
                    if (defS != null) defS.value = _currentArmor.defense;
                    if (tghS != null) tghS.value = _currentArmor.toughness;
                    if (knkS != null) knkS.value = _currentArmor.knockbackResistance;

                    idF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentArmor.armorId = evt.newValue; OnModelChanged(); } });
                    nameF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentArmor.displayName = evt.newValue; OnModelChanged(); } });
                    slotF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { if (Enum.TryParse<ArmorSlot>(evt.newValue, out ArmorSlot s)) _currentArmor.armorSlot = s; OnModelChanged(); } });
                    defS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentArmor.defense = (int)evt.newValue; OnModelChanged(); } });
                    tghS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentArmor.toughness = evt.newValue; OnModelChanged(); } });
                    knkS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentArmor.knockbackResistance = evt.newValue; OnModelChanged(); } });
                }
                break;

            case EditorMode.Recipe:
                {
                    // Recipe Type Dropdown
                    var typeF = root.Q<DropdownField>("input-recipe-type");
                    if (typeF != null)
                    {
                        typeF.value = _currentRecipe.recipeType.ToString();
                        typeF.RegisterValueChangedCallback(evt => {
                            if (!_isUpdating)
                            {
                                if (Enum.TryParse<RecipeType>(evt.newValue, out RecipeType rt))
                                    _currentRecipe.recipeType = rt;
                                UpdateRecipeSectionVisibility(root, _currentRecipe.recipeType);
                                OnModelChanged();
                            }
                        });
                    }

                    // Seksiya ko'rinishini yangilash
                    UpdateRecipeSectionVisibility(root, _currentRecipe.recipeType);

                    // ── Shaped/Shapeless: 3x3 Grid ──
                    for (int i = 0; i < 9; i++)
                    {
                        int index = i;
                        var slotF = root.Q<TextField>($"input-slot-{index}");
                        if (slotF != null)
                        {
                            slotF.value = _currentRecipe.grid[index];
                            slotF.RegisterValueChangedCallback(evt => {
                                if (!_isUpdating)
                                {
                                    _currentRecipe.grid[index] = evt.newValue;
                                    OnModelChanged();
                                }
                            });
                        }
                    }

                    var resF = root.Q<TextField>("input-slot-result");
                    if (resF != null)
                    {
                        resF.value = _currentRecipe.resultItem;
                        resF.RegisterValueChangedCallback(evt => {
                            if (!_isUpdating)
                            {
                                _currentRecipe.resultItem = evt.newValue;
                                OnModelChanged();
                            }
                        });
                    }

                    var countF = root.Q<IntegerField>("input-result-count");
                    if (countF != null)
                    {
                        countF.value = _currentRecipe.resultCount;
                        countF.RegisterValueChangedCallback(evt => {
                            if (!_isUpdating)
                            {
                                _currentRecipe.resultCount = evt.newValue;
                                OnModelChanged();
                            }
                        });
                    }

                    // ── Smelting/Blasting/Smoking/Campfire fieldlari ──
                    var smeltInputF = root.Q<TextField>("input-smelting-input");
                    var smeltResultF = root.Q<TextField>("input-smelting-result");
                    var smeltCountF = root.Q<IntegerField>("input-smelting-count");
                    var smeltXpS = root.Q<Slider>("slider-smelting-xp");
                    var smeltTimeF = root.Q<IntegerField>("input-smelting-time");

                    if (smeltInputF != null) { smeltInputF.value = _currentRecipe.smeltingInput; smeltInputF.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentRecipe.smeltingInput = evt.newValue; OnModelChanged(); } }); }
                    if (smeltResultF != null) { smeltResultF.value = _currentRecipe.resultItem; smeltResultF.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentRecipe.resultItem = evt.newValue; OnModelChanged(); } }); }
                    if (smeltCountF != null) { smeltCountF.value = _currentRecipe.resultCount; smeltCountF.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentRecipe.resultCount = evt.newValue; OnModelChanged(); } }); }
                    if (smeltXpS != null) { smeltXpS.value = _currentRecipe.experience; smeltXpS.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentRecipe.experience = evt.newValue; OnModelChanged(); } }); }
                    if (smeltTimeF != null) { smeltTimeF.value = _currentRecipe.cookingTime; smeltTimeF.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentRecipe.cookingTime = evt.newValue; OnModelChanged(); } }); }

                    // ── Stonecutting fieldlari ──
                    var stoneInputF = root.Q<TextField>("input-stonecutting-input");
                    var stoneResultF = root.Q<TextField>("input-stonecutting-result");
                    var stoneCountF = root.Q<IntegerField>("input-stonecutting-count");

                    if (stoneInputF != null) { stoneInputF.value = _currentRecipe.stonecuttingInput; stoneInputF.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentRecipe.stonecuttingInput = evt.newValue; OnModelChanged(); } }); }
                    if (stoneResultF != null) { stoneResultF.value = _currentRecipe.resultItem; stoneResultF.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentRecipe.resultItem = evt.newValue; OnModelChanged(); } }); }
                    if (stoneCountF != null) { stoneCountF.value = _currentRecipe.resultCount; stoneCountF.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentRecipe.resultCount = evt.newValue; OnModelChanged(); } }); }

                    BindRecipeProFields(root);
                }
                break;

            case EditorMode.LootTable:
                {
                    BindLootTableFields(root);
                }
                break;

            case EditorMode.TagManager:
                {
                    BindTagManagerFields(root);
                }
                break;

            case EditorMode.Mob:
                {
                    var idF = root.Q<TextField>("input-mob-id");
                    var nameF = root.Q<TextField>("input-mob-name");
                    var catF = root.Q<DropdownField>("input-mob-category");
                    var hpS = root.Q<Slider>("slider-mob-health");
                    var spdS = root.Q<Slider>("slider-mob-speed");
                    var dmgS = root.Q<Slider>("slider-mob-damage");
                    var widthS = root.Q<Slider>("slider-mob-width");
                    var heightS = root.Q<Slider>("slider-mob-height");

                    if (idF != null) idF.value = _currentEntity.entityId;
                    if (nameF != null) nameF.value = _currentEntity.displayName;
                    if (catF != null) catF.value = _currentEntity.mobCategory.ToString();
                    if (hpS != null) hpS.value = _currentEntity.health;
                    if (spdS != null) spdS.value = _currentEntity.movementSpeed;
                    if (dmgS != null) dmgS.value = _currentEntity.attackDamage;
                    if (widthS != null) widthS.value = _currentEntity.width;
                    if (heightS != null) heightS.value = _currentEntity.height;

                    idF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentEntity.entityId = evt.newValue; OnModelChanged(); } });
                    nameF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentEntity.displayName = evt.newValue; OnModelChanged(); } });
                    catF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { if (Enum.TryParse<MobCategory>(evt.newValue, out MobCategory c)) _currentEntity.mobCategory = c; OnModelChanged(); } });
                    hpS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentEntity.health = evt.newValue; OnModelChanged(); } });
                    spdS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentEntity.movementSpeed = evt.newValue; OnModelChanged(); } });
                    dmgS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentEntity.attackDamage = evt.newValue; OnModelChanged(); } });
                    widthS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentEntity.width = evt.newValue; OnModelChanged(); } });
                    heightS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentEntity.height = evt.newValue; OnModelChanged(); } });

                    BindAdvancedEntityFields(root);
                }
                break;

            case EditorMode.Biome:
                {
                    var idF = root.Q<TextField>("input-biome-id");
                    var nameF = root.Q<TextField>("input-biome-name");
                    var precT = root.Q<Toggle>("input-biome-prec");
                    var tempS = root.Q<Slider>("slider-biome-temp");
                    var skyF = root.Q<TextField>("input-biome-sky");
                    var grassF = root.Q<TextField>("input-biome-grass");
                    var waterF = root.Q<TextField>("input-biome-water");
                    var fogF = root.Q<TextField>("input-biome-fog");

                    if (idF != null) idF.value = _currentBiome.biomeId;
                    if (nameF != null) nameF.value = _currentBiome.displayName;
                    if (precT != null) precT.value = _currentBiome.precipitation;
                    if (tempS != null) tempS.value = _currentBiome.temperature;
                    if (skyF != null) skyF.value = _currentBiome.skyColor;
                    if (grassF != null) grassF.value = _currentBiome.grassColor;
                    if (waterF != null) waterF.value = _currentBiome.waterColor;
                    if (fogF != null) fogF.value = _currentBiome.fogColor;

                    idF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBiome.biomeId = evt.newValue; OnModelChanged(); } });
                    nameF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBiome.displayName = evt.newValue; OnModelChanged(); } });
                    precT?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBiome.precipitation = evt.newValue; OnModelChanged(); } });
                    tempS?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBiome.temperature = evt.newValue; OnModelChanged(); } });
                    skyF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBiome.skyColor = evt.newValue; OnModelChanged(); } });
                    grassF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBiome.grassColor = evt.newValue; OnModelChanged(); } });
                    waterF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBiome.waterColor = evt.newValue; OnModelChanged(); } });
                    fogF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentBiome.fogColor = evt.newValue; OnModelChanged(); } });

                    BindAdvancedBiomeFields(root);
                }
                break;

            case EditorMode.Dimension:
                {
                    BindDimensionFields(root);
                }
                break;

            case EditorMode.Structure:
                {
                    BindStructureFields(root);
                }
                break;

            case EditorMode.GuiScreen:
                {
                    BindGuiScreenFields(root);
                }
                break;

            case EditorMode.Config:
                {
                    BindConfigFields(root);
                }
                break;

            case EditorMode.Networking:
                {
                    BindNetworkingFields(root);
                }
                break;

            case EditorMode.Keybind:
                {
                    BindKeybindFields(root);
                }
                break;

            case EditorMode.CreativeTab:
                {
                    var idF = root.Q<TextField>("input-tab-id");
                    var nameF = root.Q<TextField>("input-tab-name");
                    var iconF = root.Q<TextField>("input-tab-icon");

                    if (idF != null) idF.value = _currentTab.tabId;
                    if (nameF != null) nameF.value = _currentTab.displayName;
                    if (iconF != null) iconF.value = _currentTab.iconItemId;

                    idF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentTab.tabId = evt.newValue; OnModelChanged(); } });
                    nameF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentTab.displayName = evt.newValue; OnModelChanged(); } });
                    iconF?.RegisterValueChangedCallback(evt => { if (!_isUpdating) { _currentTab.iconItemId = evt.newValue; OnModelChanged(); } });
                }
                break;

            case EditorMode.TexturePainter:
                {
                    var gridContainer = root.Q<VisualElement>("painter-grid");
                    var colorField = root.Q<TextField>("input-paint-color");
                    var filenameField = root.Q<TextField>("input-paint-filename");
                    var targetDrop = root.Q<DropdownField>("dropdown-paint-target");
                    var saveBtn = root.Q<Button>("btn-paint-save");

                    if (colorField != null)
                    {
                        colorField.value = "#" + ColorUtility.ToHtmlStringRGBA(_activePaintColor);
                        colorField.RegisterValueChangedCallback(evt => {
                            if (!_isUpdating)
                            {
                                _activePaintColor = ParseColorFromHex(evt.newValue);
                            }
                        });
                    }

                    if (filenameField != null)
                    {
                        filenameField.value = _paintFilename;
                        filenameField.RegisterValueChangedCallback(evt => {
                            if (!_isUpdating)
                            {
                                _paintFilename = evt.newValue;
                                OnModelChanged();
                            }
                        });
                    }

                    if (targetDrop != null)
                    {
                        targetDrop.choices = new List<string> { "block", "item" };
                        targetDrop.value = string.IsNullOrEmpty(_paintTargetFolder) ? "block" : _paintTargetFolder;
                        targetDrop.RegisterValueChangedCallback(evt => {
                            if (!_isUpdating)
                            {
                                _paintTargetFolder = evt.newValue;
                                OnModelChanged();
                            }
                        });
                    }

                    if (saveBtn != null)
                    {
                        saveBtn.clicked += () => SaveTextureToProject(_paintFilename);
                    }

                    BindToolSelection(root, "pencil");
                    BindToolSelection(root, "eraser");
                    BindToolSelection(root, "bucket");
                    BindToolSelection(root, "eyedropper");

                    BindPresetColor(root, "color-preset-red", "#FF5555");
                    BindPresetColor(root, "color-preset-green", "#55FF55");
                    BindPresetColor(root, "color-preset-blue", "#5555FF");
                    BindPresetColor(root, "color-preset-yellow", "#FFFF55");
                    BindPresetColor(root, "color-preset-orange", "#FFaa00");
                    BindPresetColor(root, "color-preset-white", "#FFFFFF");
                    BindPresetColor(root, "color-preset-black", "#000000");
                    BindPresetColor(root, "color-preset-gray", "#888888");

                    if (gridContainer != null)
                    {
                        gridContainer.Clear();
                        for (int i = 0; i < 256; i++)
                        {
                            int index = i;
                            VisualElement pixel = new VisualElement();
                            pixel.style.width = Length.Percent(6.25f);
                            pixel.style.height = Length.Percent(6.25f);
                            pixel.style.backgroundColor = _pixels[index];
                            
                            pixel.style.borderTopWidth = 0.5f;
                            pixel.style.borderBottomWidth = 0.5f;
                            pixel.style.borderLeftWidth = 0.5f;
                            pixel.style.borderRightWidth = 0.5f;
                            
                            Color borderColor = new Color(0.2f, 0.2f, 0.2f, 0.3f);
                            pixel.style.borderTopColor = borderColor;
                            pixel.style.borderBottomColor = borderColor;
                            pixel.style.borderLeftColor = borderColor;
                            pixel.style.borderRightColor = borderColor;

                            pixel.RegisterCallback<PointerDownEvent>(evt => {
                                if (evt.button == 0)
                                {
                                    PaintPixelAt(index, pixel);
                                }
                            });

                            pixel.RegisterCallback<PointerEnterEvent>(evt => {
                                if (evt.pressedButtons == 1)
                                {
                                    PaintPixelAt(index, pixel);
                                }
                            });

                            gridContainer.Add(pixel);
                        }
                    }
                }
                break;

            case EditorMode.AssetBrowser:
                {
                    BindAssetBrowserUI();
                }
                break;

            case EditorMode.ReleasePanel:
                {
                    BindReleasePanelUI();
                }
                break;

            case EditorMode.ProjectSettings:
                {
                    var idF = root.Q<TextField>("input-settings-modid");
                    var nameF = root.Q<TextField>("input-settings-modname");
                    var verDrop = root.Q<DropdownField>("dropdown-mc-version");
                    var loaderDrop = root.Q<DropdownField>("dropdown-modloader");

                    if (idF != null) idF.value = WorkspaceManager.workspace.modId;
                    if (nameF != null) nameF.value = WorkspaceManager.workspace.modName;

                    if (verDrop != null)
                    {
                        verDrop.choices = StudioDatabase.Versions.Select(v => v.gameVersion).ToList();
                        verDrop.value = WorkspaceManager.workspace.mcVersion;
                    }

                    if (loaderDrop != null)
                    {
                        var data = StudioDatabase.GetVersionData(WorkspaceManager.workspace.mcVersion);
                        loaderDrop.choices = data != null ? data.supportedModloaders : new List<string> { "Fabric" };
                        loaderDrop.value = WorkspaceManager.workspace.modloader;
                    }

                    UpdateProjectSettingsLabels();

                    idF?.RegisterValueChangedCallback(evt => {
                        if (!_isUpdating)
                        {
                            WorkspaceManager.workspace.modId = evt.newValue;
                            OnModelChanged();
                        }
                    });

                    nameF?.RegisterValueChangedCallback(evt => {
                        if (!_isUpdating)
                        {
                            WorkspaceManager.workspace.modName = evt.newValue;
                            OnModelChanged();
                        }
                    });

                    verDrop?.RegisterValueChangedCallback(evt => {
                        if (!_isUpdating)
                        {
                            WorkspaceManager.workspace.mcVersion = evt.newValue;
                            
                            var data = StudioDatabase.GetVersionData(WorkspaceManager.workspace.mcVersion);
                            if (loaderDrop != null && data != null)
                            {
                                loaderDrop.choices = data.supportedModloaders;
                                if (!data.supportedModloaders.Contains(WorkspaceManager.workspace.modloader))
                                {
                                    WorkspaceManager.workspace.modloader = data.supportedModloaders[0];
                                    loaderDrop.value = WorkspaceManager.workspace.modloader;
                                }
                            }

                            if (data != null)
                            {
                                LogToTerminal($"[Loyiha] Versiya o'zgartirildi: {data.gameVersion}. Tizim ushbu versiya uchun Java {data.requiredJavaVersion} talab qiladi.");
                            }

                            UpdateProjectSettingsLabels();
                            OnModelChanged();
                        }
                    });

                    loaderDrop?.RegisterValueChangedCallback(evt => {
                        if (!_isUpdating)
                        {
                            WorkspaceManager.workspace.modloader = evt.newValue;
                            OnModelChanged();
                        }
                    });
                }
                break;
        }

        } // end try
        finally
        {
            _isUpdating = false;
        }
    }

    private int ResolveTargetJavaVersion()
    {
        try
        {
            var resolved = VersionResolver.Resolve(WorkspaceManager.workspace);
            if (resolved != null && resolved.javaVersion > 0)
                return resolved.javaVersion;
        }
        catch
        {
            // VersionResolver hali tayyor bo'lmasa, StudioDatabase fallback ishlatiladi.
        }

        var data = StudioDatabase.GetVersionData(WorkspaceManager.workspace.mcVersion);
        return data != null ? data.requiredJavaVersion : 17;
    }

    private bool ValidateBeforeBuildOrRun()
    {
        VerifyWorkspaceConsistency();

        var results = ModValidator.ValidateWorkspace(WorkspaceManager.workspace);
        int errorCount = ModValidator.GetErrorCount(results);

        if (errorCount > 0)
        {
            LogToTerminal(ModValidator.FormatResults(results));
            EditorUtility.DisplayDialog(
                "Build/Run to'xtatildi",
                $"Loyihada {errorCount} ta jiddiy xato bor. Avval Tekshirish panelidagi xatolarni tuzating.",
                "OK"
            );
            return false;
        }

        return true;
    }

    private void BuildCurrentProject()
    {
        if (!ValidateBeforeBuildOrRun()) return;

        WorkspaceManager.SaveWorkspace(ProjectPath);
        WorkspaceManager.CompileAndExportAll(ProjectPath);

        int javaVer = ResolveTargetJavaVersion();
        LogToTerminal($"[BuildRunner] Gradle build uchun Java {javaVer} tanlandi.");
        _gradleCompiler.RunBuild(ProjectPath, javaVer);
    }

    private void RunMinecraftClientFromStudio()
    {
        if (!ValidateBeforeBuildOrRun()) return;

        WorkspaceManager.SaveWorkspace(ProjectPath);
        WorkspaceManager.CompileAndExportAll(ProjectPath);

        int javaVer = ResolveTargetJavaVersion();
        LogToTerminal($"[BuildRunner] runClient uchun Java {javaVer} tanlandi.");
        _gradleCompiler.RunMinecraftClient(ProjectPath, javaVer);
    }

    private void StopCurrentGradleProcess()
    {
        if (_gradleCompiler == null)
        {
            LogToTerminal("[BuildRunner] Gradle compiler hali ishga tushmagan.");
            return;
        }

        _gradleCompiler.StopProcess();
    }

    private void AnalyzeLastGradleLog()
    {
        if (_gradleCompiler == null)
        {
            LogToTerminal("[ErrorAnalyzer] Tahlil qilinadigan runner topilmadi.");
            return;
        }

        var report = _gradleCompiler.AnalyzeLastLog();
        string formatted = report != null ? report.Format() : "[ErrorAnalyzer] Hisobot bo'sh.";
        LogToTerminal(formatted);

        if (report != null && report.HasErrors())
        {
            EditorUtility.DisplayDialog(
                "Build Error Analyzer",
                $"{report.ErrorCount()} ta jiddiy muammo topildi. Terminal panelida sabab va tavsiyalar chiqarildi.",
                "OK"
            );
        }
        else
        {
            EditorUtility.DisplayDialog(
                "Build Error Analyzer",
                "Aniq jiddiy muammo topilmadi. Terminal panelidagi log summary'ni ko'ring.",
                "OK"
            );
        }
    }

    private void ValidateCurrentProject()
    {
        VerifyWorkspaceConsistency();
        WorkspaceManager.workspace.studioProject = ProjectStateManager.SyncFromWorkspace(WorkspaceManager.workspace, ProjectPath);
        LogToTerminal("[ProjectModel] " + ProjectStateManager.GetSummary());

        var results = ModValidator.ValidateWorkspace(WorkspaceManager.workspace);
        string report = ModValidator.FormatResults(results);
        int errorCount = ModValidator.GetErrorCount(results);

        LogToTerminal(report);

        if (errorCount > 0)
        {
            EditorUtility.DisplayDialog(
                "Loyihada xatolar bor",
                $"Loyiha ichida {errorCount} ta jiddiy xato topildi.\n\nTerminal panelini tekshiring.",
                "OK"
            );
        }
        else
        {
            EditorUtility.DisplayDialog(
                "Tekshiruv muvaffaqiyatli",
                "Jiddiy xato topilmadi. Endi loyihani export/build qilish mumkin.",
                "OK"
            );
        }
    }

    private void SaveProjectAndExport()
    {
        VerifyWorkspaceConsistency();
        WorkspaceManager.workspace.studioProject = ProjectStateManager.SyncFromWorkspace(WorkspaceManager.workspace, ProjectPath);
        LogToTerminal("[ProjectModel] " + ProjectStateManager.GetSummary());

        var results = ModValidator.ValidateWorkspace(WorkspaceManager.workspace);
        int errorCount = ModValidator.GetErrorCount(results);

        if (errorCount > 0)
        {
            LogToTerminal(ModValidator.FormatResults(results));

            EditorUtility.DisplayDialog(
                "Export to'xtatildi",
                $"Loyihada {errorCount} ta jiddiy xato bor. Avval ularni tuzating.",
                "OK"
            );

            return;
        }

        WorkspaceManager.SaveWorkspace(ProjectPath);
        WorkspaceManager.CompileAndExportAll(ProjectPath);

        LogToTerminal($"[Workspace] Loyiha muvaffaqiyatli saqlandi va eksport qilindi: {ProjectPath}");

        EditorUtility.DisplayDialog(
            "Workspace Saqlandi ✓",
            $"Workspace JSON saqlandi va loyiha eksport qilindi!\n\nYo'l: {ProjectPath}",
            "OK"
        );
    }

    /// <summary>
    /// Retsept turiga qarab tegishli seksiyani ko'rsatadi/yashiradi.
    /// </summary>
    private void UpdateRecipeSectionVisibility(VisualElement root, RecipeType type)
    {
        var craftingSection = root.Q<VisualElement>("crafting-section");
        var smeltingSection = root.Q<VisualElement>("smelting-section");
        var stonecuttingSection = root.Q<VisualElement>("stonecutting-section");

        bool showCrafting = type == RecipeType.CraftingShaped || type == RecipeType.CraftingShapeless;
        bool showSmelting = type == RecipeType.Smelting || type == RecipeType.Blasting || type == RecipeType.Smoking || type == RecipeType.CampfireCooking;
        bool showStonecutting = type == RecipeType.Stonecutting;

        if (craftingSection != null) craftingSection.style.display = showCrafting ? DisplayStyle.Flex : DisplayStyle.None;
        if (smeltingSection != null) smeltingSection.style.display = showSmelting ? DisplayStyle.Flex : DisplayStyle.None;
        if (stonecuttingSection != null) stonecuttingSection.style.display = showStonecutting ? DisplayStyle.Flex : DisplayStyle.None;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // MULTI-ELEMENT NAVIGATSIYA TIZIMI
    // ═══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Har bir editor rejimi uchun elementlar orasida navigatsiya paneli yaratadi.
    /// ← → tugmalari, element nomi, qo'shish va o'chirish tugmalari.
    /// </summary>
    private VisualElement CreateElementNavigationBar(EditorMode mode)
    {
        int currentIndex = GetCurrentIndex(mode);
        int totalCount = GetTotalCount(mode);
        string elementName = GetCurrentElementName(mode);

        // Asosiy konteyner
        var navBar = new VisualElement();
        navBar.name = "element-nav-bar";
        navBar.style.flexDirection = FlexDirection.Row;
        navBar.style.alignItems = Align.Center;
        navBar.style.justifyContent = Justify.SpaceBetween;
        navBar.style.backgroundColor = new StyleColor(new Color(0.17f, 0.17f, 0.19f, 1f));
        navBar.style.paddingTop = 6;
        navBar.style.paddingBottom = 6;
        navBar.style.paddingLeft = 10;
        navBar.style.paddingRight = 10;
        navBar.style.marginBottom = 10;
        navBar.style.borderBottomWidth = 1;
        navBar.style.borderBottomColor = new StyleColor(new Color(0.24f, 0.24f, 0.24f, 1f));
        navBar.style.borderTopLeftRadius = 4;
        navBar.style.borderTopRightRadius = 4;

        // Chap qism: ← → tugmalari va element nomi
        var leftGroup = new VisualElement();
        leftGroup.style.flexDirection = FlexDirection.Row;
        leftGroup.style.alignItems = Align.Center;

        var prevBtn = new Button(() => NavigateElement(mode, -1)) { text = "◀" };
        prevBtn.style.width = 28;
        prevBtn.style.height = 24;
        prevBtn.style.fontSize = 12;
        prevBtn.style.marginRight = 4;
        prevBtn.style.backgroundColor = new StyleColor(new Color(0.25f, 0.25f, 0.27f, 1f));
        prevBtn.style.color = new StyleColor(Color.white);
        prevBtn.style.borderTopWidth = prevBtn.style.borderBottomWidth = prevBtn.style.borderLeftWidth = prevBtn.style.borderRightWidth = 0;
        prevBtn.style.borderTopLeftRadius = prevBtn.style.borderTopRightRadius = prevBtn.style.borderBottomLeftRadius = prevBtn.style.borderBottomRightRadius = 3;
        prevBtn.SetEnabled(currentIndex > 0);

        var indexLabel = new Label($"{currentIndex + 1} / {totalCount}");
        indexLabel.style.color = new StyleColor(new Color(0.7f, 0.85f, 1f, 1f));
        indexLabel.style.fontSize = 12;
        indexLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
        indexLabel.style.marginLeft = 6;
        indexLabel.style.marginRight = 6;
        indexLabel.style.minWidth = 40;
        indexLabel.style.unityTextAlign = TextAnchor.MiddleCenter;

        var nextBtn = new Button(() => NavigateElement(mode, +1)) { text = "▶" };
        nextBtn.style.width = 28;
        nextBtn.style.height = 24;
        nextBtn.style.fontSize = 12;
        nextBtn.style.marginLeft = 4;
        nextBtn.style.backgroundColor = new StyleColor(new Color(0.25f, 0.25f, 0.27f, 1f));
        nextBtn.style.color = new StyleColor(Color.white);
        nextBtn.style.borderTopWidth = nextBtn.style.borderBottomWidth = nextBtn.style.borderLeftWidth = nextBtn.style.borderRightWidth = 0;
        nextBtn.style.borderTopLeftRadius = nextBtn.style.borderTopRightRadius = nextBtn.style.borderBottomLeftRadius = nextBtn.style.borderBottomRightRadius = 3;
        nextBtn.SetEnabled(currentIndex < totalCount - 1);

        // Element nomi labeli
        var nameLabel = new Label(elementName);
        nameLabel.style.color = new StyleColor(new Color(0.85f, 0.85f, 0.85f, 1f));
        nameLabel.style.fontSize = 12;
        nameLabel.style.marginLeft = 12;
        nameLabel.style.overflow = Overflow.Hidden;
        nameLabel.style.textOverflow = TextOverflow.Ellipsis;
        nameLabel.style.maxWidth = 150;

        leftGroup.Add(prevBtn);
        leftGroup.Add(indexLabel);
        leftGroup.Add(nextBtn);
        leftGroup.Add(nameLabel);

        // O'ng qism: qo'shish va o'chirish tugmalari
        var rightGroup = new VisualElement();
        rightGroup.style.flexDirection = FlexDirection.Row;
        rightGroup.style.alignItems = Align.Center;

        var addBtn = new Button(() => AddNewElement(mode)) { text = "＋ Yangi" };
        addBtn.style.height = 24;
        addBtn.style.fontSize = 11;
        addBtn.style.paddingLeft = 8;
        addBtn.style.paddingRight = 8;
        addBtn.style.marginRight = 6;
        addBtn.style.backgroundColor = new StyleColor(new Color(0.18f, 0.49f, 0.2f, 1f));
        addBtn.style.color = new StyleColor(Color.white);
        addBtn.style.borderTopWidth = addBtn.style.borderBottomWidth = addBtn.style.borderLeftWidth = addBtn.style.borderRightWidth = 0;
        addBtn.style.borderTopLeftRadius = addBtn.style.borderTopRightRadius = addBtn.style.borderBottomLeftRadius = addBtn.style.borderBottomRightRadius = 3;

        var deleteBtn = new Button(() => DeleteCurrentElement(mode)) { text = "🗑" };
        deleteBtn.style.width = 28;
        deleteBtn.style.height = 24;
        deleteBtn.style.fontSize = 13;
        deleteBtn.style.backgroundColor = new StyleColor(new Color(0.55f, 0.15f, 0.15f, 1f));
        deleteBtn.style.color = new StyleColor(Color.white);
        deleteBtn.style.borderTopWidth = deleteBtn.style.borderBottomWidth = deleteBtn.style.borderLeftWidth = deleteBtn.style.borderRightWidth = 0;
        deleteBtn.style.borderTopLeftRadius = deleteBtn.style.borderTopRightRadius = deleteBtn.style.borderBottomLeftRadius = deleteBtn.style.borderBottomRightRadius = 3;
        deleteBtn.SetEnabled(totalCount > 1); // Oxirgi elementni o'chirib bo'lmaydi

        rightGroup.Add(addBtn);
        rightGroup.Add(deleteBtn);

        navBar.Add(leftGroup);
        navBar.Add(rightGroup);

        return navBar;
    }

    private int GetCurrentIndex(EditorMode mode)
    {
        switch (mode)
        {
            case EditorMode.Block:       return _currentBlockIdx;
            case EditorMode.Item:        return _currentItemIdx;
            case EditorMode.Tool:        return _currentToolIdx;
            case EditorMode.Armor:       return _currentArmorIdx;
            case EditorMode.Recipe:      return _currentRecipeIdx;
            case EditorMode.LootTable:   return _currentLootIdx;
            case EditorMode.TagManager:  return _currentTagIdx;
            case EditorMode.Mob:         return _currentEntityIdx;
            case EditorMode.Biome:       return _currentBiomeIdx;
            case EditorMode.Dimension:   return _currentDimensionIdx;
            case EditorMode.Structure:   return _currentStructureIdx;
            case EditorMode.GuiScreen:   return _currentScreenIdx;
            case EditorMode.Config:      return _currentConfigIdx;
            case EditorMode.CreativeTab: return _currentTabIdx;
            default: return 0;
        }
    }

    private int GetTotalCount(EditorMode mode)
    {
        var ws = WorkspaceManager.workspace;
        switch (mode)
        {
            case EditorMode.Block:       return ws.blocks.Count;
            case EditorMode.Item:        return ws.items.Count;
            case EditorMode.Tool:        return ws.tools.Count;
            case EditorMode.Armor:       return ws.armors.Count;
            case EditorMode.Recipe:      return ws.recipes.Count;
            case EditorMode.LootTable:   return ws.lootTables.Count;
            case EditorMode.TagManager:  return ws.tags.Count;
            case EditorMode.Mob:         return ws.entities.Count;
            case EditorMode.Biome:       return ws.biomes.Count;
            case EditorMode.Dimension:   return ws.dimensions.Count;
            case EditorMode.Structure:   return ws.structures.Count;
            case EditorMode.GuiScreen:   return ws.screens.Count;
            case EditorMode.Config:      return ws.configs.Count;
            case EditorMode.CreativeTab: return ws.creativeTabs.Count;
            default: return 0;
        }
    }

    private string GetCurrentElementName(EditorMode mode)
    {
        switch (mode)
        {
            case EditorMode.Block:       return _currentBlock.displayName;
            case EditorMode.Item:        return _currentItem.displayName;
            case EditorMode.Tool:        return _currentTool.displayName;
            case EditorMode.Armor:       return _currentArmor.displayName;
            case EditorMode.Recipe:      return _currentRecipe.resultItem;
            case EditorMode.LootTable:   return _currentLoot.displayName;
            case EditorMode.TagManager:  return _currentTag.displayName;
            case EditorMode.Mob:         return _currentEntity.displayName;
            case EditorMode.Biome:       return _currentBiome.displayName;
            case EditorMode.Dimension:   return _currentDimension.displayName;
            case EditorMode.Structure:   return _currentStructure.displayName;
            case EditorMode.GuiScreen:   return _currentScreen.displayName;
            case EditorMode.Config:      return _currentConfig.displayName;
            case EditorMode.CreativeTab: return _currentTab.displayName;
            default: return "";
        }
    }

    private void NavigateElement(EditorMode mode, int direction)
    {
        int total = GetTotalCount(mode);
        if (total <= 0) return;

        switch (mode)
        {
            case EditorMode.Block:       _currentBlockIdx  = Mathf.Clamp(_currentBlockIdx  + direction, 0, total - 1); break;
            case EditorMode.Item:        _currentItemIdx   = Mathf.Clamp(_currentItemIdx   + direction, 0, total - 1); break;
            case EditorMode.Tool:        _currentToolIdx   = Mathf.Clamp(_currentToolIdx   + direction, 0, total - 1); break;
            case EditorMode.Armor:       _currentArmorIdx  = Mathf.Clamp(_currentArmorIdx  + direction, 0, total - 1); break;
            case EditorMode.Recipe:      _currentRecipeIdx = Mathf.Clamp(_currentRecipeIdx + direction, 0, total - 1); break;
            case EditorMode.LootTable:   _currentLootIdx   = Mathf.Clamp(_currentLootIdx   + direction, 0, total - 1); break;
            case EditorMode.TagManager:  _currentTagIdx    = Mathf.Clamp(_currentTagIdx    + direction, 0, total - 1); break;
            case EditorMode.Mob:         _currentEntityIdx = Mathf.Clamp(_currentEntityIdx + direction, 0, total - 1); break;
            case EditorMode.Biome:       _currentBiomeIdx  = Mathf.Clamp(_currentBiomeIdx  + direction, 0, total - 1); break;
            case EditorMode.Dimension:   _currentDimensionIdx = Mathf.Clamp(_currentDimensionIdx + direction, 0, total - 1); break;
            case EditorMode.Structure:   _currentStructureIdx = Mathf.Clamp(_currentStructureIdx + direction, 0, total - 1); break;
            case EditorMode.GuiScreen:   _currentScreenIdx = Mathf.Clamp(_currentScreenIdx + direction, 0, total - 1); break;
            case EditorMode.Config:      _currentConfigIdx = Mathf.Clamp(_currentConfigIdx + direction, 0, total - 1); break;
            case EditorMode.CreativeTab: _currentTabIdx    = Mathf.Clamp(_currentTabIdx    + direction, 0, total - 1); break;
        }

        // UI ni qayta yuklash
        SwitchEditorMode(mode);
    }

    private void AddNewElement(EditorMode mode)
    {
        var ws = WorkspaceManager.workspace;

        switch (mode)
        {
            case EditorMode.Block:
                ws.blocks.Add(new BlockDataModel { blockId = $"new_block_{ws.blocks.Count}", displayName = $"New Block {ws.blocks.Count}" });
                _currentBlockIdx = ws.blocks.Count - 1;
                break;
            case EditorMode.Item:
                ws.items.Add(new ItemDataModel { itemId = $"new_item_{ws.items.Count}", displayName = $"New Item {ws.items.Count}" });
                _currentItemIdx = ws.items.Count - 1;
                break;
            case EditorMode.Tool:
                ws.tools.Add(new ToolDataModel { toolId = $"new_tool_{ws.tools.Count}", displayName = $"New Tool {ws.tools.Count}" });
                _currentToolIdx = ws.tools.Count - 1;
                break;
            case EditorMode.Armor:
                ws.armors.Add(new ArmorDataModel { armorId = $"new_armor_{ws.armors.Count}", displayName = $"New Armor {ws.armors.Count}" });
                _currentArmorIdx = ws.armors.Count - 1;
                break;
            case EditorMode.Recipe:
                ws.recipes.Add(new RecipeDataModel { resultItem = $"new_result_{ws.recipes.Count}" });
                _currentRecipeIdx = ws.recipes.Count - 1;
                break;
            case EditorMode.LootTable:
                ws.lootTables.Add(new LootTableDataModel { lootId = $"new_loot_{ws.lootTables.Count}", displayName = $"New Loot {ws.lootTables.Count}" });
                _currentLootIdx = ws.lootTables.Count - 1;
                break;
            case EditorMode.TagManager:
                ws.tags.Add(new TagDataModel { tagId = $"new_tag_{ws.tags.Count}", displayName = $"New Tag {ws.tags.Count}" });
                _currentTagIdx = ws.tags.Count - 1;
                break;
            case EditorMode.Mob:
                ws.entities.Add(new EntityDataModel { entityId = $"new_entity_{ws.entities.Count}", displayName = $"New Entity {ws.entities.Count}" });
                _currentEntityIdx = ws.entities.Count - 1;
                break;
            case EditorMode.Biome:
                ws.biomes.Add(new BiomeDataModel { biomeId = $"new_biome_{ws.biomes.Count}", displayName = $"New Biome {ws.biomes.Count}" });
                _currentBiomeIdx = ws.biomes.Count - 1;
                break;
            case EditorMode.Dimension:
                ws.dimensions.Add(new DimensionDataModel { dimensionId = $"new_dimension_{ws.dimensions.Count}", displayName = $"New Dimension {ws.dimensions.Count}" });
                _currentDimensionIdx = ws.dimensions.Count - 1;
                break;
            case EditorMode.Structure:
                ws.structures.Add(new StructureDataModel { structureId = $"new_structure_{ws.structures.Count}", displayName = $"New Structure {ws.structures.Count}" });
                _currentStructureIdx = ws.structures.Count - 1;
                break;
            case EditorMode.GuiScreen:
                ws.screens.Add(new ScreenDataModel { screenId = $"new_screen_{ws.screens.Count}", displayName = $"New Screen {ws.screens.Count}" });
                _currentScreenIdx = ws.screens.Count - 1;
                break;
            case EditorMode.Config:
                ws.configs.Add(new ConfigDataModel { configId = $"new_config_{ws.configs.Count}", displayName = $"New Config {ws.configs.Count}" });
                _currentConfigIdx = ws.configs.Count - 1;
                break;
            case EditorMode.CreativeTab:
                ws.creativeTabs.Add(new CreativeTabDataModel { tabId = $"new_tab_{ws.creativeTabs.Count}", displayName = $"New Tab {ws.creativeTabs.Count}" });
                _currentTabIdx = ws.creativeTabs.Count - 1;
                break;
        }

        LogToTerminal($"[Workspace] Yangi {mode} elementi qo'shildi.");
        SwitchEditorMode(mode);
    }

    private void DeleteCurrentElement(EditorMode mode)
    {
        var ws = WorkspaceManager.workspace;
        int total = GetTotalCount(mode);
        if (total <= 1)
        {
            LogToTerminal($"[Ogohlantirish] Oxirgi {mode} elementini o'chirib bo'lmaydi!");
            return;
        }

        string elementName = GetCurrentElementName(mode);
        bool confirmed = EditorUtility.DisplayDialog(
            "Elementni o'chirish",
            $"'{elementName}' elementini o'chirishni xohlaysizmi?\nBu amalni qaytarib bo'lmaydi!",
            "Ha, o'chir", "Bekor qilish"
        );

        if (!confirmed) return;

        switch (mode)
        {
            case EditorMode.Block:
                ws.blocks.RemoveAt(_currentBlockIdx);
                _currentBlockIdx = Mathf.Clamp(_currentBlockIdx, 0, ws.blocks.Count - 1);
                break;
            case EditorMode.Item:
                ws.items.RemoveAt(_currentItemIdx);
                _currentItemIdx = Mathf.Clamp(_currentItemIdx, 0, ws.items.Count - 1);
                break;
            case EditorMode.Tool:
                ws.tools.RemoveAt(_currentToolIdx);
                _currentToolIdx = Mathf.Clamp(_currentToolIdx, 0, ws.tools.Count - 1);
                break;
            case EditorMode.Armor:
                ws.armors.RemoveAt(_currentArmorIdx);
                _currentArmorIdx = Mathf.Clamp(_currentArmorIdx, 0, ws.armors.Count - 1);
                break;
            case EditorMode.Recipe:
                ws.recipes.RemoveAt(_currentRecipeIdx);
                _currentRecipeIdx = Mathf.Clamp(_currentRecipeIdx, 0, ws.recipes.Count - 1);
                break;
            case EditorMode.LootTable:
                ws.lootTables.RemoveAt(_currentLootIdx);
                _currentLootIdx = Mathf.Clamp(_currentLootIdx, 0, ws.lootTables.Count - 1);
                break;
            case EditorMode.TagManager:
                ws.tags.RemoveAt(_currentTagIdx);
                _currentTagIdx = Mathf.Clamp(_currentTagIdx, 0, ws.tags.Count - 1);
                break;
            case EditorMode.Mob:
                ws.entities.RemoveAt(_currentEntityIdx);
                _currentEntityIdx = Mathf.Clamp(_currentEntityIdx, 0, ws.entities.Count - 1);
                break;
            case EditorMode.Biome:
                ws.biomes.RemoveAt(_currentBiomeIdx);
                _currentBiomeIdx = Mathf.Clamp(_currentBiomeIdx, 0, ws.biomes.Count - 1);
                break;
            case EditorMode.Dimension:
                ws.dimensions.RemoveAt(_currentDimensionIdx);
                _currentDimensionIdx = Mathf.Clamp(_currentDimensionIdx, 0, ws.dimensions.Count - 1);
                break;
            case EditorMode.Structure:
                ws.structures.RemoveAt(_currentStructureIdx);
                _currentStructureIdx = Mathf.Clamp(_currentStructureIdx, 0, ws.structures.Count - 1);
                break;
            case EditorMode.GuiScreen:
                ws.screens.RemoveAt(_currentScreenIdx);
                _currentScreenIdx = Mathf.Clamp(_currentScreenIdx, 0, ws.screens.Count - 1);
                break;
            case EditorMode.Config:
                ws.configs.RemoveAt(_currentConfigIdx);
                _currentConfigIdx = Mathf.Clamp(_currentConfigIdx, 0, ws.configs.Count - 1);
                break;
            case EditorMode.CreativeTab:
                ws.creativeTabs.RemoveAt(_currentTabIdx);
                _currentTabIdx = Mathf.Clamp(_currentTabIdx, 0, ws.creativeTabs.Count - 1);
                break;
        }

        LogToTerminal($"[Workspace] '{elementName}' elementi o'chirildi.");
        SwitchEditorMode(mode);
    }

    private void BindToolSelection(VisualElement root, string name)
    {
        var btn = root.Q<Button>($"btn-tool-{name}");
        if (btn != null)
        {
            btn.clicked += () => SelectPaintTool(root, name);
        }
    }

    private void SelectPaintTool(VisualElement root, string toolName)
    {
        _activeTool = toolName;
        string[] tools = { "pencil", "eraser", "bucket", "eyedropper" };
        foreach (var t in tools)
        {
            var btn = root.Q<Button>($"btn-tool-{t}");
            if (btn != null)
            {
                if (t == toolName)
                    btn.AddToClassList("painter-tool-btn--active");
                else
                    btn.RemoveFromClassList("painter-tool-btn--active");
            }
        }
    }

    private void BindPresetColor(VisualElement root, string name, string hex)
    {
        var btn = root.Q<Button>(name);
        var hexField = root.Q<TextField>("input-paint-color");
        if (btn != null)
        {
            btn.clicked += () => {
                if (hexField != null) hexField.value = hex;
                _activePaintColor = ParseColorFromHex(hex);
            };
        }
    }

    private Color ParseColorFromHex(string hex)
    {
        hex = hex.Replace("#", "").Trim();
        if (hex.Length == 6)
        {
            byte r = Convert.ToByte(hex.Substring(0, 2), 16);
            byte g = Convert.ToByte(hex.Substring(2, 2), 16);
            byte b = Convert.ToByte(hex.Substring(4, 2), 16);
            return new Color32(r, g, b, 255);
        }
        return Color.red;
    }

    private void PaintPixelAt(int index, VisualElement pixel)
    {
        if (_activeTool == "pencil")
        {
            _pixels[index] = _activePaintColor;
            pixel.style.backgroundColor = _activePaintColor;
            UpdatePreviewMaterial();
        }
        else if (_activeTool == "eraser")
        {
            _pixels[index] = Color.clear;
            pixel.style.backgroundColor = Color.clear;
            UpdatePreviewMaterial();
        }
        else if (_activeTool == "bucket")
        {
            Color targetColor = _pixels[index];
            if (ColorMatch(targetColor, _activePaintColor)) return;
            
            FloodFill(index, targetColor, _activePaintColor);
            
            var root = rootVisualElement;
            var gridContainer = root.Q<VisualElement>("painter-grid");
            if (gridContainer != null)
            {
                var children = gridContainer.Children().ToList();
                for (int i = 0; i < 256; i++)
                {
                    children[i].style.backgroundColor = _pixels[i];
                }
            }
            UpdatePreviewMaterial();
        }
        else if (_activeTool == "eyedropper")
        {
            Color color = _pixels[index];
            _activePaintColor = color;
            
            string hex = "#" + ColorUtility.ToHtmlStringRGBA(color);
            var hexField = rootVisualElement.Q<TextField>("input-paint-color");
            if (hexField != null)
            {
                _isUpdating = true;
                try { hexField.value = hex; }
                finally { _isUpdating = false; }
            }
            SelectPaintTool(rootVisualElement, "pencil");
        }
    }

    private bool ColorMatch(Color c1, Color c2)
    {
        return Mathf.Abs(c1.r - c2.r) < 0.01f &&
               Mathf.Abs(c1.g - c2.g) < 0.01f &&
               Mathf.Abs(c1.b - c2.b) < 0.01f &&
               Mathf.Abs(c1.a - c2.a) < 0.01f;
    }

    private void FloodFill(int index, Color targetColor, Color replacementColor)
    {
        int startX = index % 16;
        int startY = index / 16;

        Queue<Vector2Int> queue = new Queue<Vector2Int>();
        queue.Enqueue(new Vector2Int(startX, startY));

        bool[] visited = new bool[256];

        while (queue.Count > 0)
        {
            Vector2Int pt = queue.Dequeue();
            if (pt.x < 0 || pt.x >= 16 || pt.y < 0 || pt.y >= 16) continue;

            int idx = pt.y * 16 + pt.x;
            if (visited[idx]) continue;
            visited[idx] = true;

            if (ColorMatch(_pixels[idx], targetColor))
            {
                _pixels[idx] = replacementColor;
                queue.Enqueue(new Vector2Int(pt.x + 1, pt.y));
                queue.Enqueue(new Vector2Int(pt.x - 1, pt.y));
                queue.Enqueue(new Vector2Int(pt.x, pt.y + 1));
                queue.Enqueue(new Vector2Int(pt.x, pt.y - 1));
            }
        }
    }

    private void UpdatePreviewMaterial()
    {
        var cube = GameObject.Find("VoxelCube_Preview");
        if (cube == null) return;

        var renderer = cube.GetComponent<Renderer>();
        if (renderer == null) return;

        if (_previewTexture == null)
        {
            _previewTexture = new Texture2D(16, 16);
            _previewTexture.filterMode = FilterMode.Point;
            _previewTexture.wrapMode = TextureWrapMode.Clamp;
        }

        _previewTexture.SetPixels(_pixels);
        _previewTexture.Apply();

        renderer.sharedMaterial.mainTexture = _previewTexture;
        renderer.sharedMaterial.SetFloat("_Smoothness", 0f);
        renderer.sharedMaterial.SetFloat("_Metallic", 0f);
    }

    private void SaveTextureToProject(string filename)
    {
        try
        {
            string unityPath = StudioTexturePipeline.SavePainterTextureToUnityLibrary(filename, _pixels, _paintTargetFolder);

            AssetDatabase.ImportAsset(unityPath);
            var imp = AssetImporter.GetAtPath(unityPath) as TextureImporter;
            if (imp != null)
            {
                PixelArtTexturePostProcessor.ApplyPixelArtSettings(imp, unityPath);
                imp.SaveAndReimport();
            }

            string exportPath = string.Empty;
            if (!string.IsNullOrEmpty(ProjectPath))
            {
                exportPath = StudioTexturePipeline.SavePainterTextureToExportProject(ProjectPath, WorkspaceManager.workspace, filename, _pixels, _paintTargetFolder);
            }

            LogToTerminal($"[TexturePipeline] Painter texture saqlandi: {unityPath}");
            if (!string.IsNullOrEmpty(exportPath))
                LogToTerminal($"[TexturePipeline] Export resource ham yangilandi: {exportPath}");

            EditorUtility.DisplayDialog(
                "Tekstura Saqlandi ✓",
                string.IsNullOrEmpty(exportPath)
                    ? $"Tekstura Unity kutubxonasiga saqlandi:\n{unityPath}"
                    : $"Tekstura saqlandi:\n{unityPath}\n\nExport projectga ham yozildi:\n{exportPath}",
                "OK"
            );
        }
        catch (Exception ex)
        {
            LogToTerminal($"[TexturePipeline ERROR] {ex.Message}");
            EditorUtility.DisplayDialog("Tekstura saqlanmadi", ex.Message, "OK");
        }
    }


    private void BindAssetBrowserUI()
    {
        var root = rootVisualElement;
        var filterDrop = root.Q<DropdownField>("dropdown-asset-filter");
        var searchField = root.Q<TextField>("input-asset-search");
        var showMissingToggle = root.Q<Toggle>("toggle-show-missing");
        var refreshBtn = root.Q<Button>("btn-assets-refresh");
        var openResourcesBtn = root.Q<Button>("btn-assets-open-resources");
        var openProjectBtn = root.Q<Button>("btn-assets-open-project");
        var exportBtn = root.Q<Button>("btn-assets-export-refresh");

        if (filterDrop != null)
        {
            filterDrop.choices = new List<string> { "all", "texture", "model", "blockstate", "lang", "recipe", "biome", "metadata", "detected", "missing" };
            if (string.IsNullOrEmpty(_assetBrowserFilter)) _assetBrowserFilter = "all";
            filterDrop.value = _assetBrowserFilter;
            filterDrop.RegisterValueChangedCallback(evt =>
            {
                if (_isUpdating) return;
                _assetBrowserFilter = evt.newValue;
                RefreshAssetBrowserList();
            });
        }

        if (searchField != null)
        {
            searchField.value = _assetBrowserSearch;
            searchField.RegisterValueChangedCallback(evt =>
            {
                if (_isUpdating) return;
                _assetBrowserSearch = evt.newValue ?? "";
                RefreshAssetBrowserList();
            });
        }

        if (showMissingToggle != null)
        {
            showMissingToggle.value = _assetBrowserShowMissing;
            showMissingToggle.RegisterValueChangedCallback(evt =>
            {
                if (_isUpdating) return;
                _assetBrowserShowMissing = evt.newValue;
                RefreshAssetBrowserList();
            });
        }

        if (refreshBtn != null) refreshBtn.clicked += RefreshAssetBrowserList;
        if (exportBtn != null) exportBtn.clicked += () =>
        {
            SaveProjectAndExport();
            RefreshAssetBrowserList();
        };

        if (openProjectBtn != null) openProjectBtn.clicked += () =>
        {
            EnsureProjectFolderExists();
            EditorUtility.RevealInFinder(ProjectPath);
        };

        if (openResourcesBtn != null) openResourcesBtn.clicked += () =>
        {
            string resourcesPath = StudioAssetBrowserScanner.GetResourcesRoot(ProjectPath);
            Directory.CreateDirectory(resourcesPath);
            EditorUtility.RevealInFinder(resourcesPath);
        };

        RefreshAssetBrowserList();
    }

    private void RefreshAssetBrowserList()
    {
        VerifyWorkspaceConsistency();
        _assetBrowserReport = StudioAssetBrowserScanner.Scan(WorkspaceManager.workspace, ProjectPath);

        var root = rootVisualElement;
        var summary = root.Q<Label>("label-asset-summary");
        var list = root.Q<ScrollView>("asset-browser-list");
        var details = root.Q<Label>("label-asset-details");

        if (summary != null)
        {
            summary.text = _assetBrowserReport != null
                ? _assetBrowserReport.FormatSummary()
                : "Asset Browser: report topilmadi";
        }

        if (details != null)
        {
            details.text = "Resursni tanlang. Missing bo'lgan fayllar export vaqtida 8-patch texture pipeline yoki generatorlar orqali yaratiladi.";
        }

        if (list == null || _assetBrowserReport == null) return;
        list.Clear();

        List<StudioAssetBrowserEntry> entries = _assetBrowserReport.entries ?? new List<StudioAssetBrowserEntry>();
        entries = ApplyAssetBrowserFilters(entries);

        if (entries.Count == 0)
        {
            var empty = new Label("Hech qanday resurs topilmadi. Filter/search qiymatini o'zgartirib ko'ring yoki avval Save/Export qiling.");
            empty.style.color = new StyleColor(new Color(0.75f, 0.75f, 0.75f));
            empty.style.whiteSpace = WhiteSpace.Normal;
            empty.style.paddingTop = 12;
            empty.style.paddingLeft = 10;
            list.Add(empty);
            return;
        }

        foreach (var entry in entries)
        {
            list.Add(CreateAssetBrowserRow(entry, details));
        }
    }

    private List<StudioAssetBrowserEntry> ApplyAssetBrowserFilters(List<StudioAssetBrowserEntry> entries)
    {
        IEnumerable<StudioAssetBrowserEntry> query = entries;

        string filter = (_assetBrowserFilter ?? "all").ToLowerInvariant();
        if (filter == "missing")
        {
            query = query.Where(e => !e.exists);
        }
        else if (filter == "detected")
        {
            query = query.Where(e => string.Equals(e.origin, "detected", StringComparison.OrdinalIgnoreCase));
        }
        else if (filter != "all")
        {
            query = query.Where(e => string.Equals(e.assetType, filter, StringComparison.OrdinalIgnoreCase) || string.Equals(e.resourceKind, filter, StringComparison.OrdinalIgnoreCase));
        }

        if (!_assetBrowserShowMissing)
        {
            query = query.Where(e => e.exists);
        }

        string search = (_assetBrowserSearch ?? "").Trim().ToLowerInvariant();
        if (!string.IsNullOrEmpty(search))
        {
            query = query.Where(e =>
                (e.id ?? "").ToLowerInvariant().Contains(search) ||
                (e.displayName ?? "").ToLowerInvariant().Contains(search) ||
                (e.relativePath ?? "").ToLowerInvariant().Contains(search) ||
                (e.resourceLocation ?? "").ToLowerInvariant().Contains(search) ||
                (e.origin ?? "").ToLowerInvariant().Contains(search));
        }

        return query
            .OrderBy(e => e.exists ? 1 : 0)
            .ThenBy(e => e.assetType)
            .ThenBy(e => e.relativePath)
            .ToList();
    }

    private VisualElement CreateAssetBrowserRow(StudioAssetBrowserEntry entry, Label detailsLabel)
    {
        var row = new VisualElement();
        row.style.flexDirection = FlexDirection.Row;
        row.style.alignItems = Align.Center;
        row.style.paddingTop = 6;
        row.style.paddingBottom = 6;
        row.style.paddingLeft = 8;
        row.style.paddingRight = 8;
        row.style.marginBottom = 4;
        row.style.backgroundColor = new StyleColor(entry.exists ? new Color(0.14f, 0.15f, 0.16f, 1f) : new Color(0.23f, 0.12f, 0.10f, 1f));
        row.style.borderLeftWidth = 3;
        row.style.borderLeftColor = new StyleColor(entry.exists ? new Color(0.25f, 0.65f, 0.35f, 1f) : new Color(0.95f, 0.45f, 0.25f, 1f));

        var status = new Label(entry.exists ? "✓" : "!");
        status.style.width = 24;
        status.style.unityTextAlign = TextAnchor.MiddleCenter;
        status.style.color = new StyleColor(entry.exists ? new Color(0.45f, 1f, 0.55f) : new Color(1f, 0.62f, 0.35f));
        status.style.unityFontStyleAndWeight = FontStyle.Bold;
        row.Add(status);

        var main = new VisualElement();
        main.style.flexGrow = 1;

        var title = new Label($"{entry.GetIcon()} {entry.displayName}");
        title.style.color = new StyleColor(Color.white);
        title.style.unityFontStyleAndWeight = FontStyle.Bold;
        title.style.fontSize = 12;
        main.Add(title);

        var path = new Label(entry.relativePath);
        path.style.color = new StyleColor(new Color(0.68f, 0.68f, 0.68f));
        path.style.fontSize = 10;
        path.style.whiteSpace = WhiteSpace.NoWrap;
        main.Add(path);

        row.Add(main);

        var tag = new Label(entry.GetStatusText());
        tag.style.minWidth = 150;
        tag.style.unityTextAlign = TextAnchor.MiddleRight;
        tag.style.color = new StyleColor(new Color(0.78f, 0.78f, 0.78f));
        tag.style.fontSize = 10;
        row.Add(tag);

        row.RegisterCallback<ClickEvent>(_ =>
        {
            if (detailsLabel != null) detailsLabel.text = entry.FormatDetails();
            if (entry.exists && !string.IsNullOrEmpty(entry.absolutePath) && File.Exists(entry.absolutePath))
            {
                // One click details beradi, double click esa finderda ko'rsatadi.
            }
        });

        row.RegisterCallback<MouseDownEvent>(evt =>
        {
            if (evt.clickCount >= 2 && entry.exists && !string.IsNullOrEmpty(entry.absolutePath))
            {
                EditorUtility.RevealInFinder(entry.absolutePath);
            }
        });

        return row;
    }


    private void BindReleasePanelUI()
    {
        var root = rootVisualElement;
        var versionField = root.Q<TextField>("input-release-version");
        var refreshBtn = root.Q<Button>("btn-release-refresh");
        var docsBtn = root.Q<Button>("btn-release-generate-docs");
        var packageBtn = root.Q<Button>("btn-release-package");
        var openBtn = root.Q<Button>("btn-release-open");

        if (versionField != null)
        {
            versionField.value = string.IsNullOrWhiteSpace(_releaseVersion) ? "1.0.0" : _releaseVersion;
            versionField.RegisterValueChangedCallback(evt =>
            {
                if (_isUpdating) return;
                _releaseVersion = string.IsNullOrWhiteSpace(evt.newValue) ? "1.0.0" : evt.newValue.Trim();
                RefreshReleaseReport(false);
            });
        }

        if (refreshBtn != null) refreshBtn.clicked += () => RefreshReleaseReport(true);
        if (docsBtn != null) docsBtn.clicked += GenerateReleaseDocsFromStudio;
        if (packageBtn != null) packageBtn.clicked += CreateReleasePackageFromStudio;
        if (openBtn != null) openBtn.clicked += OpenReleasesFolder;

        RefreshReleaseReport(false);
    }

    private void RefreshReleaseReport(bool showDialog)
    {
        VerifyWorkspaceConsistency();
        _releaseReport = StudioReleaseManager.Analyze(WorkspaceManager.workspace, ProjectPath, _releaseVersion);
        RenderReleaseReport(_releaseReport);

        if (showDialog)
        {
            EditorUtility.DisplayDialog(
                "Release Gate",
                _releaseReport != null ? _releaseReport.FormatSummary() : "Release report topilmadi.",
                "OK"
            );
        }
    }

    private void GenerateReleaseDocsFromStudio()
    {
        try
        {
            EnsureProjectFolderExists();
            VerifyWorkspaceConsistency();
            _releaseReport = StudioReleaseManager.CreateMissingReleaseDocs(WorkspaceManager.workspace, ProjectPath, _releaseVersion);
            RenderReleaseReport(_releaseReport);
            LogToTerminal("[Release] README.md, CHANGELOG.md va LICENSE tekshirildi/yetishmasa yaratildi.");
            EditorUtility.DisplayDialog("Release Docs", "README.md, CHANGELOG.md va LICENSE tayyorlandi. Public release oldidan license matnini albatta ko'rib chiqing.", "OK");
        }
        catch (Exception ex)
        {
            LogToTerminal("[Release ERROR] " + ex.Message);
            EditorUtility.DisplayDialog("Release Docs xatosi", ex.Message, "OK");
        }
    }

    private void CreateReleasePackageFromStudio()
    {
        try
        {
            if (!ValidateBeforeBuildOrRun()) return;

            EnsureProjectFolderExists();
            WorkspaceManager.SaveWorkspace(ProjectPath);
            WorkspaceManager.CompileAndExportAll(ProjectPath);

            _releaseReport = StudioReleaseManager.CreateReleasePackage(WorkspaceManager.workspace, ProjectPath, _releaseVersion);
            RenderReleaseReport(_releaseReport);
            LogToTerminal(_releaseReport.FormatDetails());

            if (_releaseReport.HasBlockingIssues())
            {
                EditorUtility.DisplayDialog(
                    "Release Package to'xtatildi",
                    "Release gate failed. Asosiy sabab ko'pincha build/libs ichida .jar yo'qligi. Avval Build Jar tugmasini bosing.",
                    "OK"
                );
                return;
            }

            EditorUtility.DisplayDialog(
                "Release Package tayyor ✓",
                "Release zip yaratildi:\n" + _releaseReport.packagePath,
                "OK"
            );
        }
        catch (Exception ex)
        {
            LogToTerminal("[Release ERROR] " + ex.Message);
            EditorUtility.DisplayDialog("Release Package xatosi", ex.Message, "OK");
        }
    }

    private void OpenReleasesFolder()
    {
        EnsureProjectFolderExists();
        string releasesPath = Path.Combine(ProjectPath, ".modstudio", "releases");
        Directory.CreateDirectory(releasesPath);
        EditorUtility.RevealInFinder(releasesPath);
    }

    private void RenderReleaseReport(StudioReleaseReport report)
    {
        var root = rootVisualElement;
        var summary = root.Q<Label>("label-release-summary");
        var list = root.Q<ScrollView>("release-issues-list");
        var details = root.Q<Label>("label-release-details");

        if (summary != null)
        {
            summary.text = report != null ? report.FormatSummary() : "Release Gate: report topilmadi";
            bool failed = report != null && report.HasBlockingIssues();
            summary.style.backgroundColor = new StyleColor(failed ? new Color(0.32f, 0.12f, 0.10f, 1f) : new Color(0.10f, 0.25f, 0.14f, 1f));
        }

        if (details != null)
        {
            details.text = report != null ? report.FormatDetails() : "Release report topilmadi.";
        }

        if (list == null) return;
        list.Clear();

        if (report == null)
        {
            list.Add(new Label("Release report topilmadi."));
            return;
        }

        if (report.issues == null || report.issues.Count == 0)
        {
            var ok = new Label("✓ Blocking issue topilmadi. Release package yaratishga tayyor.");
            ok.style.color = new StyleColor(new Color(0.50f, 1f, 0.55f));
            ok.style.whiteSpace = WhiteSpace.Normal;
            ok.style.paddingBottom = 8;
            list.Add(ok);
        }
        else
        {
            foreach (var issue in report.issues)
            {
                list.Add(CreateReleaseIssueRow(issue, details));
            }
        }

        if (report.artifacts != null && report.artifacts.Count > 0)
        {
            var artifactTitle = new Label("\nArtifacts");
            artifactTitle.style.color = new StyleColor(new Color(0.61f, 0.80f, 1f));
            artifactTitle.style.unityFontStyleAndWeight = FontStyle.Bold;
            list.Add(artifactTitle);

            foreach (var artifact in report.artifacts)
            {
                list.Add(CreateReleaseArtifactRow(artifact, details));
            }
        }
    }

    private VisualElement CreateReleaseIssueRow(StudioReleaseIssue issue, Label detailsLabel)
    {
        var row = new VisualElement();
        row.style.paddingTop = 7;
        row.style.paddingBottom = 7;
        row.style.paddingLeft = 8;
        row.style.paddingRight = 8;
        row.style.marginBottom = 5;
        row.style.backgroundColor = new StyleColor(issue.IsError() ? new Color(0.25f, 0.10f, 0.09f, 1f) : new Color(0.24f, 0.20f, 0.10f, 1f));
        row.style.borderLeftWidth = 3;
        row.style.borderLeftColor = new StyleColor(issue.IsError() ? new Color(1f, 0.35f, 0.25f, 1f) : new Color(1f, 0.72f, 0.25f, 1f));

        var title = new Label($"{(issue.IsError() ? "❌" : "⚠️")} {issue.code}");
        title.style.color = new StyleColor(Color.white);
        title.style.unityFontStyleAndWeight = FontStyle.Bold;
        row.Add(title);

        var msg = new Label(issue.message);
        msg.style.color = new StyleColor(new Color(0.85f, 0.85f, 0.85f));
        msg.style.whiteSpace = WhiteSpace.Normal;
        row.Add(msg);

        row.RegisterCallback<ClickEvent>(_ =>
        {
            if (detailsLabel != null) detailsLabel.text = issue.Format();
        });

        return row;
    }

    private VisualElement CreateReleaseArtifactRow(StudioReleaseArtifact artifact, Label detailsLabel)
    {
        var row = new VisualElement();
        row.style.paddingTop = 6;
        row.style.paddingBottom = 6;
        row.style.paddingLeft = 8;
        row.style.paddingRight = 8;
        row.style.marginBottom = 4;
        row.style.backgroundColor = new StyleColor(new Color(0.13f, 0.15f, 0.17f, 1f));
        row.style.borderLeftWidth = 3;
        row.style.borderLeftColor = new StyleColor(new Color(0.34f, 0.58f, 0.95f, 1f));

        var title = new Label($"📦 {artifact.type}: {artifact.name} ({artifact.FormatSize()})");
        title.style.color = new StyleColor(Color.white);
        title.style.unityFontStyleAndWeight = FontStyle.Bold;
        row.Add(title);

        var path = new Label(artifact.relativePath);
        path.style.color = new StyleColor(new Color(0.68f, 0.68f, 0.68f));
        path.style.whiteSpace = WhiteSpace.NoWrap;
        row.Add(path);

        row.RegisterCallback<ClickEvent>(_ =>
        {
            if (detailsLabel != null) detailsLabel.text = artifact.Format();
        });

        row.RegisterCallback<MouseDownEvent>(evt =>
        {
            if (evt.clickCount >= 2 && !string.IsNullOrEmpty(artifact.absolutePath) && File.Exists(artifact.absolutePath))
            {
                EditorUtility.RevealInFinder(artifact.absolutePath);
            }
        });

        return row;
    }

    private void EnsureProjectFolderExists()
    {
        if (!Directory.Exists(ProjectPath)) Directory.CreateDirectory(ProjectPath);
    }

    private void UpdateProjectSettingsLabels()
    {
        var root = rootVisualElement;
        var javaLabel = root.Q<Label>("label-required-java");
        var changelogLabel = root.Q<Label>("label-changelog");
        
        var data = StudioDatabase.GetVersionData(WorkspaceManager.workspace.mcVersion);
        if (data != null)
        {
            if (javaLabel != null)
            {
                javaLabel.text = $"Java Versiyasi: Java {data.requiredJavaVersion}";
                javaLabel.style.color = data.requiredJavaVersion == 21 ? new Color(1f, 0.4f, 0.4f) : new Color(0f, 1f, 0f);
            }
            if (changelogLabel != null)
            {
                changelogLabel.text = data.versionChangelog;
            }
        }
    }

    private string GenerateFabricModJson()
    {
        var ws = WorkspaceManager.workspace;
        var data = StudioDatabase.GetVersionData(ws.mcVersion);
        int javaVer = data != null ? data.requiredJavaVersion : 17;
        
        return $@"{{
  ""schemaVersion"": 1,
  ""id"": ""{ws.modId}"",
  ""version"": ""1.0.0"",
  ""name"": ""{ws.modName}"",
  ""description"": ""A Minecraft mod generated using Mod Studio Desktop."",
  ""environment"": ""*"",
  ""depends"": {{
    ""fabricloader"": "">=0.15.0"",
    ""minecraft"": ""~{ws.mcVersion}"",
    ""java"": "">={javaVer}""
  }}
}}";
    }

    private void ExecuteTwoWaySync()
    {
        if (_isUpdating) return;

        if (_currentMode != EditorMode.Block)
        {
            LogToTerminal("[Eslatma] Ikki tomonlama sinxronizatsiya faqat Blok tahrirlovchi uchun qo'llab-quvvatlanadi.");
            return;
        }

        string userWrittenCode = _codePreviewField.value;
        if (string.IsNullOrEmpty(userWrittenCode)) return;

        _isUpdating = true;

        try
        {
            // Qo'lda yozilgan kodni tahlil qilib, modelni yangilaymiz
            JavaCodeParser.ParseJavaIntoModel(userWrittenCode, _currentBlock);
            
            // UI-ni yangilaymiz
            UpdateUiFromModel();

            // Kod oynasidagi rangli teglarni qayta chizamiz
            string rawJavaCode = JavaCodeGenerator.GenerateFabricBlockCode(_currentBlock);
            string highlightedCode = JavaSyntaxHighlighter.HighlightJavaCode(rawJavaCode);
            _codePreviewField.value = highlightedCode;
        }
        catch (Exception ex)
        {
            Debug.LogError($"[ModStudio] TwoWaySync xatolik: {ex.Message}");
            LogToTerminal($"[Xato] Sinxronizatsiya amalga oshmadi: {ex.Message}");
        }
        finally
        {
            _isUpdating = false;
        }
        
        LogToTerminal("[Muvaffaqiyat] Java kodi tahlil qilindi va barcha panellar sinxronlashtirildi.");
    }

    private void UpdateUiFromModel()
    {
        BindFieldsForMode(_currentMode);
    }

    private void OnModelChanged()
    {
        if (_codePreviewField == null) return;

        _isUpdating = true;

        try
        {
            string loader    = WorkspaceManager.workspace.modloader;
            string mcVersion = WorkspaceManager.workspace.mcVersion;
            string modId     = WorkspaceManager.workspace.modId;
            string rawCode   = "";

            switch (_currentMode)
            {
                case EditorMode.Block:
                    // Single-block live preview — always Fabric-style for simplicity
                    _currentBlock.textureNamespace = string.IsNullOrEmpty(modId) ? "mymod" : modId;
                    rawCode = JavaCodeGenerator.GenerateFabricBlockCode(_currentBlock);
                    break;
                case EditorMode.Item:
                    rawCode = _currentItem.GenerateFabricCode();
                    break;
                case EditorMode.Tool:
                    rawCode = _currentTool.GenerateFabricCode();
                    break;
                case EditorMode.Armor:
                    rawCode = _currentArmor.GenerateFabricCode();
                    break;
                case EditorMode.Recipe:
                    rawCode = _currentRecipe.GenerateFabricCode();
                    break;
                case EditorMode.LootTable:
                    rawCode = _currentLoot.GeneratePreview(modId);
                    break;
                case EditorMode.TagManager:
                    rawCode = _currentTag.GeneratePreview(modId);
                    break;
                case EditorMode.Mob:
                    rawCode = _currentEntity.GenerateFabricCode();
                    break;
                case EditorMode.Biome:
                    rawCode = _currentBiome.GenerateFabricCode();
                    break;
                case EditorMode.Dimension:
                    rawCode = _currentDimension.GenerateDimensionJson(modId) + "\n\n// dimension_type\n" + _currentDimension.GenerateDimensionTypeJson();
                    break;
                case EditorMode.Structure:
                    rawCode = _currentStructure.GenerateStructureJson(modId) + "\n\n// structure_set\n" + _currentStructure.GenerateStructureSetJson(modId);
                    break;
                case EditorMode.GuiScreen:
                    rawCode = _currentScreen.GeneratePreview();
                    break;
                case EditorMode.Config:
                    rawCode = _currentConfig.GenerateConfigText(modId);
                    break;
                case EditorMode.Networking:
                    rawCode = _currentNetworkPacket.GeneratePreview(modId);
                    break;
                case EditorMode.Keybind:
                    rawCode = _currentKeybind.GeneratePreview(modId);
                    break;
                case EditorMode.CreativeTab:
                    rawCode = _currentTab.GenerateFabricCode();
                    break;
                case EditorMode.TexturePainter:
                    rawCode = GenerateTextureManifestJson();
                    break;
                case EditorMode.ProjectSettings:
                    rawCode = GenerateFabricModJson();
                    break;
            }

            string highlighted = JavaSyntaxHighlighter.HighlightJavaCode(rawCode);
            _codePreviewField.value = highlighted;
            _codePreviewField.MarkDirtyRepaint();
        }
        catch (Exception ex)
        {
            Debug.LogError($"[ModStudio] OnModelChanged xatolik: {ex.Message}");
        }
        finally
        {
            _isUpdating = false;
        }
    }

    private string GenerateTextureManifestJson()
    {
        return $@"{{
  ""texture_name"": ""{_paintFilename}.png"",
  ""resolution"": ""16x16"",
  ""format"": ""PNG"",
  ""filter_mode"": ""Point"",
  ""compression"": ""None"",
  ""target_path"": ""Assets/Textures/{_paintFilename}.png""
}}";
    }

    private void LogToTerminal(string message)
    {
        rootVisualElement.schedule.Execute(() => {
            if (_terminalLogLabel != null)
            {
                _terminalLogLabel.text += $"\n[Gradle] {message}";
                var scroll = _terminalLogLabel.GetFirstAncestorOfType<ScrollView>();
                if (scroll != null) scroll.scrollOffset = new Vector2(0, _terminalLogLabel.layout.height);
            }
        });
    }

    private void ErrorToTerminal(string message)
    {
        rootVisualElement.schedule.Execute(() => {
            if (_terminalLogLabel != null)
            {
                _terminalLogLabel.text += $"\n<color=#FF3333>[XATO] {message}</color>";
            }
        });
    }

    private void OnDestroy()
    {
        if (_gradleCompiler != null) _gradleCompiler.StopProcess();
    }
}
