using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public class TextureToolkitProWindow : EditorWindow
{
    private TextureEditorToolSettings settings = new TextureEditorToolSettings();
    private TextureEditorAdvancedSettings advanced = new TextureEditorAdvancedSettings();
    private TextureCanvasState canvas = new TextureCanvasState(16, 16);
    private TextureUndoStack undo = new TextureUndoStack(80);
    private TextureAnimationProject animationProject = new TextureAnimationProject();
    private List<TextureBrushPreset> presets = new List<TextureBrushPreset>();
    private Texture2D previewTexture;
    private Vector2 scroll;
    private Vector2 rightScroll;
    private int selectedPresetIndex = 0;
    private Color32 primary = new Color32(139, 195, 74, 255);
    private Color32 secondary = new Color32(55, 55, 55, 255);
    private string validationText = "Validate bosilmagan.";
    private string status = "Texture Toolkit Pro tayyor.";

    [MenuItem("Mod Studio/Texture Toolkit Pro...", priority = 13)]
    [MenuItem("Tools/Mod Studio/Texture Toolkit Pro...", priority = 13)]
    public static void Open()
    {
        TextureToolkitProWindow window = GetWindow<TextureToolkitProWindow>();
        window.titleContent = new GUIContent("Texture Toolkit Pro");
        window.minSize = new Vector2(1120, 700);
        window.Show();
        window.Focus();
    }

    private void OnEnable()
    {
        if (settings == null) settings = new TextureEditorToolSettings();
        if (advanced == null) advanced = new TextureEditorAdvancedSettings();
        settings.ClampValues();
        advanced.ClampValues();
        if (canvas == null || canvas.layers == null || canvas.layers.Count == 0) canvas = new TextureCanvasState(settings.canvasWidth, settings.canvasHeight);
        presets = TextureBrushPresetLibrary.BuildDefaultPresets();
        animationProject.EnsureFrames(canvas, advanced.animationFrameTimeTicks);
        RebuildPreview();
    }

    private void OnDisable()
    {
        if (previewTexture != null) UnityEngine.Object.DestroyImmediate(previewTexture);
    }

    private void OnGUI()
    {
        DrawToolbar();
        EditorGUILayout.BeginHorizontal();
        DrawLeftPanel();
        DrawPreviewPanel();
        DrawRightPanel();
        EditorGUILayout.EndHorizontal();
        EditorGUILayout.HelpBox(status, MessageType.None);
    }

    private void DrawToolbar()
    {
        EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
        if (GUILayout.Button("New", EditorStyles.toolbarButton, GUILayout.Width(60))) NewCanvas();
        if (GUILayout.Button("Import PNG", EditorStyles.toolbarButton, GUILayout.Width(90))) ImportPng();
        if (GUILayout.Button("Export PNG", EditorStyles.toolbarButton, GUILayout.Width(90))) ExportPng();
        if (GUILayout.Button("Export Animation", EditorStyles.toolbarButton, GUILayout.Width(120))) ExportAnimation();
        if (GUILayout.Button("Undo", EditorStyles.toolbarButton, GUILayout.Width(60))) Undo();
        if (GUILayout.Button("Redo", EditorStyles.toolbarButton, GUILayout.Width(60))) Redo();
        GUILayout.FlexibleSpace();
        GUILayout.Label("Patch 25 - Brush Presets / Procedural / Animation / Validation", EditorStyles.miniLabel);
        EditorGUILayout.EndHorizontal();
    }

    private void DrawLeftPanel()
    {
        EditorGUILayout.BeginVertical(GUILayout.Width(320));
        scroll = EditorGUILayout.BeginScrollView(scroll);

        GUILayout.Label("Texture Identity", EditorStyles.boldLabel);
        settings.textureId = EditorGUILayout.TextField("Texture ID", settings.textureId);
        settings.displayName = EditorGUILayout.TextField("Display Name", settings.displayName);
        settings.targetType = (StudioTextureTargetType)EditorGUILayout.EnumPopup("Target", settings.targetType);
        settings.canvasWidth = EditorGUILayout.IntPopup("Width", settings.canvasWidth, new[] { "16", "32", "64", "128", "256" }, new[] { 16, 32, 64, 128, 256 });
        settings.canvasHeight = EditorGUILayout.IntPopup("Height", settings.canvasHeight, new[] { "16", "32", "64", "128", "256" }, new[] { 16, 32, 64, 128, 256 });
        settings.zoom = EditorGUILayout.IntSlider("Zoom", settings.zoom, 4, 48);
        if (GUILayout.Button("Resize / Reset Canvas")) NewCanvas();

        EditorGUILayout.Space(8);
        GUILayout.Label("Brush Presets", EditorStyles.boldLabel);
        string[] names = new string[presets.Count];
        for (int i = 0; i < names.Length; i++) names[i] = presets[i].displayName;
        selectedPresetIndex = EditorGUILayout.Popup("Preset", selectedPresetIndex, names);
        if (GUILayout.Button("Apply Preset") && presets.Count > 0)
        {
            presets[Mathf.Clamp(selectedPresetIndex, 0, presets.Count - 1)].ApplyTo(settings);
            primary = ParseColor(settings.selectedPrimaryColor, primary);
            secondary = ParseColor(settings.selectedSecondaryColor, secondary);
            status = "Brush preset qo‘llandi: " + presets[selectedPresetIndex].displayName;
        }

        settings.activeTool = (StudioTextureToolType)EditorGUILayout.EnumPopup("Tool", settings.activeTool);
        settings.brushShape = (StudioTextureBrushShape)EditorGUILayout.EnumPopup("Shape", settings.brushShape);
        settings.brushSize = EditorGUILayout.IntSlider("Brush Size", settings.brushSize, 1, 32);
        settings.opacity = EditorGUILayout.Slider("Opacity", settings.opacity, 0f, 1f);
        settings.toolStrength = EditorGUILayout.Slider("Strength", settings.toolStrength, 0f, 1f);
        settings.alphaLock = EditorGUILayout.Toggle("Alpha Lock", settings.alphaLock);
        settings.symmetryX = EditorGUILayout.Toggle("Symmetry X", settings.symmetryX);
        settings.symmetryY = EditorGUILayout.Toggle("Symmetry Y", settings.symmetryY);

        EditorGUILayout.Space(8);
        GUILayout.Label("Colors / Palette", EditorStyles.boldLabel);
        primary = EditorGUILayout.ColorField("Primary", primary);
        secondary = EditorGUILayout.ColorField("Secondary", secondary);
        settings.selectedPrimaryColor = ToHtml(primary);
        settings.selectedSecondaryColor = ToHtml(secondary);

        if (GUILayout.Button("Extract Palette From Texture"))
        {
            settings.paletteColors = TexturePaletteAnalyzer.ExtractTopColorHtml(canvas, advanced.maxPaletteColors, false);
            status = "Palette yangilandi: " + settings.paletteColors.Count + " rang.";
        }
        if (GUILayout.Button("Generate Value Ramp From Primary"))
        {
            List<Color32> ramp = TexturePaletteAnalyzer.GenerateRamp(primary, 8);
            settings.paletteColors = new List<string>();
            foreach (Color32 c in ramp) settings.paletteColors.Add(TexturePaletteAnalyzer.ToHtml(c));
            status = "Primary color asosida value ramp yaratildi.";
        }
        DrawPaletteButtons();

        EditorGUILayout.EndScrollView();
        EditorGUILayout.EndVertical();
    }

    private void DrawPreviewPanel()
    {
        EditorGUILayout.BeginVertical(GUILayout.ExpandWidth(true));
        GUILayout.Label("Canvas Preview", EditorStyles.boldLabel);
        settings.showGrid = EditorGUILayout.ToggleLeft("Show Grid", settings.showGrid, GUILayout.Width(120));
        RebuildPreview();
        int zoom = Mathf.Clamp(settings.zoom, 2, 64);
        Rect rect = GUILayoutUtility.GetRect(canvas.width * zoom, canvas.height * zoom, GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(false));
        DrawChecker(rect);
        if (previewTexture != null) GUI.DrawTexture(rect, previewTexture, ScaleMode.StretchToFill, true);
        if (settings.showGrid) DrawGrid(rect, canvas.width, canvas.height);
        HandleCanvasMouse(rect);
        EditorGUILayout.Space(8);
        EditorGUILayout.LabelField("Size", canvas.width + "x" + canvas.height + " | Layers: " + (canvas.layers == null ? 0 : canvas.layers.Count));
        EditorGUILayout.EndVertical();
    }

    private void DrawRightPanel()
    {
        EditorGUILayout.BeginVertical(GUILayout.Width(360));
        rightScroll = EditorGUILayout.BeginScrollView(rightScroll);

        GUILayout.Label("Procedural Generator", EditorStyles.boldLabel);
        advanced.proceduralPattern = (TextureProceduralPattern)EditorGUILayout.EnumPopup("Pattern", advanced.proceduralPattern);
        advanced.proceduralSeed = EditorGUILayout.IntField("Seed", advanced.proceduralSeed);
        advanced.proceduralStrength = EditorGUILayout.Slider("Strength", advanced.proceduralStrength, 0f, 1f);
        advanced.proceduralUseSecondaryColor = EditorGUILayout.Toggle("Use Secondary", advanced.proceduralUseSecondaryColor);
        if (GUILayout.Button("Apply Procedural To Active Layer")) ApplyProcedural();

        EditorGUILayout.Space(8);
        GUILayout.Label("Animation Frames", EditorStyles.boldLabel);
        animationProject.EnsureFrames(canvas, advanced.animationFrameTimeTicks);
        animationProject.animationId = EditorGUILayout.TextField("Animation ID", animationProject.animationId);
        advanced.animationLayout = (TextureAnimationLayout)EditorGUILayout.EnumPopup("Layout", advanced.animationLayout);
        advanced.animationFrameTimeTicks = EditorGUILayout.IntSlider("Default Ticks", advanced.animationFrameTimeTicks, 1, 40);
        advanced.animationGenerateMcmeta = EditorGUILayout.Toggle("Generate .mcmeta", advanced.animationGenerateMcmeta);
        animationProject.activeFrameIndex = EditorGUILayout.IntSlider("Active Frame", animationProject.activeFrameIndex, 0, Mathf.Max(0, animationProject.frames.Count - 1));
        if (GUILayout.Button("Add Current As New Frame"))
        {
            animationProject.AddFrameFrom(canvas, advanced.animationFrameTimeTicks);
            status = "Frame qo‘shildi.";
        }
        if (GUILayout.Button("Load Active Frame To Canvas"))
        {
            canvas = animationProject.ActiveFrame.canvas.Clone();
            status = "Active frame canvasga yuklandi.";
        }
        if (GUILayout.Button("Replace Active Frame From Canvas"))
        {
            animationProject.ActiveFrame.canvas = canvas.Clone();
            animationProject.ActiveFrame.frameTimeTicks = advanced.animationFrameTimeTicks;
            status = "Active frame yangilandi.";
        }
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Duplicate Frame")) animationProject.DuplicateActiveFrame();
        if (GUILayout.Button("Remove Frame")) animationProject.RemoveActiveFrame();
        EditorGUILayout.EndHorizontal();
        EditorGUILayout.LabelField("Frames", animationProject.frames.Count.ToString());

        EditorGUILayout.Space(8);
        GUILayout.Label("Validation", EditorStyles.boldLabel);
        advanced.maxPaletteColors = EditorGUILayout.IntSlider("Max Palette", advanced.maxPaletteColors, 2, 256);
        advanced.validatePowerOfTwo = EditorGUILayout.Toggle("Power-of-two", advanced.validatePowerOfTwo);
        advanced.validateMinecraftPath = EditorGUILayout.Toggle("MC path/id", advanced.validateMinecraftPath);
        advanced.validateTransparentPixels = EditorGUILayout.Toggle("Transparency", advanced.validateTransparentPixels);
        advanced.validatePaletteLimit = EditorGUILayout.Toggle("Palette limit", advanced.validatePaletteLimit);
        if (GUILayout.Button("Validate Texture")) ValidateTexture();
        EditorGUILayout.TextArea(validationText, GUILayout.MinHeight(180));

        EditorGUILayout.EndScrollView();
        EditorGUILayout.EndVertical();
    }

    private void ApplyProcedural()
    {
        undo.Push(canvas);
        Color32 second = advanced.proceduralUseSecondaryColor ? secondary : new Color32(255, 255, 255, primary.a);
        TextureProceduralGenerator.Fill(canvas, advanced.proceduralPattern, primary, second, advanced.proceduralSeed, advanced.proceduralStrength);
        RebuildPreview();
        status = "Procedural pattern qo‘llandi: " + advanced.proceduralPattern;
    }

    private void ValidateTexture()
    {
        TextureValidationReport report = TextureValidator.Validate(canvas, settings, advanced);
        validationText = report.Format();
        status = "Validation: " + report.ErrorCount + " error, " + report.WarningCount + " warning.";
    }

    private void ExportPng()
    {
        string path = EditorUtility.SaveFilePanel("Export PNG", Application.dataPath, settings.textureId + ".png", "png");
        if (string.IsNullOrEmpty(path)) return;
        if (TexturePngExporter.Export(canvas, path, settings.pixelPerfectExport, out string error))
        {
            if (settings.generateMcmeta) TexturePngExporter.ExportMcmeta(path, settings.frameTimeTicks, out error);
            status = "PNG export qilindi: " + path;
        }
        else status = "Export xato: " + error;
    }

    private void ExportAnimation()
    {
        animationProject.EnsureFrames(canvas, advanced.animationFrameTimeTicks);
        string path = EditorUtility.SaveFilePanel("Export Animated PNG Strip", Application.dataPath, animationProject.animationId + ".png", "png");
        if (string.IsNullOrEmpty(path)) return;
        if (TextureAnimationExporter.Export(animationProject, path, advanced.animationLayout, advanced.animationGenerateMcmeta, out string error))
            status = "Animation strip export qilindi: " + path;
        else status = "Animation export xato: " + error;
    }

    private void ImportPng()
    {
        string path = EditorUtility.OpenFilePanel("Import PNG", Application.dataPath, "png");
        if (string.IsNullOrEmpty(path)) return;
        byte[] bytes = File.ReadAllBytes(path);
        Texture2D tex = new Texture2D(2, 2, TextureFormat.RGBA32, false);
        if (!tex.LoadImage(bytes))
        {
            UnityEngine.Object.DestroyImmediate(tex);
            status = "PNG import bo‘lmadi.";
            return;
        }
        undo.Push(canvas);
        canvas = new TextureCanvasState(tex.width, tex.height);
        Color32[] pixels = tex.GetPixels32();
        canvas.ActiveLayer.pixels = pixels;
        settings.canvasWidth = tex.width;
        settings.canvasHeight = tex.height;
        UnityEngine.Object.DestroyImmediate(tex);
        RebuildPreview();
        status = "PNG import qilindi: " + path;
    }

    private void NewCanvas()
    {
        settings.ClampValues();
        undo.Push(canvas);
        canvas = new TextureCanvasState(settings.canvasWidth, settings.canvasHeight);
        RebuildPreview();
        status = "Yangi canvas yaratildi.";
    }

    private void Undo()
    {
        canvas = undo.Undo(canvas);
        RebuildPreview();
    }

    private void Redo()
    {
        canvas = undo.Redo(canvas);
        RebuildPreview();
    }

    private void HandleCanvasMouse(Rect rect)
    {
        Event e = Event.current;
        if (!rect.Contains(e.mousePosition)) return;
        if (e.type != EventType.MouseDown && e.type != EventType.MouseDrag) return;
        int x = Mathf.FloorToInt((e.mousePosition.x - rect.x) / rect.width * canvas.width);
        int y = Mathf.FloorToInt((e.mousePosition.y - rect.y) / rect.height * canvas.height);
        y = canvas.height - 1 - y;
        if (!canvas.IsInside(x, y)) return;
        if (e.type == EventType.MouseDown) undo.Push(canvas);
        TextureBrushEngine.ApplyTool(canvas, settings, new Vector2Int(x, y), new Vector2Int(x, y), e.button == 1 ? secondary : primary, secondary);
        RebuildPreview();
        e.Use();
        Repaint();
    }

    private void RebuildPreview()
    {
        if (previewTexture != null) UnityEngine.Object.DestroyImmediate(previewTexture);
        if (canvas == null) canvas = new TextureCanvasState(16, 16);
        previewTexture = canvas.ToTexture2D(FilterMode.Point);
    }

    private void DrawPaletteButtons()
    {
        if (settings.paletteColors == null) settings.paletteColors = new List<string>();
        int columns = 6;
        for (int i = 0; i < settings.paletteColors.Count; i++)
        {
            if (i % columns == 0) EditorGUILayout.BeginHorizontal();
            Color32 c = ParseColor(settings.paletteColors[i], new Color32(255, 255, 255, 255));
            Color old = GUI.backgroundColor;
            GUI.backgroundColor = c;
            if (GUILayout.Button("", GUILayout.Width(28), GUILayout.Height(22))) primary = c;
            GUI.backgroundColor = old;
            if (i % columns == columns - 1 || i == settings.paletteColors.Count - 1) EditorGUILayout.EndHorizontal();
        }
    }

    private void DrawChecker(Rect rect)
    {
        int cell = 8;
        Color a = new Color(0.22f, 0.22f, 0.22f, 1f);
        Color b = new Color(0.32f, 0.32f, 0.32f, 1f);
        for (float y = rect.y; y < rect.yMax; y += cell)
        {
            for (float x = rect.x; x < rect.xMax; x += cell)
            {
                bool odd = (((int)((x - rect.x) / cell) + (int)((y - rect.y) / cell)) % 2) == 0;
                EditorGUI.DrawRect(new Rect(x, y, cell, cell), odd ? a : b);
            }
        }
    }

    private void DrawGrid(Rect rect, int width, int height)
    {
        Handles.BeginGUI();
        Handles.color = new Color(0f, 0f, 0f, 0.35f);
        for (int x = 0; x <= width; x++)
        {
            float px = rect.x + rect.width * x / width;
            Handles.DrawLine(new Vector3(px, rect.y), new Vector3(px, rect.yMax));
        }
        for (int y = 0; y <= height; y++)
        {
            float py = rect.y + rect.height * y / height;
            Handles.DrawLine(new Vector3(rect.x, py), new Vector3(rect.xMax, py));
        }
        Handles.EndGUI();
    }

    private static Color32 ParseColor(string html, Color32 fallback)
    {
        if (string.IsNullOrWhiteSpace(html)) return fallback;
        if (ColorUtility.TryParseHtmlString(html, out Color c)) return c;
        return fallback;
    }

    private static string ToHtml(Color32 c)
    {
        return "#" + c.r.ToString("X2") + c.g.ToString("X2") + c.b.ToString("X2") + c.a.ToString("X2");
    }
}
