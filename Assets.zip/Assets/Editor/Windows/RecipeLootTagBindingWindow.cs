#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEngine;

public class RecipeLootTagBindingWindow : EditorWindow
{
    private string projectRoot = string.Empty;
    private string modId = "mymod";
    private Vector2 scroll;
    private string reportText = "Click Load Workspace, then Validate or Generate.";
    private object workspace;

    [MenuItem("Mod Studio/Recipe Loot Tag Binding Generator...")]
    public static void Open()
    {
        GetWindow<RecipeLootTagBindingWindow>("Recipe/Loot/Tag Binding");
    }

    [MenuItem("Tools/Mod Studio/Recipe Loot Tag Binding Generator...")]
    public static void OpenFromTools()
    {
        Open();
    }

    private void OnEnable()
    {
        TryLoadWorkspace();
        TryAutofillProjectRoot();
        TryAutofillModId();
    }

    private void OnGUI()
    {
        EditorGUILayout.LabelField("Recipe / Loot / Tag Real Binding", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox("Bu tool Recipe Pro, Loot Table va Tag fieldlarini DataModel + Generator + Validator + Binding manifest zanjiriga ulaydi.", MessageType.Info);

        using (new EditorGUILayout.VerticalScope("box"))
        {
            EditorGUILayout.LabelField("Project", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                projectRoot = EditorGUILayout.TextField("Project Root", projectRoot);
                if (GUILayout.Button("Browse", GUILayout.Width(80)))
                {
                    string selected = EditorUtility.OpenFolderPanel("Select exported Minecraft project root", string.IsNullOrEmpty(projectRoot) ? Application.dataPath : projectRoot, string.Empty);
                    if (!string.IsNullOrEmpty(selected)) projectRoot = selected;
                }
            }
            modId = EditorGUILayout.TextField("Mod ID", modId);
        }

        using (new EditorGUILayout.HorizontalScope())
        {
            if (GUILayout.Button("Load Workspace", GUILayout.Height(28))) TryLoadWorkspace();
            if (GUILayout.Button("Validate", GUILayout.Height(28))) Validate();
            if (GUILayout.Button("Generate Binding", GUILayout.Height(28))) Generate();
        }

        using (new EditorGUILayout.HorizontalScope())
        {
            if (GUILayout.Button("Open Project", GUILayout.Height(24))) OpenFolder(projectRoot);
            if (GUILayout.Button("Open Report", GUILayout.Height(24))) OpenFolder(Path.Combine(projectRoot, ".modstudio/reports"));
            if (GUILayout.Button("Export Field Catalog", GUILayout.Height(24))) ExportFieldCatalog();
        }

        EditorGUILayout.Space();
        EditorGUILayout.LabelField("Report", EditorStyles.boldLabel);
        scroll = EditorGUILayout.BeginScrollView(scroll);
        EditorGUILayout.TextArea(reportText, GUILayout.ExpandHeight(true));
        EditorGUILayout.EndScrollView();
    }

    private void TryLoadWorkspace()
    {
        workspace = GetStaticMember("WorkspaceManager", "workspace");
        if (workspace != null)
        {
            reportText = "Workspace loaded from WorkspaceManager.workspace";
            TryAutofillModId();
        }
        else
        {
            reportText = "WorkspaceManager.workspace not found. Generate can still export manifests, but no recipes/loot/tags will be generated.";
        }
    }

    private void TryAutofillProjectRoot()
    {
        object pathObj = GetStaticMember("WorkspaceManager", "ProjectPath");
        string path = pathObj as string;
        if (!string.IsNullOrEmpty(path))
        {
            projectRoot = path;
            return;
        }

        object currentPathObj = GetStaticMember("WorkspaceManager", "currentProjectPath");
        string currentPath = currentPathObj as string;
        if (!string.IsNullOrEmpty(currentPath)) projectRoot = currentPath;
    }

    private void TryAutofillModId()
    {
        if (workspace == null) return;
        string fromWorkspace = RecipeLootTagBindingUtility.GetString(workspace, "modId", null);
        if (!string.IsNullOrEmpty(fromWorkspace))
        {
            modId = fromWorkspace;
            return;
        }

        object projectSettings = RecipeLootTagBindingUtility.GetMemberValue(workspace, "project");
        string fromProject = RecipeLootTagBindingUtility.GetString(projectSettings, "modId", null);
        if (!string.IsNullOrEmpty(fromProject)) modId = fromProject;
    }

    private void Validate()
    {
        TryLoadWorkspace();
        List<string> issues = RecipeLootTagBindingValidator.Validate(workspace);
        if (issues.Count == 0)
        {
            reportText = "Recipe/Loot/Tag validation passed. No serious binding issue found.";
            return;
        }

        reportText = "Recipe/Loot/Tag validation issues:\n";
        for (int i = 0; i < issues.Count; i++)
            reportText += "- " + issues[i] + "\n";
    }

    private void Generate()
    {
        TryLoadWorkspace();
        if (string.IsNullOrEmpty(projectRoot))
        {
            EditorUtility.DisplayDialog("Project root kerak", "Avval exported Minecraft project root tanlang.", "OK");
            return;
        }

        RecipeLootTagBindingReport report = RecipeLootTagBindingGenerator.Generate(workspace, projectRoot, modId);
        RecipeLootTagFieldBindingCatalog.Export(projectRoot, modId);
        reportText = report.Format();
        AssetDatabase.Refresh();
    }

    private void ExportFieldCatalog()
    {
        if (string.IsNullOrEmpty(projectRoot))
        {
            EditorUtility.DisplayDialog("Project root kerak", "Avval project root tanlang.", "OK");
            return;
        }
        RecipeLootTagFieldBindingCatalog.Export(projectRoot, modId);
        reportText = "Field binding catalog exported to .modstudio/field-bindings/recipe-loot-tag-field-catalog.json";
    }

    private static void OpenFolder(string path)
    {
        if (string.IsNullOrEmpty(path) || !Directory.Exists(path)) return;
        EditorUtility.RevealInFinder(path);
    }

    private static object GetStaticMember(string typeName, string memberName)
    {
        Type type = FindType(typeName);
        if (type == null) return null;
        const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;
        FieldInfo field = type.GetField(memberName, flags);
        if (field != null) return field.GetValue(null);
        PropertyInfo prop = type.GetProperty(memberName, flags);
        if (prop != null && prop.GetIndexParameters().Length == 0) return prop.GetValue(null, null);
        return null;
    }

    private static Type FindType(string name)
    {
        Type direct = Type.GetType(name);
        if (direct != null) return direct;
        Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
        for (int i = 0; i < assemblies.Length; i++)
        {
            Type type = assemblies[i].GetType(name);
            if (type != null) return type;
        }
        return null;
    }
}
#endif
