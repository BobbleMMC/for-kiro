using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public class FieldBindingReportWindow : EditorWindow
{
    private Vector2 _scroll;
    private string _search = string.Empty;
    private string _projectRoot = string.Empty;
    private StudioFieldBindingReport _report;

    [MenuItem("Mod Studio/Field Binding Report...", priority = 45)]
    [MenuItem("Tools/Mod Studio/Field Binding Report...", priority = 45)]
    public static void Open()
    {
        FieldBindingReportWindow window = GetWindow<FieldBindingReportWindow>();
        window.titleContent = new GUIContent("Field Binding");
        window.minSize = new Vector2(820, 560);
        window.Refresh();
        window.Show();
    }

    private void OnEnable()
    {
        if (string.IsNullOrEmpty(_projectRoot)) _projectRoot = Directory.GetParent(Application.dataPath).FullName;
        Refresh();
    }

    private void Refresh()
    {
        StudioFieldRegistry.EnsureInitialized();
        _report = StudioFieldRegistry.ValidateRegistry();
    }

    private void OnGUI()
    {
        if (_report == null) Refresh();

        EditorGUILayout.Space(8);
        EditorGUILayout.LabelField("Mod Studio Field Binding Core", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox("Har bir setting DataModel + UI + Generator/PatchEngine + Validator zanjiriga bog'langan bo'lishi kerak. Bu oynada field coverage tekshiriladi va manifest export qilinadi.", MessageType.Info);

        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Refresh", GUILayout.Width(100))) Refresh();
        if (GUILayout.Button("Export Manifest", GUILayout.Width(140))) ExportManifest();
        if (GUILayout.Button("Select Project Root", GUILayout.Width(150))) SelectProjectRoot();
        GUILayout.Label(_projectRoot, EditorStyles.miniLabel);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space(6);
        _search = EditorGUILayout.TextField("Search", _search);

        EditorGUILayout.Space(8);
        DrawSummary();

        EditorGUILayout.Space(8);
        _scroll = EditorGUILayout.BeginScrollView(_scroll);
        DrawIssues();
        DrawFields();
        EditorGUILayout.EndScrollView();
    }

    private void DrawSummary()
    {
        EditorGUILayout.BeginVertical("box");
        EditorGUILayout.LabelField("Summary", EditorStyles.boldLabel);
        EditorGUILayout.LabelField("Total fields", _report.totalFields.ToString());
        EditorGUILayout.LabelField("Connected fields", _report.connectedFields.ToString());
        EditorGUILayout.LabelField("Incomplete fields", _report.incompleteFields.ToString());
        EditorGUILayout.EndVertical();
    }

    private void DrawIssues()
    {
        if (_report.issues == null || _report.issues.Count == 0)
        {
            EditorGUILayout.HelpBox("Registry coverage OK: duplicate yoki incomplete binding topilmadi.", MessageType.Info);
            return;
        }

        EditorGUILayout.BeginVertical("box");
        EditorGUILayout.LabelField("Issues", EditorStyles.boldLabel);
        foreach (string issue in _report.issues)
        {
            EditorGUILayout.HelpBox(issue, MessageType.Warning);
        }
        EditorGUILayout.EndVertical();
        EditorGUILayout.Space(6);
    }

    private void DrawFields()
    {
        IReadOnlyList<StudioFieldBinding> fields = StudioFieldRegistry.All;
        foreach (StudioFieldBinding field in fields)
        {
            if (!MatchesSearch(field)) continue;
            EditorGUILayout.BeginVertical("box");
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(field.id, EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();
            GUILayout.Label(field.IsFullyConnected() ? "CONNECTED" : "INCOMPLETE", EditorStyles.miniBoldLabel);
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.LabelField("Label", field.label);
            EditorGUILayout.LabelField("Feature", field.featureType + " / " + field.editorPage);
            EditorGUILayout.LabelField("DataModel", field.dataPath);
            EditorGUILayout.LabelField("UI", field.uiType + " | default: " + field.defaultValue);
            EditorGUILayout.LabelField("Description", field.description, EditorStyles.wordWrappedMiniLabel);

            DrawRuleList("Generator/PatchEngine", field.generatorRules);
            DrawPatchList("Patch Rules", field.patchRules);
            DrawValidationList("Validator", field.validationRules);
            EditorGUILayout.EndVertical();
        }
    }

    private void DrawRuleList(string label, List<StudioFieldGeneratorRule> rules)
    {
        EditorGUILayout.LabelField(label, EditorStyles.miniBoldLabel);
        if (rules == null || rules.Count == 0)
        {
            EditorGUILayout.LabelField("- yo'q", EditorStyles.miniLabel);
            return;
        }
        foreach (StudioFieldGeneratorRule rule in rules)
        {
            EditorGUILayout.LabelField("- " + rule.target + " [" + rule.outputKind + "] " + rule.description, EditorStyles.wordWrappedMiniLabel);
        }
    }

    private void DrawPatchList(string label, List<StudioFieldPatchRule> rules)
    {
        if (rules == null || rules.Count == 0) return;
        EditorGUILayout.LabelField(label, EditorStyles.miniBoldLabel);
        foreach (StudioFieldPatchRule rule in rules)
        {
            EditorGUILayout.LabelField("- " + rule.targetFile + " [" + rule.mergeStrategy + "] " + rule.description, EditorStyles.wordWrappedMiniLabel);
        }
    }

    private void DrawValidationList(string label, List<StudioFieldValidationRule> rules)
    {
        EditorGUILayout.LabelField(label, EditorStyles.miniBoldLabel);
        if (rules == null || rules.Count == 0)
        {
            EditorGUILayout.LabelField("- yo'q", EditorStyles.miniLabel);
            return;
        }
        foreach (StudioFieldValidationRule rule in rules)
        {
            EditorGUILayout.LabelField("- " + rule.id + " [" + rule.severity + "] " + rule.description, EditorStyles.wordWrappedMiniLabel);
        }
    }

    private bool MatchesSearch(StudioFieldBinding field)
    {
        if (string.IsNullOrWhiteSpace(_search)) return true;
        string s = _search.ToLowerInvariant();
        return (field.id != null && field.id.ToLowerInvariant().Contains(s))
            || (field.label != null && field.label.ToLowerInvariant().Contains(s))
            || (field.featureType != null && field.featureType.ToLowerInvariant().Contains(s))
            || (field.dataPath != null && field.dataPath.ToLowerInvariant().Contains(s));
    }

    private void ExportManifest()
    {
        if (string.IsNullOrEmpty(_projectRoot)) _projectRoot = Directory.GetParent(Application.dataPath).FullName;
        string path = StudioFieldBindingExporter.ExportManifest(_projectRoot);
        EditorUtility.DisplayDialog("Field Binding Manifest", "Manifest yozildi:\n" + path, "OK");
        Debug.Log("[FieldBinding] Manifest yozildi: " + path);
    }

    private void SelectProjectRoot()
    {
        string selected = EditorUtility.OpenFolderPanel("Minecraft mod project root tanlang", _projectRoot, "");
        if (!string.IsNullOrEmpty(selected)) _projectRoot = selected;
    }
}
