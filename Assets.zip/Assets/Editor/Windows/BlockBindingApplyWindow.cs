using System;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

public class BlockBindingApplyWindow : EditorWindow
{
    private TextField _projectRootField;
    private Toggle _overwriteToggle;
    private Toggle _backupToggle;
    private TextField _reportField;
    private WorkspaceData _workspace;

    [MenuItem("Mod Studio/Block Binding Generator...")]
    public static void Open()
    {
        BlockBindingApplyWindow window = GetWindow<BlockBindingApplyWindow>("Block Binding");
        window.minSize = new Vector2(720, 520);
    }

    [MenuItem("Tools/Mod Studio/Block Binding Generator...")]
    public static void OpenTools()
    {
        Open();
    }

    private void CreateGUI()
    {
        rootVisualElement.style.paddingLeft = 10;
        rootVisualElement.style.paddingRight = 10;
        rootVisualElement.style.paddingTop = 10;
        rootVisualElement.style.paddingBottom = 10;

        Label title = new Label("Block Real Binding Generator");
        title.style.unityFontStyleAndWeight = FontStyle.Bold;
        title.style.fontSize = 16;
        title.style.marginBottom = 8;
        rootVisualElement.Add(title);

        Label help = new Label("Block fieldlari endi 4 joyga ulanadi: DataModel + UI + Generator/PatchEngine + Validator. Bu oynada waterlogged/light/transparent/requiresTool/blockEntity kabi block settinglar real JSON/tag/java-stub outputga chiqariladi.");
        help.style.whiteSpace = WhiteSpace.Normal;
        help.style.marginBottom = 8;
        help.style.backgroundColor = new Color(0.13f, 0.16f, 0.2f);
        help.style.paddingLeft = 8;
        help.style.paddingRight = 8;
        help.style.paddingTop = 6;
        help.style.paddingBottom = 6;
        rootVisualElement.Add(help);

        VisualElement row = new VisualElement();
        row.style.flexDirection = FlexDirection.Row;
        row.style.marginBottom = 6;
        _projectRootField = new TextField("Minecraft project root");
        _projectRootField.style.flexGrow = 1;
        _projectRootField.value = GuessProjectRoot();
        row.Add(_projectRootField);
        Button browse = new Button(BrowseProjectRoot) { text = "Browse" };
        browse.style.width = 90;
        row.Add(browse);
        rootVisualElement.Add(row);

        _overwriteToggle = new Toggle("Overwrite existing generated files") { value = true };
        _backupToggle = new Toggle("Backup before overwrite") { value = true };
        rootVisualElement.Add(_overwriteToggle);
        rootVisualElement.Add(_backupToggle);

        VisualElement buttons = new VisualElement();
        buttons.style.flexDirection = FlexDirection.Row;
        buttons.style.marginTop = 8;
        buttons.style.marginBottom = 8;
        buttons.Add(new Button(LoadWorkspace) { text = "Load Workspace" });
        buttons.Add(new Button(ValidateBlocks) { text = "Validate Blocks" });
        buttons.Add(new Button(GenerateBlocks) { text = "Generate Block Binding" });
        buttons.Add(new Button(OpenProjectRoot) { text = "Open Project" });
        rootVisualElement.Add(buttons);

        _reportField = new TextField("Report");
        _reportField.multiline = true;
        _reportField.isReadOnly = true;
        _reportField.style.flexGrow = 1;
        _reportField.style.minHeight = 340;
        rootVisualElement.Add(_reportField);

        LoadWorkspace();
    }

    private string GuessProjectRoot()
    {
        string pref = EditorPrefs.GetString("ModStudio.ProjectPath", string.Empty);
        if (!string.IsNullOrEmpty(pref) && Directory.Exists(pref)) return pref;
        string docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        string defaultPath = Path.Combine(docs, "MinecraftMods", "MyMod");
        return defaultPath;
    }

    private void BrowseProjectRoot()
    {
        string selected = EditorUtility.OpenFolderPanel("Minecraft project root", _projectRootField.value, "");
        if (!string.IsNullOrEmpty(selected))
        {
            _projectRootField.value = selected;
            EditorPrefs.SetString("ModStudio.ProjectPath", selected);
        }
    }

    private void LoadWorkspace()
    {
        _workspace = TryGetWorkspaceFromModStudio();
        if (_workspace == null)
        {
            _workspace = TryLoadWorkspaceFromProjectRoot(_projectRootField.value);
        }

        if (_workspace == null)
        {
            _reportField.value = "Workspace topilmadi. Avval Mod Studio oynasida loyiha oching yoki project.mstudio/studio.project.json mavjud project root tanlang.";
            return;
        }

        int count = _workspace.blocks == null ? 0 : _workspace.blocks.Count;
        _reportField.value = "Workspace loaded. ModId=" + _workspace.modId + " | Loader=" + _workspace.modloader + " | Blocks=" + count;
    }

    private WorkspaceData TryGetWorkspaceFromModStudio()
    {
        try
        {
            Type wm = Type.GetType("WorkspaceManager");
            if (wm == null) return null;
            FieldInfo field = wm.GetField("workspace", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (field != null) return field.GetValue(null) as WorkspaceData;
            PropertyInfo prop = wm.GetProperty("workspace", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
            if (prop != null) return prop.GetValue(null, null) as WorkspaceData;
        }
        catch { }
        return null;
    }

    private WorkspaceData TryLoadWorkspaceFromProjectRoot(string root)
    {
        if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) return null;
        // To avoid breaking compile with unknown loader signatures, this window only reads live WorkspaceManager.
        // If not available, user can open project in Mod Studio first.
        return null;
    }

    private void ValidateBlocks()
    {
        if (_workspace == null) LoadWorkspace();
        BlockBoundGenerationReport report = BlockBindingValidator.ValidateWorkspace(_workspace, _projectRootField.value);
        _reportField.value = report.Format();
    }

    private void GenerateBlocks()
    {
        if (_workspace == null) LoadWorkspace();
        if (_workspace == null)
        {
            EditorUtility.DisplayDialog("Workspace yo'q", "Avval workspace yuklang.", "OK");
            return;
        }
        string root = _projectRootField.value;
        if (string.IsNullOrEmpty(root))
        {
            EditorUtility.DisplayDialog("Project root kerak", "Minecraft project root tanlang.", "OK");
            return;
        }
        try
        {
            BlockBoundGenerationReport report = BlockBindingGenerator.GenerateWorkspace(_workspace, root, _overwriteToggle.value, _backupToggle.value);
            _reportField.value = report.Format();
            EditorUtility.DisplayDialog(report.HasErrors() ? "Block binding xatolari bor" : "Block binding tayyor", report.HasErrors() ? "Reportni tekshiring." : "Block files, tags, blockstate/model/lang va java stublar yaratildi.", "OK");
        }
        catch (Exception ex)
        {
            _reportField.value = ex.ToString();
            EditorUtility.DisplayDialog("Block binding failed", ex.Message, "OK");
        }
    }

    private void OpenProjectRoot()
    {
        string root = _projectRootField.value;
        if (!string.IsNullOrEmpty(root) && Directory.Exists(root)) EditorUtility.RevealInFinder(root);
    }
}
