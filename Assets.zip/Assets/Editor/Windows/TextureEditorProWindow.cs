using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public class TextureEditorProWindow : EditorWindow
{
    private const string EditorPrefsProjectPathKey = "ModStudio.TextureEditor.MinecraftProjectPath";
    private const string EditorPrefsModIdKey = "ModStudio.TextureEditor.OverrideModId";

    private TextureEditorToolSettings settings = new TextureEditorToolSettings();
    private TextureCanvasState canvas = new TextureCanvasState(16, 16);
    private TextureUndoStack undoStack = new TextureUndoStack(80);
    private Texture2D previewTexture;
    private Vector2 scroll;
    private Vector2Int dragStart;
    private Vector2Int lastPixel;
    private bool isDragging;
    private Color32 primary = new Color32(139, 195, 74, 255);
    private Color32 secondary = new Color32(0, 0, 0, 0);
    private string status = "Texture Editor Pro tayyor.";
    private string lastExportReport = string.Empty;

    [MenuItem("Mod Studio/Texture Editor Pro...", priority = 12)]
    [MenuItem("Tools/Mod Studio/Texture Editor Pro...", priority = 12)]
    public static void Open()
    {
        TextureEditorProWindow window = GetWindow<TextureEditorProWindow>();
        window.titleContent = new GUIContent("Texture Editor Pro");
        window.minSize = new Vector2(1060, 680);
        window.Show();
        window.Focus();
    }

    private void OnEnable()
    {
        settings.ClampValues();
        settings.minecraftProjectPath = EditorPrefs.GetString(EditorPrefsProjectPathKey, settings.minecraftProjectPath);
        settings.overrideModId = EditorPrefs.GetString(EditorPrefsModIdKey, settings.overrideModId);

        if (canvas == null || canvas.layers == null || canvas.layers.Count == 0)
        {
            canvas = new TextureCanvasState(settings.canvasWidth, settings.canvasHeight);
        }
        RebuildPreview();
    }

    private void OnDisable()
    {
        SaveEditorPrefs();
        if (previewTexture != null) DestroyImmediate(previewTexture);
    }

    private void OnGUI()
    {
        DrawHeader();
        EditorGUILayout.Space(4);
        EditorGUILayout.BeginHorizontal();
        DrawLeftPanel();
        DrawCanvasPanel();
        DrawRightPanel();
        EditorGUILayout.EndHorizontal();
        DrawFooter();
    }

    private void DrawHeader()
    {
        EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
        if (GUILayout.Button("New", EditorStyles.toolbarButton, GUILayout.Width(56))) NewCanvas();
        if (GUILayout.Button("Import PNG", EditorStyles.toolbarButton, GUILayout.Width(92))) ImportPng();
        if (GUILayout.Button("Export Manual", EditorStyles.toolbarButton, GUILayout.Width(100))) ExportPngManual();
        if (GUILayout.Button("Export Unity", EditorStyles.toolbarButton, GUILayout.Width(92))) ExportToUnityAssets();
        if (GUILayout.Button("Export MC", EditorStyles.toolbarButton, GUILayout.Width(82))) ExportToMinecraftProject();
        if (GUILayout.Button("Export Both", EditorStyles.toolbarButton, GUILayout.Width(92))) ExportBoth();
        if (GUILayout.Button("Undo", EditorStyles.toolbarButton, GUILayout.Width(60))) Undo();
        if (GUILayout.Button("Redo", EditorStyles.toolbarButton, GUILayout.Width(60))) Redo();
        GUILayout.FlexibleSpace();
        GUILayout.Label("Texture Editor Pro - Patch 22", EditorStyles.miniLabel);
        EditorGUILayout.EndHorizontal();
    }

    private void DrawLeftPanel()
    {
        EditorGUILayout.BeginVertical(GUILayout.Width(300));
        GUILayout.Label("Canvas / Export", EditorStyles.boldLabel);
        settings.textureId = EditorGUILayout.TextField("Texture ID", settings.textureId);
        settings.displayName = EditorGUILayout.TextField("Display Name", settings.displayName);
        settings.langKey = EditorGUILayout.TextField("Lang Key", settings.langKey);
        settings.targetType = (StudioTextureTargetType)EditorGUILayout.EnumPopup("Target", settings.targetType);

        EditorGUI.BeginChangeCheck();
        settings.canvasWidth = EditorGUILayout.IntPopup("Width", settings.canvasWidth, new[] { "16", "32", "64", "128", "256" }, new[] { 16, 32, 64, 128, 256 });
        settings.canvasHeight = EditorGUILayout.IntPopup("Height", settings.canvasHeight, new[] { "16", "32", "64", "128", "256" }, new[] { 16, 32, 64, 128, 256 });
        if (EditorGUI.EndChangeCheck())
        {
            if (EditorUtility.DisplayDialog("Canvas resize", "Canvas qayta yaratiladi. Davom etilsinmi?", "Ha", "Yo‘q")) NewCanvas();
        }

        settings.zoom = EditorGUILayout.IntSlider("Zoom", settings.zoom, 4, 48);
        settings.exportPath = EditorGUILayout.TextField("MC Texture Path", settings.exportPath);
        if (GUILayout.Button("Auto MC Texture Path"))
        {
            settings.AutoUpdateExportPath();
        }

        EditorGUILayout.Space(8);
        GUILayout.Label("Workspace Sync", EditorStyles.boldLabel);
        settings.exportToUnityAssets = EditorGUILayout.Toggle("Export to Unity Assets", settings.exportToUnityAssets);
        settings.exportToMinecraftResources = EditorGUILayout.Toggle("Export to MC Resources", settings.exportToMinecraftResources);
        settings.writeTextureManifest = EditorGUILayout.Toggle("Write Manifest", settings.writeTextureManifest);
        settings.openFolderAfterExport = EditorGUILayout.Toggle("Open Folder After Export", settings.openFolderAfterExport);
        settings.overrideModId = EditorGUILayout.TextField("Override Mod ID", settings.overrideModId);

        EditorGUILayout.BeginHorizontal();
        settings.minecraftProjectPath = EditorGUILayout.TextField("MC Project", settings.minecraftProjectPath);
        if (GUILayout.Button("...", GUILayout.Width(28))) BrowseMinecraftProject();
        EditorGUILayout.EndHorizontal();

        if (GUILayout.Button("Use Workspace Mod ID"))
        {
            settings.overrideModId = TextureWorkspaceBridge.GetWorkspaceModId("mymod");
        }

        EditorGUILayout.HelpBox("Unity path: " + TextureWorkspaceBridge.GetUnityTextureRelativePath(settings) + "\nMC path: src/main/resources/assets/<modid>/" + TextureWorkspaceBridge.GetMinecraftTextureRelativePath(settings), MessageType.None);

        EditorGUILayout.Space(8);
        GUILayout.Label("Toolbox", EditorStyles.boldLabel);
        settings.activeTool = (StudioTextureToolType)EditorGUILayout.EnumPopup("Tool", settings.activeTool);
        settings.brushShape = (StudioTextureBrushShape)EditorGUILayout.EnumPopup("Brush Shape", settings.brushShape);
        settings.brushSize = EditorGUILayout.IntSlider("Brush Size", settings.brushSize, 1, 32);
        settings.opacity = EditorGUILayout.Slider("Opacity", settings.opacity, 0f, 1f);
        settings.toolStrength = EditorGUILayout.Slider("Strength", settings.toolStrength, 0f, 1f);
        settings.alphaLock = EditorGUILayout.Toggle("Alpha Lock", settings.alphaLock);
        settings.symmetryX = EditorGUILayout.Toggle("Symmetry X", settings.symmetryX);
        settings.symmetryY = EditorGUILayout.Toggle("Symmetry Y", settings.symmetryY);

        EditorGUILayout.Space(8);
        GUILayout.Label("Colors", EditorStyles.boldLabel);
        primary = EditorGUILayout.ColorField("Primary", primary);
        secondary = EditorGUILayout.ColorField("Secondary", secondary);
        settings.selectedPrimaryColor = TexturePaletteUtility.ToHtml(primary);
        settings.selectedSecondaryColor = TexturePaletteUtility.ToHtml(secondary);

        DrawPaletteButtons();
        EditorGUILayout.EndVertical();
    }

    private void DrawCanvasPanel()
    {
        EditorGUILayout.BeginVertical(GUILayout.ExpandWidth(true));
        GUILayout.Label("Canvas", EditorStyles.boldLabel);
        EditorGUILayout.BeginHorizontal();
        settings.showGrid = EditorGUILayout.ToggleLeft("Show Grid", settings.showGrid, GUILayout.Width(100));
        settings.showCheckerboard = EditorGUILayout.ToggleLeft("Checkerboard", settings.showCheckerboard, GUILayout.Width(120));
        settings.tilePreview = EditorGUILayout.ToggleLeft("Tile Preview", settings.tilePreview, GUILayout.Width(110));
        EditorGUILayout.EndHorizontal();

        Rect canvasRect = GUILayoutUtility.GetRect(canvas.width * settings.zoom, canvas.height * settings.zoom, GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(false));
        DrawCheckerboard(canvasRect);
        if (previewTexture != null)
        {
            GUI.DrawTexture(canvasRect, previewTexture, ScaleMode.StretchToFill, true);
        }
        if (settings.showGrid) DrawGrid(canvasRect);
        HandleCanvasInput(canvasRect);

        if (settings.tilePreview && previewTexture != null)
        {
            EditorGUILayout.Space(8);
            GUILayout.Label("Tile Preview", EditorStyles.boldLabel);
            Rect tileRect = GUILayoutUtility.GetRect(128, 128, GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(false));
            DrawTiledPreview(tileRect);
        }

        EditorGUILayout.Space(8);
        GUILayout.Label("Status: " + status, EditorStyles.helpBox);
        EditorGUILayout.EndVertical();
    }

    private void DrawRightPanel()
    {
        EditorGUILayout.BeginVertical(GUILayout.Width(320));
        scroll = EditorGUILayout.BeginScrollView(scroll);

        GUILayout.Label("Layers", EditorStyles.boldLabel);
        canvas.EnsureLayer();
        for (int i = 0; i < canvas.layers.Count; i++)
        {
            TextureLayerData layer = canvas.layers[i];
            EditorGUILayout.BeginHorizontal();
            bool selected = i == canvas.activeLayerIndex;
            if (GUILayout.Toggle(selected, layer.name, "Button")) canvas.activeLayerIndex = i;
            layer.visible = EditorGUILayout.Toggle(layer.visible, GUILayout.Width(20));
            layer.locked = EditorGUILayout.Toggle(layer.locked, GUILayout.Width(20));
            EditorGUILayout.EndHorizontal();
            layer.opacity = EditorGUILayout.Slider("Opacity", layer.opacity, 0f, 1f);
        }

        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("+ Layer")) { SaveUndo(); canvas.AddLayer("Layer " + (canvas.layers.Count + 1)); RebuildPreview(); }
        if (GUILayout.Button("- Layer")) { SaveUndo(); canvas.RemoveActiveLayer(); RebuildPreview(); }
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space(8);
        GUILayout.Label("Transforms", EditorStyles.boldLabel);
        if (GUILayout.Button("Mirror Horizontal")) { SaveUndo(); TextureBrushEngine.MirrorActiveLayer(canvas, true, false); RebuildPreview(); }
        if (GUILayout.Button("Mirror Vertical")) { SaveUndo(); TextureBrushEngine.MirrorActiveLayer(canvas, false, true); RebuildPreview(); }
        if (GUILayout.Button("Rotate 90°")) { SaveUndo(); TextureBrushEngine.RotateActiveLayer90(canvas); RebuildPreview(); }

        EditorGUILayout.Space(8);
        GUILayout.Label("Animation", EditorStyles.boldLabel);
        settings.animationEnabled = EditorGUILayout.Toggle("Animated", settings.animationEnabled);
        settings.frameCount = EditorGUILayout.IntSlider("Frame Count", settings.frameCount, 1, 64);
        settings.frameTimeTicks = EditorGUILayout.IntSlider("Frame Time", settings.frameTimeTicks, 1, 40);
        settings.generateMcmeta = EditorGUILayout.Toggle("Generate .mcmeta", settings.generateMcmeta);

        EditorGUILayout.Space(8);
        GUILayout.Label("Last Export Report", EditorStyles.boldLabel);
        EditorGUILayout.TextArea(string.IsNullOrEmpty(lastExportReport) ? "Hali export qilinmagan." : lastExportReport, GUILayout.MinHeight(130));

        EditorGUILayout.Space(8);
        GUILayout.Label("Patch 22 Roadmap", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox("Keyingi bosqichlar: texture-to-model auto-link, block/item model JSON update, lang entry update, asset browser refresh hook, Blockbench texture sync.", MessageType.Info);
        EditorGUILayout.EndScrollView();
        EditorGUILayout.EndVertical();
    }

    private void DrawFooter()
    {
        EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
        GUILayout.Label("Layer: " + canvas.activeLayerIndex + " / " + canvas.layers.Count + " | Size: " + canvas.width + "x" + canvas.height, EditorStyles.miniLabel);
        GUILayout.FlexibleSpace();
        if (GUILayout.Button("Save Settings", EditorStyles.toolbarButton, GUILayout.Width(100))) SaveSettingsSnapshot();
        EditorGUILayout.EndHorizontal();
    }

    private void DrawPaletteButtons()
    {
        if (settings.paletteColors == null) settings.paletteColors = new List<string>();
        int columns = 6;
        for (int i = 0; i < settings.paletteColors.Count; i += columns)
        {
            EditorGUILayout.BeginHorizontal();
            for (int j = 0; j < columns && i + j < settings.paletteColors.Count; j++)
            {
                Color32 color = TexturePaletteUtility.ParseColor(settings.paletteColors[i + j], new Color32(255, 255, 255, 255));
                GUI.backgroundColor = color;
                if (GUILayout.Button("", GUILayout.Width(28), GUILayout.Height(20))) primary = color;
                GUI.backgroundColor = Color.white;
            }
            EditorGUILayout.EndHorizontal();
        }
        if (GUILayout.Button("Add Primary To Palette")) settings.paletteColors.Add(TexturePaletteUtility.ToHtml(primary));
    }

    private void HandleCanvasInput(Rect rect)
    {
        Event e = Event.current;
        if (!rect.Contains(e.mousePosition)) return;

        int x = Mathf.FloorToInt((e.mousePosition.x - rect.x) / settings.zoom);
        int y = Mathf.FloorToInt((rect.yMax - e.mousePosition.y) / settings.zoom);
        Vector2Int pixel = new Vector2Int(x, y);

        if (e.type == EventType.MouseDown && e.button == 0)
        {
            SaveUndo();
            isDragging = true;
            dragStart = pixel;
            lastPixel = pixel;
            Apply(pixel, pixel);
            e.Use();
        }
        else if (e.type == EventType.MouseDrag && isDragging && e.button == 0)
        {
            if (settings.activeTool == StudioTextureToolType.Pencil || settings.activeTool == StudioTextureToolType.Eraser || settings.activeTool == StudioTextureToolType.Shade || settings.activeTool == StudioTextureToolType.Dodge || settings.activeTool == StudioTextureToolType.Noise)
            {
                TextureBrushEngine.ApplyTool(canvas, settings, lastPixel, pixel, primary, secondary);
                lastPixel = pixel;
                RebuildPreview();
            }
            e.Use();
        }
        else if (e.type == EventType.MouseUp && isDragging)
        {
            isDragging = false;
            Apply(dragStart, pixel);
            e.Use();
        }
    }

    private void Apply(Vector2Int start, Vector2Int end)
    {
        TextureBrushEngine.ApplyTool(canvas, settings, start, end, primary, secondary);
        RebuildPreview();
    }

    private void SaveUndo()
    {
        undoStack.Push(canvas);
    }

    private void Undo()
    {
        if (!undoStack.CanUndo) return;
        canvas = undoStack.Undo(canvas);
        RebuildPreview();
    }

    private void Redo()
    {
        if (!undoStack.CanRedo) return;
        canvas = undoStack.Redo(canvas);
        RebuildPreview();
    }

    private void NewCanvas()
    {
        settings.ClampValues();
        canvas = new TextureCanvasState(settings.canvasWidth, settings.canvasHeight);
        undoStack.Clear();
        RebuildPreview();
        status = "Yangi canvas yaratildi.";
    }

    private void RebuildPreview()
    {
        if (previewTexture != null) DestroyImmediate(previewTexture);
        previewTexture = canvas.ToTexture2D(FilterMode.Point);
        Repaint();
    }

    private void ExportPngManual()
    {
        string defaultName = SafeId(settings.textureId) + ".png";
        string path = EditorUtility.SaveFilePanel("Export PNG", Application.dataPath, defaultName, "png");
        if (string.IsNullOrEmpty(path)) return;
        string error;
        if (TexturePngExporter.Export(canvas, path, settings.pixelPerfectExport, out error))
        {
            if (settings.generateMcmeta) TexturePngExporter.ExportMcmeta(path, settings.frameTimeTicks, out error);
            AssetDatabase.Refresh();
            status = "Manual export qilindi: " + path;
        }
        else
        {
            status = "Export xato: " + error;
            EditorUtility.DisplayDialog("Export xato", error, "OK");
        }
    }

    private void ExportToUnityAssets()
    {
        settings.ClampValues();
        TextureWorkspaceExportReport report = TextureWorkspaceBridge.ExportToUnityAssets(canvas, settings);
        AfterExport(report);
    }

    private void ExportToMinecraftProject()
    {
        settings.ClampValues();
        TextureWorkspaceExportReport report = TextureWorkspaceBridge.ExportToMinecraftProject(canvas, settings, settings.minecraftProjectPath, GetSelectedModId());
        AfterExport(report);
    }

    private void ExportBoth()
    {
        settings.ClampValues();
        TextureWorkspaceExportReport report = TextureWorkspaceBridge.ExportBoth(canvas, settings, settings.minecraftProjectPath, GetSelectedModId());
        AfterExport(report);
    }

    private void AfterExport(TextureWorkspaceExportReport report)
    {
        SaveEditorPrefs();
        lastExportReport = report.Format();
        status = report.success ? "Workspace export muvaffaqiyatli." : "Workspace exportda xato bor.";
        AssetDatabase.Refresh();
        Debug.Log(lastExportReport);

        if (!report.success)
        {
            EditorUtility.DisplayDialog("Texture export xato", lastExportReport, "OK");
        }
        else if (settings.openFolderAfterExport && report.writtenFiles.Count > 0)
        {
            string first = report.writtenFiles[0];
            if (File.Exists(first)) EditorUtility.RevealInFinder(first);
        }
    }

    private void ImportPng()
    {
        string path = EditorUtility.OpenFilePanel("Import PNG", Application.dataPath, "png");
        if (string.IsNullOrEmpty(path)) return;
        byte[] bytes = File.ReadAllBytes(path);
        Texture2D texture = new Texture2D(2, 2, TextureFormat.RGBA32, false);
        if (!texture.LoadImage(bytes))
        {
            DestroyImmediate(texture);
            EditorUtility.DisplayDialog("Import xato", "PNG o‘qilmadi.", "OK");
            return;
        }

        SaveUndo();
        canvas = new TextureCanvasState(texture.width, texture.height);
        canvas.ActiveLayer.pixels = texture.GetPixels32();
        settings.canvasWidth = texture.width;
        settings.canvasHeight = texture.height;
        DestroyImmediate(texture);
        RebuildPreview();
        status = "PNG import qilindi: " + path;
    }

    private void BrowseMinecraftProject()
    {
        string start = string.IsNullOrWhiteSpace(settings.minecraftProjectPath) ? Directory.GetParent(Application.dataPath).FullName : settings.minecraftProjectPath;
        string path = EditorUtility.OpenFolderPanel("Minecraft Mod Project Root", start, string.Empty);
        if (string.IsNullOrEmpty(path)) return;
        settings.minecraftProjectPath = path;
        SaveEditorPrefs();
    }

    private string GetSelectedModId()
    {
        if (!string.IsNullOrWhiteSpace(settings.overrideModId)) return settings.overrideModId;
        return TextureWorkspaceBridge.GetWorkspaceModId("mymod");
    }

    private void SaveEditorPrefs()
    {
        EditorPrefs.SetString(EditorPrefsProjectPathKey, settings.minecraftProjectPath ?? string.Empty);
        EditorPrefs.SetString(EditorPrefsModIdKey, settings.overrideModId ?? string.Empty);
    }

    private void SaveSettingsSnapshot()
    {
        settings.ClampValues();
        string folder = Path.Combine(Application.dataPath, "TextureEditorSnapshots");
        Directory.CreateDirectory(folder);
        string path = Path.Combine(folder, SafeId(settings.textureId) + "_settings.json");
        File.WriteAllText(path, JsonUtility.ToJson(settings, true));
        AssetDatabase.Refresh();
        status = "Settings snapshot saqlandi: " + path;
    }

    private void DrawCheckerboard(Rect rect)
    {
        if (!settings.showCheckerboard)
        {
            EditorGUI.DrawRect(rect, Color.clear);
            return;
        }
        float cell = Mathf.Max(4, settings.zoom);
        for (float y = rect.y; y < rect.yMax; y += cell)
        {
            for (float x = rect.x; x < rect.xMax; x += cell)
            {
                bool even = (((int)((x - rect.x) / cell) + (int)((y - rect.y) / cell)) % 2) == 0;
                EditorGUI.DrawRect(new Rect(x, y, cell, cell), even ? new Color(0.34f, 0.34f, 0.34f) : new Color(0.22f, 0.22f, 0.22f));
            }
        }
    }

    private void DrawGrid(Rect rect)
    {
        Handles.BeginGUI();
        Handles.color = new Color(0f, 0f, 0f, 0.35f);
        for (int x = 0; x <= canvas.width; x++)
        {
            float px = rect.x + x * settings.zoom;
            Handles.DrawLine(new Vector3(px, rect.y), new Vector3(px, rect.yMax));
        }
        for (int y = 0; y <= canvas.height; y++)
        {
            float py = rect.y + y * settings.zoom;
            Handles.DrawLine(new Vector3(rect.x, py), new Vector3(rect.xMax, py));
        }
        Handles.EndGUI();
    }

    private void DrawTiledPreview(Rect rect)
    {
        DrawCheckerboard(rect);
        if (previewTexture == null) return;
        float tile = rect.width / 4f;
        for (int y = 0; y < 4; y++)
        {
            for (int x = 0; x < 4; x++)
            {
                GUI.DrawTexture(new Rect(rect.x + x * tile, rect.y + y * tile, tile, tile), previewTexture, ScaleMode.StretchToFill, true);
            }
        }
    }

    private static string SafeId(string value)
    {
        return TextureWorkspaceBridge.SafeId(value, "custom_texture").Replace("/", "_");
    }
}
