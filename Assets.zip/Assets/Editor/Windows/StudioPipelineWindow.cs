#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

public class StudioPipelineWindow : EditorWindow
{
    private TextField projectRootField;
    private TextField gradleTaskField;
    private TextField gradleArgsField;
    private Toggle stopOnPreflightToggle;
    private TextField outputText;

    [MenuItem("Mod Studio/Studio Pipeline Runner...")]
    public static void OpenFromModStudioMenu()
    {
        var window = GetWindow<StudioPipelineWindow>();
        window.titleContent = new GUIContent("Studio Pipeline");
        window.minSize = new Vector2(900, 620);
        window.Show();
    }

    [MenuItem("Tools/Mod Studio/Studio Pipeline Runner...")]
    public static void OpenFromToolsMenu()
    {
        OpenFromModStudioMenu();
    }

    private void CreateGUI()
    {
        rootVisualElement.style.paddingLeft = 10;
        rootVisualElement.style.paddingRight = 10;
        rootVisualElement.style.paddingTop = 10;
        rootVisualElement.style.paddingBottom = 10;

        var title = new Label("Studio Pipeline Runner / One-Click Preflight + Build");
        title.style.unityFontStyleAndWeight = FontStyle.Bold;
        title.style.fontSize = 16;
        title.style.marginBottom = 8;
        rootVisualElement.Add(title);

        var help = new Label("Bu panel Unified Binding Report, Quality Gate va Gradle build/run tasklarini bitta oqimda ishga tushiradi. Gradle loglar .modstudio/build-history ichiga yoziladi.");
        help.style.whiteSpace = WhiteSpace.Normal;
        help.style.marginBottom = 10;
        rootVisualElement.Add(help);

        var rootRow = new VisualElement();
        rootRow.style.flexDirection = FlexDirection.Row;
        rootRow.style.marginBottom = 6;
        rootVisualElement.Add(rootRow);

        projectRootField = new TextField("Project Root");
        projectRootField.style.flexGrow = 1;
        projectRootField.value = GuessProjectRoot();
        rootRow.Add(projectRootField);

        var browseBtn = new Button(BrowseProjectRoot) { text = "Browse" };
        browseBtn.style.width = 90;
        browseBtn.style.marginLeft = 6;
        rootRow.Add(browseBtn);

        var settingsRow = new VisualElement();
        settingsRow.style.flexDirection = FlexDirection.Row;
        settingsRow.style.marginBottom = 8;
        rootVisualElement.Add(settingsRow);

        gradleTaskField = new TextField("Custom Gradle Task");
        gradleTaskField.value = "build";
        gradleTaskField.style.flexGrow = 1;
        settingsRow.Add(gradleTaskField);

        gradleArgsField = new TextField("Extra Args");
        gradleArgsField.value = "";
        gradleArgsField.style.flexGrow = 1;
        gradleArgsField.style.marginLeft = 6;
        settingsRow.Add(gradleArgsField);

        stopOnPreflightToggle = new Toggle("Stop on preflight error");
        stopOnPreflightToggle.value = true;
        stopOnPreflightToggle.style.marginBottom = 8;
        rootVisualElement.Add(stopOnPreflightToggle);

        var buttons = new VisualElement();
        buttons.style.flexDirection = FlexDirection.Row;
        buttons.style.flexWrap = Wrap.Wrap;
        buttons.style.marginBottom = 8;
        rootVisualElement.Add(buttons);

        buttons.Add(MakeButton("Preflight", RunPreflight));
        buttons.Add(MakeButton("Build Jar", RunBuild));
        buttons.Add(MakeButton("Full Pipeline", RunFullPipeline));
        buttons.Add(MakeButton("Clean", delegate { RunTask("clean"); }));
        buttons.Add(MakeButton("Run Client", delegate { RunTask("runClient"); }));
        buttons.Add(MakeButton("Run Data", delegate { RunTask("runData"); }));
        buttons.Add(MakeButton("Gen Sources", delegate { RunTask("genSources"); }));
        buttons.Add(MakeButton("Run Custom Task", RunCustomTask));
        buttons.Add(MakeButton("Open Reports", OpenReports));
        buttons.Add(MakeButton("Open Build Logs", OpenBuildHistory));

        outputText = new TextField();
        outputText.multiline = true;
        outputText.isReadOnly = true;
        outputText.style.flexGrow = 1;
        outputText.style.whiteSpace = WhiteSpace.Normal;
        outputText.value = "Project root tanlang. Avval Preflight, keyin Build Jar yoki Full Pipeline bosing.";
        rootVisualElement.Add(outputText);
    }

    private Button MakeButton(string text, System.Action action)
    {
        var button = new Button(action) { text = text };
        button.style.marginRight = 6;
        button.style.marginBottom = 6;
        return button;
    }

    private void BrowseProjectRoot()
    {
        string start = Directory.Exists(projectRootField.value) ? projectRootField.value : System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
        string selected = EditorUtility.OpenFolderPanel("Minecraft Mod Project Root", start, "");
        if (!string.IsNullOrEmpty(selected)) projectRootField.value = selected;
    }

    private bool EnsureRoot()
    {
        if (!Directory.Exists(projectRootField.value))
        {
            EditorUtility.DisplayDialog("Project root noto'g'ri", "Project root topilmadi.", "OK");
            return false;
        }
        return true;
    }

    private void RunPreflight()
    {
        if (!EnsureRoot()) return;
        var report = StudioPipelineRunner.RunPreflight(projectRootField.value);
        outputText.value = report.FormatText();
        AssetDatabase.Refresh();
    }

    private void RunBuild()
    {
        if (!EnsureRoot()) return;
        var report = StudioPipelineRunner.RunGradleBuild(projectRootField.value, gradleArgsField.value);
        outputText.value = report.FormatText();
        AssetDatabase.Refresh();
    }

    private void RunFullPipeline()
    {
        if (!EnsureRoot()) return;
        var report = StudioPipelineRunner.RunFullPipeline(projectRootField.value, stopOnPreflightToggle.value, gradleArgsField.value);
        outputText.value = report.FormatText();
        AssetDatabase.Refresh();
    }

    private void RunCustomTask()
    {
        RunTask(gradleTaskField.value);
    }

    private void RunTask(string task)
    {
        if (!EnsureRoot()) return;
        if (string.IsNullOrEmpty(task)) task = "build";
        var report = StudioPipelineRunner.RunGradleTask(projectRootField.value, task, gradleArgsField.value);
        outputText.value = report.FormatText();
        AssetDatabase.Refresh();
    }

    private void OpenReports()
    {
        if (!EnsureRoot()) return;
        string path = Path.Combine(projectRootField.value, ".modstudio", "reports");
        Directory.CreateDirectory(path);
        EditorUtility.RevealInFinder(path);
    }

    private void OpenBuildHistory()
    {
        if (!EnsureRoot()) return;
        string path = Path.Combine(projectRootField.value, ".modstudio", "build-history");
        Directory.CreateDirectory(path);
        EditorUtility.RevealInFinder(path);
    }

    private string GuessProjectRoot()
    {
        try
        {
            string documents = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
            string defaultPath = Path.Combine(documents, "MinecraftMods", "MyMod");
            if (Directory.Exists(defaultPath)) return defaultPath;
        }
        catch
        {
        }
        return Application.dataPath.Replace("/Assets", "");
    }
}
#endif
