#if UNITY_EDITOR
using System;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

public static class UxmlHelpBoxCompatibilityCleaner
{
    private const string Replacement = "<ui:VisualElement class=\"compat-help-card\" style=\"margin-top: 6px; margin-bottom: 6px; padding: 8px; background-color: #2d2d30; border-left-width: 3px; border-left-color: #4aa3ff;\"><ui:Label text=\"Info: HelpBox replaced for Unity UXML compatibility.\" style=\"white-space: normal; color: #cfcfcf; font-size: 11px;\" /></ui:VisualElement>";

    [MenuItem("Mod Studio/Tools/Clean UXML HelpBox Compatibility")]
    public static void CleanAll()
    {
        string assetsPath = Application.dataPath;
        string backupRoot = Path.Combine(Path.GetDirectoryName(assetsPath) ?? string.Empty, ".modstudio", "uxml-helpbox-backups", DateTime.Now.ToString("yyyyMMdd_HHmmss"));
        Directory.CreateDirectory(backupRoot);

        int scanned = 0;
        int changed = 0;
        foreach (var file in Directory.GetFiles(assetsPath, "*.uxml", SearchOption.AllDirectories))
        {
            scanned++;
            string text = File.ReadAllText(file);
            if (!text.Contains("HelpBox")) continue;
            string old = text;
            text = ReplaceHelpBox(text);
            if (text == old) continue;

            string rel = file.Substring(assetsPath.Length).TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string backup = Path.Combine(backupRoot, rel);
            Directory.CreateDirectory(Path.GetDirectoryName(backup) ?? backupRoot);
            File.Copy(file, backup, true);
            File.WriteAllText(file, text);
            changed++;
        }

        AssetDatabase.Refresh();
        Debug.Log($"[ModStudio] UXML HelpBox cleanup complete. Scanned={scanned}, Changed={changed}, Backup={backupRoot}");
        EditorUtility.DisplayDialog("UXML HelpBox cleanup", $"Scanned: {scanned}\nChanged: {changed}\nBackup:\n{backupRoot}", "OK");
    }

    private static string ReplaceHelpBox(string text)
    {
        string[] blockPatterns =
        {
            @"<\s*uie:HelpBox\b[^>]*>.*?<\s*/\s*uie:HelpBox\s*>",
            @"<\s*UnityEditor\.UIElements\.HelpBox\b[^>]*>.*?<\s*/\s*UnityEditor\.UIElements\.HelpBox\s*>",
            @"<\s*UnityEditor\.UIElements:HelpBox\b[^>]*>.*?<\s*/\s*UnityEditor\.UIElements:HelpBox\s*>",
            @"<\s*HelpBox\b[^>]*>.*?<\s*/\s*HelpBox\s*>"
        };
        string[] singlePatterns =
        {
            @"<\s*uie:HelpBox\b[^>]*/\s*>",
            @"<\s*UnityEditor\.UIElements\.HelpBox\b[^>]*/\s*>",
            @"<\s*UnityEditor\.UIElements:HelpBox\b[^>]*/\s*>",
            @"<\s*HelpBox\b[^>]*/\s*>"
        };

        foreach (var p in blockPatterns)
            text = Regex.Replace(text, p, Replacement, RegexOptions.IgnoreCase | RegexOptions.Singleline);
        foreach (var p in singlePatterns)
            text = Regex.Replace(text, p, Replacement, RegexOptions.IgnoreCase);
        return text;
    }
}
#endif
